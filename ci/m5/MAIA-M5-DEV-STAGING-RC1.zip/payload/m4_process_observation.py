"""Bounded Toolhelp metadata for known job members; no PID process handles.

Names/parent IDs classify incidental console-host accounting only. They never
authenticate a worker, imply current liveness, or confer execution authority.
"""
import ctypes as C
from baseline_m3 import m3_windows as native

Refusal=native.Refusal
MAX_PROCESSES=4096
class PROCESSENTRY32W(C.Structure):
    _fields_=[('size',native.U32),('usage',native.U32),('pid',native.U32),
              ('heap',native.SIZE),('module',native.U32),('threads',native.U32),
              ('parent',native.U32),('priority',native.I32),('flags',native.U32),
              ('image',C.c_uint16*260)]

class _Toolhelp(native._Native):
    def __init__(self):
        super().__init__()
        self.k.CreateToolhelp32Snapshot.argtypes=[native.U32,native.U32]
        self.k.CreateToolhelp32Snapshot.restype=native.H
        for name in ('Process32FirstW','Process32NextW'):
            fn=getattr(self.k,name);fn.argtypes=[native.H,C.POINTER(PROCESSENTRY32W)];fn.restype=native.I32

def snapshot_processes(pids):
    """Inspect only explicit job IDs; a read-only global snapshot emits no others."""
    if type(pids)is not list or not 1<=len(pids)<=16 or any(type(p)is not int or not 0<p<=0xffffffff for p in pids) or len(set(pids))!=len(pids):raise Refusal('explicit bounded job PIDs required')
    if C.sizeof(native.H)!=8 or C.sizeof(PROCESSENTRY32W)!=568 or PROCESSENTRY32W.image.offset!=44:raise Refusal('Toolhelp Win64 layout')
    api=_Toolhelp();handle,error=api.call('CreateToolhelp32Snapshot',2,0)
    if not native._valid_handle(handle):raise Refusal('CreateToolhelp32Snapshot:'+str(error))
    found={};seen=set();entry=PROCESSENTRY32W();entry.size=C.sizeof(entry)
    try:
        name='Process32FirstW'
        while True:
            raw,error=api.call(name,native.H(handle),C.byref(entry))
            if raw==0:
                if error!=18:raise Refusal(name+':'+str(error))
                break
            if type(raw)is not int or entry.size!=C.sizeof(entry):raise Refusal('Toolhelp entry shape')
            pid=int(entry.pid)
            if pid in seen or len(seen)>=MAX_PROCESSES:raise Refusal('Toolhelp duplicate/count bound')
            seen.add(pid)
            if pid in pids:
                units=list(entry.image)
                if 0 not in units:raise Refusal('Toolhelp unterminated executable name')
                try:image=bytes(entry.image)[:units.index(0)*2].decode('utf-16-le','strict')
                except UnicodeError as exc:raise Refusal('Toolhelp executable encoding')from exc
                if not image or any(ord(c)<32 or c in '/\\:' for c in image):raise Refusal('Toolhelp executable basename')
                found[pid]={'pid':pid,'parent_pid':int(entry.parent),'image_name':image}
            entry.size=C.sizeof(entry);name='Process32NextW'
        if set(found)!=set(pids):raise Refusal('Toolhelp requested job member missing')
    finally:
        # UNKNOWN native calls freeze this boundary; do not retry a close then.
        if not api.frozen:api.close(handle)
    return {'processes':[found[p]for p in sorted(found)],'native_calls':list(api.calls),
            'snapshot_handle_closed':True,'scope':'PROCESS_METADATA_ONLY_NO_AUTHORITY'}
