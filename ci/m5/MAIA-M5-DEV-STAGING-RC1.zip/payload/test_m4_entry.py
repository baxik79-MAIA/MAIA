"""Portable source-import/namespace guards; no Win64 source-capsule execution."""
import importlib.util,sys,tempfile,types,unittest
from pathlib import Path
from unittest.mock import patch
import m4_entry as e
import m4_native as n

class Controls(unittest.TestCase):
 def test_unlisted_baseline_import_cannot_fall_back_to_disk(self):
  with tempfile.TemporaryDirectory()as d:
   finder=e._Buffers(Path(d),{})
   with self.assertRaises(e.Refusal):finder.find_spec('baseline_m3.unlisted')
   namespace=types.ModuleType('baseline_m3');finder.exec_module(namespace)
   self.assertEqual(namespace.__path__,[])
 def test_unlisted_root_module_found_by_pathfinder_is_refused_before_execution(self):
  with tempfile.TemporaryDirectory()as d:
   root=Path(d);(root/'test_unlisted_m4_capsule.py').write_text('raise RuntimeError("must never execute")')
   with patch.object(sys,'path',[d,*sys.path]):
    with self.assertRaises(e.Refusal):e._Buffers(root,{}).find_spec('test_unlisted_m4_capsule')
 def test_flat_baseline_alias_is_same_module_not_duplicate_classes(self):
  from baseline_m3 import m3_windows
  finder=e._Buffers(Path(__file__).parent,{'baseline_m3/m3_windows.py':b''})
  spec=finder.find_spec('m3_windows');actual=spec.loader.create_module(spec)
  self.assertIs(actual,m3_windows);self.assertIs(actual.NativeProcess,n.NativeProcess)
 def test_source_paths_reject_escape_ads_aliases(self):
  for name in ('../outside.py','a\\x.py','a:stream.py','a /x.py','a./x.py','/x.py','a//x.py'):
   with self.subTest(name=name),self.assertRaises(e.Refusal):e._relative(name)
  self.assertEqual(e._relative('worker/Run-CodexWorker.ps1'),'worker/Run-CodexWorker.ps1')
 def test_m4_mutation_namespace_does_not_admit_m3_or_production(self):
  for name in ('C:/MAIA/orchestrator/x','C:/MAIA/reports/M4_STAGING_20261108/.. /outside','C:/MAIA/reports/M3_BEGIN_20261108/x','//server/share/M4_STAGING_20261108/x','C:MAIA/reports/M4_STAGING_20261108/x'):
   with self.subTest(name=name),self.assertRaises(n.Refusal):n.fixture_root(name)

if __name__=='__main__':unittest.main()
