'use strict';
let stageLastRead=0;
const stageMode = !!document.querySelector('meta[name="maia-stage"]');
const token = document.querySelector('meta[name="maia-token"]').content;
const byId = name => document.getElementById(name);
const state = {runId:null,cursor:null,paused:false,requestInFlight:false,lastResponse:0,jobId:null,jobRunning:false,jobCommand:'',lastLogText:'',tab:'overview',agentJobId:null,agentRunning:false,agentHistory:[],agentMessage:''};
const apiHeaders = {'X-MAIA-Token':token};

function setText(id,text){const el=byId(id);if(el)el.textContent=text===null||text===undefined||text===''?'—':String(text);}
function age(x){if(x==null||!Number.isFinite(Number(x)))return 'brak danych';const n=Math.max(0,Math.round(Number(x)));if(n<60)return `${n} s temu`;if(n<3600)return `${Math.floor(n/60)} min temu`;return `${Math.floor(n/3600)} h ${Math.floor(n%3600/60)} min temu`;}
function elapsed(s){if(!s)return '—';const n=Date.parse(s);if(!Number.isFinite(n))return '—';return age((Date.now()-n)/1000);}
function localTime(iso){if(!iso)return '—';let v=new Date(iso);return Number.isFinite(v.getTime())?v.toLocaleString('pl-PL'):'—';}
function sizeFmt(n){if(!Number.isFinite(Number(n)))return '—';const v=Number(n);return v>=1024*1024?(v/(1024*1024)).toFixed(1)+' MB':v>=1024?(v/1024).toFixed(1)+' KB':v+' B';}
function processText(pid,alive,historical=false){if(!pid)return 'Nieaktywny';if(historical)return `PID ${pid} · zapis historyczny`;return `PID ${pid} · ${alive===true?'żyje':alive===false?'nie działa':'niezweryfikowany'}`;}
function stageLabel(stage,prompt){const k=(stage||prompt||'').toLowerCase();if(k.includes('requalif'))return 'Rekwalifikacja LAB';if(k.includes('architecture'))return 'Architecture Review';if(k.includes('closure'))return 'Closure / zamknięcie';return stage||'Brak aktywnego etapu';}
function showError(message){if(stageMode){stageError(message);return;}renderProjectOffline(message);byId('connection-dot').classList.add('error');setText('connection-text',message);setText('last-refresh','błąd');}
async function getJSON(path,opts={}){const {headers:extraHeaders={},...requestOptions}=opts;const response=await fetch(path,{cache:'no-store',...requestOptions,headers:{...apiHeaders,...extraHeaders}});const data=await response.json();if(!response.ok)throw new Error(data.error||`HTTP ${response.status}`);return data;}
function updateTimeline(s){let phase=0;const k=(s.current_prompt_id||s.current_stage||'').toLowerCase();if(k.includes('requalif'))phase=1;else if(k.includes('architecture'))phase=2;else if(k.includes('closure'))phase=3;for(let i=1;i<=3;i++){const el=byId(`phase-${i}`);el.classList.toggle('current',phase===i&&s.status==='ACTIVE');el.classList.toggle('past',phase>i);el.querySelector('.stage-marker').textContent=phase===i&&s.status==='ACTIVE'?'◉':phase>i?'✓':'·';}}
function renderCycleProgress(progress){
 const p=progress||{};
 setText('cycle-title',p.available?p.task:'Brak aktualnego checkpointu cyklu');
 const labels={active:'Praca',waiting:'Oczekiwanie',complete:'Zakończony',error:'Błąd'};
 setText('cycle-status',p.available?(p.stale_active?'Nieaktualny zapis aktywności':labels[p.status]||p.status):p.validation_error?'Błąd odczytu checkpointu':'Brak zapisu');
 setText('cycle-updated',p.available?`${localTime(p.updated_utc)} · ${age(p.age_seconds)}${p.stale_active?' · aktywność niepotwierdzona':''}`:p.validation_error||'—');
 setText('cycle-action',p.available?p.current_action:'—');
 setText('cycle-files',p.available&&p.changed_files.length?p.changed_files.join('\n'):'—');
 setText('cycle-check',p.available?p.check_result:'—');
 setText('cycle-next',p.available?p.next_step:'—');
 setText('cycle-blocker',p.available?p.blocker:'—');
 setText('cycle-checkpoint',p.available?p.checkpoint:'—');
}
function render(data){if(stageMode){renderStage(data);return;}renderProjectLive(data);state.lastResponse=Date.now();byId('connection-dot').classList.remove('error');setText('connection-text','Panel lokalny połączony · odczyt co 2 s');setText('last-refresh',new Date().toLocaleTimeString('pl-PL'));
 const s=data.state||{},hb=data.heartbeat||{},log=data.session_log||{},att=data.attention||'idle';
 const active=s.status==='ACTIVE',danger=att==='process_exited'||s.status==='STOP_HUMAN_REVIEW',warn=active&&(att==='no_recent_evidence'||att==='quiet');
 setText('state-name',s.status||'BRAK DANYCH');byId('state-led').className='state-led'+(danger?' danger':warn?' warn':active?' active':'');
 let subtitle='Brak aktywnego zadania';
 if(!data.source_available)subtitle='Nie znaleziono state.json — sprawdź lokalizację MAIA';
 else if(danger)subtitle=s.stop_reason||'Wymaga sprawdzenia';
 else if(active&&att==='output_live')subtitle='Nowe wpisy w SESSION.log';
 else if(active&&att==='heartbeat_live')subtitle='Heartbeat aktualny; log chwilowo cichy';
 else if(active&&att==='quiet')subtitle='Praca aktywna, ale log chwilowo bez nowych wpisów';
 else if(active&&att==='no_recent_evidence')subtitle='Brak świeżych wpisów — sprawdź etap w logu';
 else if(active)subtitle='Supervisor przetwarza zadanie';
 setText('state-subtitle',subtitle);setText('health-strip',s.status==='ACTIVE'?`Worker: ${processText(s.current_worker_pid,data.worker_alive)} · integralność: ${s.run_health||'nieznana'}`:`Brak aktywnej pracy · integralność zapisu: ${s.run_health||'—'} (nie jest to wynik misji)`);
 setText('metric-milestone',s.expected_milestone||'—');setText('metric-stage',stageLabel(s.current_stage,s.current_prompt_id));
 setText('metric-log-age',age(log.age_seconds));setText('metric-log-bytes',`${sizeFmt(log.bytes)} · ${data.displayed_run_is_current?'aktywny run':'ostatni znany run'}`);
 setText('metric-heartbeat',age(hb.age_seconds));setText('metric-heartbeat-sub',hb.at_utc?`${hb.historical?'Historyczny, nieaktywny':'Run bieżący'} · ${localTime(hb.at_utc)}${hb.historical?' · '+hb.run_id:''}`:'Nie znaleziono żadnego heartbeat.jsonl');
 setText('metric-disk',data.disk.free_gb==null?'—':`${data.disk.free_gb.toFixed(2)} GB`);setText('metric-disk-sub',`Wolne z ${data.disk.total_gb??'?'} GB`);
 setText('mission-stage',stageLabel(s.current_stage,s.current_prompt_id));setText('mission-description',active?'Trwa obecny run. Log i heartbeat są odczytywane oddzielnie.':s.status==='STOP_HUMAN_REVIEW'&&s.verdict?`Supervisor zatrzymał cykl po werdykcie: ${s.verdict}.`:danger?'Wykonywanie zatrzymane. Sprawdź formalny powód w stanie supervisora.':'Brak aktywnego runu. Wyświetlany jest zapis historyczny.');
 setText('detail-prompt',s.current_prompt_id||'—');setText('detail-supervisor',processText(s.supervisor_pid,data.supervisor_alive,data.process_ids_historical));setText('detail-worker',processText(s.current_worker_pid,data.worker_alive,data.process_ids_historical));setText('detail-started',localTime(s.started_utc));setText('detail-health',s.run_health||'—');setText('detail-queue',data.queue.length?data.queue.join(', '):'Pusta');setText('detail-branch',s.current_branch||'—');setText('detail-worktree',s.current_worktree||'—');setText('detail-rundir',data.run_dir||'—');
 renderCycleProgress(data.cycle_progress);
 setText('last-report-label',data.last_report_source==='supervisor.verdict'?'WERDYKT SUPERVISORA':'OSTATNI KOMUNIKAT WORKERA');
 setText('last-report',data.last_report);setText('log-run-label',data.displayed_run_id||'Brak runu');setText('log-size-label',sizeFmt(log.bytes));
 const diagnostic=data.closure_diagnostic||{};const incident=byId('closure-incident');
 if(incident){incident.classList.toggle('hidden',!diagnostic.parser_rejected);setText('closure-incident-reason',diagnostic.reason||'Brak szczegółów');setText('closure-incident-reported',diagnostic.reported_candidate||'Nieustalony');setText('closure-incident-source',diagnostic.candidate_source||'lokalnych zapisach');}
 const stream=byId('log-live-flag');const isFresh=active&&att==='output_live';
 setText('log-live-flag',state.paused?'PAUZA':!active?'ARCHIWUM':isFresh?'LIVE':att==='heartbeat_live'?'CISZA LOGU':att==='process_exited'?'PROCES ZAKOŃCZONY':'BRAK NOWYCH WPISÓW');
 stream.classList.toggle('paused',state.paused||!isFresh);
 updateTimeline(s);renderEvents(data.events||[]);
 if(!state.paused&&data.displayed_run_id)pollLog(data.displayed_run_id);
 if(!data.displayed_run_id&&!state.paused){state.runId=null;state.cursor=null;setText('session-log','Brak logu SESSION.log do wyświetlenia.');}
}
function renderEvents(events){const box=byId('events-list');box.replaceChildren();if(!events.length){const el=document.createElement('div');el.className='empty-events';el.textContent='Brak zdarzeń supervisora.';box.append(el);return;}
 for(const raw of [...events].reverse().slice(0,10)){const div=document.createElement('div');const classification=/FAIL|ERROR|STOP|BLOCK|INTERRUPT/i.test(raw)?'error':/START|COMPLETE|RECOVER|ENQUEUE|PASS/i.test(raw)?'ok':'';div.className='event-item '+classification;const stamp=document.createElement('div');stamp.className='event-time';stamp.textContent=raw.slice(0,27);const txt=document.createElement('div');txt.className='event-text';txt.textContent=raw.slice(27).trim()||raw;div.append(stamp,txt);box.append(div);}}
async function pollLog(run){if(state.requestInFlight)return;state.requestInFlight=true;try{if(run!==state.runId){state.runId=run;state.cursor=null;byId('session-log').textContent='';}
 let url='/api/log?run='+encodeURIComponent(run);if(state.cursor!==null)url+='&cursor='+encodeURIComponent(state.cursor);
 const data=await getJSON(url);if(run!==state.runId||state.paused)return;state.cursor=data.cursor;
 const logEl=byId('session-log'),parent=byId('console-wrap');const atBottom=parent.scrollTop+parent.clientHeight>=parent.scrollHeight-80;
 if(data.reset)logEl.textContent='';if(data.text){logEl.textContent+=data.text.replace(/\u0000/g,'');if(logEl.textContent.length>210000)logEl.textContent='[...starsze wpisy pominięte przez panel...]\n'+logEl.textContent.slice(-170000);if(atBottom)parent.scrollTop=parent.scrollHeight;}
 }catch(err){setText('log-live-flag','LOG ERROR');}finally{state.requestInFlight=false;}}
async function poll(){try{const data=await getJSON('/api/status');render(data);}catch(err){showError('Brak połączenia: '+err.message);}}
function view(tab){state.tab=tab;byId('view-overview').classList.toggle('hidden',tab!=='overview');byId('view-terminal').classList.toggle('hidden',tab!=='terminal');byId('view-operations').classList.toggle('hidden',tab!=='operations');byId('view-copilot').classList.toggle('hidden',tab!=='copilot');byId('view-chatgpt').classList.toggle('hidden',tab!=='chatgpt');for(const t of ['overview','terminal','copilot','chatgpt','operations'])byId('nav-'+t).classList.toggle('active',tab===t);if(tab==='terminal')byId('shell-command').focus();if(tab==='copilot')byId('copilot-question').focus();if(tab==='operations')pollOps(true);}
function setupNav(){for(const b of document.querySelectorAll('[data-view]'))b.addEventListener('click',()=>view(b.dataset.view));
 byId('btn-pause').addEventListener('click',()=>{state.paused=!state.paused;byId('btn-pause').textContent=state.paused?'Wznów podgląd':'Pauza podglądu';byId('log-live-flag').classList.toggle('paused',state.paused);setText('log-live-flag',state.paused?'PAUZA':'AKTUALIZACJA…');if(!state.paused)poll();});
 byId('btn-copy').addEventListener('click',async()=>{try{await navigator.clipboard.writeText(byId('session-log').textContent);setText('btn-copy','Skopiowano');setTimeout(()=>setText('btn-copy','Kopiuj log'),1500);}catch(err){setText('btn-copy','Brak dostępu do schowka');}});
}
const presets={
 status:"& powershell.exe -NoProfile -ExecutionPolicy Bypass -File 'C:\\MAIA\\orchestrator\\MAIA-Codex-Supervisor.ps1' -Action Status",
 process:"Get-CimInstance Win32_Process | Where-Object { $_.Name -in @('codex.exe','cargo.exe','rustc.exe') } | Select-Object ProcessId,ParentProcessId,Name",
 disk:"Get-PSDrive C | Select-Object Name,@{N='FreeGB';E={[math]::Round($_.Free/1GB,2)}}"
};
function setupTerminal(){for(const b of document.querySelectorAll('[data-preset]'))b.addEventListener('click',()=>{byId('shell-command').value=presets[b.dataset.preset];byId('shell-command').focus();});
 byId('shell-command').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();runTerminal();}});
 byId('btn-run').addEventListener('click',runTerminal);
 byId('btn-cancel').addEventListener('click',cancelTerminal);
}
async function runTerminal(){if(state.jobRunning)return;const command=byId('shell-command').value.trim();if(!command)return;state.jobCommand=command;state.jobRunning=true;saveTerminalCheckpoint();byId('btn-run').disabled=true;byId('btn-cancel').disabled=false;setText('terminal-state','RUNNING');byId('terminal-state').classList.remove('paused');byId('shell-output').textContent=`PS> ${command}\n\n[Uruchamianie PowerShell...]\n`;
 try{const reply=await getJSON('/api/terminal/run',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({command})});if(!reply||typeof reply.id!=='string'||!/^[a-f0-9]{12}$/.test(reply.id))throw Error('Brak poprawnego identyfikatora zadania');state.jobId=reply.id;saveTerminalCheckpoint();await pollTerminal();}catch(err){byId('shell-output').textContent+=`\nNiepewny wynik wysłania: ${err.message}\n`;uncertainTerminal();}}
async function pollTerminal(){if(!state.jobId)return;try{const data=await getJSON('/api/terminal/status?job='+encodeURIComponent(state.jobId));if(!data||data.id!==state.jobId||typeof data.done!=='boolean')throw Error('Niepoprawny receipt zadania');state.terminalSnapshot=data;state.terminalReadAt=Date.now();byId('shell-output').textContent=`PS> ${state.jobCommand}\n\n${data.output||'[Polecenie trwa, nie ma jeszcze danych wyjściowych...]'}${data.done?'\n\n[Koniec, exit code: '+data.exit_code+(data.error?' · '+data.error:'')+']':'\n\n[Wykonywanie...]'}`;byId('shell-output').scrollTop=byId('shell-output').scrollHeight;setText('shell-elapsed',`${data.elapsed_seconds} s`);if(data.done){endTerminal(data);return;}
 setTimeout(pollTerminal,800);}catch(err){byId('shell-output').textContent+='\nBłąd odczytu terminala: '+err.message;uncertainTerminal();}}
async function cancelTerminal(){if(!state.jobRunning||!state.jobId)return;byId('btn-cancel').disabled=true;try{await getJSON('/api/terminal/cancel',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:state.jobId})});}catch(err){byId('shell-output').textContent+='\nNie udało się przerwać tego procesu: '+err.message+'\n';}}
function endTerminal(data){if(MAIAProjectModel.terminalOutcome(data)==='unknown'){uncertainTerminal();return;}state.jobRunning=false;state.jobId=null;state.terminalUnknown=false;try{sessionStorage.removeItem('maia-terminal-pending');}catch(e){}byId('btn-run').disabled=false;byId('btn-cancel').disabled=true;byId('btn-recover-terminal').classList.add('hidden');const outcome=MAIAProjectModel.terminalOutcome(data);setText('terminal-state',outcome==='exit0'?'ZAKOŃCZONO · EXIT 0':outcome==='failed'?'ZAKOŃCZONO · BŁĄD':'ZAKOŃCZONO · WYNIK NIEZNANY');state.terminalLast=outcome;}
function saveTerminalCheckpoint(){try{sessionStorage.setItem('maia-terminal-pending',JSON.stringify({id:state.jobId}));}catch(e){}}
function uncertainTerminal(){state.jobRunning=true;state.terminalUnknown=true;saveTerminalCheckpoint();byId('btn-run').disabled=true;byId('btn-cancel').disabled=true;byId('btn-recover-terminal').classList.remove('hidden');byId('btn-recover-terminal').disabled=!state.jobId;setText('terminal-state','WYNIK NIEZNANY · NIE PONAWIAJ');if(!state.jobId)byId('shell-output').textContent+='\nBrak identyfikatora odpowiedzi. Sprawdź lokalne receipts/procesy przed nowym poleceniem; odświeżenie strony nie odblokuje ponowienia.\n';}
function recoverTerminal(){if(state.jobId){state.terminalUnknown=false;byId('btn-recover-terminal').classList.add('hidden');pollTerminal();}}
function addAgentBubble(role,message){
 const container=byId('copilot-messages');const node=document.createElement('div');node.className='copilot-bubble '+role;
 const label=document.createElement('div');label.className='copilot-role';label.textContent=role==='user'?'TY':role==='agent'?'ASYSTENT MAIA':'SYSTEM';
 const text=document.createElement('div');text.textContent=message;node.append(label,text);container.append(node);container.scrollTop=container.scrollHeight;return node;
}
let agentCapabilities={codex_available:false,api_available:false};
function updateAgentAvailability(){
 const provider=byId('copilot-provider').value;
 const available=provider==='codex'?agentCapabilities.codex_available:agentCapabilities.api_available;
 const status=provider==='codex'?(available?'Codex CLI wykryty · logowanie i sieć nie zostały jeszcze sprawdzone. Tryb do odczytu.':'Nie znaleziono Codex CLI. Sprawdź APPDATA\\npm\\codex.cmd.'):(available?'OpenAI API skonfigurowane na serwerze · model '+(agentCapabilities.model||'—')+'. Osobne opłaty API.':'API niedostępne — ustaw OPENAI_API_KEY przed uruchomieniem panelu.');
 const el=byId('copilot-capability');el.textContent=status;el.classList.toggle('warning',!available);
 byId('copilot-send').disabled=state.agentRunning||!available;
}
async function loadAgentCapabilities(){try{agentCapabilities=await getJSON('/api/copilot/capabilities');}catch(err){agentCapabilities={};byId('copilot-capability').textContent='Błąd sprawdzenia silników: '+err.message;}updateAgentAvailability();}
function agentBusy(value){state.agentRunning=value;byId('copilot-provider').disabled=value;byId('copilot-attach').disabled=value;byId('copilot-question').disabled=value;byId('copilot-cancel').disabled=!value;setText('copilot-state',value?'PRACUJE':'GOTOWY');updateAgentAvailability();}
async function askAgent(){
 if(state.agentRunning)return;const message=byId('copilot-question').value.trim();if(!message)return;
 const provider=byId('copilot-provider').value;const attach=byId('copilot-attach').checked;
 const history=state.agentHistory.slice(-8);
 agentBusy(true);state.agentMessage=message;addAgentBubble('user',message);byId('copilot-question').value='';
 addAgentBubble('notice','Pytanie wysłane na Twoje polecenie do '+(provider==='codex'?'Codex CLI':'OpenAI API')+'. '+(attach?'Dołączono ograniczony zestaw pól statusu MAIA.':'Nie dołączono telemetrii statusu.'));
 try{const reply=await getJSON('/api/copilot/ask',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({provider,message,history,include_status:attach})});state.agentJobId=reply.id;await pollAgent();}
 catch(err){addAgentBubble('notice','Błąd: '+err.message);agentBusy(false);}
}
async function pollAgent(){
 if(!state.agentJobId)return;
 try{const data=await getJSON('/api/copilot/status?job='+encodeURIComponent(state.agentJobId));setText('copilot-timer',`Wykonywanie: ${data.elapsed_seconds} s · ${data.log_bytes?sizeFmt(data.log_bytes)+' log · ':''}${data.progress||'czekam'} · bez automatycznych zmian`);
 if(data.done){if(data.answer){addAgentBubble('agent',data.answer);state.agentHistory.push({role:'user',content:state.agentMessage},{role:'assistant',content:data.answer});state.agentHistory=state.agentHistory.slice(-8);}else addAgentBubble('notice',data.error||'Brak odpowiedzi agenta.');state.agentJobId=null;agentBusy(false);return;}
 setTimeout(pollAgent,1000);
 }catch(err){addAgentBubble('notice','Błąd monitorowania: '+err.message);state.agentJobId=null;agentBusy(false);}
}
async function cancelAgent(){if(!state.agentJobId||!state.agentRunning)return;const job=state.agentJobId;byId('copilot-cancel').disabled=true;try{await getJSON('/api/copilot/cancel',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:job})});addAgentBubble('notice','Zgłoszono przerwanie. Dla OpenAI API żądanie sieciowe może jeszcze dobiec końca, ale jego wynik zostanie odrzucony.');}catch(err){addAgentBubble('notice','Nie można przerwać: '+err.message);}}
function setupCopilot(){byId('copilot-provider').addEventListener('change',updateAgentAvailability);byId('copilot-send').addEventListener('click',askAgent);byId('copilot-cancel').addEventListener('click',cancelAgent);byId('copilot-question').addEventListener('keydown',e=>{if(e.key==='Enter'&&(e.ctrlKey||e.metaKey)){e.preventDefault();askAgent();}});loadAgentCapabilities();}


// WebMCP registers READ-ONLY tools in the top-level page. Never proxy generic
// PowerShell or untrusted JSON commands from ChatGPT through this bridge.
function maiaToolStatus(snap){
  const s=snap.state||{},hb=snap.heartbeat||{},log=snap.session_log||{};
  return {
    source:'MAIA Mission Control / local LABtop',
    sampled_at_utc:snap.server_time_utc||null,
    supervisor_status:s.status||'UNKNOWN',
    run_health:s.run_health||'UNKNOWN',
    attention:snap.attention||'UNKNOWN',
    milestone:s.expected_milestone||null,
    stage:s.current_stage||null,
    prompt_id:s.current_prompt_id||null,
    displayed_run_id:snap.displayed_run_id||null,
    worker_alive:snap.worker_alive,
    supervisor_alive:snap.supervisor_alive,
    log_age_seconds:log.age_seconds,
    heartbeat_at_utc:hb.at_utc||null,
    heartbeat_historical:!!hb.historical,
    stop_reason:s.stop_reason||null,
    formal_verdict:s.verdict||null,
    reported_closure_candidate:(snap.closure_diagnostic||{}).reported_candidate||null,
    closure_parser_rejected:!!(snap.closure_diagnostic||{}).parser_rejected,
    queue_count:Array.isArray(snap.queue)?snap.queue.length:0,
    free_disk_gb:(snap.disk||{}).free_gb??null,
    note:'Status i reported_closure_candidate nie są równoważne formalnemu zatwierdzeniu milestone.',
  };
}
async function registerMaiaSiteTools(){
  setText('maia-local-url',location.origin==='null'?'Adres lokalnego panelu pojawi się po uruchomieniu':location.origin+'/');
  const capability=document.modelContext;
  if(!capability||typeof capability.registerTool!=='function'){
    setText('webmcp-availability','NIEDOSTĘPNE W TEJ PRZEGLĄDARCE');
    setText('webmcp-info','Ten Edge nie udostępnia WebMCP. Otwórz ten lokalny adres we wbudowanej przeglądarce ChatGPT Desktop, jeśli Site tools są dostępne dla Twojego konta i trybu.');
    return;
  }
  const emptyInput={type:'object',properties:{},additionalProperties:false};
  const tools=[
    {
      name:'maia_read_status',
      description:'Read the current local MAIA supervisor state, worker vitality, milestone, status reason, latest heartbeat and formal verdict. Read-only; never starts a pipeline or runs commands.',
      inputSchema:emptyInput, annotations:{readOnlyHint:true},
      execute:async()=>{
        if(!byId('webmcp-share-status').checked)return {ok:false,consent_required:true,reason:'Operator must enable MAIA status sharing inside Mission Control.'};
        const result=maiaToolStatus(await getJSON('/api/status'));
        if(!byId('webmcp-share-status').checked)return {ok:false,consent_required:true,reason:'Consent was withdrawn.'};
        return result;
      },
    },
    {
      name:'maia_read_events',
      description:'Read at most 10 recent MAIA controller events. Does not change local state, execute shell commands, or modify the worktree.',
      inputSchema:emptyInput, annotations:{readOnlyHint:true},
      execute:async()=>{
        if(!byId('webmcp-share-status').checked)return {ok:false,consent_required:true,reason:'Operator must enable MAIA status sharing inside Mission Control.'};
        const snap=await getJSON('/api/status');
        if(!byId('webmcp-share-status').checked)return {ok:false,consent_required:true,reason:'Consent was withdrawn.'};
        return {sampled_at_utc:snap.server_time_utc,events:(snap.events||[]).slice(-10).map(e=>String(e).slice(0,400))};
      },
    },
    {
      name:'maia_read_log_excerpt',
      description:'Read a short excerpt of the latest displayed MAIA SESSION.log ONLY when the human explicitly checks the local log-sharing consent checkbox. The log can contain proprietary code or sensitive information. No write access.',
      inputSchema:emptyInput, annotations:{readOnlyHint:true},
      execute:async()=>{
        if(!byId('webmcp-share-log').checked)return {ok:false,consent_required:true,reason:'Operator must enable the explicit log-sharing checkbox inside Mission Control.'};
        const snap=await getJSON('/api/status');
        if(!snap.displayed_run_id)return {ok:false,reason:'No run log available.'};
        // Recheck the consent after asynchronous I/O, including while changing view.
        const data=await getJSON('/api/log?run='+encodeURIComponent(snap.displayed_run_id));
        if(!byId('webmcp-share-log').checked)return {ok:false,consent_required:true,reason:'Consent was withdrawn.'};
        return {ok:true,run_id:snap.displayed_run_id,is_active:snap.state?.status==='ACTIVE',excerpt:String(data.text||'').slice(-4000)};
      },
    },
  ];
  // Tools exposed by site are additional, opt-in operator controls. They never
  // call supervisor Start/Stop, and write missions require a separate toggle.
  const taskInput={type:'object',properties:{title:{type:'string',description:'Short mission title'},instruction:{type:'string',description:'Specific task instruction'},worktree:{type:'string',description:'Exact path selected from MAIA worktree list'}},required:['title','instruction','worktree'],additionalProperties:false};
  const idInput={type:'object',properties:{id:{type:'string',description:'Mission ID from maia_read_missions'}},required:['id'],additionalProperties:false};
  tools.push({name:'maia_read_missions',description:'Read recent local MAIA Mission Control tasks and phase progress. Does not start or change anything.',inputSchema:emptyInput,annotations:{readOnlyHint:true},execute:async()=>{
    if(!byId('webmcp-ops-read').checked)return {ok:false,consent_required:true};
    const result=await getJSON('/api/missions');return byId('webmcp-ops-read').checked?result:{ok:false,consent_required:true};
  }});
  tools.push({name:'maia_read_changes',description:'Read Git status and bounded patch summary for a selected Mission Control task. Contains local code; needs permission.',inputSchema:idInput,annotations:{readOnlyHint:true},execute:async({id})=>{
    if(!byId('webmcp-ops-read').checked)return {ok:false,consent_required:true};
    const changes=await getJSON('/api/missions/changes?id='+encodeURIComponent(id));
    return byId('webmcp-ops-read').checked?{ok:true,id,status:changes.status,diff_stat:changes.diff_stat,diff_excerpt:String(changes.diff||'').slice(0,10000),note:changes.note}:{ok:false,consent_required:true};
  }});
  tools.push({name:'maia_start_inspection',description:'Start a NEW bounded read-only Codex mission inside the selected local MAIA worktree. Operator must enable AI mission delegation. This may invoke a new Codex network session but cannot edit files.',inputSchema:taskInput,annotations:{readOnlyHint:false,destructiveHint:false,openWorldHint:false},execute:async({title,instruction,worktree})=>{
    if(!byId('webmcp-ops-read').checked)return {ok:false,consent_required:true,reason:'Enable delegated inspection missions in MAIA panel.'};
    const cap=await getJSON('/api/missions/capabilities');
    if(!(cap.worktrees||[]).some(w=>w.path===worktree))return {ok:false,reason:'Choose a worktree from MAIA capabilities list.'};
    if(!byId('webmcp-ops-read').checked)return {ok:false,consent_required:true};
    return await getJSON('/api/missions/create',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({title,instruction,worktree,mode:'inspect'})});
  }});
  tools.push({name:'maia_start_worktree_mission',description:'Start a new bounded three-stage Codex mission (read-only analyze, workspace-write implement, workspace-write verify) in an operator-approved clean Git worktree. Requires the dedicated write delegation checkbox. Does not start or modify MAIA Supervisor, push, deploy, or use danger-full-access.',inputSchema:taskInput,annotations:{readOnlyHint:false,destructiveHint:true,openWorldHint:false},execute:async({title,instruction,worktree})=>{
    if(!byId('webmcp-ops-write').checked)return {ok:false,consent_required:true,reason:'Enable write mission delegation in MAIA panel.'};
    const cap=await getJSON('/api/missions/capabilities');
    if(!(cap.worktrees||[]).some(w=>w.path===worktree&&w.git))return {ok:false,reason:'Select a Git worktree from MAIA list.'};
    if(!byId('webmcp-ops-write').checked)return {ok:false,consent_required:true};
    return await getJSON('/api/missions/create',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({title,instruction,worktree,mode:'worktree-write',owner_write_approval:true})});
  }});
  tools.push({name:'maia_control_mission',description:'Pause AFTER CURRENT STAGE, resume from a completed checkpoint, or STOP a Codex process owned by the MAIA panel. Cannot control existing production supervisor. Requires operator consent.',inputSchema:{type:'object',properties:{id:{type:'string'},action:{type:'string',enum:['pause','resume','stop']}},required:['id','action'],additionalProperties:false},annotations:{readOnlyHint:false,destructiveHint:true,openWorldHint:false},execute:async({id,action})=>{
    if(!byId('webmcp-ops-control').checked)return {ok:false,consent_required:true,reason:'Mission controls disabled.'};
    return await getJSON('/api/missions/control',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id,action})});
  }});
  let count=0;
  try{
    for(const tool of tools){await capability.registerTool(tool);count++;}
    setText('webmcp-availability','NARZĘDZIA GOTOWE');
    setText('webmcp-info',`Zarejestrowano ${count} narzędzi WebMCP. Operacje i zapis wymagają osobnych zgód poniżej. Wbudowana przeglądarka ChatGPT może je odkryć, jeśli ma aktywną funkcję Site tools. Nie oznacza to automatycznego połączenia bieżącej rozmowy.`);
  }catch(error){
    setText('webmcp-availability',count?'CZĘŚCIOWO':'BRAK REJESTRACJI');
    setText('webmcp-info','Rejestracja narzędzi nie powiodła się: '+String(error.message||error));
  }
}
function setupChatGPTBridge(){
  const button=byId('btn-chatgpt-open');
  button.addEventListener('click',()=>{
    window.open('https://chatgpt.com/','_blank','noopener,popup=yes,width=840,height=920');
    // noopener prevents the signed-in external site from controlling this localhost window.
    setText('webmcp-info','Wysłano polecenie otwarcia oficjalnej strony ChatGPT. Jeśli Edge zablokował nowe okno, użyj przycisku „Otwórz w nowej karcie”.');
  });
  byId('btn-copy-panel-url').addEventListener('click',async()=>{
    try{await navigator.clipboard.writeText(location.origin+'/');setText('btn-copy-panel-url','Skopiowano');}
    catch(err){setText('webmcp-info','Nie udało się skopiować adresu. Zaznacz adres lokalny widoczny obok i skopiuj ręcznie.');}
  });
  registerMaiaSiteTools();
}
if(!stageMode)setupChatGPTBridge();

if(stageMode)setupStage();else{setupNav();setupTerminal();setupCopilot();}poll();setInterval(poll,2000);



// --- MAIA Mission Control v0.3: persistent supervised missions ---
const ops={selected:null,lastChange:0,lastLog:'',busy:false,capabilities:null,active:null,tabInitialized:false};
function opsError(msg){const el=byId('ops-error');el.textContent=msg;el.classList.remove('hidden');}
function opsClearError(){byId('ops-error').classList.add('hidden');}
function opsBadge(status){const values={RUNNING:'PRACUJE',PAUSE_REQUESTED:'PAUZA ZGŁOSZONA',PAUSED:'WSTRZYMANE',STOP_REQUESTED:'ZATRZYMYWANIE',STOPPED:'ZATRZYMANE',STOPPED_UNCERTAIN:'ZATRZYMANE · NIEPEWNY STAN',REVIEW_ACKNOWLEDGED:'PRZERWANIE ROZLICZONE',INTERRUPTED_REVIEW:'WYMAGA PRZEGLĄDU',SUCCEEDED:'ZAKOŃCZONO ETAPY',FAILED:'BŁĄD',BLOCKED:'BLOKADA'};return values[status]||status||'GOTOWY';}
async function loadOpsCapabilities(){
 try{ops.capabilities=await getJSON('/api/missions/capabilities');
 const sel=byId('ops-worktree'),before=sel.value;sel.replaceChildren();
 for(const w of ops.capabilities.worktrees||[]){const option=document.createElement('option');option.value=w.path;option.textContent=w.name+' · '+w.path+(w.git?'':' · tylko odczyt');sel.append(option);}
 const best=(ops.capabilities.worktrees||[]).find(x=>x.name==='m0168-self-correction');
 sel.value=before||(best?best.path:(ops.capabilities.worktrees||[])[0]?.path||'');
 setText('ops-create-hint',ops.capabilities.supervisor_ready===false?ops.capabilities.supervisor_block_reason:ops.capabilities.codex_available?'Codex CLI znaleziony · misje działają w osobnej sesji i zapisują logi.':'Codex CLI nie został wykryty na LABtopie.');
 }catch(err){opsError('Błąd wczytywania obszarów pracy: '+err.message);}
}
function opsShowTask(t){
 if(!t){setText('ops-state','BEZ MISJI');setText('ops-summary','Możesz uruchomić misję analityczną lub świadomie zatwierdzić zmiany w worktree.');setText('ops-activity','Brak wykonania.');setText('ops-pid','—');setText('ops-last-output','—');byId('ops-steps').replaceChildren();setText('ops-log','Oczekiwanie na misję…');setText('ops-diff','Oczekiwanie na misję…');setText('ops-log-flag','ARCHIWUM');}
 else{
 setText('ops-state',opsBadge(t.status));setText('ops-summary',t.title+' · '+t.worktree);
 setText('ops-activity',t.message||'—');setText('ops-pid',t.pid?'Agent PID '+t.pid:'Brak aktywnego procesu');
 setText('ops-last-output',t.last_output_utc?'Ostatnie wyjście: '+localTime(t.last_output_utc):'Brak wpisów z Codexa');
 const activePhase=['RUNNING','PAUSE_REQUESTED'].includes(t.status);const freshMs=t.last_output_utc?(Date.now()-Date.parse(t.last_output_utc)):Infinity;setText('ops-log-flag',!activePhase?'ARCHIWUM':freshMs<45000?'LIVE':freshMs<120000?'CISZA LOGU':'BRAK ŚWIEŻYCH WPISÓW');
 const box=byId('ops-steps');box.replaceChildren();(t.steps||[]).forEach((st,i)=>{
   const div=document.createElement('div');div.className='ops-step '+(st.status==='RUNNING'?'active':st.status==='COMPLETE'?'complete':['FAILED','BLOCKED'].includes(st.status)?'failed':'');
   const number=document.createElement('span');number.className='ops-num';number.textContent=String(i+1).padStart(2,'0');
   const body=document.createElement('div');const name=document.createElement('strong');name.textContent=st.name;const sub=document.createElement('span');sub.textContent=st.status+' · '+st.sandbox+(st.exit_code==null?'':' · exit '+st.exit_code);body.append(name,sub);div.append(number,body);box.append(div);
 });
 }
 const live=t&&['RUNNING','PAUSE_REQUESTED','STOP_REQUESTED'].includes(t.status);
 byId('ops-pause').disabled=!t||t.status!=='RUNNING';byId('ops-resume').disabled=!t||t.status!=='PAUSED';byId('ops-stop').disabled=!t||!['RUNNING','PAUSED','PAUSE_REQUESTED'].includes(t.status);byId('ops-ack').disabled=!t||!['INTERRUPTED_REVIEW','STOPPED_UNCERTAIN'].includes(t.status);
 byId('ops-start').disabled=!!ops.active||!ops.capabilities?.codex_available||ops.capabilities?.supervisor_ready===false;
}
function opsHistory(list){const box=byId('ops-history');box.replaceChildren();if(!list?.length){box.textContent='Brak historii.';return;}
 for(const t of list){const btn=document.createElement('button');btn.type='button';btn.classList.toggle('selected',ops.selected===t.id);const a=document.createElement('span');a.textContent=t.title;const b=document.createElement('span');b.textContent=opsBadge(t.status);btn.append(a,b);btn.addEventListener('click',()=>{ops.selected=t.id;ops.lastLog='';ops.lastChange=0;pollOps(true);});box.append(btn);}
}
async function pollOps(force=false){if(ops.busy&&!force)return;ops.busy=true;
 try{const snap=await getJSON('/api/missions');ops.active=snap.active;
 if(!ops.selected&&snap.recent?.length)ops.selected=snap.recent[0].id;
 const selected=(snap.recent||[]).find(t=>t.id===ops.selected)||null;
 opsShowTask(selected);opsHistory(snap.recent||[]);
 if(selected){
  const log=await getJSON('/api/missions/log?id='+encodeURIComponent(selected.id));
  const next=log.text||'Brak nowych danych…';if(force||next!==ops.lastLog){ops.lastLog=next;const out=byId('ops-log');const nearEnd=out.scrollTop+out.clientHeight>=out.scrollHeight-50;out.textContent=next;if(nearEnd)out.scrollTop=out.scrollHeight;}
  if(force||Date.now()-ops.lastChange>6000){const changes=await getJSON('/api/missions/changes?id='+encodeURIComponent(selected.id));
   ops.lastChange=Date.now();setText('ops-git-stat',(changes.diff_stat||'Brak zmian w śledzonych plikach')+(changes.diff_truncated?' · DIFF OBCIĘTY':''));setText('ops-diff',(changes.status||'Worktree czysty')+'\n\n'+(changes.diff||'Brak diff w śledzonych plikach.'));}
 }
 }catch(err){setText('ops-state','BŁĄD');opsError('Nie można odczytać misji: '+err.message);}finally{ops.busy=false;}
}
async function opsStart(){opsClearError();
 const title=byId('ops-title').value.trim(),instruction=byId('ops-instruction').value.trim(),mode=byId('ops-mode').value,worktree=byId('ops-worktree').value;
 if(!title||!instruction||!worktree){opsError('Podaj nazwę, opis zadania i wybierz obszar pracy.');return;}
 const owner_write_approval=mode==='worktree-write'&&byId('ops-write-approval').checked;
 if(mode==='worktree-write'&&!owner_write_approval){opsError('Zaznacz zgodę na automatyczne zmiany kodu w wybranym worktree.');return;}
 byId('ops-start').disabled=true;
 try{const task=await getJSON('/api/missions/create',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({title,instruction,mode,worktree,owner_write_approval})});ops.selected=task.id;ops.lastLog='';ops.lastChange=0;await pollOps(true);}
 catch(err){opsError('Nie uruchomiono misji: '+err.message);}finally{byId('ops-start').disabled=!!ops.active;}
}
async function opsControl(action){if(!ops.selected)return;
 if(action==='acknowledge'&&!window.confirm('Potwierdzasz sprawdzenie, że pierwotny agent i jego procesy zakończyły pracę? Rozliczy to przerwaną misję bez ponownego wykonywania etapu.'))return;
 if(action==='stop'&&!window.confirm('Zatrzymać TYLKO agenta uruchomionego przez Mission Control? Zmiany w trakcie wykonywania mogą pozostać częściowe; restart nie nastąpi automatycznie.'))return;
 opsClearError();try{await getJSON('/api/missions/control',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:ops.selected,action})});await pollOps(true);}
 catch(err){opsError('Nie wykonano operacji: '+err.message);}}
function setupOps(){byId('ops-start').addEventListener('click',opsStart);byId('ops-pause').addEventListener('click',()=>opsControl('pause'));byId('ops-resume').addEventListener('click',()=>opsControl('resume'));byId('ops-stop').addEventListener('click',()=>opsControl('stop'));byId('ops-ack').addEventListener('click',()=>opsControl('acknowledge'));byId('ops-refresh-diff').addEventListener('click',()=>pollOps(true));
 byId('ops-mode').addEventListener('change',()=>{const write=byId('ops-mode').value==='worktree-write';byId('ops-write-approval-wrap').classList.toggle('hidden',!write);if(!write)byId('ops-write-approval').checked=false;});
 loadOpsCapabilities();pollOps(true);setInterval(()=>{if(state.tab==='operations')pollOps();},1900);
}
if(!stageMode)setupOps();

// Read-only project presentation. No executor, scheduler, provider or native calls.
const MAIAProjectModel = (() => {
  const DAY = 86400000;
  function utcDay(value) {
    if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return NaN;
    const n = Date.parse(value + 'T00:00:00Z');
    return Number.isFinite(n) && new Date(n).toISOString().slice(0,10) === value ? n : NaN;
  }
  function validate(r) {
    if (!r || r.schema !== 1 || typeof r.revision !== 'string' || r.revision.length > 100 ||
        !Number.isFinite(Date.parse(r.updated_utc)) || !Number.isFinite(utcDay(r.target)) ||
        !Array.isArray(r.milestones) || r.milestones.length !== 6 || !Array.isArray(r.history) || r.history.length > 200) throw Error('Niepoprawny rejestr projektu');
    if (!Array.isArray(r.sources) || !r.sources.length || r.sources.some(x=>typeof x!=='string'||x.length>2000) || !Array.isArray(r.gates) || r.gates.some(x=>typeof x!=='string'||x.length>500) || typeof r.basis!=='string' || typeof r.coverage!=='string') throw Error('Brak źródeł lub ograniczeń');
    const ids = new Set();
    for (const m of [...r.milestones,...r.history]) {
      if (!m || typeof m.id !== 'string' || ids.has(m.id) || !['closed','current','pending','unconfirmed'].includes(m.status) ||
          typeof m.title !== 'string' || !m.title || m.title.length > 250 || typeof m.detail !== 'string' || m.detail.length > 2500 ||
          typeof m.evidence !== 'string' || !m.evidence || m.evidence.length > 2000) throw Error('Niepoprawny kamień milowy');
      ids.add(m.id);
      if (m.status === 'closed' && m.acceptance !== 'scoped-record') throw Error('Zamknięcie wymaga jawnego zakresu dowodu');
    }
    r.milestones.forEach((m,i) => {
      if (m.id !== 'M'+(i+1) || !Number.isFinite(utcDay(m.start)) || !Number.isFinite(utcDay(m.end)) || utcDay(m.end)<utcDay(m.start) ||
          !Array.isArray(m.depends) || m.depends.some(d => !r.milestones.slice(0,i).some(p=>p.id===d))) throw Error('Niepoprawna zależność lub termin');
    });
    if (r.milestones.filter(m=>m.status==='current').length!==1 || !r.milestones.some(m=>m.id === r.current && m.status==='current')) throw Error('Brak aktualnego etapu');
    return r;
  }
  function freshness(iso, now=Date.now(), seconds=120) {
    const t=Date.parse(iso);
    if (!Number.isFinite(t) || t>now+1000) return {fresh:false, age:null, label:'Niepotwierdzony czas'};
    const age=Math.max(0,(now-t)/1000);
    return {fresh:age<=seconds, age, label:age<=seconds?'Świeży zapis':'Zapis nieaktualny'};
  }
  function scenario(r, finish, now=Date.now()) {
    const d=utcDay(finish), baseline=utcDay(r.milestones[1].end), target=utcDay(r.target);
    if (!Number.isFinite(d) || d<utcDay(new Date(now).toISOString().slice(0,10)) || d>utcDay('2027-12-31')) return null;
    const delay=Math.max(0,Math.round((d-baseline)/DAY));
    return {date:new Date(target+delay*DAY).toISOString().slice(0,10), delay, days:Math.ceil((target+delay*DAY-now)/DAY)};
  }
  function worker(s,h,now=Date.now()) {
    if (!s || s.status!=='ACTIVE') return {level:'quiet',label:'Brak aktywnego runu Supervisora',detail:'Historyczne PID i logi nie dowodzą pracy B2 ani ChatGPT.'};
    if (s.historical || s.alive!==true || !h || h.historical || !freshness(h.at_utc,now).fresh)
      return {level:'warn',label:'Aktywność procesu niepotwierdzona',detail:'Wymagane są bieżący PID oraz świeży heartbeat tego runu.'};
    return {level:'ok',label:'Bieżący PID + świeży heartbeat',detail:'Obserwacja Supervisora; nie dowodzi postępu modelu ani zakończenia potomków.'};
  }
  function terminalOutcome(data) {
    if (!data || typeof data.done!=='boolean') return 'unknown';
    if (!data.done) return 'running';
    if (data.error || !Number.isInteger(data.exit_code)) return 'unknown';
    return data.exit_code===0?'exit0':'failed';
  }
  return {utcDay,validate,freshness,scenario,worker,terminalOutcome};
})();
if (typeof module !== 'undefined' && module.exports) module.exports=MAIAProjectModel;

/* MAIA_PROJECT_DATA_BEGIN */
const MAIA_PROJECT_DATA = {"schema":1,"revision":"mission-control-m4-plan-20261108","updated_utc":"2026-11-08T21:41:24.596407+00:00","target":"2026-11-30","current":"M4","milestones":[{"id":"M1","title":"Zakres 1.0 i decyzje","start":"2026-11-01","end":"2026-11-03","status":"closed","depends":[],"detail":"Zatwierdzone trzy kierunki projektowe i zakres M1. Operacyjny Begin/Apply, FU2/FU3 i nowy przypi\u0119ty cykl maj\u0105 osobne otwarte bramki.","acceptance":"scoped-record","evidence":"C:\\MAIA\\plans\\MAIA_1_0_NOV_2026_PLAN.md \u00b7 zakres planu; bie\u017c\u0105cy raport B2 pod C:\\MAIA","group":"Droga do 1.0"},{"id":"M2","title":"Natywna granica wykonania","start":"2026-11-04","end":"2026-11-08","status":"closed","depends":["M1"],"detail":"CLOSED_QUALIFIED_REFUSAL. 7/7 wejsc natywnej macierzy M0-M5 w23.70s; Linux/Windows261 PASS, niezalezny przeglad Gemini. Brak dowodu sekcji powoduje kontrolowana odmowe i rozliczenie O/C/W. To nie odblokowuje Git, Apply ani durability.","acceptance":"scoped-record","evidence":"C:\\MAIA\\reports\\M2_DIAGNOSTIC_HOST_20261108\\COMPONENT_REPORT.md","group":"Droga do 1.0"},{"id":"M3","title":"Trwa\u0142y Begin i recovery","start":"2026-11-09","end":"2026-11-15","status":"closed","depends":["M2"],"detail":"CLOSED_SCOPED_NATIVE_PROCESS_CRASH_QUALIFIED. Windows64/64, wejscia13/13, odmowy4/4, macierz13/13 i zimne restarty13/13. Trwaly receiver fence, potwierdzenia startu i recovery bez replay. Dotyczy izolowanego adaptera; integracja produkcyjna i utrata zasilania pozostaja osobno.","acceptance":"scoped-record","evidence":"C:\\MAIA\\reports\\M3_BEGIN_20261108\\COMPONENT_REPORT.md","group":"Droga do 1.0"},{"id":"M4","title":"Integracja staging","start":"2026-11-16","end":"2026-11-22","status":"current","depends":["M3"],"detail":"PLAN GOTOWY; kod i przebiegi M4 UNRUN. P0: kontrakt i dopuszczony profil staging. P1: rzeczywista integracja Begin/Supervisor/wykonawca/monitor. P2: dwa review i freeze. P3: normalny, przerwanie po efekcie, recovery tego samego cyklu bez replay. Budzet4-8h aktywnej pracy, warunkowy.","acceptance":"pending","evidence":"C:\\MAIA\\plans\\milestones\\M4_STAGING_PLAN_20261108.md","group":"Droga do 1.0"},{"id":"M5","title":"Release candidate","start":"2026-11-23","end":"2026-11-27","status":"pending","depends":["M4"],"detail":"Instalacja, migracja, powr\u00f3t, \u015bwie\u017ca paczka Windows/CI, ograniczenia i dok\u0142adne review RC.","acceptance":"pending","evidence":"C:\\MAIA\\plans\\MAIA_1_0_NOV_2026_PLAN.md \u00b7 zakres planu; bie\u017c\u0105cy raport B2 pod C:\\MAIA","group":"Droga do 1.0"},{"id":"M6","title":"Odbi\u00f3r MAIA 1.0","start":"2026-11-28","end":"2026-11-30","status":"pending","depends":["M5"],"detail":"GO/NO GO na podstawie dowod\u00f3w. Je\u015bli bramki pozostan\u0105 otwarte: jawny RC i nowy termin, bez etykiety pe\u0142nego 1.0.","acceptance":"pending","evidence":"C:\\MAIA\\plans\\MAIA_1_0_NOV_2026_PLAN.md \u00b7 zakres planu; bie\u017c\u0105cy raport B2 pod C:\\MAIA","group":"Droga do 1.0"}],"history":[{"id":"M0","title":"Repozytorium i przep\u0142yw pracy","status":"closed","acceptance":"scoped-record","detail":"Zamkni\u0119cie zapisane w historycznym ledgerze; zakres: Repozytorium i przep\u0142yw pracy. Nie oznacza gotowo\u015bci 1.0. Commit 121257c.","evidence":"C:\\MAIA\\repo\\docs\\project\\04_MILESTONE_LEDGER.md \u00b7 Git history","group":"Fundamenty"},{"id":"M0.0.1","title":"Kanoniczne kontrakty wykonania","status":"closed","acceptance":"scoped-record","detail":"Zamkni\u0119cie zapisane w historycznym ledgerze; zakres: Kanoniczne kontrakty wykonania. Nie oznacza gotowo\u015bci 1.0. Commit 828e19a.","evidence":"C:\\MAIA\\repo\\docs\\project\\04_MILESTONE_LEDGER.md \u00b7 Git history; historical handoff","group":"Fundamenty"},{"id":"M0.1","title":"Fundament domeny Rust","status":"closed","acceptance":"scoped-record","detail":"Zamkni\u0119cie zapisane w historycznym ledgerze; zakres: Fundament domeny Rust. Nie oznacza gotowo\u015bci 1.0. Commit 049899f.","evidence":"C:\\MAIA\\repo\\docs\\project\\04_MILESTONE_LEDGER.md \u00b7 Git history; handoff","group":"Fundamenty"},{"id":"M0.1.1","title":"Binding i autoryzacja","status":"closed","acceptance":"scoped-record","detail":"Zamkni\u0119cie zapisane w historycznym ledgerze; zakres: Binding i autoryzacja. Nie oznacza gotowo\u015bci 1.0. Commit 472ff64.","evidence":"C:\\MAIA\\repo\\docs\\project\\04_MILESTONE_LEDGER.md \u00b7 milestone-reports/M0.1.1_FINAL_REPORT.md","group":"Fundamenty"},{"id":"M0.1.2","title":"Zgodno\u015b\u0107 zatwierdzania i wykonania","status":"closed","acceptance":"scoped-record","detail":"Zamkni\u0119cie zapisane w historycznym ledgerze; zakres: Zgodno\u015b\u0107 zatwierdzania i wykonania. Nie oznacza gotowo\u015bci 1.0. Commit 8362953.","evidence":"C:\\MAIA\\repo\\docs\\project\\04_MILESTONE_LEDGER.md \u00b7 milestone-reports/M0.1.2_FINAL_REPORT.md","group":"Fundamenty"},{"id":"M0.2","title":"Polityki i orkiestracja","status":"closed","acceptance":"scoped-record","detail":"Zamkni\u0119cie zapisane w historycznym ledgerze; zakres: Polityki i orkiestracja. Nie oznacza gotowo\u015bci 1.0. Commit 97978d8.","evidence":"C:\\MAIA\\repo\\docs\\project\\04_MILESTONE_LEDGER.md \u00b7 milestone-reports/M0.2_FINAL_REPORT.md","group":"Fundamenty"},{"id":"M0.2.1","title":"Kontrakty trwa\u0142o\u015bci i audytu","status":"closed","acceptance":"scoped-record","detail":"Zamkni\u0119cie zapisane w historycznym ledgerze; zakres: Kontrakty trwa\u0142o\u015bci i audytu. Nie oznacza gotowo\u015bci 1.0. Commit d144a06.","evidence":"C:\\MAIA\\repo\\docs\\project\\04_MILESTONE_LEDGER.md \u00b7 milestone-reports/M0.2.1_FINAL_REPORT.md","group":"Fundamenty"},{"id":"M0.3","title":"Lokalny store / SQLite","status":"closed","acceptance":"scoped-record","detail":"Zamkni\u0119cie zapisane w historycznym ledgerze; zakres: Lokalny store / SQLite. Nie oznacza gotowo\u015bci 1.0. Commit db59ed8.","evidence":"C:\\MAIA\\repo\\docs\\project\\04_MILESTONE_LEDGER.md \u00b7 milestone-reports/M0.3_FINAL_REPORT.md","group":"Fundamenty"},{"id":"M0.4","title":"Transakcyjny runtime","status":"closed","acceptance":"scoped-record","detail":"Zamkni\u0119cie zapisane w historycznym ledgerze; zakres: Transakcyjny runtime. Nie oznacza gotowo\u015bci 1.0. Commit e8b9b16.","evidence":"C:\\MAIA\\repo\\docs\\project\\04_MILESTONE_LEDGER.md \u00b7 milestone-reports/M0.4_FINAL_REPORT.md","group":"Fundamenty"},{"id":"M0.5","title":"Granica wykonawcy one-shot","status":"closed","acceptance":"scoped-record","detail":"Zamkni\u0119cie zapisane w historycznym ledgerze; zakres: Granica wykonawcy one-shot. Nie oznacza gotowo\u015bci 1.0. Commit 7dc1511.","evidence":"C:\\MAIA\\repo\\docs\\project\\04_MILESTONE_LEDGER.md \u00b7 milestone-reports/M0.5_FINAL_REPORT.md","group":"Fundamenty"},{"id":"M0.8","title":"Round Table i granica dostawcy","status":"closed","acceptance":"scoped-record","detail":"Zamkni\u0119cie zapisane w historycznym ledgerze; zakres: Round Table i granica dostawcy. Nie oznacza gotowo\u015bci 1.0. Commit afe04aa.","evidence":"C:\\MAIA\\repo\\docs\\project\\04_MILESTONE_LEDGER.md \u00b7 docs/development/M0.8-live-verification-and-deskbridge.md","group":"Fundamenty"},{"id":"M0.9","title":"Routing zapewnienia i briefing","status":"closed","acceptance":"scoped-record","detail":"Zamkni\u0119cie zapisane w historycznym ledgerze; zakres: Routing zapewnienia i briefing. Nie oznacza gotowo\u015bci 1.0. Commit d81039d.","evidence":"C:\\MAIA\\repo\\docs\\project\\04_MILESTONE_LEDGER.md \u00b7 docs/development/M0.9-assurance-routing-verification.md","group":"Fundamenty"},{"id":"M0.10","title":"Briefing, trwa\u0142o\u015b\u0107 i DeskBridge","status":"closed","acceptance":"scoped-record","detail":"Zamkni\u0119cie zapisane w historycznym ledgerze; zakres: Briefing, trwa\u0142o\u015b\u0107 i DeskBridge. Nie oznacza gotowo\u015bci 1.0. Commit 8dde25c.","evidence":"C:\\MAIA\\repo\\docs\\project\\04_MILESTONE_LEDGER.md \u00b7 docs/development/M0.10-local-evidence-briefing.md","group":"Fundamenty"},{"id":"M0.15.7e","title":"Round Table: walidacja live","status":"closed","acceptance":"scoped-record","detail":"Zapisane zamkni\u0119cie live Claude Code + lokalny Ollama/Qwen. Otwarte ograniczenia containment i SessionStore pozostaj\u0105 odr\u0119bne.","evidence":"C:\\MAIA\\repo\\docs\\project\\05_CURRENT_ROADMAP.md","group":"Modele i architektura"},{"id":"M0.15.8","title":"Oddzielenie Round Table od Core","status":"closed","acceptance":"scoped-record","detail":"Zamkni\u0119cie strukturalne; zachowanie produktu bez zmiany, bez nowego wywo\u0142ania modelu.","evidence":"C:\\MAIA\\repo\\docs\\project\\05_CURRENT_ROADMAP.md","group":"Modele i architektura"},{"id":"M0.15.9","title":"Local Intelligence Runtime","status":"closed","acceptance":"scoped-record","detail":"Migracja granicy capability; nie jest dowodem jako\u015bci Qwen ani nowej pracy offline.","evidence":"C:\\MAIA\\repo\\docs\\project\\05_CURRENT_ROADMAP.md","group":"Modele i architektura"},{"id":"M0.11","title":"Desktop / Alpha 1 \u2014 osobna \u015bcie\u017cka","status":"unconfirmed","detail":"Roadmap nadal opisuje oddzielny aktywny w\u0105tek. Brak odczytanego dowodu jego ko\u0144cowego odbioru; nie oznaczono jako zamkni\u0119ty.","evidence":"C:\\MAIA\\repo\\docs\\project\\05_CURRENT_ROADMAP.md","group":"Historia do rozliczenia"},{"id":"M0.16.8","title":"Cykl Supervisora \u2014 historia operacyjna","status":"unconfirmed","detail":"Supervisor ma PIPELINE_COMPLETE, ale sam stan silnika nie jest akceptacj\u0105 milestone produktu. Historyczny log jest dost\u0119pny ni\u017cej.","evidence":"C:\\MAIA\\orchestrator\\state\\state.json","group":"Historia do rozliczenia"},{"id":"SUPPORT-20261101","title":"SUPPORT i dashboard \u2014 instalacja","status":"closed","acceptance":"scoped-record","detail":"Zainstalowane i post-validated 1 XI. Zakres SUPPORT, bez zamkni\u0119cia M2/M3; terminal NO REPLAY.","evidence":"C:\\MAIA\\reports\\R76_SUPPORT_PATCH_20261101\\backup \u00b7 R76/NATIVE_STATUS.installed_support","group":"Dostawy listopadowe"},{"id":"B2-NATIVE-20261107","title":"B2 \u2014 natywna kwalifikacja 8 przypadk\u00f3w","status":"closed","acceptance":"scoped-record","detail":"Jedna terminalna macierz: normalne T/E i 6 kontrolowanych przerwa\u0144, surowe dowody i uchwyty rozliczone. Nie jest pe\u0142nym odbiorem B2/M2 ani image-chain/Apply/durability.","evidence":"C:\\MAIA\\reports\\B2_D6_QUALIFICATION_20261106\\ADMISSION_PACKAGE_20261107\\NATIVE_DELIVERY_REPORT.md","group":"Dostawy listopadowe"}],"coverage":"M1/M2/M3 zamkniete w zapisanych zakresach. M3: izolowany Begin i recovery po przerwaniu procesu. Integracja produkcyjna, Apply i odpornosc na utrate zasilania niepotwierdzone.","sources":["C:\\MAIA\\plans\\MAIA_1_0_NOV_2026_PLAN.md","C:\\MAIA\\repo\\docs\\project\\04_MILESTONE_LEDGER.md","C:\\MAIA\\repo\\docs\\project\\05_CURRENT_ROADMAP.md","C:\\MAIA\\reports\\B2_WHOLE_COMPLETION_20261106\\CONTINUATION\\DISPOSITION.md","C:\\MAIA\\reports\\B2_D6_QUALIFICATION_20261106\\ADMISSION_PACKAGE_20261107\\NATIVE_DELIVERY_REPORT.md","C:\\MAIA\\reports\\M2_DIAGNOSTIC_HOST_20261108\\COMPONENT_REPORT.md","C:\\MAIA\\reports\\M3_BEGIN_20261108\\COMPONENT_REPORT.md","C:\\MAIA\\plans\\milestones\\M4_STAGING_PLAN_20261108.md"],"basis":"M3: 64 kontrole, 13 wejsc, 4 odmowy, 13 scenariuszy awarii + 13 zimnych restartow PASS.","gates":["M3: kwalifikacja izolowanego Begin po awarii procesu zakonczona","M4: osobny pakiet integracji staging","Obraz / Apply / globalna durability / readiness: false"]};
/* MAIA_PROJECT_DATA_END */
// Project registry is published as inert JSON inside this existing static asset.
// Reading this block never executes downloaded code or grants execution authority.
let projectRegistry=null, projectFilter='all', projectSelected='M2', projectSnapshot=null, projectLastRead=0, projectTransportError=false;
const projectLabels={closed:'Zamknięty zakres',current:'W toku · bramki otwarte',pending:'Do wykonania',unconfirmed:'Odbiór niepotwierdzony'};
function pNode(tag, cls, text){const n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n;}
function pDate(s){return new Date(s+'T12:00:00Z').toLocaleDateString('pl-PL',{day:'numeric',month:'short',year:'numeric',timeZone:'Europe/Warsaw'});}
function projectPick(id){projectSelected=id;const m=projectRegistry.milestones.find(x=>x.id===id);if(!m)return;const box=byId('project-selected');box.replaceChildren(pNode('strong','',m.id+' / '+m.title),pNode('p','',m.detail));const dep=m.depends.length?'Wymaga odbioru: '+m.depends.join(', '):'Zakres projektowy zatwierdzony; operacyjne zgody są oddzielne.';box.append(pNode('small','',dep));for(const b of document.querySelectorAll('[data-project-id]'))b.setAttribute('aria-pressed',String(b.dataset.projectId===id));}
function renderProjectRegistry(r){
 projectRegistry=MAIAProjectModel.validate(r);
 setText('project-current-chip','TERAZ: '+r.current+(r.current==='M2'?' → B2':''));setText('project-risk-label','Termin warunkowy · '+r.current+' i zależne bramki otwarte');setText('project-basis',r.basis);setText('project-coverage',r.coverage);setText('project-updated','Stan projektu według dowodów z '+localTime(r.updated_utc)+'. Odczyt odświeża dane, nie wykonuje ponownie testów.');setText('project-sources',r.sources.join('\n'));
 const graph=byId('project-graph');graph.replaceChildren();
 for(const m of r.milestones){const li=pNode('li','project-node '+m.status);const b=pNode('button','');b.type='button';b.dataset.projectId=m.id;b.setAttribute('aria-pressed',String(m.id===projectSelected));b.append(pNode('span','project-node-id',m.id),pNode('strong','',m.title),pNode('span','project-node-status',projectLabels[m.status]),pNode('small','',pDate(m.start)+' → '+pDate(m.end)));b.addEventListener('click',()=>projectPick(m.id));li.append(b);graph.append(li);}
 projectPick(projectSelected);const gates=byId('project-gates');gates.replaceChildren(...r.gates.map(x=>pNode('span','',x)));
 const closed=r.milestones.filter(x=>x.status==='closed').length;setText('project-counts',closed+' / 6 zakresów M1–M6 odebrane · nie % gotowości');
 renderProjectHistory();renderProjectCalendar();renderProjectScenario();projectTick();
}
function renderProjectHistory(){if(!projectRegistry)return;const query=byId('project-search').value.trim().toLocaleLowerCase('pl');const box=byId('project-history-list');box.replaceChildren();const all=[...projectRegistry.milestones,...projectRegistry.history];const visible=all.filter(x=>(projectFilter==='all'||projectFilter==='open'&&['current','pending'].includes(x.status)||x.status===projectFilter)&&(!query||[x.id,x.title,x.detail].join(' ').toLocaleLowerCase('pl').includes(query)));
 for(const m of visible){const d=pNode('details','project-history-row '+m.status),s=pNode('summary','');s.append(pNode('span','history-id',m.id),pNode('strong','',m.title),pNode('span','history-state',projectLabels[m.status]));d.append(s,pNode('p','',m.detail),pNode('small','',m.group+' · Źródło: '+m.evidence));box.append(d);}
 if(!visible.length)box.append(pNode('p','project-muted','Brak wpisów dla tego filtra.'));
}
function renderProjectCalendar(){if(!projectRegistry)return;const svg=byId('project-calendar');svg.replaceChildren();const NS='http://www.w3.org/2000/svg';const add=(t,a,txt)=>{const n=document.createElementNS(NS,t);for(const [k,v] of Object.entries(a))n.setAttribute(k,String(v));if(txt)n.textContent=txt;svg.append(n);return n;};
 const start=MAIAProjectModel.utcDay('2026-11-01'),day=86400000,x=d=>140+(d-start)/day*25.5;
 add('title',{},'Plan listopadowy: M1–M6. Zielony to odebrany zakres, turkusowy to bieżący etap, szary to plan zależny.');
 for(const d of [1,4,8,15,22,27,30]){const xx=x(MAIAProjectModel.utcDay('2026-11-'+String(d).padStart(2,'0')));add('line',{x1:xx,x2:xx,y1:25,y2:247,class:'calendar-grid'});add('text',{x:xx,y:16,'text-anchor':'middle',class:'calendar-label'},d+' XI');}
 projectRegistry.milestones.forEach((m,i)=>{const y=38+i*34;add('text',{x:14,y:y+17,class:'calendar-name'},m.id+' / '+(i===0?'zakres':i===1?'native':i===2?'Begin':i===3?'staging':i===4?'RC':'wydanie'));add('rect',{x:x(MAIAProjectModel.utcDay(m.start)),y,width:(MAIAProjectModel.utcDay(m.end)-MAIAProjectModel.utcDay(m.start))/day*25.5+24,height:24,rx:5,class:'calendar-bar '+m.status});});
 const now=Date.now();if(now>=start&&now<MAIAProjectModel.utcDay('2026-12-01')){const xx=x(now);add('line',{x1:xx,x2:xx,y1:22,y2:247,class:'calendar-now'});add('text',{x:Math.min(895,xx+7),y:265,class:'calendar-now-label'},'TERAZ');}
}
function renderProjectScenario(){if(!projectRegistry)return;const v=MAIAProjectModel.scenario(projectRegistry,byId('project-m2-date').value);setText('project-forecast',v?'Scenariusz 1.0: '+pDate(v.date)+(v.delay?' · +'+v.delay+' dni względem celu':' · bez zapasu czasu'):'Wybierz datę nie wcześniejszą niż dziś.');}
function renderProjectLive(data){projectSnapshot=data;projectLastRead=Date.now();projectTransportError=false;projectTick();}
function renderProjectOffline(message){projectTransportError=true;setText('project-local','Utrata połączenia z panelem');setText('project-local-detail',message+'. Ostatni odczyt nie dowodzi bieżącej aktywności.');byId('project-local').parentElement.dataset.level='warn';}
function projectTick(){if(!byId('project-local'))return;if(typeof activityTick==='function')activityTick();const now=Date.now(),live=!projectTransportError&&projectLastRead&&now-projectLastRead<=6500;
 if(live){setText('project-local','Serwer odpowiada');setText('project-local-detail','Ostatnia odpowiedź '+age((now-projectLastRead)/1000)+'. To połączenie przeglądarki z localhost, nie z modelem.');byId('project-local').parentElement.dataset.level='ok';}
 else if(projectLastRead){setText('project-local','Brak świeżej odpowiedzi');setText('project-local-detail','Ostatni odczyt '+age((now-projectLastRead)/1000)+'. Stan procesów jest teraz niepotwierdzony.');byId('project-local').parentElement.dataset.level='warn';}
 const data=projectSnapshot||{},p=data.cycle_progress||{},fresh=p.available&&MAIAProjectModel.freshness(p.updated_utc,now).fresh;
 setText('project-contact',fresh?(p.status==='complete'?'Ostatni pakiet rozliczony':p.status==='waiting'?'Oczekiwanie według checkpointu':p.status==='error'?'Checkpoint zgłasza błąd':'Świeży checkpoint czynności'):'Brak świeżego checkpointu');
 setText('project-contact-detail',p.available?(p.current_action+' · '+elapsed(p.updated_utc)+(fresh?' · nie jest heartbeat modelu.':' · obecna praca ChatGPT niepotwierdzona.')):'Brak poprawnego zapisu czynności operatora.');byId('project-contact').parentElement.dataset.level=fresh?'quiet':'warn';
 const w=MAIAProjectModel.worker({...data.state,alive:data.worker_alive,historical:data.process_ids_historical},data.heartbeat,now);
 let label=w.label,detail=w.detail,level=w.level;
 if(state.jobRunning){const t=state.terminalSnapshot,ageMs=now-(state.terminalReadAt||0);label=state.terminalUnknown||!live||t&&ageMs>6500?'Wynik polecenia niepotwierdzony':t&&t.pid?'PowerShell · PID '+t.pid:'Oczekiwanie na identyfikator procesu';detail=state.jobId?'Zadanie '+state.jobId+' · wynik tylko z jego odpowiedzi. Utrata odczytu nie uruchamia ponowienia.':'Brak potwierdzenia odpowiedzi; nie wysyłaj drugi raz.';level=label.includes('niepotwierdzony')?'warn':'quiet';}
 else if(!live){label='Bieżący stan niepotwierdzony';detail='Brak świeżego odczytu. Historyczny stan nie oznacza ani pracy, ani zatrzymania.';level='warn';}
 setText('project-worker',label);setText('project-worker-detail',detail);byId('project-worker').parentElement.dataset.level=level;
 if(projectRegistry){const days=Math.ceil((MAIAProjectModel.utcDay(projectRegistry.target)+86400000-now)/86400000);setText('project-days',days>0?days+' dni do końca okna wydania':'Cel planu minął — potrzebne rozliczenie');setText('project-today',new Date(now).toLocaleDateString('pl-PL',{timeZone:'Europe/Warsaw',day:'numeric',month:'long'}));}
}
async function refreshProjectRegistry(){try{const response=await fetch('/app.js?project-registry=1',{cache:'no-store'});if(!response.ok)throw Error('HTTP '+response.status);const text=await response.text();if(typeof activityLoadText==='function')activityLoadText(text);if(text.length>500000)throw Error('Zbyt duży rejestr');const match=text.match(/\/\* MAIA_PROJECT_DATA_BEGIN \*\/\s*const MAIA_PROJECT_DATA = (.*?)\s*;\s*\/\* MAIA_PROJECT_DATA_END \*\//s);if(!match)throw Error('Brak rejestru');const r=MAIAProjectModel.validate(JSON.parse(match[1]));if(JSON.stringify(r)!==JSON.stringify(projectRegistry))renderProjectRegistry(r);}catch(e){setText('project-updated','Nie udało się odświeżyć mapy: '+e.message+'. Pokazujemy ostatni odebrany zapis.');}}
function setupProject(){renderProjectRegistry(MAIA_PROJECT_DATA);for(const b of document.querySelectorAll('[data-project-filter]'))b.addEventListener('click',()=>{projectFilter=b.dataset.projectFilter;for(const x of document.querySelectorAll('[data-project-filter]'))x.setAttribute('aria-pressed',String(x===b));renderProjectHistory();});byId('project-search').addEventListener('input',renderProjectHistory);byId('project-m2-date').min=new Date().toISOString().slice(0,10);if(byId('project-m2-date').value<byId('project-m2-date').min)byId('project-m2-date').value=byId('project-m2-date').min;renderProjectScenario();byId('project-m2-date').addEventListener('input',renderProjectScenario);byId('btn-recover-terminal').addEventListener('click',recoverTerminal);
 try{const saved=JSON.parse(sessionStorage.getItem('maia-terminal-pending')||'null');if(saved){state.jobId=typeof saved.id==='string'&&/^[a-f0-9]{12}$/.test(saved.id)?saved.id:null;state.jobCommand='[Polecenie sprzed odświeżenia — wynik z serwera]';uncertainTerminal();if(state.jobId)recoverTerminal();}}catch(e){}setInterval(projectTick,1000);setInterval(refreshProjectRegistry,30000);}
if(!stageMode)setupProject();

// Observation data only. Never starts a tool or infers model liveness.
const MAIAActivityModel=(()=>{
 const environments={workspace:'Kod i testy · środowisko robocze',browser:'Przeglądarka · Edge',review:'Recenzje · Claude / Gemini',windows:'Walidacja · Windows',powershell:'Polecenia · PowerShell'};
 function validate(data){
  if(!data||data.schema!==1||!Array.isArray(data.events)||data.events.length>40)throw Error('Niepoprawny dziennik czynności');
  const seen=new Set();
  for(const e of data.events){
   if(!e||typeof e.id!=='string'||!/^[a-z0-9-]{1,100}$/.test(e.id)||seen.has(e.id)||!Object.hasOwn(environments,e.environment)||!['working','waiting','done','blocked'].includes(e.status)||!Number.isFinite(Date.parse(e.at_utc)))throw Error('Niepoprawny wpis czynności');
   seen.add(e.id);
   for(const [k,max] of [['tool',100],['action',1200],['result',1200],['next',1200],['blocker',1200],['evidence',1000]])if(typeof e[k]!=='string'||e[k].length>max)throw Error('Niepoprawne pole czynności');
   if(!e.action.trim()||!e.tool.trim())throw Error('Brak czynności');
  }
  for(let i=1;i<data.events.length;i++)if(Date.parse(data.events[i].at_utc)<Date.parse(data.events[i-1].at_utc))throw Error('Odwrócona kolejność dziennika');
  return data;
 }
 function view(data,{now=Date.now(),serverFresh=false,cycle=null}={}){
  const last=data.events.at(-1)||null,t=last?Date.parse(last.at_utc):NaN;
  const valid=Number.isFinite(t)&&t<=now+1000,age=valid?Math.max(0,(now-t)/1000):null;
  const superseded=cycle?.available&&last&&Date.parse(cycle.updated_utc)>t&&cycle.cycle_id!==last.id;
  const fresh=serverFresh&&valid&&age<=120&&!superseded;
  return {last,age,fresh,superseded,label:!last?'Brak wpisu czynności':!valid?'Czas wpisu niepotwierdzony':!serverFresh?'Brak kontaktu z panelem':superseded?'Nowszy checkpoint poza dziennikiem':!fresh?'Brak świeżego potwierdzenia':last.status==='done'?'Ostatni krok zakończony':last.status==='blocked'?'Zgłoszona blokada':last.status==='waiting'?'Zgłoszone oczekiwanie':'Świeży zapis wykonywanej czynności',environments};
 }
 return {validate,view,environments};
})();
if(typeof module!=='undefined'&&module.exports)module.exports=MAIAActivityModel;

/* MAIA_ACTIVITY_DATA_BEGIN */
const MAIA_ACTIVITY_DATA = {"schema":1,"events":[{"id":"activity-install-cc1819fd2a4145fe953c22f7959e032f","at_utc":"2026-11-07T00:28:38Z","environment":"windows","tool":"Mission Control / walidacja Windows","action":"Wdro\u017cono wsp\u00f3lny podgl\u0105d prac. Trwa sprawdzenie widoku w Edge.","status":"working","result":"Nowe kontrole: Node9/9 i Python5/5. Backend bez zmian; B2 native nie uruchomiono.","next":"Ocena wizualna i zapis wyniku wdro\u017cenia.","blocker":"B2 pozostaje OPEN; widok nie jest dopuszczeniem native.","evidence":"C:\\MAIA\\reports\\MISSION_CONTROL_WORK_ACTIVITY_20261107\\RECOVERY_UTF8\\RESULT.json"},{"environment":"workspace","tool":"Kod i testy / \u015brodowisko robocze","action":"Zintegrowano okno podgl\u0105du z istniej\u0105c\u0105 map\u0105 projektu i poprawiono start ca\u0142ego widoku.","status":"done","result":"Nowy test rzeczywistej kolejno\u015bci startu oraz komplet kontroli Node: 10/10 lokalnie i Windows. Python publisher: 5/5 Windows.","next":"Odczyt istniej\u0105cych recenzji B2 i weryfikacja dziennika w Edge.","blocker":"Pr\u00f3ba native B2 nadal UNRUN.","evidence":"C:\\MAIA\\reports\\MISSION_CONTROL_WORK_ACTIVITY_20261107\\STARTUP_CORRECTION\\RESULT.json","id":"activity-bdbb08ecbf644e5eb2f7366b63eb0b5f","at_utc":"2026-11-07T00:32:57Z"},{"environment":"review","tool":"Claude i Gemini / Edge","action":"Odczytano istniej\u0105ce ko\u0144cowe recenzje materialnej delty B2 bez ponownego wysy\u0142ania.","status":"done","result":"Obie odpowiedzi s\u0105 finalne. Wskazuj\u0105 rozliczenie wcze\u015bniejszych findings w zakresie statycznym; nadal potrzebne rzeczywiste dopuszczenie i obserwacje Windows/native.","next":"Zachowanie surowych recenzji w C:\\MAIA i doko\u0144czenie przerwanego transferu kandydata B2.","blocker":"Recenzja nie jest dowodem wykonania ani zamkni\u0119ciem B2.","evidence":"C:\\MAIA\\reports\\B2_D6_QUALIFICATION_20261106","id":"activity-0e71b3ec730141789a15cc6e9cb70736","at_utc":"2026-11-07T00:35:41Z"},{"environment":"powershell","tool":"PowerShell / zapis dowod\u00f3w","action":"Zapisano orygina\u0142y wdro\u017cenia i odebranych recenzji B2 pod C:\\MAIA.","status":"done","result":"Raport i cztery pliki recenzji maj\u0105 zweryfikowane bajty i hashe; preserved preimages oraz receipts nieudanych etap\u00f3w.","next":"Odbi\u00f3r okna podgl\u0105du i kontynuacja B2 od zapisanego punktu.","blocker":"Macierz native/D6 pozostaje UNRUN.","evidence":"C:\\MAIA\\reports\\MISSION_CONTROL_WORK_ACTIVITY_20261107\\REPORT.md","id":"activity-803cd7a2c31e4974adf97e3e7bf5778d","at_utc":"2026-11-07T00:40:46Z"},{"environment":"browser","tool":"Edge / kontrola Mission Control","action":"Sprawdzono okno \u201eCo dzieje si\u0119 teraz?\u201d, histori\u0119 oraz aktualizacj\u0119 wpis\u00f3w bez ponownego uruchamiania prac.","status":"done","result":"Monitor odpowiada; wida\u0107 czynno\u015bci z kodu, recenzji, Windows i PowerShell. Stary wpis traci \u015bwie\u017co\u015b\u0107. Ostatni krok jest rozliczony.","next":"B2: \u015bwie\u017cy odczyt prefixu transferu, zako\u0144czenie zapisu kandydata, jedna walidacja Windows zmienionych bajt\u00f3w i rozliczenie dopuszczenia.","blocker":"B2 jeszcze otwarte. Brak aktywnej pr\u00f3by native w tle.","evidence":"C:\\MAIA\\reports\\MISSION_CONTROL_WORK_ACTIVITY_20261107\\REPORT.md","id":"activity-c4b719da0961449f994dc4ff9f95b924","at_utc":"2026-11-07T00:40:46Z"},{"id":"activity-cc923d5141c049638b038b02bc93ba6e","at_utc":"2026-11-07T00:59:47Z","environment":"windows","tool":"Codex CLI / Mission Control","action":"Przygotowanie ciaglosci duzych misji: sesja, wyniki, limity i zapis stanu.","status":"working","result":"CLI 0.160.1; logowanie ChatGPT potwierdzone; dwa historyczne zadania SUCCEEDED. Nowy agent nie zostal uruchomiony.","next":"Walidacja protokolu i jednego kandydata integracji.","blocker":"Supervisor PIPELINE_COMPLETE blokuje start nowej misji. Bramka pozostaje bez zmian.","evidence":"C:\\MAIA\\reports\\MISSION_CONTROL_AUTONOMY_20261107"},{"id":"activity-90b14e7290f4489cb3a6163cf590087f","at_utc":"2026-11-07T01:33:40Z","environment":"workspace","tool":"Mission Control / Codex exec resume","action":"Uproszczono kontynuacje duzych misji do oficjalnego CLI i przypietego ID rozmowy.","status":"working","result":"Handshake konta PASS bez modelu; prototyp niewdrozony po recenzji. Zbudowano kandydata CLI, zachowano bramke Supervisor.","next":"Kontrole awarii, pause/resume i odbior dokladnego kandydata CLI.","blocker":"Nowa misja pozostaje zablokowana przy PIPELINE_COMPLETE.","evidence":"C:\\MAIA\\reports\\MISSION_CONTROL_AUTONOMY_20261107"},{"id":"activity-cfb37e63b3d645088c3672bc23234212","at_utc":"2026-11-07T02:58:08Z","environment":"review","tool":"Codex exec/resume + source review","action":"Walidacja calej kontynuacji misji i niezalezne recenzje aktualnego kodu.","result":"32/32 kontroli Windows; preflight konta/config PASS; zero uruchomionych misji modelu, 0 PLN nowych wydatkow. Kandydat niezainstalowany.","next":"Rozliczyc kontrprzyklady przerwan, terminow, odzyskania wlasciciela i Copilot interlock jednym kandydatem.","blocker":"Aktywacja wymaga operacyjnego przyjecia: Supervisor PIPELINE_COMPLETE nadal odmawia; brak pilota modelu.","evidence":"C:\\MAIA\\reports\\MISSION_CONTROL_AUTONOMY_20261107\\CURRENT_RESULT.json","status":"working"},{"id":"activity-ac5e1df4740e4d6abe1e005098a9e1b2","at_utc":"2026-11-07T03:55:36Z","environment":"review","tool":"Missions continuation - grouped source delta","action":"Zintegrowano odzyskanie wlasciciela, checkpointy, przypiete PID-y i odczyty Git.","result":"57/57 Windows controls; zero lokalnych misji modelu; kandydat niezainstalowany. Poprzedni live preflight PASS dotyczy niezmienionego guardu kosztow.","next":"Odczytac final recenzji dokladnej delty, rozliczyc ograniczenia i przygotowac przyjecie/pilot.","blocker":"Brak przyjecia operacyjnego i rzeczywistego pilota exec/resume; Supervisor PIPELINE_COMPLETE nadal odmawia. Nie ma wykonawcy dzialajacego w tle.","evidence":"C:\\MAIA\\reports\\MISSION_CONTROL_AUTONOMY_20261107\\CURRENT_RESULT.json","status":"waiting"},{"id":"activity-1577932b94f247338be23d1ee43cb209","at_utc":"2026-11-07T04:59:36Z","environment":"windows","tool":"Mission Control continuation / Windows fixtures","action":"Zapisano spojny kandydat: jedna cala dostawa w sesji Codexa, przerwania i receipts.","status":"blocked","result":"68/68 Windows fixture controls OK; 2 realne readonly tury CLI zakonczone. Dokladna delta recenzji odebrana. Kandydat NIEZAINSTALOWANY.","next":"Kwalifikacja izolacji zapisu i limitow podczas sesji oraz nowy przypiety cykl operacyjny przed pilotem.","blocker":"Supervisor PIPELINE_COMPLETE blokuje Missions; automatyzacja PAUSED. Otwarte PID reuse identity, quota-in-turn i rzeczywisty write pilot. Brak aktywnego worker claim.","evidence":"C:\\MAIA\\reports\\MISSION_CONTROL_AUTONOMY_20261107\\WHOLE_DELIVERY_FINAL_REPORT.md"},{"id":"activity-8499400836e0484fb3497ad70fd2e93b","at_utc":"2026-11-07T08:15:02Z","environment":"windows","tool":"B2 / Windows pure + R76 recovery","action":"B2: dokonczono zrodlo64 i jednorazowa walidacje Windows358; zapisano wspolny R76v82.","status":"waiting","result":"358/358 bez bledow/pominiec; PID3440 exit0, termination_confirmed. Raw receipts i recenzje odebrane, R76v82 zapisany. B2 NADAL OTWARTE.","next":"Dokladne dopuszczenie input/capsule/review/outer command przed pierwsza natywna macierza C/D/O/W i D6.","blocker":"Native8rows UNRESERVED/UNRUN; image-chain/TOCTOU i D6 nieudowodnione. Automatyzacja niezainstalowana/PAUSED. Brak aktywnego worker claim.","evidence":"C:\\MAIA\\reports\\MAIA_CONTINUATION_20261107\\REPORT.md"},{"id":"b2-admission-df7497e1e68342f094e084dd6ed58eff","at_utc":"2026-11-07T08:49:45.824294+00:00","environment":"windows","tool":"B2 / przygotowanie calej macierzy","action":"Przygotowano 7 pakietow / 8 przypadkow i zweryfikowano pliki LABtopa.","status":"waiting","result":"64+54 pliki zrodla, 8 runtime, OS19045.7807 i nazwy eksportow zgodne. Kontrola wszystkich 8 rezerwacji: UNCONSUMED. Native nieuruchomione.","next":"Recenzja dokladnego admission/capsule/outer command wyslana osobno Claude i Gemini; po rzeczywistych bramkach jedna macierz.","blocker":"Oczekiwanie na finalne recenzje. B2 OPEN; readiness/Apply/durability FALSE. Brak aktywnego native worker claim.","evidence":"C:\\MAIA\\reports\\B2_D6_QUALIFICATION_20261106\\ADMISSION_PACKAGE_20261107\\PREPARE_RESULT.json"},{"id":"b2-native-qualified-20261107","at_utc":"2026-11-07T09:09:24.647289+00:00","environment":"windows","tool":"B2 / natywna kwalifikacja","action":"Zakonczono i rozliczono jednorazowa macierz: normalne T/E i 6 kontrolowanych przerwan.","status":"done","result":"8 przypadkow przyjetych; 7 procesow W exit0 i potwierdzony koniec. Surowe dowody i uchwyty rozliczone. T_PRE pozostaje PRE_EXIT_INCONCLUSIVE; nie twierdzimy unikalnej przyczyny.","next":"Nastepny spojny blok: Git/image-chain/TOCTOU/refusal z osobnymi przypietymi bramkami. B2 pelny odbior i M2 nadal otwarte.","blocker":"Image-chain/TOCTOU, Apply i durability nadal FALSE. Brak aktywnego worker claim; zadna z 8 prob nie moze byc ponowiona.","evidence":"C:\\MAIA\\reports\\B2_D6_QUALIFICATION_20261106\\ADMISSION_PACKAGE_20261107\\NATIVE_DELIVERY_REPORT.md"},{"id":"b2-native-checkpoint-20261107","at_utc":"2026-11-07T09:17:33.816897+00:00","environment":"windows","tool":"B2 / wynik natywny i wspolny checkpoint","action":"Rozliczono native8 i zapisano wspolny R76v83 z surowymi dowodami.","status":"done","result":"Normalne T/E + 6 kontrolowanych przerwan: 7 procesow W exit0, koniec potwierdzony; raport i oryginaly w C:\\MAIA. R76v83 i manifest nie sa odbiorem B2/M2.","next":"Pelny odbior B2/M2: spojny blok Git/image-chain/TOCTOU/refusal z przypietymi bramkami. Nie ponawiac 8 terminalnych prob.","blocker":"Image-chain/TOCTOU, Apply, durability i ogolne native_run_ready nadal FALSE. Brak aktywnego worker/background claim. M2 do8XI nadal zagrozone.","evidence":"C:\\MAIA\\reports\\B2_D6_QUALIFICATION_20261106\\ADMISSION_PACKAGE_20261107\\R76_WRITEBACK_NATIVE_RESULT.json"},{"id":"m2-coding-review-20261107","at_utc":"2026-11-07T09:49:58.051857+00:00","environment":"review","tool":"Claude web / Gemini web / Codex","action":"Kod i testy grafu obrazow w istniejacym collectorze; niezalezna analiza kontraktu.","status":"working","result":"Claude pisze i testuje kod; Gemini zakonczyl analize. Dwa dokladne wejscia zapisane w C:\\MAIA. Native B2 nie jest ponawiany.","next":"Weryfikacja kodu, kontrprzykladow i testow; bezpieczna aktualizacja GitHub.","blocker":"","evidence":"C:\\MAIA\\worktrees\\M2_IMAGE_CHAIN_20261107"},{"id":"m2-graph-delivery-20261107","at_utc":"2026-11-07T10:13:15.836674+00:00","environment":"windows","tool":"Claude / Gemini / Codex / Python","action":"Domknieto komponent deklaracji grafu obrazow M2.","status":"done","result":"25 Linux i jednorazowo25/25 Windows bez skip, PID11152 exit0. Kod Claude, niezalezny review Gemini, rozliczenie kontrprzykladow. GitHub zapis odmowiony403; patch gotowy lokalnie. Native B2 zrodlo64 plikow i protected state unchanged.","next":"Jeden zintegrowany M2 native event pump, parent provenance, actual DLL/fixture, ABI i kompletna recenzja przed macierza.","blocker":"Publikacja GitHub: brak uprawnienia integracji. Nie blokuje lokalnego kodowania.","evidence":"C:\\MAIA\\reports\\M2_IMAGE_CHAIN_20261107\\DELIVERY_REPORT.md"},{"id":"autonomy-admission-audit-20261107","at_utc":"2026-11-07T13:26:50.423269+00:00","environment":"review","tool":"Codex / Claude web / Gemini web","action":"Audyt przyczyny braku automatycznej kontynuacji.","status":"working","result":"Potwierdzono: automatyzacja wylaczona, kandydat niewdrozony, Missions blokuje PIPELINE_COMPLETE. Brak aktywnego owner lease. Istniejacy sandbox elevated skonfigurowany, brak dowodu izolacji zapisu.","next":"Niezalezny przeglad rzeczywistych bramek, konkretne rozliczenie i minimalny kontrakt aktywacji.","blocker":"Samo wlaczenie harmonogramu nie podpina wykonawcy. Brak autoryzowanej aktywacji mechanizmu i kwalifikacji zapisu.","evidence":"C:\\MAIA\\worktrees\\AUTONOMY_ADMISSION_20261107\\CLAUDE_ADMISSION_INPUT.json"},{"id":"autonomy-admission-decision-20261107","at_utc":"2026-11-07T13:48:45.540736+00:00","environment":"review","tool":"Codex / Claude / Gemini","action":"Automatyczna kontynuacja: wstrzymana przed kwalifikacja piaskownicy.","status":"blocked","result":"Audyt i dwie recenzje zakonczone. Automatyzacja nadal wylaczona, kandydat niewdrozony. Potrzebne dopuszczenie jednej kwalifikacji istniejacej piaskownicy Codexa;3 nowe testy poprawki odmowy, bez Windows/native run.","next":"Decyzja o waskim wyjatku ACL tylko dla nowych katalogow testowych C:\\MAIA, potem kwalifikacja i jedna dopuszczona misja.","blocker":"Obowiazuje zakaz zmian ACL/profili. Nie uruchomiono automatycznego wykonawcy ani chronionego cyklu.","evidence":"C:\\MAIA\\reports\\AUTONOMY_ADMISSION_20261107\\QUALIFICATION_APPROVAL_REQUEST.md"},{"id":"sandbox-qualification-authorized-20261107","at_utc":"2026-11-07T14:05:57.221Z","environment":"windows","tool":"Codex / Windows","action":"Kwalifikacja piaskownicy po zgodzie na testy ACL/profili.","status":"working","result":"Edge polaczony; binarny Codex i chronione piny state/queue zweryfikowane. Nie uruchomiono modelu ani nowej misji.","next":"Jedna deterministyczna proba odczytu/zapisu w disposable fixture; zachowanie ACL przed i po.","blocker":"","evidence":"C:\\MAIA\\reports\\AUTONOMY_SANDBOX_20261107"},{"id":"missions-source-m2-started-20261107","at_utc":"2026-11-07T15:01:12.130911+00:00","environment":"windows","tool":"Mission Control / Codex","action":"Wdrozone Missions: jeden duzy komponent zrodlowy M2 w sesji DELIVER.","status":"done","result":"Piaskownica: dwa profile potwierdzone; ACL fixture przywrocone. Windows29/29 i dwie scoped recenzje. Misja355e570fb0564cb9: SUCCEEDED; PID None; widoczny proces=False; ostatni output 2026-11-07T15:00:44.072838+00:00.","next":"Odebrac finalne receipts i niezaleznie sprawdzic caly wynik M2 bez nowego polecenia uzytkownika.","blocker":"","evidence":"C:\\MAIA\\mission-control-data\\355e570fb0564cb9\\task.json; C:\\MAIA\\reports\\AUTONOMY_SANDBOX_20261107"},{"id":"m2-source-integrated-windows32-20261107","at_utc":"2026-11-07T21:27:43.119863+00:00","environment":"windows","tool":"Missions / source review","action":"M2: zintegrowany komponent \u017ar\u00f3d\u0142owy zweryfikowany na Windows.","status":"done","result":"32/32 Linux i 32/32 Windows, bez pomini\u0119\u0107, exit0. Surowe recenzje zachowane; dwa konkretne findings rozliczone reprodukcjami. Misja355e570fb0564cb9 zako\u0144czona; brak bie\u017c\u0105cego PID.","next":"Jedna pe\u0142na integracja native event/status policy, fixture/ABI, retained handles, observer i zewn\u0119trzny D6 przed now\u0105 rezerwacj\u0105 native.","blocker":"M2 native image-chain/TOCTOU i pe\u0142na akceptacja nadal OPEN; \u017ar\u00f3d\u0142o/testy nie s\u0105 dowodem native ani durability.","evidence":"C:\\MAIA\\reports\\AUTONOMY_SANDBOX_20261107\\m2-refinement-windows\\RESULT.json; C:\\MAIA\\reports\\AUTONOMY_SANDBOX_20261107\\M2_FINAL_REVIEW_DISPOSITION.md"},{"id":"m2-source-evidence-review-closed-20261107","at_utc":"2026-11-07T21:39:05.214677+00:00","environment":"review","tool":"Claude / Gemini / independent reconciliation","action":"M2: rozliczony ca\u0142y zaleg\u0142y pakiet \u017ar\u00f3d\u0142a, Windows i recenzji.","status":"done","result":"Windows32/32, exit0, no skips. Odebrane i zweryfikowane205 plik\u00f3w C, pe\u0142ny log misji oraz19 wpis\u00f3w manifestu panelu. Claude: scoped no blocker. Gemini: surowa odpowied\u017a zachowana, ko\u0144c\u00f3wka JSON uszkodzona, bez akceptacji.","next":"Pe\u0142na integracja native z kompletnym event/status policy, ABI/fixture, observer/D6 i now\u0105 rezerwacj\u0105 po przegl\u0105dzie dok\u0142adnego kodu.","blocker":"Pe\u0142ne M2/image-chain/TOCTOU i Apply/durability pozostaj\u0105 OPEN. Brak aktywnego workera; brak obietnicy pracy w tle.","evidence":"C:\\MAIA\\reports\\AUTONOMY_SANDBOX_20261107\\M2_INTEGRATED_DELIVERY_REPORT.md; C:\\MAIA\\reports\\AUTONOMY_SANDBOX_20261107\\FINAL_RECONCILIATION.json"},{"id":"m2-native-integration-source-started-20261107","at_utc":"2026-11-07T22:13:08.999486+00:00","environment":"workspace","tool":"Missions / Codex CLI","action":"M2: jedna pe\u0142na integracja natywna \u2014 praca nad \u017ar\u00f3d\u0142em.","status":"working","result":"Misja778f99c5c9ac4239, rzeczywisty PID19956, \u015bwie\u017cy zapis post\u0119pu 2026-11-07T22:13:07.769609+00:00. Kontrakt ca\u0142ej \u015bcie\u017cki zapisany; implementacja w toku. To obserwacja chwilowa, nie gwarancja pracy24/7.","next":"Kompletne \u017ar\u00f3d\u0142o, testy granic, niezale\u017cna recenzja dok\u0142adnych bajt\u00f3w; potem osobna kwalifikacja native.","blocker":"Native image-chain/TOCTOU, Apply i durability pozostaj\u0105 nieudowodnione. Brak nowej rezerwacji native.","evidence":"C:\\MAIA\\mission-control-data\\778f99c5c9ac4239\\task.json; C:\\MAIA\\reports\\M2_NATIVE_INTEGRATION_20261107\\admission\\RESULT.json"},{"id":"m2-native-integration-source-reconciled-20261107","at_utc":"2026-11-07T22:48:53.476543+00:00","environment":"windows","tool":"Missions / source reconciliation","action":"M2: cz\u0119\u015bciowy wynik rozliczony; pe\u0142na integracja nadal zablokowana.","status":"blocked","result":"Misja778f99c5c9ac4239 zako\u0144czona BLOCKED, brak bie\u017c\u0105cego PID. Grupowe poprawki:19Linux i19Windows bez pomini\u0119\u0107, exit0. To testy metod, nie dzia\u0142aj\u0105cy host natywny.","next":"Domkn\u0105\u0107 rzeczywisty przebieg C/D/O/W i fixture/module pins w tym samym komponencie, przed przegl\u0105dem pe\u0142nego wywo\u0142ania i now\u0105 rezerwacj\u0105 native.","blocker":"Brak pe\u0142nego spi\u0119cia hosta, retained custody/observer/W i rzeczywistej fixture. Native image-chain/Apply/durability FALSE; nie ponawia\u0107 zamkni\u0119tych pr\u00f3b.","evidence":"C:\\MAIA\\reports\\M2_NATIVE_INTEGRATION_20261107\\COMPONENT_REPORT.md; C:\\MAIA\\reports\\M2_NATIVE_INTEGRATION_20261107\\boundary-windows\\RESULT.json"},{"id":"m2-file-observation-validated-20261108","at_utc":"2026-11-08T00:14:26.405002+00:00","environment":"windows","tool":"Source engineering / Windows / review","action":"M2: odczyt plik\u00f3w i rozliczenie przerwa\u0144 zwalidowane.","status":"blocked","result":"60/60 Linux i 60/60 Windows, bez pomini\u0119\u0107. Dok\u0142adne \u017ar\u00f3d\u0142o zrecenzowane i zachowane w C:\\MAIA. To walidacja metod, nie pr\u00f3ba natywnego hosta. Brak aktywnego procesu roboczego.","next":"Pod\u0142\u0105czy\u0107 t\u0119 warstw\u0119 do pe\u0142nego C/D/O/W: retained kopie potomk\u00f3w, observer, zewn\u0119trzny watchdog i dok\u0142adna fixture przed now\u0105 rezerwacj\u0105 native.","blocker":"Pe\u0142ne M2 nadal nieodebrane. Image-chain / Apply / durability FALSE; termin 8 XI zagro\u017cony.","evidence":"C:\\MAIA\\reports\\M2_OBSERVATION_20261108\\COMPONENT_REPORT.md; C:\\MAIA\\reports\\M2_OBSERVATION_20261108\\windows\\RESULT.json"},{"id":"m2-check-component-20261108","at_utc":"2026-11-08T01:25:06.761491+00:00","environment":"windows","tool":"Missions, Python, Gemini","action":"Rozliczenie komponentu Check i polityki zdarzen M2","status":"blocked","result":"47/47 Linux i 47/47 pure Windows; surowe wyniki zachowane. Misja kodowania zakonczyla sie BLOCKED, PID16708 zakonczony. Brak aktualnie uruchomionej przez ten przebieg misji.","next":"Dokonczyc rzeczywiste polaczenie C/D/O/W z Git, kopie uchwytow/ACK, fixture i zewnetrzne rozliczenie D6; potem dokladna recenzja i jednorazowa macierz native.","blocker":"M2 OTWARTE: kompletna implementacja wywolania nie zostala dostarczona. Nie jest to awaria polaczenia. Termin 8 XI zagrozony.","evidence":"C:\\MAIA\\reports\\M2_COMPLETION_20261108\\COMPONENT_REPORT.md"},{"id":"m2-connected-custody-20261108","at_utc":"2026-11-08T09:09:19.326511+00:00","environment":"windows","tool":"Python, Claude web, Edge","action":"Walidacja polaczonej sciezki uchwytow C/D/O/W M2","status":"blocked","result":"62/62 Linux i 62/62 pure Windows, exit0; oryginaly i receipts w C:\\MAIA. Polaczona sciezka C/D/O oraz wybrane W/D6 sprawdzone na fake boundaries. Brak aktywnego workera i brak nowego native run.","next":"Dokonczyc wybrany host C/D/O/W, laczny budzet i dokladna fixture Git; potem pelna recenzja oraz jednorazowa macierz Windows/D6/TOCTOU.","blocker":"M2 OTWARTE: rzeczywisty host i macierz native nadal niedostarczone. Wynik pure nie zamyka milestone. Termin 8 XI zagrozony.","evidence":"C:\\MAIA\\reports\\M2_WHOLE_PATH_20261108\\COMPONENT_REPORT.md"},{"id":"m2-real-pipes-20261108","at_utc":"2026-11-08T10:42:08.434815+00:00","environment":"windows","tool":"Python, Claude web, Edge","action":"Zwalidowano rzeczywiste potoki i wymiane uchwytow M2","status":"done","result":"Rzeczywiste potoki C/D/O/W:26/26 Linux i26/26 Windows, exit0 PID1984; native wstrzykniete, W syntetyczny. Recenzja finalna; warunek terminow odtworzony. Wynik zapisany w C:/MAIA.","next":"Dokonczyc host C/D/O/W i laczny budzet/fixture, potem recenzja calego kodu i nowa macierz Windows Git/TOCTOU/D6. Brak aktywnego workera.","blocker":"M2 nadal OTWARTE: pozostala implementacja i dowody native, nie awaria internetu. Termin8XI zagrozony; image-chain/Apply/durability FALSE.","evidence":"C:\\MAIA\\reports\\M2_WHOLE_PATH_20261108\\pipe_delivery\\PIPE_COMPONENT_REPORT.md"},{"id":"m2-host-admission-20261108","at_utc":"2026-11-08T11:56:01.057566+00:00","environment":"windows","tool":"Python, Claude web, Edge","action":"Zwalidowano wspolne limity i odmowy M2","status":"done","result":"Limity i odmowy hosta M2:27/27 Linux i27/27 Windows, PID3184 exit0. Niepewny wynik blokuje obie warstwy D. Przypiete polecenia Git; bez wykonania Git/native. Recenzja rozliczona.","next":"Podlaczyc start C/D/O/W, pelne limity W i custody fixture, potem recenzja calego kodu i nowa macierz Windows Git/TOCTOU/D6. Brak aktywnego workera.","blocker":"M2 nadal OTWARTE: pozostala implementacja i dowody native, nie awaria internetu. Termin8XI zagrozony; image-chain/Apply/durability FALSE.","evidence":"C:\\MAIA\\reports\\M2_WHOLE_PATH_20261108\\host_admission\\COMPONENT_REPORT.md"},{"id":"m2-host-bootstrap-20261108","at_utc":"2026-11-08T12:54:34.375639+00:00","environment":"windows","tool":"Python, Claude web, Edge","action":"Zwalidowano granice uruchomienia M2; milestone nadal otwarty","status":"done","result":"Poprawiono granice tworzenia i rozliczenia M2. 40/40 Linux i40/40 Windows, PID15516 exit0; surowe dowody i recenzja rozliczone. Bez uruchomienia Git/native.","next":"Dokonczyc wspolny start C/D/O/W, odbior stdout/stderr Git, W i fixture. Potem przeglad calego kodu oraz native Git/TOCTOU/D6. Brak aktywnego workera.","blocker":"M2 nadal OTWARTE: pozostala implementacja i dowody native, nie awaria internetu. Termin8XI zagrozony; image-chain/Apply/durability FALSE.","evidence":"C:\\MAIA\\reports\\M2_WHOLE_PATH_20261108\\host_bootstrap\\COMPONENT_REPORT.md"},{"id":"m2-output-capture-20261108","at_utc":"2026-11-08T14:06:48.556069+00:00","environment":"windows","tool":"Python, Gemini Enterprise Argon, Edge","action":"Dodano i sprawdzono odbior stdout/stderr; M2 pozostaje otwarte","status":"done","result":"Odbior stdout/stderr Git: 35 testow Linux i 35 Windows PASS. Potoki systemowe, limity, bledy, tryb binarny i zwalnianie zasobow. Gemini Enterprise: projekt i dwie recenzje kodu.","next":"Polaczyc odbior wyjscia z CreateProcess, dokonczyc start C/D/O/W, nadzor W i dowody Git/image-chain. M2 nadal otwarte.","blocker":"Brak pelnej integracji native M2. Testy potokow nie dowodza uruchomienia Git ani odbioru milestone. Brak aktywnego workera po zakonczeniu testow.","evidence":"C:\\MAIA\\reports\\M2_OUTPUT_CAPTURE_20261108\\COMPONENT_REPORT.md"},{"id":"m2-process-streams-20261108","at_utc":"2026-11-08T16:13:30.175698+00:00","environment":"windows","tool":"Python, Gemini Enterprise Argon, Edge","action":"Polaczono wyjscie ze startem procesu; testy Windows PASS","status":"done","result":"Polaczono potoki z CreateProcess i dokladna lista uchwytow. Linux: 206 testow PASS. Windows: 206 testow + 2 rzeczywiste proby procesu PASS; 60 kB na kazdym wyjsciu, bajty binarne, izolacja uchwytu i blad startu.","next":"Dokonczyc start C/D/O/W, rozliczanie procesu i nadzor W; nastepnie rzeczywisty Git i image-chain/TOCTOU. M2 pozostaje otwarte.","blocker":"Test potomnego Pythona potwierdza potoki Windows. Nie dowodzi pelnego hosta M2, sledzenia Git ani image-chain. Brak aktywnego workera po testach.","evidence":"C:\\MAIA\\reports\\M2_PROCESS_STREAMS_20261108\\COMPONENT_REPORT.md"},{"id":"m2-root-ack-20261108","at_utc":"2026-11-08T16:44:36.134564+00:00","environment":"windows","tool":"Python, Edge; Claude review declined","action":"Poprawiono pierwsze zdarzenie debuggera; Windows 217 PASS","status":"done","result":"Poprawiono przekazanie pierwszego zdarzenia ACK do TRACE: jeden odczyt, jedna transakcja przejecia, brak przedwczesnego Continue. 217/217 testow Linux i 217/217 Windows PASS; 11 nowych regresji.","next":"Dokonczyc pojedyncza integracje C/D/O/W: kapsula wejscia, nadzor W i porownanie surowych raportow. Potem niezalezny przeglad calego zrodla i rzeczywista proba Git/image-chain. M2 nadal otwarte.","blocker":"Testy obejmuja zrodlo i rzeczywiste potoki z symulowanymi wywolaniami Windows. Pelny host i dowod wykonanego obrazu nie sa gotowe; szkic hosta nie zostal uruchomiony. Brak aktywnego workera po testach.","evidence":"C:\\MAIA\\reports\\M2_ROOT_ACK_20261108\\COMPONENT_REPORT.md"},{"id":"m2-native-refusal-20261108","at_utc":"2026-11-08T17:48:28.630456+00:00","environment":"windows","tool":"Python, Edge, Gemini Enterprise","action":"Natywna odmowa Git i sprzatanie W potwierdzone","status":"done","result":"236/236 testow Linux i Windows PASS. Rzeczywisty Git: pierwsze CREATE, odmowa SECTION_BINDING_UNPROVEN, zero Continue. Potwierdzone zakonczenie C/D/O, pusty job i zamkniecie uchwytow nadzorcy W.","next":"M2 otwarte: pozostala szesciowierszowa macierz podmian/resolution oraz osobne sprzatanie O po odmowie. Biezacy kod w reports/M2_DIAGNOSTIC_HOST_20261108/strict236.","blocker":"Przejscie proby odmowy nie jest odbiorem calego M2. O zakonczyl po EOF; nie ma jego osobnego potwierdzenia sprzatania. Brak aktywnego procesu tej proby po potwierdzonym zakonczeniu.","evidence":"C:\\MAIA\\reports\\M2_DIAGNOSTIC_HOST_20261108\\COMPONENT_REPORT.md"},{"id":"m2-observer-settled-20261108","at_utc":"2026-11-08T18:15:30.607106+00:00","environment":"windows","tool":"Python, Edge, Gemini Enterprise","action":"O:5/5 uchwytow zamknietych; Windows249 PASS","status":"done","result":"249/249 Linux i Windows PASS. Natywna odmowa Git w6.04s: O niezaleznie potwierdzil sygnaly i pusty job, zamknal5/5 uchwytow; C i W rozliczone. Punkt kontrolny98 zapisany.","next":"Trwa przygotowanie pozostalych przypadkow macierzy M0-M5 na prywatnych kopiach. M2 nadal otwarte.","blocker":"Brak ukrytej pracy w tle: ten wpis potwierdza ostatni zakonczony krok. Nie jest heartbeat ani dowod aktywnej sesji. Stan polaczenia czatu oceniaj osobno.","evidence":"C:\\MAIA\\reports\\M2_DIAGNOSTIC_HOST_20261108\\COMPONENT_REPORT.md"},{"id":"m2-matrix-qualified-20261108","at_utc":"2026-11-08T18:47:00.432080+00:00","environment":"windows","tool":"Python, Edge, Gemini Enterprise","action":"M2 ZAMKNIETE - 7/7, kontrolowana odmowa","status":"done","result":"M2 ZAMKNIETE: kontrolowana odmowa. Linux/Windows261 PASS; macierz M0-M5:7/7 w23.70s, bez timeoutu. Gemini: SCOPE QUALIFIED. Apply i dowod obrazu nadal false.","next":"M3: trwaly journal, start receipt i recovery bez replay; osobna kwalifikacja. Zamkniecie M2 nie odblokowuje polecen Git ani Apply.","blocker":"OSTATNI ZAKONCZONY KROK, nie sygnal zycia agenta. Brak aktywnego zadania w tle po zakonczeniu tej sesji. Zerwane polaczenie czatu oznacza brak potwierdzenia dalszej pracy.","evidence":"C:\\MAIA\\reports\\M2_DIAGNOSTIC_HOST_20261108\\COMPONENT_REPORT.md"},{"id":"m3-package-design-20261108","at_utc":"2026-11-08T19:57:51.382693+00:00","environment":"workspace","tool":"Codex, Gemini Enterprise, Claude","action":"M3: jeden spojny pakiet implementacji i kwalifikacji","status":"done","result":"M3: kontrakt calego pakietu ustalony po pierwszym przegladzie Gemini i Claude. Trwa skladanie izolowanej implementacji journal+queue, potwierdzenia startu i recovery bez replay. Kontrole lokalne przeszly; Windows jeszcze niewykonane.","next":"Jeden przeglad dokladnego calego zrodla, potem skonczona macierz natywnych przerwan i odmow. M3 pozostaje otwarte.","blocker":"Ostatni potwierdzony krok, nie heartbeat modelu. Brak uruchomionej misji w tle. Status pracy w czacie wynika z biezacych odpowiedzi.","evidence":"C:\\MAIA\\reports\\M3_BEGIN_20261108\\COMPONENT_REPORT.md"},{"id":"m3-native-qualified-20261108","at_utc":"2026-11-08T21:06:29.369594+00:00","environment":"workspace","tool":"Codex, Gemini Enterprise, Claude","action":"M3: kwalifikacja natywna zakonczona","status":"done","result":"M3 zamkniete w zakresie izolowanego Begin po awarii procesu. Windows64/64; wejscia13/13, odmowy4/4, scenariusze13/13 i zimny restart13/13 PASS. Gemini i Claude dopuscily zrodlo i ocene wynikow. Produkcyjne pliki bez zmian.","next":"M4: spojny pakiet integracji staging; normalny przebieg, przerwanie i recovery bez duplikacji.","blocker":"To ostatni zakonczony krok, nie heartbeat modelu. Macierz zakonczyla sie; brak deklarowanego procesu w tle. Globalne obraz/Apply/durability/readiness=false.","evidence":"C:\\MAIA\\reports\\M3_BEGIN_20261108\\COMPONENT_REPORT.md"},{"id":"m4-plan-20261108","at_utc":"2026-11-08T21:41:24.596407+00:00","environment":"workspace","tool":"Codex, Gemini Enterprise","action":"M4: plan gotowy, wykonanie UNRUN","status":"done","result":"Plan M4 gotowy: cztery spojne pakiety P0-P3 i dokladnie trzy scenariusze odbioru. Gemini4Argon: PLAN_READY po jednej rundzie doprecyzowan. Estymacja4-8h aktywnej pracy; M4 nie zostalo uruchomione.","next":"P0: odczyt aktualnych portow i spec/ADR, dopuszczony profil staging oraz kryteria S1-S3 przed kodem.","blocker":"Zakonczono planowanie, nie heartbeat modelu ani run M4. Brak deklarowanego procesu w tle. P0 musi rozstrzygnac zaleznosc Git; zainstalowany Supervisor i produkcyjne dane chronione.","evidence":"C:\\MAIA\\plans\\milestones\\M4_STAGING_PLAN_20261108.md"}]};
/* MAIA_ACTIVITY_DATA_END */
var activityReady=false;
let activityData=MAIAActivityModel.validate(MAIA_ACTIVITY_DATA);
function activityLoadText(text){
 const m=text.match(/\/\* MAIA_ACTIVITY_DATA_BEGIN \*\/\s*const MAIA_ACTIVITY_DATA = (.*?)\s*;\s*\/\* MAIA_ACTIVITY_DATA_END \*\//s);
 if(!m)throw Error('Brak dziennika czynności');
 const next=MAIAActivityModel.validate(JSON.parse(m[1]));
 if(JSON.stringify(next)!==JSON.stringify(activityData)){activityData=next;activityHistory();}
 activityTick();
}
function activityHistory(){
 const box=byId('activity-history');box.replaceChildren();
 for(const e of [...activityData.events].reverse()){
  const row=pNode('details','activity-event'),s=pNode('summary','');
  s.append(pNode('time','',localTime(e.at_utc)),pNode('span','activity-tool',e.tool),pNode('span','',e.action));
  row.append(s,pNode('p','',MAIAActivityModel.environments[e.environment]),pNode('p','',e.result||'Wynik tego kroku jeszcze nie zapisany.'),pNode('p','','Dalej: '+e.next));
  if(e.blocker)row.append(pNode('p','activity-warning',e.blocker));
  if(e.evidence)row.append(pNode('small','',e.evidence));
  box.append(row);
 }
 if(!activityData.events.length)box.append(pNode('p','','Nie odebrano jeszcze wpisu.'));
 setText('activity-history-count',activityData.events.length+' ostatnich wpisów');
}
function activityTick(){
 if(!activityReady)return;
 if(!byId('activity-window'))return;
 const now=Date.now(),live=!projectTransportError&&projectLastRead&&now-projectLastRead<=6500;
 const v=MAIAActivityModel.view(activityData,{now,serverFresh:!!live,cycle:projectSnapshot?.cycle_progress});
 setText('activity-status',v.label);byId('activity-window').dataset.fresh=String(v.fresh);
 setText('activity-age',v.last?localTime(v.last.at_utc)+' · '+(v.age===null?'czas niepotwierdzony':age(v.age)):'Brak aktualizacji');
 const p=projectSnapshot?.cycle_progress;
 setText('activity-action',v.superseded?p.current_action:v.last?.action||'Brak potwierdzonej czynności');
 setText('activity-tool',v.superseded?'Źródło: checkpoint operatora':v.last?(MAIAActivityModel.environments[v.last.environment]+' / '+v.last.tool):'Środowisko niepodane');
 setText('activity-result',v.superseded?p.check_result:v.last?.result||'Wynik jeszcze nie zapisany.');
 setText('activity-next',v.superseded?p.next_step:v.last?.next||'—');
 setText('activity-blocker',v.superseded?p.blocker:v.last?.blocker||'Brak zgłoszonej blokady w tym wpisie.');
 const signals=byId('activity-environments');signals.replaceChildren();
 for(const [id,title] of Object.entries(MAIAActivityModel.environments)){
  const last=[...activityData.events].reverse().find(e=>e.environment===id);
  const cell=pNode('article','');cell.append(pNode('strong','',title),pNode('p','',last?last.action:'Brak wpisu z tego środowiska.'),pNode('small','',last?localTime(last.at_utc)+' · ostatnia obserwacja':'Stan niepotwierdzony'));signals.append(cell);
 }
}
if(!stageMode){activityReady=true;activityHistory();activityTick();}

// M4 staging view: all displayed facts originate in the authenticated read model.

function setupStage(){
 const card=document.createElement('main');card.className='panel';card.id='m4-stage-card';
 const title=document.createElement('h1');title.textContent='MAIA · M4 staging';card.append(title);
 const note=document.createElement('p');note.textContent='Dziennik dev-host · eksperyment izolowany · poza kanonicznym Core';card.append(note);
 for(const [id,label] of [['status','Stan'],['cycle','Cykl'],['profile','Zakres'],['phase','Faza dziennika'],['executor','Wykonawca'],['identity','PID / narodziny'],['custody','Bieżąca obserwacja'],['log','Log'],['semantic','Wynik semantyczny'],['head','Wiązanie dowodu']]){
  const row=document.createElement('p'),name=document.createElement('strong'),value=document.createElement('span');name.textContent=label+': ';value.id='m4-'+id;value.textContent='—';row.append(name,value);card.append(row);
 }
 document.body.replaceChildren(card);
 setInterval(()=>{if(stageLastRead&&Date.now()-stageLastRead>5000)stageError('Status utracił świeżość');},1000);
}
function stageError(message){setText('m4-status','NIEPOTWIERDZONE · '+message);byId('m4-stage-card').dataset.active='false';}
function renderStage(data){
 stageLastRead=Date.now();
 const s=data.stage;
 if(!s||s.schema!==1||s.start_capability!==false||s.replay_permitted!==false){stageError('Niepoprawna odpowiedź statusu');return;}
 const observationAge=Date.now()-Date.parse(s.observed_utc||'');
 const active=s.active===true&&s.custody==='RETAINED_HANDLE_CURRENT'&&s.phase==='STARTED'&&s.quarantined===false&&Number.isFinite(observationAge)&&observationAge>=0&&observationAge<=5000;
 byId('m4-stage-card').dataset.active=String(active);
 const view=s.view==='ACTIVE'&&!active?'NIEPOTWIERDZONE · brak świeżej obserwacji':s.view;
 setText('m4-status',active?'AKTYWNY · potwierdzony uchwyt':view);
 setText('m4-cycle',s.binding?.cycle);setText('m4-profile',s.profile);setText('m4-phase',s.phase);setText('m4-executor',s.executor);
 // FILETIME exceeds Number.MAX_SAFE_INTEGER; only exact server decimal strings may be displayed.
 const d=s.identity_display;
 const decimal=(v,max)=>typeof v==='string'&&/^[1-9][0-9]*$/.test(v)&&(v.length<max.length||(v.length===max.length&&v<=max));
 const displayIdentity=d&&typeof d==='object'&&Object.keys(d).length===2&&decimal(d.pid,'4294967295')&&decimal(d.birth,'18446744073709551615');
 setText('m4-identity',displayIdentity?d.pid+' / '+d.birth:'Niepotwierdzona / brak');
 setText('m4-custody',s.custody+(s.observed_utc?' · '+s.observed_utc:''));setText('m4-log',s.log_tail||'Brak odczytanego logu');
 // Present semantic outcome fields; numeric identity is already shown exactly above.
 const result=s.semantic;
 const field=name=>typeof result?.[name]==='string'?result[name]:'Niepotwierdzone';
 setText('m4-semantic',result&&typeof result==='object'?'Status: '+field('status')+' · is_error: '+(result.is_error===false?'false':result.is_error===true?'true':'Niepotwierdzone')+' · Werdykt: '+field('verdict')+' · Artefakt: '+field('artifact')+' · SHA256: '+field('artifact_sha256'):'Niepotwierdzony / brak zakończenia');
 setText('m4-head',s.head_sha||'Brak zweryfikowanego nagłówka');
}
