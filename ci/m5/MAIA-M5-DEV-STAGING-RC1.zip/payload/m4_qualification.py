"""One finite, source-frozen M4 qualification of the real copied PS path.

Native execution is Windows-only and explicitly dispatched by the coordinator.
The manifest and ATTEMPT are exclusive: a completed or partial batch is terminal.
No bootstrap keys, server tokens or DPAPI blobs are included in report objects.
"""
from __future__ import annotations
import argparse
import base64
import datetime as dt
import hashlib
import importlib
import json
import os
from pathlib import Path
import platform
import queue
import re
import secrets
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import threading
import time
import unittest
import urllib.error
import urllib.request

BASELINE_SOURCE = '64d59a6cf10b8b940d55f91b9948ca2cabf98e51bb4a7cf0338fc3a444c444f2'
PROFILE = 'M4_PROTECTED_PROPOSAL_STAGING'
CREATE_NO_WINDOW = 0x08000000
ROWS = (
 ('receiver_committed','after_commit:RECEIVER_CLAIM','PREPARED',0,0),
 ('queue_before_commit','before_commit:QUEUED','PREPARED',0,0),
 ('queue_committed','after_commit:QUEUED','QUEUED',0,0),
 ('queue_lock_released','queue_lock_released','QUEUED',0,0),
 ('start_request_uncertain','request_received','QUEUED',0,0),
 ('intent_committed','after_commit:START_INTENT','START_INTENT',0,0),
 ('create_before_started','worker_created','START_INTENT',0,1),
 ('started_before_release','after_commit:STARTED','STARTED',0,1),
 ('worker_before_effect','worker_before_effect','STARTED',0,1),
 ('completed_before_reply','after_commit:COMPLETED','COMPLETED',1,1),
 ('concurrent_intents',None,'COMPLETED',1,1),
 ('S1_normal',None,'COMPLETED',1,1),
 ('S2_interrupted','worker_after_effect','STARTED',1,1),
)
CAPABILITY_FLAGS = ('ready','start_capability','launch_capability','replay_permitted')
SECRET_FIELDS = {'key','key_b64','key_hex','receipt_key','token','authorization','cookie'}
LOGICAL_AUTHORITY = ('binding','phase','receiver','records','queue','receipts_authenticated','semantic','identity')
COLD_REFUSAL = 'M4_ENGINE_REFUSED:RECEIVER_CLAIM_REFUSED_NO_REPLAY'
KNOWN_BARRIERS = {
 'engine_created','worker_created','default_refusal_ready','launch_enter','queue_lock_released','request_received',
 'worker_before_effect','worker_after_effect',
 *(f'{edge}:{phase}' for edge in ('before_commit','after_commit')
   for phase in ('RECEIVER_CLAIM','QUEUED','START_INTENT','STARTED','COMPLETED')),
}

class QualificationRefusal(RuntimeError):
    pass

def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode('ascii')

def sha(data):
    return hashlib.sha256(data).hexdigest()

def need(condition, reason):
    if not condition:
        raise QualificationRefusal(reason)

def public(value):
    """Defensive boundary; callers never pass an initial wire bootstrap here."""
    if isinstance(value,dict):
        return {str(k):public(v) for k,v in value.items() if str(k).casefold() not in SECRET_FIELDS}
    if isinstance(value,(tuple,list)):
        return [public(v) for v in value]
    if isinstance(value,Path):
        return str(value)
    if value is None or type(value) in (str,int,bool,float):
        return value
    raise QualificationRefusal('unserializable report value:'+type(value).__name__)

def write_json(path, value):
    raw=json.dumps(public(value),indent=2,ensure_ascii=True,allow_nan=False).encode('ascii')+b'\n'
    with Path(path).open('xb') as out:
        out.write(raw);out.flush();os.fsync(out.fileno())

def identity(value):
    need(type(value) is dict and set(value)=={'pid','birth'} and
         all(type(value[k]) is int and value[k]>0 for k in value),'identity shape')
    return value

def event_counts(events):
    return {'launch_barrier_entries':sum(e['kind']=='EVENT_BARRIER' and e['payload'].get('stage')=='launch_enter' for e in events),
            'emitted_worker_created_frames':sum(e['kind']=='WORKER_CREATED' for e in events)}

def no_capabilities(value):
    need(all(value.get(k) is False for k in CAPABILITY_FLAGS),'recovery granted a capability')
    need(value.get('live_process_reauthenticated') is False,'recovery inferred current process liveness')

def require_cold_fence(probe):
    need(probe['terminal']=='REFUSED' and probe['launch_entries']==probe['created_workers']==0,'cold replay launched')
    reasons=[str(e['payload'].get('reason','')) for e in probe['events'] if e['kind']=='REFUSED']
    need(reasons==[COLD_REFUSAL],'cold replay refusal has unrelated reason')
    need(probe['retained_handles_closed'],'cold replay retained custody unresolved')

def check_row(row, executions, recovery, effect_count):
    label,cut,phase,effects,created=row
    no_capabilities(recovery)
    need(recovery.get('phase')==phase and recovery.get('quarantined') is not True,'recovery phase differs:'+label)
    need(recovery.get('authority_unchanged') is True,'recovery authority not preserved:'+label)
    primary=[x for x in executions if x.get('purpose')!='COLD_REBOOTSTRAP_REPLAY_PROBE']
    probes=[x for x in executions if x.get('purpose')=='COLD_REBOOTSTRAP_REPLAY_PROBE']
    need(len(probes)==1,'one cold replay probe required')
    probe=probes[0]
    require_cold_fence(probe)
    need(sum(x['launch_entries'] for x in primary)==created and
         sum(x['created_workers'] for x in primary)==created,'launch/creation counters differ:'+label)
    need(effect_count==effects,'effect count differs:'+label)
    if label=='concurrent_intents':
        need(sorted(x['terminal'] for x in primary)==['COMPLETED','REFUSED'],'concurrent receivers did not yield one winner')
    elif cut:
        need(len(primary)==1 and primary[0]['terminal']=='INJECTED_PROCESS_CRASH' and primary[0]['cut_reached'],'crash cut not reached:'+label)
    else:
        need(len(primary)==1 and primary[0]['terminal']=='COMPLETED','normal route not completed')
    need(all(x['retained_handles_closed'] for x in executions),'retained handles unresolved')
    return {'row':label,'qualified':True,'expected_phase':phase,'effect_count':effect_count,
            'launch_entries':created,'created_workers':created,'cold_refusals':1}

def source_snapshot(source_root, expected_source):
    source_root=Path(source_root).absolute()
    need(type(expected_source) is str and re.fullmatch('[0-9a-f]{64}',expected_source),'source digest shape')
    raw=(source_root/'SOURCE_MANIFEST.json').read_bytes();manifest=json.loads(raw)
    need(manifest.get('schema')==1 and manifest.get('source_sha256')==expected_source,'manifest/source binding')
    files=manifest.get('files');need(type(files) is dict and files,'source files missing')
    digests={}
    for name,pin in sorted(files.items()):
        need(type(name) is str and name and not name.startswith('/') and '\\' not in name and
             ':' not in name and all(x not in ('','.','..') for x in name.split('/')),'unsafe source path')
        path=source_root/name;need(path.is_file() and not path.is_symlink(),'source not ordinary:'+name)
        data=path.read_bytes()
        need(type(pin) is dict and len(data)==pin['bytes'] and sha(data)==pin['sha256'],'source bytes drift:'+name)
        digests[name]=sha(data)
    need(sha(canonical(digests))==expected_source,'source map digest differs')
    baseline={Path(n).name:h for n,h in digests.items() if n.startswith('baseline_m3/') and n.endswith('.py')}
    need(len(baseline)==14 and sha(canonical(baseline))==BASELINE_SOURCE,'M3 library baseline differs')
    return {'root':source_root,'manifest':manifest,'manifest_sha256':sha(raw),'source_sha256':expected_source}

def runtime_proof():
    from m4_native import validate_runtime
    native=validate_runtime()
    python=Path(sys.executable).absolute()
    ps=Path('C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe')
    need(ps.is_file(),'fixed PowerShell interpreter missing')
    command=[str(ps),'-NoProfile','-NonInteractive','-Command','$PSVersionTable.PSVersion.ToString()']
    value=subprocess.run(command,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                         timeout=10,check=False)
    need(value.returncode==0 and not value.stderr,'PowerShell version probe failed')
    version=value.stdout.decode('utf-8-sig').strip()
    need(version.startswith('5.1.'),'PowerShell5.1 runtime required')
    free=shutil.disk_usage('C:/').free;need(free>=3*1024**3,'minimum freeC reserve not available')
    return {'python':{'path':str(python),'sha256':sha(python.read_bytes()),'version':sys.version},
            'powershell':{'path':str(ps),'sha256':sha(ps.read_bytes()),'version':version},
            'native_contract':native,'sqlite_version':sqlite3.sqlite_version,'os_build':platform.version(),
            'free_c_bytes':free}

def runtime_inputs(runtime):
    return {k:runtime[k] for k in ('python','powershell')}

def admitted_test_modules(source, label):
    """Enumerate exact source-manifest tests; never discover ambient filesystem code."""
    need(label in ('M3','M4'),'pure control family')
    pattern=(r'baseline_m3/test_m3[A-Za-z0-9_]*\.py' if label=='M3'
             else r'test_m4[A-Za-z0-9_]*\.py')
    names=[name[:-3].replace('/','.') for name in sorted(source['manifest']['files'])
           if re.fullmatch(pattern,name)]
    need(names,'manifest-listed pure controls missing:'+label)
    return names

def pure_controls(source, output):
    result={}
    for label,expected in (('M3',64),('M4',None)):
        modules=admitted_test_modules(source,label)
        suite=unittest.TestSuite(unittest.TestLoader().loadTestsFromModule(importlib.import_module(name))
                                 for name in modules)
        fixture_root=Path(output)/('pure_fixtures_'+label);fixture_root.mkdir(exist_ok=False)
        previous_tempdir=tempfile.tempdir
        try:
            tempfile.tempdir=str(fixture_root)
            with (Path(output)/(label+'_PURE_TESTS.log')).open('x',encoding='utf-8') as log:
                run=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
        finally:tempfile.tempdir=previous_tempdir
        row={'tests':run.testsRun,'errors':len(run.errors),'failures':len(run.failures),
             'skipped':len(run.skipped),'passed':run.wasSuccessful(),'manifest_listed_modules':modules}
        need(row['passed'] and not row['skipped'] and row['tests']>0,'pure controls failed:'+label)
        if expected is not None:need(row['tests']==expected,'baseline control count differs')
        result[label]=row
    return result

def close_server(server):
    server.shutdown();server.server_close();server.stage_thread.join(timeout=2)
    need(not server.stage_thread.is_alive(),'stage HTTP server did not settle')

def expected_http_assets(source_sha, token):
    source=source_snapshot(Path(__file__).parent,source_sha)
    assets={}
    for name in ('index.html','app.js','app.css'):
        raw=(source['root']/'ui'/name).read_bytes()
        pin=source['manifest']['files']['ui/'+name]
        need(len(raw)==pin['bytes'] and sha(raw)==pin['sha256'],'HTTP source asset drift:'+name)
        if name=='index.html':
            raw=raw.replace(b'__MAIA_TOKEN__',token.encode('ascii'))
            raw=raw.replace(b'</head>',b'<meta name="maia-stage" content="readonly"></head>',1)
        assets[name]=raw
    return assets

class NoHTTPRedirects(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):
        raise QualificationRefusal('loopback HTTP redirect refused')

def local_http_opener():
    # Environment/PAC proxies must never receive this server's private token.
    return urllib.request.build_opener(urllib.request.ProxyHandler({}),NoHTTPRedirects())

def http_snapshot(instance, source_sha, native=None, observation_lock=None, expected_active=None):
    from maia_panel import start_stage_server
    from m4_readmodel import RetainedObserver
    observer=RetainedObserver(instance['binding'],native,observation_lock) if native is not None else None
    server=start_stage_server(instance['root'],source_sha,observer)
    try:
        opener=local_http_opener();expected_assets=expected_http_assets(source_sha,server.token)
        request=urllib.request.Request(server.ui_url+'api/status',headers={'X-MAIA-Token':server.token})
        with opener.open(request,timeout=5) as response:
            raw=response.read(1024*1024+1);need(len(raw)<=1024*1024,'status response bound')
            data=json.loads(raw)
        stage=data.get('stage');need(type(stage) is dict,'actual Monitor status stage missing')
        need(stage.get('binding')==instance['binding'],'HTTP status bound to wrong cycle')
        if expected_active is not None:need(stage.get('active') is expected_active,'HTTP retained liveness differs')
        with opener.open(server.ui_url,timeout=5) as response:
            html=response.read(1024*1024+1)
        need(len(html)<=1024*1024,'UI response bound')
        need(html==expected_assets['index.html'],'HTTP HTML differs from frozen rendered source')
        assets={}
        for name in ('app.js','app.css'):
            with opener.open(server.ui_url+name,timeout=5) as response:
                body=response.read(2*1024*1024+1)
                need(len(body)<=2*1024*1024,'UI asset bound')
            need(body==expected_assets[name],'HTTP asset differs from frozen manifest:'+name)
            assets[name]={'bytes':len(body),'sha256':sha(body),'source_manifest_match':True}
        mutation=urllib.request.Request(server.ui_url+'api/terminal/run',data=b'{}',method='POST',
                                       headers={'Content-Type':'application/json','X-MAIA-Token':server.token})
        try:opener.open(mutation,timeout=5)
        except urllib.error.HTTPError as exc:need(exc.code in (403,404,405),'stage mutation endpoint response')
        else:raise QualificationRefusal('stage HTTP accepted mutation endpoint')
        return {'status':200,'stage':stage,'status_body_utf8':raw.decode('utf-8'),
                'status_sha256':sha(raw),'html_bytes':len(html),
                'html_sha256':sha(html),'html_source_manifest_match':True,'assets':assets,'mutation_refused':True,
                'server_bound_loopback':server.server_address[0]=='127.0.0.1'}
    finally:close_server(server)

def request_job_termination(job):
    # Shared concurrent-controller cleanup observes a prior request; it never
    # repeats an entered mutation, including a call with an unknown outcome.
    if getattr(job,'_m4_termination_entered',False):return False
    job._m4_termination_entered=True;job.terminate();return True

def until_empty(job, deadline, lock):
    while True:
        with lock:count=job.active_processes()
        if count==0:return
        need(time.monotonic()<deadline,'owned job did not settle')
        time.sleep(.01)

def enroll_job_process(job,role,native):
    state=getattr(job,'_m4_observation',None)
    if state is None:
        state={'known':{},'extras':{},'samples':[]};job._m4_observation=state
    observed=identity(dict(native._identity));pid=observed['pid']
    need(role in ('controller','engine','worker','readonly_monitor'),'job process role')
    need(pid not in state['known'],'job PID enrolled twice')
    state['known'][pid]={'role':role,'identity':observed}


def classify_job_metadata(known,extras,rows):
    current={row['pid']:row for row in rows};next_extras=dict(extras)
    for pid,row in current.items():
        need(set(row)=={'pid','parent_pid','image_name'} and type(pid) is int and
             type(row['parent_pid']) is int and type(row['image_name']) is str,'job metadata shape')
        if pid in known:
            expected='python.exe' if known[pid]['role'] in ('engine','readonly_monitor') else 'powershell.exe'
            need(row['image_name'].casefold()==expected,'known job member metadata differs')
            continue
        parent=known.get(row['parent_pid'])
        need(row['image_name'].casefold()=='conhost.exe' and parent is not None and
             parent['role'] in ('controller','worker','engine','readonly_monitor'),'unexpected job descendant metadata')
        previous=next_extras.get(pid)
        need(previous is None or previous==row,'incidental host metadata changed')
        need(not any(value['parent_pid']==row['parent_pid'] and other!=pid
                     for other,value in next_extras.items()),'more than one conhost per retained console-program parent')
        next_extras[pid]=row
    return next_extras


def observe_job_processes(job,lock,deadline,require_ps_pids=()):
    from m4_process_observation import snapshot_processes,Refusal as MetadataRefusal
    end=min(deadline,time.monotonic()+5)
    with lock:
        state=job._m4_observation
        for pid in require_ps_pids:
            need(pid in state['known'] and state['known'][pid]['role'] in ('controller','worker','engine'),'host initialization parent missing')
        for attempt in range(256):
            need(time.monotonic()<end,'job metadata observation deadline')
            before=job.members();need(before,'owned job unexpectedly empty at creation barrier')
            missing=[pid for pid in require_ps_pids if not any(row['parent_pid']==pid for row in state['extras'].values())]
            # Wait with bounded job-membership reads until a host can exist;
            # do not duplicate full global metadata snapshots during PS startup.
            if missing and not (set(before)-set(state['known'])-set(state['extras'])):
                time.sleep(.02);continue
            try:sample=snapshot_processes(before)
            except MetadataRefusal:
                after=job.members()
                if before==after:raise
                need(time.monotonic()<end,'job membership observation deadline')
                continue
            after=job.members()
            if before!=after:
                need(time.monotonic()<end,'job membership observation deadline')
                continue
            need(time.monotonic()<end,'job metadata observation deadline')
            need(sample.get('snapshot_handle_closed') is True,'metadata snapshot handle unresolved')
            extras=classify_job_metadata(state['known'],state['extras'],sample['processes'])
            state['extras']=extras
            state['samples'].append({'job_members_before':before,'job_members_after':after,
                'metadata':sample,'known_retained_identities':list(state['known'].values()),
                'classification':'METADATA_ONLY_NO_IMAGE_OR_LIVENESS_AUTHORITY'})
            if all(any(row['parent_pid']==pid for row in extras.values()) for pid in require_ps_pids):return
            need(time.monotonic()<end,'retained PS console-host initialization deadline')
            time.sleep(.02)
        raise QualificationRefusal('job metadata observation retry bound')


def settled_job_evidence(job, executions, before):
    after=job.accounting()
    names=('total_processes','active_processes','terminated_processes')
    need(set(before)==set(names) and set(after)==set(names) and
         all(type(value[name]) is int and value[name]>=0 for value in (before,after) for name in names),
         'job accounting shape')
    need(before['total_processes']==before['active_processes']==0,'qualification job was not fresh')
    identities=[]
    for execution in executions:
        for role,record in execution['native_processes'].items():
            need(record.get('closed') is True,'job process retained custody unresolved:'+role)
            observed=identity(record['identity']);identities.append((observed['pid'],observed['birth']))
    need(len(identities)==len(set(identities)),'same retained native identity counted twice')
    need(after['active_processes']==0,'job contains active descendants after settlement')
    observation=getattr(job,'_m4_observation',{'known':{},'extras':{},'samples':[]})
    known={(row['identity']['pid'],row['identity']['birth']) for row in observation['known'].values()}
    need(not known or known==set(identities),'job enrollment differs from retained process settlement')
    extras=list(observation['extras'].values())
    need(not any(row['pid'] in {pid for pid,birth in identities} for row in extras),'incidental host overlaps retained process')
    need(after['total_processes']-before['total_processes']==len(identities)+len(extras),
         'job process count differs from retained identities plus actually observed console hosts')
    return {'before':before,'after':after,'expected_unique_retained_processes':len(identities),
            'retained_identities':[{'pid':pid,'birth':birth} for pid,birth in identities],
            'unexpected_process_allowance':0,'conhost_allowance':len(extras),
            'incidental_console_hosts':extras,'process_observations':observation['samples'],
            'controller_console_host_boundary':[{'parent_identity':row['identity'],
                'status':'OBSERVED_IN_OWNED_JOB' if any(host['parent_pid']==pid for host in extras) else 'NOT_OBSERVED_IN_OWNED_JOB',
                'limitation':'A_CONSOLE_HOST_MAY_PRECEDE_JOB_ASSIGNMENT_AND_BE_OUTSIDE_THIS_JOB_ACCOUNTING'}
                for pid,row in observation['known'].items() if row['role']=='controller'],
            'conhost_rule':'ACTUALLY_OBSERVED_CONHOST_EXE_MAX_ONE_PER_KNOWN_RETAINED_FIXED_RUNTIME_PARENT',
            'terminated_processes_semantics':'WINDOWS_LIMIT_VIOLATION_COUNTER_NOT_ALL_EXITS',
            'job_total_reconciled':True}

def process_record(native, code):
    return {'identity':dict(native._identity),'exit_code':code,'native_calls':list(native.calls),
            'closed':native.closed,'close_attempted':native.close_attempted}

def drive_controller(instance, source, runtime, job, job_lock, cut=None, action='Stage', monitor=True, engine_sync=None):
    from m4_native import NativeProcess
    from m4_wire import Wire,raw_write
    root=Path(instance['root']);session=secrets.token_hex(16);key=secrets.token_bytes(32)
    deadline=min(instance['deadline'],time.monotonic()+45)
    log_root=Path(instance['report_root']);log_root.mkdir(exist_ok=True)
    stderr=(log_root/(action+'-'+session+'.stderr')).open('xb')
    args=[runtime['powershell']['path'],'-NoLogo','-NoProfile','-NonInteractive',
          '-File',str(source['root']/'MAIA-Codex-Supervisor.ps1'),'-Action',action,
          '-Root',str(root),'-PromptId',instance['binding']['cycle']]
    child=subprocess.Popen(args,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=stderr,
                           bufsize=0,cwd=source['root'],close_fds=True,creationflags=CREATE_NO_WINDOW)
    controller=None;engine=None;worker=None;events=[];snapshots=[];terminal=None;cut_reached=False
    native_records={};observation_lock=threading.RLock();completion=None;failure=None
    assigned=False;bootstrap_sent=False;engine_start=None
    try:
        controller=NativeProcess(child)
        with job_lock:
            job.assign(controller);assigned=True;enroll_job_process(job,'controller',controller)
        raw_write(child.stdin,{'v':1,'key_b64':base64.b64encode(key).decode('ascii'),'session':session,
                   'binding':instance['binding'],'root':str(root),'source_root':str(source['root']),
                   'source_manifest_sha':source['manifest_sha256'],'source_sha':source['source_sha256'],
                   'command':{'Stage':'RUN','StageStatus':'STATUS','StageRecover':'RECOVER'}.get(action,'RUN'),
                   'policy_sha256':instance['policy_sha256']},deadline)
        bootstrap_sent=True
        channel=Wire(child.stdout,child.stdin,key,session,'outer_to_controller','controller_to_outer')
        while True:
            frame=channel.receive(deadline);kind=frame['kind'];payload=frame['payload']
            events.append({'kind':kind,'payload':public(payload)})
            stage=None
            if kind=='ENGINE_CREATED':
                need(engine is None,'second engine creation')
                engine=NativeProcess.from_remote(controller,payload['remote_handle'],identity(payload['identity']))
                with job_lock:enroll_job_process(job,'engine',engine)
                if engine_sync is not None:engine_sync.wait(timeout=max(.01,min(8,deadline-time.monotonic())))
                else:observe_job_processes(job,job_lock,deadline,[engine._identity['pid']])
                stage='engine_created'
            elif kind=='WORKER_CREATED':
                need(engine is not None and worker is None,'worker creation without one retained engine')
                worker=NativeProcess.from_remote(engine,payload['remote_handle'],identity(payload['identity']))
                need(worker.identity()==payload['identity'],'retained worker tuple mismatch')
                with job_lock:enroll_job_process(job,'worker',worker)
                observe_job_processes(job,job_lock,deadline,[worker._identity['pid']])
                stage='worker_created'
            elif kind=='EVENT_BARRIER':
                stage=payload.get('stage');need(stage in KNOWN_BARRIERS,'unknown barrier:'+str(stage))
                if stage=='default_refusal_ready':
                    need(action not in ('Stage','StageStatus','StageRecover') and engine is None and worker is None,
                         'default refusal diagnostic barrier on execution path')
                    observe_job_processes(job,job_lock,deadline)
            elif kind=='RESULT_START':
                need(engine_start is None and type(payload.get('launch_entries')) is int and
                     type(payload.get('created_workers')) is int and
                     payload['launch_entries']==payload['created_workers']==1,'engine launch counter shape')
                engine_start=payload
                continue
            elif kind in ('ENGINE_READY','READ_ONLY_RESULT') or kind.startswith('RESULT_'):
                continue
            elif kind=='CONTROLLER_RESULT':
                completion=payload
                terminal='COMPLETED' if action=='Stage' and payload.get('phase')=='COMPLETED' else 'READ_ONLY'
                need(payload.get('engine_exit')==0 and payload.get('engine_handle_closed') is True,'controller engine custody unresolved')
                break
            elif kind=='REFUSED':
                if engine is not None:
                    need(payload.get('engine_exit')==2 and payload.get('engine_handle_closed') is True,
                         'refusal engine creating handle unresolved')
                terminal='REFUSED';break
            else:raise QualificationRefusal('unknown controller frame:'+kind)
            if stage is not None:
                if worker is not None and monitor and stage in ('after_commit:STARTED','worker_after_effect'):
                    snapshot=http_snapshot(instance,source['source_sha256'],worker,observation_lock,True)
                    need(snapshot['stage'].get('phase')=='STARTED','active monitor phase differs')
                    snapshots.append({'at_barrier':stage,**snapshot})
                if stage==cut:
                    with job_lock:request_job_termination(job)
                    cut_reached=True;terminal='INJECTED_PROCESS_CRASH';break
                channel.send('ACK_BARRIER',{'stage':stage},deadline)
        need(not cut or cut_reached,'declared cut not reached')
        if terminal=='REFUSED' and worker is not None:
            # A known refusal after effect uncertainty is not a replay-safe exit.
            with job_lock:
                if job.active_processes():request_job_termination(job)
        codes={}
        for name,handle in (('worker',worker),('engine',engine),('controller',controller)):
            if handle is None:continue
            with observation_lock:
                code=handle.wait(max(0,min(5,deadline-time.monotonic())))
                need(code is not None,'unsignaled retained '+name)
                if terminal in ('COMPLETED','READ_ONLY'):need(code==0,'successful route exit differs:'+name)
                handle.close();codes[name]=code;native_records[name]=process_record(handle,code)
        if terminal=='REFUSED':need(codes.get('controller')==2,'refusal controller exit differs')
        counts=event_counts(events)
        counts['created_workers']=int(worker is not None)
        counts['launch_entries']=0 if engine_start is None else engine_start['launch_entries']
        need(counts['launch_entries']==counts['launch_barrier_entries'],'engine attempt and launch barrier counters differ')
        need(counts['created_workers']==counts['emitted_worker_created_frames'],'worker frame and duplicated native handle counters differ')
        if worker is not None:need(engine_start is not None and engine_start['identity']==worker._identity,'engine creation counter/retained worker tuple differs')
        return {'terminal':terminal,'action':action,'cut':cut,'cut_reached':cut_reached,'events':events,
                **counts,'native_processes':native_records,'completion':completion,'http_snapshots':snapshots,
                'retained_handles_closed':all(v['closed'] for v in native_records.values()),
                'command':args,'creationflags':CREATE_NO_WINDOW,'engine_start_counters':None if engine_start is None else {k:engine_start[k] for k in ('launch_entries','created_workers')},
                'created_worker_count_basis':'DUPLICATED_RETAINED_NATIVE_HANDLE_AND_VERIFIED_PID_BIRTH',
                'outer_bootstrap_after_job_assignment':True}
    except BaseException as exc:
        failure=type(exc).__name__+':'+str(exc)
        # A failed job query cannot suppress cleanup through an independent
        # known creator handle. Never repeat an entered job-termination call.
        job_cleanup_error=None;job_termination_entered=False
        try:
            with job_lock:
                if not job.closed and not job.api.frozen and job.active_processes():
                    job_termination_entered=True;request_job_termination(job)
        except BaseException as cleanup_error:
            job_cleanup_error=type(cleanup_error).__name__+':'+str(cleanup_error)
            failure+='|JOB_CLEANUP:'+job_cleanup_error
        finally:
            for handle in (worker,engine,controller):
                if handle is not None and not handle.closed and not handle.api.frozen:
                    with observation_lock:
                        uncontained=not assigned or ((job.api.frozen or job_cleanup_error is not None) and not job_termination_entered)
                        if uncontained and handle.wait(0) is None:handle.terminate()
                        code=handle.wait(5)
                        if code is not None:handle.close()
                        native_records[('worker' if handle is worker else 'engine' if handle is engine else 'controller')]=process_record(handle,code)
            if controller is None and child.returncode is None:
                # Constructor failed before ownership transfer: original Popen capability.
                child.terminate();child.wait(timeout=5);child._handle.Close()
        raise
    finally:
        stderr.close()
        if child.returncode is not None:
            for pipe in (child.stdin,child.stdout):
                try:pipe.close()
                except (OSError,ValueError):pass
        write_json(log_root/(action+'-'+session+'.json'),
                   {'terminal':terminal,'failure':failure,'cut':cut,'cut_reached':cut_reached,
                    'command':args,'events':events,'native_processes':native_records,
                    'controller_assigned_to_job':assigned,'outer_bootstrap_sent':bootstrap_sent,
                    'http_snapshots':snapshots})

def concurrent_controllers(instance,source,runtime,job,job_lock):
    outcomes=queue.Queue(maxsize=2);threads=[]
    def observe_engines():
        with job_lock:
            pids=sorted(pid for pid,row in job._m4_observation['known'].items() if row['role']=='engine')
            need(len(pids)==2,'concurrent engine enrollment differs')
            observe_job_processes(job,job_lock,instance['deadline'],pids)
    engine_sync=threading.Barrier(2,action=observe_engines)
    def run():
        try:outcomes.put((True,drive_controller(instance,source,runtime,job,job_lock,
                          engine_sync=engine_sync)))
        except BaseException as exc:outcomes.put((False,exc))
    for _ in range(2):
        thread=threading.Thread(target=run,daemon=True);thread.start();threads.append(thread)
    result=[]
    for _ in range(2):
        left=max(0,instance['deadline']-time.monotonic())
        try:ok,value=outcomes.get(timeout=min(50,left))
        except queue.Empty:raise QualificationRefusal('concurrent controller deadline')
        if not ok:raise value
        result.append(value)
    for thread in threads:thread.join(timeout=2);need(not thread.is_alive(),'controller thread remained live')
    return result

def prepare_row(row_root,source,runtime,deadline):
    from m4_admission import build_instance,prepare_instance
    row_root.mkdir(exist_ok=False)
    root=row_root/'instance';built=build_instance(root,source['root'],source['source_sha256'],runtime_inputs(runtime))
    prepared=prepare_instance(root,built['binding'],built['expected'])
    # Private sealing key is deliberately never copied into a report/instance dict.
    prepared.pop('key_b64',None)
    instance={'root':root,'report_root':row_root/'process_logs','deadline':deadline,**built}
    write_json(row_root/'INPUT_ADMISSION.json',{'binding':built['binding'],'expected':built['expected'],
               'policy_sha256':built['policy_sha256'],'source_manifest_sha':built['source_manifest_sha'],
               'admission':prepared})
    return instance

def run_row(base,row,source,runtime,deadline):
    from m4_native import OwnedJob
    from m4_engine import read_projection,authority_image
    from m4_admission import analysis_bytes
    label,cut,phase,effects,created=row;folder=Path(base)/label;instance=prepare_row(folder,source,runtime,deadline)
    job=OwnedJob();accounting_before=job.accounting();lock=threading.RLock();executions=[];cleanup=[];result=None
    try:
        primary=concurrent_controllers(instance,source,runtime,job,lock) if label=='concurrent_intents' else [drive_controller(instance,source,runtime,job,lock,cut)]
        executions.extend(primary)
        until_empty(job,min(deadline,time.monotonic()+5),lock)
        primary_accounting=settled_job_evidence(job,primary,accounting_before)
        job.close();primary_job_calls=list(job.calls)
        cleanup.append('PRIMARY_JOB_EMPTY_AND_CLOSED')
        before_probe=authority_image(instance['root'])
        logical_before=read_projection(instance['root'],instance['binding'],live=False)
        no_capabilities(logical_before);job=OwnedJob();accounting_before=job.accounting()
        probe=drive_controller(instance,source,runtime,job,lock,monitor=False)
        probe['purpose']='COLD_REBOOTSTRAP_REPLAY_PROBE';executions.append(probe)
        until_empty(job,min(deadline,time.monotonic()+5),lock)
        probe_accounting=settled_job_evidence(job,[probe],accounting_before)
        job.close();probe_job_calls=list(job.calls)
        cleanup.append('COLD_PROBE_JOB_EMPTY_AND_CLOSED')
        recovery=read_projection(instance['root'],instance['binding'],live=False)
        need(authority_image(instance['root'])==before_probe,'cold receiver refusal changed DB/nonemptyWAL bytes')
        need({k:logical_before.get(k) for k in LOGICAL_AUTHORITY}==
             {k:recovery.get(k) for k in LOGICAL_AUTHORITY},'cold refusal committed authority changes')
        artifact=instance['root']/'worktree/ANALYSIS.md';effect_count=int(artifact.exists())
        need({p.name for p in artifact.parent.iterdir()}==({'INPUT.txt','ANALYSIS.md'} if effect_count else {'INPUT.txt'}),
             'unexpected worktree effect file')
        if effect_count:
            expected=analysis_bytes((instance['root']/'worktree/INPUT.txt').read_bytes(),instance['binding'])
            need(artifact.read_bytes()==expected,'actual analysis bytes mismatch')
        result=check_row(row,executions,recovery,effect_count)
        status=http_snapshot(instance,source['source_sha256'],expected_active=False)
        need(status['stage'].get('phase')==phase,'terminal HTTP phase differs')
        if phase=='COMPLETED':need(status['stage'].get('semantic_success') is True,'terminal HTTP semantic success missing')
        if phase=='STARTED':need(status['stage'].get('view')=='RECONCILIATION_REQUIRED','uncertain HTTP view differs')
        result.update(binding=instance['binding'],root=str(instance['root']),executions=executions,recovery=recovery,
                      primary_job_calls=primary_job_calls,cold_probe_job_calls=probe_job_calls,cleanup=cleanup,
                      primary_job_accounting=primary_accounting,cold_probe_job_accounting=probe_accounting,
                      cold_probe_authority_before=before_probe,cold_probe_authority_after=authority_image(instance['root']),
                      terminal_http=status,ready=False,replay_permitted=False,apply_permitted=False,power_loss_proven=False)
    except BaseException as exc:
        try:
            with lock:
                if not job.closed and not job.api.frozen and job.active_processes():request_job_termination(job)
            if not job.closed and not job.api.frozen:until_empty(job,min(deadline,time.monotonic()+5),lock);job.close()
            cleanup.append('OWNED_JOB_SETTLED_ON_FAILURE')
        except BaseException as failure:cleanup.append('UNRESOLVED_CLEANUP:'+type(failure).__name__+':'+str(failure))
        result={'row':label,'qualified':False,'error':type(exc).__name__+':'+str(exc),
                'binding':instance['binding'],'root':str(instance['root']),'executions':executions,
                'cleanup':cleanup,'job_calls':list(job.calls),'ready':False,'replay_permitted':False}
    write_json(folder/'RESULT.json',result)
    return result,instance

def restore_source(source,destination):
    destination=Path(destination);destination.mkdir(exist_ok=False)
    for name,pin in source['manifest']['files'].items():
        raw=(source['root']/name).read_bytes();need(sha(raw)==pin['sha256'],'restore source drift')
        target=destination/name;target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('xb') as out:out.write(raw);out.flush();os.fsync(out.fileno())
    with (destination/'SOURCE_MANIFEST.json').open('xb') as out:
        out.write((source['root']/'SOURCE_MANIFEST.json').read_bytes());out.flush();os.fsync(out.fileno())
    restored=source_snapshot(destination,source['source_sha256'])
    need(restored['manifest_sha256']==source['manifest_sha256'],'restored manifest differs')
    return restored

def readonly_capture(root,source_sha,report):
    from m4_engine import read_projection,authority_image
    value=read_projection(root,source_sha,live=False);no_capabilities(value)
    instance={'root':Path(root),'binding':value['binding']}
    before=authority_image(root);snapshot=http_snapshot(instance,source_sha,expected_active=False)
    after=authority_image(root);need(before==after,'readonly HTTP/UI reads changed authority')
    need(snapshot['stage'].get('phase')=='STARTED' and snapshot['stage'].get('view')=='RECONCILIATION_REQUIRED','restored monitor recovery differs')
    result={'qualified':True,'projection':value,'http':snapshot,'authority_before':before,'authority_after':after,
            'effect_workers_created':0,'launch_entries':0,'effects_added':0,'dml_permitted':False}
    write_json(report,result)
    return 0

def readonly_child_capture(instance,source,runtime,folder,deadline):
    from m4_entry import fixed_python_args
    from m4_native import NativeProcess,OwnedJob
    from m4_wire import raw_write,raw_read
    report=Path(folder)/'RESTORED_HTTP_RESULT.json'
    args=fixed_python_args(source['root'],'m4_qualification.py',['--readonly-capture','--bootstrap-wait',
          '--root',str(instance['root']),'--source-sha',source['source_sha256'],'--report',str(report)])
    job=OwnedJob();accounting_before=job.accounting();child=None;native=None;assigned=False
    with (Path(folder)/'RESTORED_HTTP.stderr').open('xb') as err:
        try:
            child=subprocess.Popen(args,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,bufsize=0,cwd=source['root'],close_fds=True,creationflags=CREATE_NO_WINDOW)
            native=NativeProcess(child);job.assign(native);assigned=True
            enroll_job_process(job,'readonly_monitor',native)
            private_ready=raw_read(child.stdout,min(deadline,time.monotonic()+10))
            need(private_ready=={'v':1,'kind':'READONLY_PRIVATE_READY','source_sha':source['source_sha256'],
                                 'pid':native._identity['pid']},'readonly private readiness differs')
            # Pipe provenance is the creating Popen capability. This PID is only
            # a consistency field, never a process reopen or liveness authority.
            write_json(Path(folder)/'RESTORED_HTTP_PRIVATE_READY.json',private_ready)
            observe_job_processes(job,threading.RLock(),deadline)
            raw_write(child.stdin,{'v':1,'permit_readonly':True,'source_sha':source['source_sha256']},min(deadline,time.monotonic()+5))
            code=native.wait(min(20,max(0,deadline-time.monotonic())))
            need(code==0,'restored HTTP runtime failed');native.close()
            until_empty(job,min(deadline,time.monotonic()+5),threading.RLock())
            accounting=settled_job_evidence(job,[{'native_processes':{'readonly_monitor':process_record(native,code)}}],accounting_before)
            job.close()
            return {'process':process_record(native,code),'job_calls':list(job.calls),'job_accounting':accounting,
                    'result':json.loads(report.read_bytes()),'command':args,'private_ready':private_ready,
                    'private_readonly_grant_after_metadata':True}
        finally:
            job_termination_entered=False;job_cleanup_failed=False
            try:
                if not job.closed and not job.api.frozen and job.active_processes():
                    job_termination_entered=True;request_job_termination(job)
            except BaseException:
                job_cleanup_failed=True;raise
            finally:
                # Retained child custody is independent of an uncertain job API.
                # An entered unknown termination is only observed, never retried.
                if native is not None and not native.closed and not native.api.frozen:
                    uncontained=not assigned or ((job.closed or job.api.frozen or job_cleanup_failed) and not job_termination_entered)
                    if uncontained and native.wait(0) is None:native.terminate()
                    if native.wait(5) is not None:native.close()
                elif native is None and child is not None:
                    # Native wrapper construction did not transfer creator ownership.
                    if child.returncode is None:child.terminate();child.wait(timeout=5)
                    child._handle.Close()
                if child is not None and child.returncode is not None:
                    for pipe in (getattr(child,'stdin',None),getattr(child,'stdout',None)):
                        if pipe is not None:pipe.close()
            if not job.closed and not job.api.frozen and job.active_processes()==0:job.close()

def run_s3(instance,source,runtime,folder,deadline):
    from m4_native import FilePins
    folder=Path(folder);folder.mkdir(exist_ok=False)
    restored=restore_source(source,folder/'source-restored')
    with FilePins(restored['root'],list(restored['manifest']['files'])+['SOURCE_MANIFEST.json'],max_bytes=1024*1024) as held:
        need(all(sha(held.buffers[n])==p['sha256'] for n,p in restored['manifest']['files'].items()),
             'restored held source differs')
        return _run_s3_held(instance,restored,runtime,folder,deadline)

def require_readonly_unknown(execution):
    need(execution['terminal']=='READ_ONLY' and
         execution['created_workers']==execution['launch_entries']==0,'public readonly path launched effect worker')
    view=execution['completion']['view'];no_capabilities(view)
    need(view.get('phase')=='STARTED' and view.get('view')=='RECONCILIATION_REQUIRED' and
         view.get('outcome_unknown') is True and not view.get('quarantined'),
         'public readonly path did not report exact STARTED/unknown outcome')

def _run_s3_held(instance,restored,runtime,folder,deadline):
    from m4_engine import read_projection,authority_image
    from m4_native import OwnedJob
    before=authority_image(instance['root'])
    need('transaction.sqlite' in before and 'transaction.sqlite-wal' in before,
         'S3 requires the actual nonempty crash WAL for the whole preservation window')
    artifact=instance['root']/'worktree/ANALYSIS.md';effect=sha(artifact.read_bytes())
    job=OwnedJob();accounting_before=job.accounting();lock=threading.RLock()
    try:
        diagnostic=drive_controller(instance,restored,runtime,job,lock,action='StageRecover',monitor=False)
        require_readonly_unknown(diagnostic)
        until_empty(job,min(deadline,time.monotonic()+5),lock)
        recovery_accounting=settled_job_evidence(job,[diagnostic],accounting_before);job.close()
    finally:
        if not job.closed and not job.api.frozen:
            if job.active_processes():request_job_termination(job)
            until_empty(job,min(deadline,time.monotonic()+5),lock);job.close()
    recovery_job_calls=list(job.calls)
    job=OwnedJob();accounting_before=job.accounting()
    try:
        status=drive_controller(instance,restored,runtime,job,lock,action='StageStatus',monitor=False)
        require_readonly_unknown(status)
        until_empty(job,min(deadline,time.monotonic()+5),lock)
        status_accounting=settled_job_evidence(job,[status],accounting_before);job.close()
    finally:
        if not job.closed and not job.api.frozen:
            if job.active_processes():request_job_termination(job)
            until_empty(job,min(deadline,time.monotonic()+5),lock);job.close()
    status_job_calls=list(job.calls)
    job=OwnedJob();accounting_before=job.accounting()
    try:
        restart=drive_controller(instance,restored,runtime,job,lock,action='Stage',monitor=False)
        restart['purpose']='S3_RESTORED_SAME_B_COLD_RESTART_REFUSAL'
        require_cold_fence(restart)
        until_empty(job,min(deadline,time.monotonic()+5),lock)
        restart_accounting=settled_job_evidence(job,[restart],accounting_before);job.close()
    finally:
        if not job.closed and not job.api.frozen:
            if job.active_processes():request_job_termination(job)
            until_empty(job,min(deadline,time.monotonic()+5),lock);job.close()
    need(authority_image(instance['root'])==before,'S3 restored same-cycle restart changed DB/nonemptyWAL')
    captured=readonly_child_capture(instance,restored,runtime,folder,deadline)
    recovery=read_projection(instance['root'],instance['binding'],live=False);no_capabilities(recovery)
    need(recovery.get('phase')=='STARTED' and recovery.get('authority_unchanged') is True,'S3 sameB recovery phase differs')
    after=authority_image(instance['root']);need(before==after,'S3 public/monitor/UI window changed DB/nonemptyWAL')
    need(sha(artifact.read_bytes())==effect,'S3 changed effect bytes')
    result={'scenario':'S3','qualified':True,'binding':instance['binding'],'same_transaction_B':True,
            'public_recovery':diagnostic,'recovery_job_calls':recovery_job_calls,'recovery_job_accounting':recovery_accounting,
            'public_status':status,'status_job_calls':status_job_calls,'status_job_accounting':status_accounting,
            'same_cycle_restart_refusal':restart,'restart_job_calls':list(job.calls),'restart_job_accounting':restart_accounting,'restored_http_runtime':captured,
            'restored_source_sha256':restored['source_sha256'],'recovery':recovery,
            'authority_before':before,'authority_after':after,'effect_sha256':effect,
            'diagnostic_processes_created':sum(v['expected_unique_retained_processes'] for v in (recovery_accounting,status_accounting,restart_accounting,captured['job_accounting'])),
            'diagnostic_process_count_basis':'EXPLICIT_RETAINED_CONTROLLERS_ENGINES_AND_READONLY_CHILD',
            'incidental_console_hosts_observed':sum(len(v['incidental_console_hosts']) for v in (recovery_accounting,status_accounting,restart_accounting,captured['job_accounting'])),
            'total_owned_job_processes':sum(v['after']['total_processes']-v['before']['total_processes'] for v in (recovery_accounting,status_accounting,restart_accounting,captured['job_accounting'])),
            'effect_workers_created':0,'launch_entries':0,'effects_added':0,'dml_permitted':False,
            'ready':False,'replay_permitted':False,'apply_permitted':False,'power_loss_proven':False}
    write_json(folder/'RESULT.json',result);return result

def failure_controls(base,source,runtime,deadline):
    from m4_engine import read_projection,authority_image
    base=Path(base);base.mkdir(exist_ok=False);rows=[]
    for label in ('missing_journal','corrupt_journal','corrupt_key'):
        folder=base/label;instance=prepare_row(folder,source,runtime,deadline);root=instance['root']
        if label=='missing_journal':(root/'transaction.sqlite').unlink()
        elif label=='corrupt_journal':(root/'transaction.sqlite').write_bytes(b'M4 corrupt disposable journal\x00')
        else:(root/'owner.key').write_bytes(b'M4 invalid DPAPI cipher\x00')
        before=authority_image(root);report=read_projection(root,instance['binding'],live=False)
        need(report.get('phase')=='QUARANTINED','bad recovery did not quarantine:'+label);no_capabilities(report)
        need(report.get('authority_unchanged') is None and report.get('receipts_authenticated')==[],'quarantine inflated evidence')
        need(authority_image(root)==before,'quarantine changed authority:'+label)
        row={'row':label,'qualified':True,'recovery':report,'actual_byte_failure':True,
             'launch_entries':0,'created_workers':0,'effect_count':0,'authority_bytes_unchanged_by_harness':True}
        write_json(folder/'RESULT.json',row);rows.append(row)
    # Exercise default-route M2 refusal through the actual public PS script.
    folder=base/'default_route_refusal';instance=prepare_row(folder,source,runtime,deadline)
    from m4_native import OwnedJob
    job=OwnedJob();accounting_before=job.accounting();lock=threading.RLock()
    try:
        execution=drive_controller(instance,source,runtime,job,lock,action='Start',monitor=False)
        need(execution['terminal']=='REFUSED' and execution['launch_entries']==execution['created_workers']==0,'nonstage route launched')
        reasons=[e['payload'].get('reason') for e in execution['events'] if e['kind']=='REFUSED']
        need(reasons==['M2_SECTION_BINDING_UNPROVEN'],'default route wrong refusal')
        until_empty(job,min(deadline,time.monotonic()+5),lock)
        accounting=settled_job_evidence(job,[execution],accounting_before);job.close()
        row={'row':'default_route_refusal','qualified':True,'execution':execution,'job_calls':list(job.calls),'job_accounting':accounting}
        write_json(folder/'RESULT.json',row);rows.append(row)
    finally:
        if not job.closed and not job.api.frozen:
            if job.active_processes():request_job_termination(job)
            until_empty(job,min(deadline,time.monotonic()+5),lock);job.close()
    return {'all_qualified':len(rows)==4 and all(r['qualified'] for r in rows),'rows':rows}

def run_batch(args):
    from m4_native import namespace_root,FilePins
    root=namespace_root(args.root);source=source_snapshot(Path(__file__).parent,args.source_sha)
    need(not root.exists(),'batch already exists: TERMINAL_NO_REPLAY');root.mkdir(parents=True,exist_ok=False)
    started=time.monotonic();deadline=started+360
    result={'status':'INCOMPLETE','source_sha256':args.source_sha,'planning_only':False,
            'scope':'ONE_ISOLATED_M4_STAGING_INTEGRATION','production_execution':False,
            'native_image_chain_proven':False,'apply_permitted':False,'durability_proven':False,
            'native_run_ready':False,'replay_permitted':False,'power_loss_proven':False}
    write_json(root/'ATTEMPT.json',{'source_sha256':args.source_sha,'source_manifest_sha256':source['manifest_sha256'],
               'source_files':source['manifest']['files'],'rows':[dict(zip(('row','cut','phase','effects','workers'),r)) for r in ROWS],
               'acceptance_cases':['S1_normal','S2_interrupted','S3_same_B_readonly_restoration'],
               'deadline_seconds':360,'no_replay':True,'started_utc':dt.datetime.now(dt.timezone.utc).isoformat()})
    try:
        names=list(source['manifest']['files'])+['SOURCE_MANIFEST.json']
        with FilePins(source['root'],names,max_bytes=1024*1024) as held:
            for n,p in source['manifest']['files'].items():need(sha(held.buffers[n])==p['sha256'],'held source differs:'+n)
            runtime=runtime_proof();result['runtime']=runtime
            result['pure_controls']=pure_controls(source,root)
            result['failure_controls']=failure_controls(root/'failure_controls',source,runtime,deadline)
            need(result['failure_controls']['all_qualified'],'failure controls refused')
            rows=[];result['native_rows']=rows;last=None
            for row in ROWS:
                need(time.monotonic()<deadline,'qualification deadline')
                value,instance=run_row(root,row,source,runtime,deadline);rows.append(value)
                print(json.dumps({'row':row[0],'qualified':value['qualified'],'error':value.get('error')}),flush=True)
                need(value['qualified'],'native row failed:'+row[0]);last=instance
            result['native_rows']=rows;need(last is not None,'no B instance')
            result['S3']=run_s3(last,source,runtime,root/'S3_same_B',deadline)
            source_snapshot(source['root'],args.source_sha)
            for label in ('python','powershell'):
                need(sha(Path(runtime[label]['path']).read_bytes())==runtime[label]['sha256'],'runtime drift:'+label)
            need(time.monotonic()<deadline,'qualification deadline after final reconciliation')
            result['status']='PASS';result['all_native_rows_qualified']=len(rows)==13 and all(x['qualified'] for x in rows)
    except BaseException as exc:
        result['status']='STOPPED_NO_REPLAY';result['error']=type(exc).__name__+':'+str(exc)
    finally:
        result['elapsed_seconds']=time.monotonic()-started;write_json(root/'RESULT.json',result)
    print(json.dumps({k:v for k,v in result.items() if k not in ('native_rows','failure_controls','S3')}),flush=True)
    return 0 if result['status']=='PASS' else 2

def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--root',required=True)
    parser.add_argument('--source-sha',required=True);parser.add_argument('--readonly-capture',action='store_true')
    parser.add_argument('--bootstrap-wait',action='store_true');parser.add_argument('--report')
    args=parser.parse_args(argv)
    if args.readonly_capture:
        need(args.report is not None,'readonly report required')
        if args.bootstrap_wait:
            # Load the exact read-only tree before its diagnostic readiness gate;
            # imports confer no Store/write/start capability.
            import m4_engine,maia_panel
            from m4_wire import raw_read,raw_write
            inp=getattr(sys.stdin.buffer,'raw',sys.stdin.buffer)
            out=getattr(sys.stdout.buffer,'raw',sys.stdout.buffer)
            raw_write(out,{'v':1,'kind':'READONLY_PRIVATE_READY','source_sha':args.source_sha,'pid':os.getpid()},time.monotonic()+10)
            grant=raw_read(inp,time.monotonic()+10)
            need(grant=={'v':1,'permit_readonly':True,'source_sha':args.source_sha},'readonly parent grant')
        return readonly_capture(args.root,args.source_sha,args.report)
    need(not args.bootstrap_wait and args.report is None,'batch argument mix')
    return run_batch(args)

if __name__=='__main__':
    raise SystemExit(main())
