Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

function Get-UtcNowIso {
    return [DateTime]::UtcNow.ToString("o")
}

function Get-Sha256File {
    param([Parameter(Mandatory=$true)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { throw "File not found: $Path" }
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        $stream = [System.IO.File]::OpenRead($Path)
        try {
            $hash = $sha.ComputeHash($stream)
        } finally { $stream.Dispose() }
    } finally { $sha.Dispose() }
    return ([BitConverter]::ToString($hash) -replace '-', '').ToLowerInvariant()
}

function Write-JsonAtomic {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)]$Object,
        [int]$Depth = 40
    )
    $dir = Split-Path -Parent $Path
    if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    $tmp = Join-Path $dir (".tmp-" + [Guid]::NewGuid().ToString("N") + ".json")
    $bak = $Path + ".bak"
    $json = $Object | ConvertTo-Json -Depth $Depth
    [System.IO.File]::WriteAllText($tmp, $json, (New-Object System.Text.UTF8Encoding($false)))
    if (Test-Path -LiteralPath $Path) {
        try {
            [System.IO.File]::Replace($tmp, $Path, $bak, $true)
        } catch {
            # Same-volume rename fallback. Keep a recoverable backup.
            Copy-Item -LiteralPath $Path -Destination $bak -Force
            Move-Item -LiteralPath $tmp -Destination $Path -Force
        }
    } else {
        Move-Item -LiteralPath $tmp -Destination $Path -Force
    }
}

function Read-JsonFile {
    param([Parameter(Mandatory=$true)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) { throw "JSON not found: $Path" }
    $raw = [System.IO.File]::ReadAllText($Path, [System.Text.Encoding]::UTF8)
    if ([string]::IsNullOrWhiteSpace($raw)) { throw "JSON is empty: $Path" }
    return ($raw | ConvertFrom-Json)
}

function New-DefaultState {
    [pscustomobject]@{
        schema_version = 1
        status = "IDLE"
        run_health = "OK"
        current_run_id = $null
        current_prompt_id = $null
        current_stage = $null
        expected_milestone = $null
        current_worker_pid = $null
        current_worktree = $null
        current_branch = $null
        current_run_dir = $null
        started_utc = $null
        last_heartbeat_utc = $null
        last_log_size = 0
        last_log_change_utc = $null
        verdict = $null
        exit_code = $null
        stop_reason = $null
        supervisor_pid = $null
        transitions = @()
    }
}

function Add-StateTransition {
    param(
        [Parameter(Mandatory=$true)]$State,
        [string]$From,
        [string]$To,
        [string]$PromptId,
        [string]$Reason
    )
    $list = @($State.transitions)
    $list += [pscustomobject]@{
        at_utc = Get-UtcNowIso
        from = $From
        to = $To
        prompt_id = $PromptId
        reason = $Reason
    }
    if ($list.Count -gt 500) { $list = $list[($list.Count-500)..($list.Count-1)] }
    $State.transitions = $list
    return $State
}

function Normalize-VerdictLine {
    param([string]$Line)
    if ($null -eq $Line) { return "" }
    $s = $Line.Trim()
    $s = [regex]::Replace($s, '^\s*#{1,6}\s*', '')
    $s = $s.Trim()
    # Strip common markdown wrappers only at the boundaries.
    while (($s.StartsWith("**") -and $s.EndsWith("**") -and $s.Length -ge 4) -or
           ($s.StartsWith("__") -and $s.EndsWith("__") -and $s.Length -ge 4)) {
        $s = $s.Substring(2, $s.Length - 4).Trim()
    }
    # Avoid a literal backtick inside a quoted PowerShell string; PS 5.1 parses it as an escape.
    $tick = [char]96
    if ($s.Length -ge 2 -and $s[0] -eq $tick -and $s[$s.Length - 1] -eq $tick) {
        $s = $s.Substring(1, $s.Length - 2).Trim()
    }
    # Keep module source ASCII-only for Windows PowerShell 5.1. Build dash characters by code point.
    $emdash = [string][char]0x2014
    $endash = [string][char]0x2013
    $s = $s.Replace($endash, $emdash)
    $s = [regex]::Replace($s, '\s+-\s+', (' ' + $emdash + ' '))
    return $s
}

function Get-CanonicalVerdictUniverse {
    param([Parameter(Mandatory=$true)][string]$PromptsDir)
    $vals = New-Object System.Collections.Generic.List[string]
    Get-ChildItem -LiteralPath $PromptsDir -Filter "*.manifest.json" -File -ErrorAction SilentlyContinue | ForEach-Object {
        try {
            $m = Read-JsonFile $_.FullName
            foreach ($v in @($m.allowed_verdicts)) {
                if (-not [string]::IsNullOrWhiteSpace([string]$v)) { $vals.Add((Normalize-VerdictLine ([string]$v))) }
            }
        } catch {}
    }
    return @($vals | Sort-Object -Unique)
}

function Get-StrictVerdict {
    param(
        [Parameter(Mandatory=$true)][string]$FinalPath,
        [Parameter(Mandatory=$true)]$Manifest,
        [Parameter(Mandatory=$true)][string]$PromptsDir
    )
    if (-not (Test-Path -LiteralPath $FinalPath -PathType Leaf)) {
        return [pscustomobject]@{ ok=$false; verdict=$null; reason="FINAL_MISSING" }
    }
    $text = [System.IO.File]::ReadAllText($FinalPath, [System.Text.Encoding]::UTF8)
    if ([string]::IsNullOrWhiteSpace($text)) {
        return [pscustomobject]@{ ok=$false; verdict=$null; reason="FINAL_EMPTY" }
    }
    $allowed = @($Manifest.allowed_verdicts | ForEach-Object { Normalize-VerdictLine ([string]$_) })
    if ($allowed.Count -eq 0) {
        return [pscustomobject]@{ ok=$false; verdict=$null; reason="NO_ALLOWED_VERDICTS" }
    }

    $lines = @($text -split "`r?`n" | ForEach-Object { Normalize-VerdictLine $_ } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
    $primary = $null
    foreach ($line in ($lines | Select-Object -First 12)) {
        if ($allowed -contains $line) { $primary = $line; break }
    }
    if ($null -eq $primary) {
        return [pscustomobject]@{ ok=$false; verdict=$null; reason="PRIMARY_VERDICT_NOT_FOUND_IN_HEADER" }
    }

    $universe = @(Get-CanonicalVerdictUniverse -PromptsDir $PromptsDir)
    $exactFound = @()
    foreach ($line in $lines) {
        if ($universe -contains $line) { $exactFound += $line }
    }
    $distinct = @($exactFound | Sort-Object -Unique)
    if ($distinct.Count -gt 1) {
        return [pscustomobject]@{ ok=$false; verdict=$null; reason=("CONFLICTING_VERDICTS:" + ($distinct -join "|")) }
    }
    if (-not ($allowed -contains $primary)) {
        return [pscustomobject]@{ ok=$false; verdict=$null; reason="VERDICT_NOT_ALLOWED_FOR_STAGE" }
    }
    return [pscustomobject]@{ ok=$true; verdict=$primary; reason="OK" }
}

function Get-PromptManifestPath {
    param([string]$PromptsDir,[string]$PromptId)
    return (Join-Path $PromptsDir ($PromptId + ".manifest.json"))
}

function Get-PromptTextPath {
    param([string]$PromptsDir,$Manifest)
    return (Join-Path $PromptsDir ([string]$Manifest.prompt_file))
}

function Test-PromptManifest {
    param(
        [Parameter(Mandatory=$true)][string]$PromptsDir,
        [Parameter(Mandatory=$true)][string]$PromptId
    )
    $mp = Get-PromptManifestPath $PromptsDir $PromptId
    if (-not (Test-Path -LiteralPath $mp -PathType Leaf)) {
        return [pscustomobject]@{ok=$false;reason="MANIFEST_MISSING:$mp";manifest=$null}
    }
    try { $m = Read-JsonFile $mp } catch {
        return [pscustomobject]@{ok=$false;reason=("MANIFEST_INVALID:" + $_.Exception.Message);manifest=$null}
    }
    foreach ($field in @("schema_version","prompt_id","milestone","stage","prompt_file","sha256","worktree","branch","idempotency_policy","allowed_verdicts","transitions")) {
        if ($null -eq $m.$field) { return [pscustomobject]@{ok=$false;reason="MANIFEST_FIELD_MISSING:$field";manifest=$m} }
    }
    if ([string]$m.prompt_id -ne $PromptId) {
        return [pscustomobject]@{ok=$false;reason="PROMPT_ID_MISMATCH";manifest=$m}
    }
    $pp = Get-PromptTextPath $PromptsDir $m
    if (-not (Test-Path -LiteralPath $pp -PathType Leaf)) {
        return [pscustomobject]@{ok=$false;reason="PROMPT_FILE_MISSING:$pp";manifest=$m}
    }
    $actual = Get-Sha256File $pp
    if ($actual -ne ([string]$m.sha256).ToLowerInvariant()) {
        return [pscustomobject]@{ok=$false;reason="PROMPT_HASH_MISMATCH";manifest=$m}
    }
    if (@($m.allowed_verdicts).Count -eq 0) {
        return [pscustomobject]@{ok=$false;reason="ALLOWED_VERDICTS_EMPTY";manifest=$m}
    }
    if (@("never_replay","safe_retry_once","manual_only") -notcontains [string]$m.idempotency_policy) {
        return [pscustomobject]@{ok=$false;reason="BAD_IDEMPOTENCY_POLICY";manifest=$m}
    }
    return [pscustomobject]@{ok=$true;reason="OK";manifest=$m}
}

function Test-ManifestTransitionTargets {
    param([string]$PromptsDir,$Manifest)
    foreach ($p in $Manifest.transitions.PSObject.Properties) {
        $target = [string]$p.Value
        if ($target -in @("STOP_HUMAN_REVIEW","PIPELINE_COMPLETE","STOPPED")) { continue }
        $mp = Get-PromptManifestPath $PromptsDir $target
        if (-not (Test-Path -LiteralPath $mp -PathType Leaf)) {
            return [pscustomobject]@{ok=$false;reason="TRANSITION_TARGET_MISSING:$target"}
        }
    }
    return [pscustomobject]@{ok=$true;reason="OK"}
}

function Test-CanReplayPrompt {
    param($Manifest,$State,[string]$RunsDir)
    $policy = [string]$Manifest.idempotency_policy
    if ($policy -eq "manual_only") { return $false }
    if ($policy -eq "never_replay") {
        $id = [string]$Manifest.prompt_id
        if ([string]$State.current_prompt_id -eq $id -and
            ($State.current_run_id -or $State.current_worker_pid -or $State.current_run_dir)) { return $false }
        if ($RunsDir) {
            if (-not (Test-Path -LiteralPath $RunsDir -PathType Container)) { return $false }
            foreach ($run in @(Get-ChildItem -LiteralPath $RunsDir -Directory -ErrorAction Stop)) {
                if ($run.Name -match ('-' + [regex]::Escape($id) + '-')) { return $false }
                $record = Join-Path $run.FullName 'supervisor-run.json'
                if (Test-Path -LiteralPath $record) {
                    try { if ([string](Read-JsonFile $record).prompt_id -eq $id) { return $false } }
                    catch { return $false }
                }
            }
        }
        $events = @($State.transitions | Where-Object { $_.prompt_id -eq $id })
        $recovered = @{}
        foreach ($event in $events) {
            if ([string]$event.to -eq 'IDLE' -and
                [string]$event.reason -match '^PREFLIGHT_RECOVERED:(.+)$') {
                $recovered[$Matches[1]] = $true
            }
        }
        foreach ($event in $events) {
            if ([string]$event.to -in @('ACTIVE','COMPLETED','PIPELINE_COMPLETE','INTERRUPTED')) { return $false }
            if ([string]$event.reason -like 'RUN_STARTED:*') { return $false }
            if ([string]$event.to -eq 'STOP_HUMAN_REVIEW') {
                $preflightOnly = ([string]$event.reason -match '^START_FAILURE:Preflight failed: [A-Z0-9_:-]+$') -or
                    ([string]$event.reason -match '^START_FAILURE:Preflight failed: CODEX_ACTIVITY_UNVERIFIED:PIDS=[0-9,]+; close the owning application normally only after checking its work$')
                $failureAt = if ($event.at_utc -is [DateTime]) {
                    ([DateTime]$event.at_utc).ToUniversalTime().ToString('o')
                } else { [string]$event.at_utc }
                if (-not $preflightOnly -or -not $recovered.ContainsKey($failureAt)) { return $false }
            }
        }
        return $true
    }
    $history = @($State.transitions | Where-Object { $_.prompt_id -eq [string]$Manifest.prompt_id -and $_.to -in @("COMPLETED","STOP_HUMAN_REVIEW","PIPELINE_COMPLETE") })
    if ($policy -eq "safe_retry_once" -and $history.Count -gt 1) { return $false }
    return $true
}

function New-RunId {
    param([string]$PromptId)
    $safe = ($PromptId -replace '[^A-Za-z0-9._-]', '_')
    return ((Get-Date).ToString("yyyyMMdd-HHmmss") + "-" + $safe + "-" + [Guid]::NewGuid().ToString("N").Substring(0,8))
}

function Get-GitBranch {
    param([string]$Worktree)
    $out = & git -C $Worktree rev-parse --abbrev-ref HEAD 2>&1
    if ($LASTEXITCODE -ne 0) { throw "git branch query failed: $out" }
    return (($out | Select-Object -First 1).ToString().Trim())
}

function Get-GitStatusPorcelain {
    param([string]$Worktree)
    $out = & git -C $Worktree status --porcelain=v1 2>&1
    if ($LASTEXITCODE -ne 0) { throw "git status failed: $out" }
    return @($out)
}

function Get-FreeBytesC {
    try { return [int64](Get-PSDrive -Name C).Free } catch { return 0 }
}

function Get-ProcessSnapshot {
    param([string]$TargetWorktree)
    $names = @("codex.exe","node.exe","cargo.exe","rustc.exe","powershell.exe","pwsh.exe")
    $rows = @()
    try {
        $procs = Get-CimInstance Win32_Process | Where-Object { $names -contains $_.Name }
        foreach ($p in $procs) {
            $rows += [pscustomobject]@{
                pid = [int]$p.ProcessId
                ppid = [int]$p.ParentProcessId
                name = [string]$p.Name
                command_line = [string]$p.CommandLine
                executable_path = [string]$p.ExecutablePath
                created_utc = if ($p.CreationDate) { $p.CreationDate.ToUniversalTime().ToString('o') } else { $null }
                created_ticks = if ($p.CreationDate) { [int64]$p.CreationDate.ToUniversalTime().Ticks } else { 0 }
                target_worktree_mentioned = (([string]$p.CommandLine).IndexOf($TargetWorktree,[StringComparison]::OrdinalIgnoreCase) -ge 0)
            }
        }
    } catch { throw ("PROCESS_INSPECTION_FAILED: " + $_.Exception.Message) }
    return $rows
}

function Test-Preflight {
    param(
        [Parameter(Mandatory=$true)]$Config,
        [Parameter(Mandatory=$true)]$Manifest,
        [Parameter(Mandatory=$true)][string]$PromptsDir,
        [Parameter(Mandatory=$true)]$State
    )
    $pp = Test-PromptManifest -PromptsDir $PromptsDir -PromptId ([string]$Manifest.prompt_id)
    if (-not $pp.ok) { return [pscustomobject]@{ok=$false;reason=$pp.reason} }

    $worktree = [string]$Manifest.worktree
    if (-not (Test-Path -LiteralPath $worktree -PathType Container)) {
        return [pscustomobject]@{ok=$false;reason="WORKTREE_MISSING:$worktree"}
    }
    try { $branch = Get-GitBranch $worktree } catch { return [pscustomobject]@{ok=$false;reason=("GIT_BRANCH_ERROR:" + $_.Exception.Message)} }
    if ($branch -ne [string]$Manifest.branch) {
        return [pscustomobject]@{ok=$false;reason="WRONG_BRANCH:$branch"}
    }
    if ([bool]$Manifest.clean_worktree_required) {
        try { $dirty = @(Get-GitStatusPorcelain $worktree) } catch { return [pscustomobject]@{ok=$false;reason=("GIT_STATUS_ERROR:" + $_.Exception.Message)} }
        if ($dirty.Count -gt 0) { return [pscustomobject]@{ok=$false;reason="WORKTREE_DIRTY"} }
    }
    $minBytes = [int64]([double]$Config.min_free_gb * 1GB)
    if ((Get-FreeBytesC) -lt $minBytes) {
        return [pscustomobject]@{ok=$false;reason="LOW_DISK"}
    }

    try { $snap = @(Get-ProcessSnapshot -TargetWorktree $worktree) }
    catch { return [pscustomobject]@{ok=$false;reason=("PROCESS_INSPECTION_FAILED: " + $_.Exception.Message)} }
    if ([bool]$Config.block_if_any_cargo) {
        if (@($snap | Where-Object { $_.name -in @("cargo.exe","rustc.exe") }).Count -gt 0) {
            return [pscustomobject]@{ok=$false;reason="ACTIVE_CARGO_OR_RUSTC"}
        }
    }
    if ([bool]$Config.block_unmanaged_codex) {
        $otherCodex = @($snap | Where-Object { $_.name -eq "codex.exe" })
        $leasePath = Join-Path (Split-Path ([string]$Config.locks_dir) -Parent) 'state\managed-codex-lease.json'
        $lease = $null
        if (Test-Path -LiteralPath $leasePath -PathType Leaf) {
            try { $lease = Read-JsonFile $leasePath }
            catch { return [pscustomobject]@{ok=$false;reason='MANAGED_CODEX_LEASE_INVALID'} }
        }
        if ($null -ne $lease -and [string]$lease.scope_worktree -cne $worktree) {
            return [pscustomobject]@{ok=$false;reason='MANAGED_CODEX_LEASE_SCOPE_MISMATCH'}
        }
        $unmanaged = @($otherCodex | Where-Object {
            -not (Test-ManagedCodexProcess -Process $_ -Lease $lease)
        })
        if ($unmanaged.Count -gt 0) {
            $ids = @($unmanaged | ForEach-Object { $_.pid }) -join ','
            return [pscustomobject]@{
                ok=$false
                reason=("CODEX_ACTIVITY_UNVERIFIED:PIDS=" + $ids + "; close the owning application normally only after checking its work")
            }
        }
    }

    $lockPath = Get-WorktreeLockPath -LocksDir ([string]$Config.locks_dir) -Worktree $worktree
    if (Test-Path -LiteralPath $lockPath) {
        try {
            $lk = Read-JsonFile $lockPath
            if ($lk.run_id -ne $State.current_run_id) {
                return [pscustomobject]@{ok=$false;reason="WORKTREE_LOCKED"}
            }
        } catch { return [pscustomobject]@{ok=$false;reason="WORKTREE_LOCK_CORRUPT"} }
    }
    return [pscustomobject]@{ok=$true;reason="OK";worktree_lock=$lockPath}
}

function Test-ManagedCodexProcess {
    param($Process,$Lease)
    if ($null -eq $Lease -or [string]$Lease.purpose -ne 'MAIA_CONTROL_PLANE' -or
        [string]$Process.name -ne 'codex.exe' -or
        [string]::IsNullOrWhiteSpace([string]$Process.executable_path) -or
        [int64]$Process.created_ticks -le 0 -or
        [bool]$Process.target_worktree_mentioned) { return $false }
    $cmd = [string]$Process.command_line
    if ($cmd -notmatch '(?i)(?:^|\s)app-server(?:\s|$)' -and
        $cmd -notmatch '(?i)(?:^|\s)exec-server(?:\s|$)') { return $false }
    $entry = @($Lease.processes | Where-Object { [int]$_.pid -eq [int]$Process.pid })
    if ($entry.Count -ne 1) { return $false }
    $entry = $entry[0]
    if ([int]$entry.ppid -ne [int]$Process.ppid -or
        [int64]$entry.created_ticks -ne [int64]$Process.created_ticks -or
        [string]$entry.executable_path -cne [string]$Process.executable_path -or
        [string]$entry.command_sha256 -ne (Get-Sha256String $cmd)) { return $false }
    if (-not (Test-Path -LiteralPath ([string]$Process.executable_path) -PathType Leaf) -or
        [string]$entry.file_sha256 -ne (Get-Sha256File ([string]$Process.executable_path))) { return $false }
    try {
        # WinPS 5.1 may inherit a PSModulePath with PowerShell 7 modules first.
        # Bind the signature cmdlet to this engine's own signed system module.
        $securityModule = Join-Path $PSHOME 'Modules\Microsoft.PowerShell.Security\Microsoft.PowerShell.Security.psd1'
        Import-Module -Name $securityModule -ErrorAction Stop
        $signature = Get-AuthenticodeSignature -LiteralPath ([string]$Process.executable_path)
        if ([string]$signature.Status -ne 'Valid' -or
            [string]$signature.SignerCertificate.Thumbprint -ne [string]$entry.signer_thumbprint -or
            [string]$signature.SignerCertificate.Subject -notmatch 'OpenAI OpCo, LLC') { return $false }
    } catch { return $false }
    return $true
}

function Get-Sha256String {
    param([string]$Value)
    $bytes = [Text.Encoding]::UTF8.GetBytes($Value)
    $hash = [Security.Cryptography.SHA256]::Create().ComputeHash($bytes)
    return ([BitConverter]::ToString($hash).Replace('-','').ToLowerInvariant())
}

function Save-WorktreeLock {
    param([string]$Path,[string]$RunId,[string]$PromptId,[string]$Worktree)
    Write-JsonAtomic -Path $Path -Object ([pscustomobject]@{
        schema_version=1; run_id=$RunId; prompt_id=$PromptId; worktree=$Worktree; created_utc=Get-UtcNowIso
    })
}

function Get-WorktreeLockPath {
    param([string]$LocksDir,[string]$Worktree)
    if ([string]::IsNullOrWhiteSpace($LocksDir) -or [string]::IsNullOrWhiteSpace($Worktree)) {
        throw 'LOCK_PATH_ARGUMENT_MISSING'
    }
    $component = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($Worktree)) -replace '[^A-Za-z0-9]',''
    $lockName = 'worktree-' + $component.Substring(0,[Math]::Min(32,$component.Length))
    return (Join-Path $LocksDir ($lockName + '.lock.json'))
}

function Remove-WorktreeLock {
    param([string]$Path,[string]$RunId,[string]$PromptId,[string]$Worktree)
    if ([string]::IsNullOrWhiteSpace($RunId) -or
        [string]::IsNullOrWhiteSpace($PromptId) -or
        [string]::IsNullOrWhiteSpace($Worktree)) { throw 'LOCK_OWNER_ARGUMENT_MISSING' }
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $false }
    $lk = Read-JsonFile $Path
    if ([string]$lk.run_id -cne $RunId -or
        [string]$lk.prompt_id -cne $PromptId -or
        [string]$lk.worktree -cne $Worktree) { return $false }
    Remove-Item -LiteralPath $Path -Force
    return $true
}

function Restore-BytesAtomic {
    param([string]$Path,[byte[]]$Bytes)
    $tmp = $Path + '.preflight-rollback-' + [Guid]::NewGuid().ToString('N')
    try {
        [IO.File]::WriteAllBytes($tmp,$Bytes)
        [IO.File]::Replace($tmp,$Path,($Path+'.preflight-rollback.bak'))
    } finally {
        if ([IO.File]::Exists($tmp)) { [IO.File]::Delete($tmp) }
    }
}

function Resolve-PreflightRecoveryMarker {
    param([Parameter(Mandatory=$true)][string]$Root)
    $rootPath = [IO.Path]::GetFullPath($Root).TrimEnd('\')
    $markerPath = Join-Path $rootPath 'state\preflight-recovery.pending.json'
    if (-not [IO.File]::Exists($markerPath)) { return 'NONE' }
    if (([IO.File]::GetAttributes($markerPath) -band [IO.FileAttributes]::ReparsePoint)) {
        throw 'PREFLIGHT_RECOVERY_MARKER_REPARSE_POINT'
    }
    $marker = Read-JsonFile $markerPath
    if ([int]$marker.schema_version -ne 1 -or [string]$marker.root -cne $rootPath -or
        [string]$marker.transaction_dir -notmatch '^([A-Za-z]:\\|\\\\)' -or
        [string]$marker.before_state_sha256 -notmatch '^[a-f0-9]{64}$' -or
        [string]$marker.after_state_sha256 -notmatch '^[a-f0-9]{64}$' -or
        [string]$marker.before_manifest_sha256 -notmatch '^[a-f0-9]{64}$' -or
        [string]$marker.after_manifest_sha256 -notmatch '^[a-f0-9]{64}$') {
        throw 'PREFLIGHT_RECOVERY_MARKER_INVALID'
    }
    $txn = [IO.Path]::GetFullPath([string]$marker.transaction_dir).TrimEnd('\')
    if ($txn.StartsWith($rootPath+'\',[StringComparison]::OrdinalIgnoreCase) -or
        -not [IO.Directory]::Exists($txn) -or
        (([IO.File]::GetAttributes($txn)) -band [IO.FileAttributes]::ReparsePoint)) {
        throw 'PREFLIGHT_RECOVERY_TRANSACTION_UNSAFE'
    }
    $statePath = Join-Path $rootPath 'state\state.json'
    $manifestPath = Join-Path $rootPath 'PACKAGE_SHA256.json'
    $queuePath = Join-Path $rootPath 'queue\queue.json'
    $logPath = Join-Path $rootPath 'logs\controller.log'
    $beforeState = Join-Path $txn 'before-state.json'
    $beforeManifest = Join-Path $txn 'before-package.json'
    $journalPath = Join-Path $txn 'TRANSACTION.json'
    foreach ($path in @($statePath,$manifestPath,$queuePath,$logPath,$beforeState,$beforeManifest,$journalPath)) {
        if (-not [IO.File]::Exists($path) -or
            (([IO.File]::GetAttributes($path)) -band [IO.FileAttributes]::ReparsePoint)) {
            throw ('PREFLIGHT_RECOVERY_FILE_UNSAFE:'+$path)
        }
    }
    $journal = Read-JsonFile $journalPath
    if ([string]$journal.root -cne $rootPath -or
        [string]$journal.prompt_id -cne [string]$marker.prompt_id -or
        [string]$journal.before_state_sha256 -cne [string]$marker.before_state_sha256 -or
        [string]$journal.after_state_sha256 -cne [string]$marker.after_state_sha256 -or
        [string]$journal.before_manifest_sha256 -cne [string]$marker.before_manifest_sha256 -or
        [string]$journal.after_manifest_sha256 -cne [string]$marker.after_manifest_sha256 -or
        [string]$journal.phase -notin @('PREPARED','APPLYING_STATE','APPLYING_MANIFEST','COMMITTED','ROLLED_BACK','ROLLBACK_INCOMPLETE')) {
        throw 'PREFLIGHT_RECOVERY_JOURNAL_MISMATCH'
    }
    if ((Get-Sha256File $beforeState) -ne [string]$marker.before_state_sha256 -or
        (Get-Sha256File $beforeManifest) -ne [string]$marker.before_manifest_sha256 -or
        (Get-Sha256File $queuePath) -ne [string]$marker.queue_sha256 -or
        (Get-Sha256File $logPath) -ne [string]$marker.controller_log_sha256 -or
        @(Get-ChildItem (Join-Path $rootPath 'runs') -Force).Count -ne 0 -or
        @(Get-ChildItem (Join-Path $rootPath 'locks') -Force).Count -ne 0) {
        throw 'PREFLIGHT_RECOVERY_INPUT_CHANGED'
    }
    $stateHash = Get-Sha256File $statePath
    $manifestHash = Get-Sha256File $manifestPath
    if ($stateHash -notin @([string]$marker.before_state_sha256,[string]$marker.after_state_sha256) -or
        $manifestHash -notin @([string]$marker.before_manifest_sha256,[string]$marker.after_manifest_sha256)) {
        throw 'PREFLIGHT_RECOVERY_LIVE_HASH_UNKNOWN'
    }
    if ([string]$journal.phase -eq 'COMMITTED') {
        if ($stateHash -ne [string]$marker.after_state_sha256 -or
            $manifestHash -ne [string]$marker.after_manifest_sha256) {
            throw 'PREFLIGHT_RECOVERY_COMMIT_INCOMPLETE'
        }
        Remove-Item -LiteralPath $markerPath -Force
        return 'COMMITTED'
    }
    if ([string]$journal.phase -eq 'ROLLED_BACK' -and
        ($stateHash -ne [string]$marker.before_state_sha256 -or
         $manifestHash -ne [string]$marker.before_manifest_sha256)) {
        throw 'PREFLIGHT_RECOVERY_ROLLBACK_INCOMPLETE'
    }
    if ($manifestHash -ne [string]$marker.before_manifest_sha256) {
        Restore-BytesAtomic $manifestPath ([IO.File]::ReadAllBytes($beforeManifest))
    }
    if ($stateHash -ne [string]$marker.before_state_sha256) {
        Restore-BytesAtomic $statePath ([IO.File]::ReadAllBytes($beforeState))
    }
    if ((Get-Sha256File $statePath) -ne [string]$marker.before_state_sha256 -or
        (Get-Sha256File $manifestPath) -ne [string]$marker.before_manifest_sha256) {
        throw 'PREFLIGHT_RECOVERY_ROLLBACK_HASH_MISMATCH'
    }
    $journal.phase = 'ROLLED_BACK'
    $journal | Add-Member -NotePropertyName recovery_completed_utc -NotePropertyValue (Get-UtcNowIso) -Force
    Write-JsonAtomic $journalPath $journal
    Remove-Item -LiteralPath $markerPath -Force
    return 'ROLLED_BACK'
}

function Get-TransitionTarget {
    param($Manifest,[string]$Verdict)
    $norm = Normalize-VerdictLine $Verdict
    foreach ($p in $Manifest.transitions.PSObject.Properties) {
        if ((Normalize-VerdictLine ([string]$p.Name)) -eq $norm) { return [string]$p.Value }
    }
    return $null
}

# M4 delta: this is a named shadow-evaluation preflight, never a Git exemption.
function Test-M4Preflight {
    param([string]$Root,[string]$PromptId,$Binding,[string]$SourceRoot)
    if ($PromptId -cnotmatch '^[a-f0-9]{32}$' -or $PromptId -cne [string]$Binding.cycle) { throw 'M4_CYCLE_BINDING' }
    $fullRoot = [IO.Path]::GetFullPath($Root).TrimEnd('\')
    $fullSource = [IO.Path]::GetFullPath($SourceRoot).TrimEnd('\')
    $allowed = 'C:\MAIA\reports\M4_STAGING_20261108\'
    if (-not $fullRoot.StartsWith($allowed,[StringComparison]::OrdinalIgnoreCase) -or
        $fullSource.StartsWith($fullRoot+'\',[StringComparison]::OrdinalIgnoreCase) -or
        $fullRoot.StartsWith($fullSource+'\',[StringComparison]::OrdinalIgnoreCase)) { throw 'M4_ROOT_SCOPE' }
    $prompts = Join-Path $fullRoot 'prompts'
    $v = Test-PromptManifest -PromptsDir $prompts -PromptId $PromptId
    if (-not $v.ok) { throw ('M4_MANIFEST:'+ $v.reason) }
    $m = $v.manifest
    if ([string]$m.stage_profile -cne 'M4_PROTECTED_PROPOSAL_STAGING' -or
        [string]$m.idempotency_policy -cne 'never_replay' -or
        [string]$m.prompt_file -cne 'prompt.txt' -or
        [string]$m.worktree -cne (Join-Path $fullRoot 'worktree') -or
        [string]$m.branch -cne 'NON_GIT_STAGING' -or
        @($m.allowed_verdicts).Count -ne 1 -or
        [string]$m.allowed_verdicts[0] -cne 'STAGING_COMPLETE' -or
        [string](Get-TransitionTarget -Manifest $m -Verdict 'STAGING_COMPLETE') -cne 'PIPELINE_COMPLETE') { throw 'M4_ROUTE_MANIFEST' }
    $t = Test-ManifestTransitionTargets -PromptsDir $prompts -Manifest $m
    if (-not $t.ok) { throw ('M4_TRANSITION:'+ $t.reason) }
    $before = Read-JsonFile (Join-Path $fullRoot 'state.before.json')
    if ([string]$before.status -cne 'PIPELINE_COMPLETE') { throw 'M4_PREIMAGE_STATE' }
    if (-not (Test-CanReplayPrompt -Manifest $m -State $before -RunsDir (Join-Path $fullRoot 'runs'))) { throw 'M4_REPLAY_REFUSED' }
    $q = Read-JsonFile (Join-Path $fullRoot 'queue.before.json')
    if (@($q.items).Count -ne 0) { throw 'M4_PREIMAGE_QUEUE' }
    if (-not (Test-Path -LiteralPath (Join-Path $m.worktree 'INPUT.txt') -PathType Leaf)) { throw 'M4_INPUT_MISSING' }
    $pin = Read-JsonFile (Join-Path $fullRoot 'worktree-pin.json')
    if ((@($pin.PSObject.Properties.Name | Sort-Object) -join '|') -cne 'input_relative|input_sha256|profile|schema|worktree' -or
        $pin.schema -ne 1 -or [string]$pin.profile -cne 'M4_PROTECTED_PROPOSAL_STAGING' -or
        [string]$pin.worktree -cne [string]$m.worktree -or [string]$pin.input_relative -cne 'INPUT.txt' -or
        [string]$pin.input_sha256 -cne (Get-Sha256File (Join-Path $m.worktree 'INPUT.txt'))) { throw 'M4_WORKTREE_PIN' }
    $locks = Join-Path $fullRoot 'locks'
    if (-not (Test-Path -LiteralPath $locks -PathType Container) -or
        @(Get-ChildItem -LiteralPath $locks -Force -ErrorAction Stop).Count -ne 0) { throw 'M4_FOREIGN_LOCK' }
    # The sole live receiver/Store claim is the staging worktree/start lock.
    return [pscustomobject]@{manifest=$m;root=$fullRoot;prompts=$prompts;worktree=[string]$m.worktree}
}

function New-M4PromptSnapshot {
    param($Preflight,[string]$Cycle)
    $run = Join-Path (Join-Path $Preflight.root 'runs') $Cycle
    if (Test-Path -LiteralPath $run) { throw 'M4_RUN_RESIDUE' }
    [void][IO.Directory]::CreateDirectory($run)
    $source = Get-PromptTextPath -PromptsDir $Preflight.prompts -Manifest $Preflight.manifest
    $snapshot = Join-Path $run 'prompt.snapshot.txt'
    # Reuse the real controller snapshot/hash contract; source is held by admission pins.
    Copy-Item -LiteralPath $source -Destination $snapshot -ErrorAction Stop
    $hash = Get-Sha256File $snapshot
    if ($hash -cne ([string]$Preflight.manifest.sha256).ToLowerInvariant()) { throw 'M4_SNAPSHOT_HASH' }
    [IO.File]::WriteAllText((Join-Path $run 'prompt.sha256'),$hash,(New-Object Text.UTF8Encoding($false)))
    return [pscustomobject]@{run_dir=$run;prompt_path=$snapshot;prompt_sha256=$hash}
}

Export-ModuleMember -Function *
