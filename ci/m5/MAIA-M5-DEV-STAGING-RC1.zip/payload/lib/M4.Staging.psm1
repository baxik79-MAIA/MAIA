# M4 protected-proposal staging delta. Binary channel output is never a PowerShell log.
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$script:M4Utf8 = New-Object Text.UTF8Encoding($false,$true)

function Assert-M4Fields {
    param($Value,[string[]]$Names)
    if ($null -eq $Value) { throw 'M4_OBJECT_REQUIRED' }
    $actual = @($Value.PSObject.Properties.Name | Sort-Object)
    $expected = @($Names | Sort-Object)
    if (($actual -join '|') -cne ($expected -join '|')) { throw 'M4_FIELDS' }
}
function Get-M4Sha {
    param([byte[]]$Bytes)
    $sha = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($sha.ComputeHash($Bytes))).Replace('-','').ToLowerInvariant() }
    finally { $sha.Dispose() }
}
function Get-M4ConsoleFacts {
    $inputEncoding = [Console]::InputEncoding
    $outputEncoding = [Console]::OutputEncoding
    return [pscustomobject]@{input_code_page=$inputEncoding.CodePage;output_code_page=$outputEncoding.CodePage;input_preamble_hex=([BitConverter]::ToString($inputEncoding.GetPreamble())).Replace('-','');output_preamble_hex=([BitConverter]::ToString($outputEncoding.GetPreamble())).Replace('-','')}
}
function Assert-M4ConsoleFacts {
    param($Facts)
    Assert-M4Fields $Facts @('input_code_page','output_code_page','input_preamble_hex','output_preamble_hex')
    if (($Facts.input_code_page -isnot [int] -and $Facts.input_code_page -isnot [long]) -or
        ($Facts.output_code_page -isnot [int] -and $Facts.output_code_page -isnot [long]) -or
        $Facts.input_code_page -ne 852 -or $Facts.output_code_page -ne 852 -or
        $Facts.input_preamble_hex -isnot [string] -or $Facts.output_preamble_hex -isnot [string] -or
        $Facts.input_preamble_hex.Length -ne 0 -or $Facts.output_preamble_hex.Length -ne 0) { throw 'M4_CONSOLE_ENCODING_UNQUALIFIED' }
}
function Read-M4Exact {
    param([IO.Stream]$Stream,[int]$Count,[DateTime]$Deadline)
    if ($Count -lt 1 -or $Count -gt 65536) { throw 'M4_READ_LENGTH' }
    $buffer = New-Object byte[] $Count
    $offset = 0
    while ($offset -lt $Count) {
        $remaining = [int][Math]::Floor(($Deadline-[DateTime]::UtcNow).TotalMilliseconds)
        if ($remaining -lt 1) { throw 'M4_READ_DEADLINE' }
        $task = $Stream.ReadAsync($buffer,$offset,($Count-$offset))
        if (-not $task.Wait($remaining)) { throw 'M4_READ_TIMEOUT_NO_RETRY' }
        $got = $task.GetAwaiter().GetResult()
        if ($got -le 0) { throw 'M4_PIPE_EOF' }
        $offset += $got
    }
    return ,$buffer
}
function ConvertFrom-M4Json {
    param([string]$Text)
    # Validate the JSON grammar and duplicate member names before PS 5.1 conversion.
    $tokens = New-Object Collections.Generic.List[string]
    $at = 0
    $pattern = '\G\s*("(?:[^"\\\x00-\x1F]|\\(?:["\\/bfnrt]|u[0-9a-fA-F]{4}))*"|-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?|true|false|null|[{}\[\],:])'
    $scanner = New-Object Text.RegularExpressions.Regex($pattern,[Text.RegularExpressions.RegexOptions]::CultureInvariant)
    while ($at -lt $Text.Length) {
        if ([string]::IsNullOrWhiteSpace($Text.Substring($at))) { break }
        $m = $scanner.Match($Text,$at)
        if (-not $m.Success -or $m.Index -ne $at) { throw 'M4_JSON_TOKEN' }
        $tokens.Add($m.Groups[1].Value); $at += $m.Length
    }
    $cursor = @{i=0}
    Read-M4JsonValue $tokens $cursor 0
    if ($cursor.i -ne $tokens.Count) { throw 'M4_JSON_TRAILING' }
    return ($Text | ConvertFrom-Json)
}
function Read-M4JsonValue {
    param($Tokens,$Cursor,[int]$Depth)
    if ($Depth -gt 24 -or $Cursor.i -ge $Tokens.Count) { throw 'M4_JSON_DEPTH_EOF' }
    $token = $Tokens[$Cursor.i]; $Cursor.i++
    if ($token -ceq '{') {
        $keys = New-Object 'Collections.Generic.Dictionary[string,bool]' ([StringComparer]::Ordinal)
        if ($Cursor.i -lt $Tokens.Count -and $Tokens[$Cursor.i] -ceq '}') { $Cursor.i++; return }
        while ($true) {
            if ($Cursor.i -ge $Tokens.Count -or -not $Tokens[$Cursor.i].StartsWith('"')) { throw 'M4_JSON_MEMBER' }
            $name = @(('['+$Tokens[$Cursor.i]+']') | ConvertFrom-Json)[0]; $Cursor.i++
            if ($keys.ContainsKey($name)) { throw 'M4_JSON_DUPLICATE' }; $keys.Add($name,$true)
            if ($Cursor.i -ge $Tokens.Count -or $Tokens[$Cursor.i] -cne ':') { throw 'M4_JSON_COLON' }; $Cursor.i++
            Read-M4JsonValue $Tokens $Cursor ($Depth+1)
            if ($Cursor.i -ge $Tokens.Count) { throw 'M4_JSON_EOF' }
            $end = $Tokens[$Cursor.i]; $Cursor.i++
            if ($end -ceq '}') { return }; if ($end -cne ',') { throw 'M4_JSON_OBJECT' }
        }
    }
    if ($token -ceq '[') {
        if ($Cursor.i -lt $Tokens.Count -and $Tokens[$Cursor.i] -ceq ']') { $Cursor.i++; return }
        while ($true) {
            Read-M4JsonValue $Tokens $Cursor ($Depth+1)
            if ($Cursor.i -ge $Tokens.Count) { throw 'M4_JSON_EOF' }
            $end = $Tokens[$Cursor.i]; $Cursor.i++
            if ($end -ceq ']') { return }; if ($end -cne ',') { throw 'M4_JSON_ARRAY' }
        }
    }
    if ($token -in @('}',']',':',',')) { throw 'M4_JSON_VALUE' }
    if ($token -cmatch '^-?[0-9]') {
        $number = [double]0
        if (-not [double]::TryParse($token,[Globalization.NumberStyles]::Float,[Globalization.CultureInfo]::InvariantCulture,[ref]$number) -or
            [double]::IsInfinity($number) -or [double]::IsNaN($number)) { throw 'M4_JSON_NONFINITE' }
    }
}
function Read-M4Raw {
    param([IO.Stream]$Stream,[DateTime]$Deadline)
    $head = Read-M4Exact $Stream 4 $Deadline
    $length = [int64]$head[0]*16777216 + [int64]$head[1]*65536 + [int64]$head[2]*256 + [int64]$head[3]
    if ($length -lt 2 -or $length -gt 65536) { throw 'M4_FRAME_LENGTH' }
    $body = Read-M4Exact $Stream ([int]$length) $Deadline
    return (ConvertFrom-M4Json ($script:M4Utf8.GetString($body)))
}
function Write-M4Raw {
    param([IO.Stream]$Stream,$Value,[DateTime]$Deadline)
    $bytes = $script:M4Utf8.GetBytes(($Value | ConvertTo-Json -Depth 24 -Compress))
    $n = $bytes.Length
    if ($n -lt 2 -or $n -gt 65536) { throw 'M4_FRAME_LENGTH' }
    [byte[]]$head = @([byte](($n -shr 24)-band 255),[byte](($n -shr 16)-band 255),[byte](($n -shr 8)-band 255),[byte]($n-band 255))
    $frame = New-Object byte[] ($n+4)
    [Array]::Copy($head,0,$frame,0,4); [Array]::Copy($bytes,0,$frame,4,$n)
    $remaining = [int][Math]::Floor(($Deadline-[DateTime]::UtcNow).TotalMilliseconds)
    if ($remaining -lt 1) { throw 'M4_WRITE_DEADLINE' }
    $task = $Stream.WriteAsync($frame,0,$frame.Length)
    if (-not $task.Wait($remaining)) { throw 'M4_WRITE_TIMEOUT_NO_RETRY' }
    [void]$task.GetAwaiter().GetResult()
    $remaining = [int][Math]::Floor(($Deadline-[DateTime]::UtcNow).TotalMilliseconds)
    if ($remaining -lt 1) { throw 'M4_FLUSH_DEADLINE' }
    $flush = $Stream.FlushAsync()
    if (-not $flush.Wait($remaining)) { throw 'M4_FLUSH_TIMEOUT_NO_RETRY' }
    [void]$flush.GetAwaiter().GetResult()
}
function New-M4Channel {
    param([IO.Stream]$InputStream,[IO.Stream]$OutputStream,$Bootstrap,[string]$SendDirection,[string]$ReceiveDirection,[DateTime]$Deadline)
    if (($Bootstrap.v -isnot [int] -and $Bootstrap.v -isnot [long]) -or $Bootstrap.v -ne 1) { throw 'M4_VERSION' }
    if ([string]$Bootstrap.session -cnotmatch '^[a-f0-9]{32}$') { throw 'M4_SESSION' }
    $key = [Convert]::FromBase64String([string]$Bootstrap.key_b64)
    if ($key.Length -ne 32) { throw 'M4_KEY_SIZE' }
    return @{input=$InputStream;output=$OutputStream;key=$key;session=[string]$Bootstrap.session;send=$SendDirection;receive=$ReceiveDirection;tx=[int64]0;rx=[int64]0;deadline=$Deadline;failed=$false}
}
function Get-M4Mac {
    param($Channel,[string]$Direction,[int64]$Sequence,[string]$Body)
    $hmac = New-Object Security.Cryptography.HMACSHA256
    try {
        $hmac.Key = $Channel.key
        $text = $Channel.session+'|'+$Direction+'|'+$Sequence.ToString([Globalization.CultureInfo]::InvariantCulture)+'|'+$Body
        return ([BitConverter]::ToString($hmac.ComputeHash($script:M4Utf8.GetBytes($text)))).Replace('-','').ToLowerInvariant()
    } finally { $hmac.Dispose() }
}
function Send-M4 {
    param($Channel,[string]$Kind,$Payload)
    if ($Channel.failed) { throw 'M4_CHANNEL_POISONED' }
    $body = [Convert]::ToBase64String($script:M4Utf8.GetBytes((@{kind=$Kind;payload=$Payload}|ConvertTo-Json -Depth 24 -Compress)))
    $seq = [int64]$Channel.tx
    $mac = Get-M4Mac $Channel $Channel.send $seq $body
    # Increment before entry: an unknown write result can never resend this command.
    $Channel.tx = $seq+1
    $Channel.failed = $true
    Write-M4Raw $Channel.output @{v=1;session=$Channel.session;direction=$Channel.send;seq=$seq;body_b64=$body;mac=$mac} $Channel.deadline
    $Channel.failed = $false
}
function Receive-M4 {
    param($Channel)
    if ($Channel.failed) { throw 'M4_CHANNEL_POISONED' }
    $Channel.failed = $true
    $frame = Read-M4Raw $Channel.input $Channel.deadline
    Assert-M4Fields $frame @('v','session','direction','seq','body_b64','mac')
    if (($frame.v -isnot [int] -and $frame.v -isnot [long]) -or $frame.v -ne 1 -or [string]$frame.session -cne $Channel.session -or
        [string]$frame.direction -cne $Channel.receive -or $frame.seq -is [bool] -or
        ($frame.seq -isnot [int] -and $frame.seq -isnot [long]) -or [int64]$frame.seq -ne $Channel.rx -or
        [string]$frame.mac -cnotmatch '^[a-f0-9]{64}$') { throw 'M4_FRAME_BINDING' }
    $expected = Get-M4Mac $Channel $Channel.receive ([int64]$frame.seq) ([string]$frame.body_b64)
    $diff = 0
    for ($i=0;$i -lt 64;$i++) { $diff = $diff -bor ([int][char]$expected[$i] -bxor [int][char]$frame.mac[$i]) }
    if ($diff -ne 0) { throw 'M4_FRAME_MAC' }
    $Channel.rx = [int64]$Channel.rx+1
    $body = ConvertFrom-M4Json ($script:M4Utf8.GetString([Convert]::FromBase64String([string]$frame.body_b64)))
    Assert-M4Fields $body @('kind','payload')
    if ($body.payload -isnot [pscustomobject]) { throw 'M4_PAYLOAD_OBJECT' }
    $Channel.failed = $false
    return $body
}
function Invoke-M4Barrier {
    param($Outer,[string]$Kind,$Payload)
    Send-M4 $Outer $Kind $Payload
    $ack = Receive-M4 $Outer
    $stage = if ($Kind -ceq 'ENGINE_CREATED') {'engine_created'} elseif ($Kind -ceq 'WORKER_CREATED') {'worker_created'} else {[string]$Payload.stage}
    Assert-M4Fields $ack.payload @('stage')
    if ([string]$ack.kind -cne 'ACK_BARRIER' -or [string]$ack.payload.stage -cne $stage) { throw 'M4_BARRIER_ACK' }
    return $ack.payload
}
function Invoke-M4EngineCommand {
    param($Engine,$Outer,[string]$Kind,$Payload)
    Send-M4 $Engine $Kind $Payload
    while ($true) {
        $reply = Receive-M4 $Engine
        if ([string]$reply.kind -in @('EVENT_BARRIER','WORKER_CREATED')) {
            $ack = Invoke-M4Barrier $Outer ([string]$reply.kind) $reply.payload
            Send-M4 $Engine 'ACK_BARRIER' $ack
            continue
        }
        if ([string]$reply.kind -ceq 'REFUSED') { throw ('M4_ENGINE_REFUSED:'+ [string]$reply.payload.reason) }
        if ([string]$reply.kind -cne ('RESULT_'+$Kind)) { throw 'M4_COMMAND_RESULT' }
        return $reply.payload
    }
}
function Write-M4Exclusive {
    param([string]$Path,[byte[]]$Bytes)
    $stream = New-Object IO.FileStream($Path,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read)
    try { $stream.Write($Bytes,0,$Bytes.Length); $stream.Flush($true) }
    finally { $stream.Dispose() }
}
function Quote-M4Argument {
    param([string]$Value)
    # CommandLineToArgvW-compatible quoting; no shell is invoked.
    return '"'+[regex]::Replace([regex]::Replace($Value,'(\\*)"','$1$1\"'),'(\\+)$','$1$1')+'"'
}
function Get-M4PythonArguments {
    param([string]$SourceRoot,$Bootstrap)
    $manifestPath = Join-Path $SourceRoot 'SOURCE_MANIFEST.json'
    if ((Get-Sha256File $manifestPath) -cne [string]$Bootstrap.source_manifest_sha) { throw 'M4_SOURCE_MANIFEST_HASH' }
    $manifest = ConvertFrom-M4Json ([IO.File]::ReadAllText($manifestPath,$script:M4Utf8))
    if ([string]$manifest.source_sha256 -cne [string]$Bootstrap.source_sha -or
        [string]$Bootstrap.binding.source -cne [string]$Bootstrap.source_sha) { throw 'M4_SOURCE_BINDING' }
    $entryPath = Join-Path $SourceRoot 'm4_entry.py'
    $entrySha = [string]$manifest.files.'m4_entry.py'.sha256
    if ($entrySha -cnotmatch '^[a-f0-9]{64}$' -or (Get-Sha256File $entryPath) -cne $entrySha) { throw 'M4_ENTRY_HASH' }
    $literal = ($entryPath.Replace('\','/').Replace("'","\'"))
    $code = "import pathlib,hashlib,sys`np=pathlib.Path('$literal')`nb=p.read_bytes()`nif hashlib.sha256(b).hexdigest()!='$entrySha': raise RuntimeError('ENTRY_HASH')`nsys.argv=[str(p)]+sys.argv[1:]`nexec(compile(b,str(p),'exec'),{'__name__':'__main__','__file__':str(p)})"
    $args = @('-I','-S','-B','-c',$code,'--manifest-sha',[string]$Bootstrap.source_manifest_sha,'--source-sha',[string]$Bootstrap.source_sha,'--entry','m4_engine.py','--','--role','engine')
    return (($args | ForEach-Object { Quote-M4Argument ([string]$_) }) -join ' ')
}
function Get-M4Policy {
    param([string]$Root,[string]$SourceRoot,$Bootstrap)
    if ([string]$Bootstrap.root -cne $Root -or [string]$Bootstrap.source_root -cne $SourceRoot -or
        [string]$Bootstrap.binding.cycle -cnotmatch '^[a-f0-9]{32}$' -or
        [string]$Bootstrap.binding.inputs -cnotmatch '^[a-f0-9]{64}$' -or
        [string]$Bootstrap.binding.source -cnotmatch '^[a-f0-9]{64}$' -or
        $Bootstrap.v -ne 1) { throw 'M4_BOOT_BINDING' }
    Assert-M4Fields $Bootstrap.binding @('cycle','source','inputs')
    $normalRoot = [IO.Path]::GetFullPath($Root).TrimEnd('\')
    $normalSource = [IO.Path]::GetFullPath($SourceRoot).TrimEnd('\')
    if (-not $normalRoot.StartsWith('C:\MAIA\reports\M4_STAGING_20261108\',[StringComparison]::OrdinalIgnoreCase) -or
        $normalRoot.StartsWith($normalSource+'\',[StringComparison]::OrdinalIgnoreCase) -or
        $normalSource.StartsWith($normalRoot+'\',[StringComparison]::OrdinalIgnoreCase)) { throw 'M4_ROOT_SCOPE' }
    $policyPath = Join-Path $Root 'M4_POLICY.json'
    if ((Get-Sha256File $policyPath) -cne [string]$Bootstrap.policy_sha256) { throw 'M4_POLICY_HASH' }
    $policy = ConvertFrom-M4Json ([IO.File]::ReadAllText($policyPath,$script:M4Utf8))
    $command = 'RUN'
    if (@($Bootstrap.PSObject.Properties.Name) -contains 'command') { $command = [string]$Bootstrap.command }
    $sourceAlias = [string]$policy.source_root -cne $SourceRoot
    # A restored RUN reaches only the engine's authenticated read-only receiver
    # fence check. The controller independently forbids ENQUEUE for this alias.
    if ($sourceAlias -and ($command -notin @('RUN','STATUS','RECOVER') -or
        -not $normalSource.StartsWith('C:\MAIA\reports\M4_STAGING_20261108\',[StringComparison]::OrdinalIgnoreCase))) { throw 'M4_SOURCE_ROOT' }
    if ([string]$policy.profile -cne 'M4_PROTECTED_PROPOSAL_STAGING' -or
        [string]$policy.operation -cne 'FIXED_INPUT_ANALYSIS_V1' -or
        [string]$policy.source_sha -cne [string]$Bootstrap.binding.source -or
        [string]$policy.instance_root -cne $Root -or
        [string]$policy.worker_relative -cne 'worker/Run-CodexWorker.ps1' -or
        [string]$policy.controller_relative -cne 'MAIA-Codex-Supervisor.ps1' -or
        [string]$policy.input_relative -cne 'worktree/INPUT.txt' -or
        [string]$policy.artifact_relative -cne 'worktree/ANALYSIS.md' -or
        $policy.deadline_seconds -ne 45 -or $policy.max_input_bytes -ne 65536) { throw 'M4_POLICY_SCOPE' }
    foreach ($name in @('python','powershell')) {
        $runtime = $policy.runtime.$name
        if ([string]$runtime.sha256 -cnotmatch '^[a-f0-9]{64}$' -or (Get-Sha256File ([string]$runtime.path)) -cne [string]$runtime.sha256) { throw 'M4_RUNTIME_HASH' }
    }
    $selfProcess = [Diagnostics.Process]::GetCurrentProcess()
    try { if ([string]$selfProcess.MainModule.FileName -ine [string]$policy.runtime.powershell.path) { throw 'M4_POWERSHELL_IDENTITY' } }
    finally { $selfProcess.Dispose() }
    if ([string]$policy.runtime.powershell.version -cne $PSVersionTable.PSVersion.ToString()) { throw 'M4_POWERSHELL_VERSION' }
    return $policy
}
function Receive-M4EngineReady {
    param($Engine,$Outer)
    while ($true) {
        $reply = Receive-M4 $Engine
        if ([string]$reply.kind -ceq 'EVENT_BARRIER') {
            $ack = Invoke-M4Barrier $Outer 'EVENT_BARRIER' $reply.payload
            Send-M4 $Engine 'ACK_BARRIER' $ack
            continue
        }
        if ([string]$reply.kind -ceq 'REFUSED') { throw ('M4_ENGINE_REFUSED:'+ [string]$reply.payload.reason) }
        if ([string]$reply.kind -cne 'ENGINE_READY') { throw 'M4_ENGINE_BOOT_RESULT' }
        Send-M4 $Outer 'ENGINE_READY' $reply.payload
        return
    }
}
function Get-M4RefusalReason {
    param([Exception]$Exception)
    $message = [string]$Exception.Message
    if ($message -cmatch '^(M4|M2)_[A-Z0-9_:.-]{1,180}$') { return $message }
    # Preserve only these known durable fence verdicts from the engine's typed exception prefix.
    foreach ($code in @('RECEIVER_CLAIM_REFUSED_NO_REPLAY','RECEIVER_CLAIM_UNCERTAIN_NO_REPLAY','LIVE_RECEIVER_CLAIM_REQUIRED','LIVE_RECEIVER_FENCE_DIFFERS')) {
        if ($message -ceq ('M4_ENGINE_REFUSED:Refusal:'+ $code)) { return ('M4_ENGINE_REFUSED:'+ $code) }
    }
    return ('M4_LOCAL_ERROR:'+ $Exception.GetType().Name)
}
function Get-M4EngineDiagnostic {
    param($Task,$Identity,[int]$ExitCode,[DateTime]$Deadline)
    # An arbitrary interpreter traceback must never become a private-pipe dump.
    # Keep a bounded categorical record, never bootstrap/body/exception text.
    $completed = $false; $raw = ''; $readError = $null
    if ($null -ne $Task) {
        try {
            $wait = [Math]::Min(1000,[Math]::Max(0,[int][Math]::Floor(($Deadline-[DateTime]::UtcNow).TotalMilliseconds)))
            $completed = $Task.Wait($wait)
            if ($completed) { $raw = [string]$Task.GetAwaiter().GetResult() }
        } catch { $readError = $_.Exception.GetType().Name }
    }
    $lines = New-Object Collections.Generic.List[string]
    $sourceLines = @($raw -split "`r?`n" | Where-Object { $_.Length -gt 0 })
    foreach ($line in ($sourceLines | Select-Object -First 24)) {
        if ($line -ceq 'Traceback (most recent call last):') { $lines.Add('TRACEBACK') }
        elseif ($line -cmatch '^(RuntimeError|ValueError|TypeError|OSError|EOFError|TimeoutError|Refusal|NativeRefusal|WireRefusal|AdmissionRefusal|StoreRefusal|ProtocolRefusal|AssertionError|FileNotFoundError|PermissionError|BrokenPipeError|ImportError|ModuleNotFoundError):') { $lines.Add($Matches[1]+': [REDACTED]') }
        else { $lines.Add('[REDACTED]') }
    }
    return @{schema=1;kind='ENGINE_STDERR_DIAGNOSTIC';identity=$Identity;observed_exit=$ExitCode;read_completed=$completed;read_error=$readError;characters=$raw.Length;truncated=($sourceLines.Count -gt 24);redaction='FIXED_CATEGORIES_NO_PRIVATE_PAYLOAD';lines=@($lines)}
}
function Save-M4EngineDiagnostic {
    param([string]$Root,$Diagnostic)
    $folder = Join-Path $Root 'process-logs'
    [void][IO.Directory]::CreateDirectory($folder)
    $filename = 'engine.'+[string]$Diagnostic.identity.pid+'.'+[string]$Diagnostic.identity.birth+'.stderr.json'
    $bytes = $script:M4Utf8.GetBytes(($Diagnostic | ConvertTo-Json -Depth 8 -Compress))
    if ($bytes.Length -gt 4096) { throw 'M4_DIAGNOSTIC_BOUND' }
    Write-M4Exclusive (Join-Path $folder $filename) $bytes
    return ('process-logs/'+$filename)
}
function Invoke-M4Worker {
    param([string]$RunDir,[string]$PromptPath,[string]$WorkDir,[string]$SourceRoot)
    $deadline = [DateTime]::UtcNow.AddSeconds(45)
    $inputStream = [Console]::OpenStandardInput()
    $outputStream = [Console]::OpenStandardOutput()
    $wire = $null
    try {
        $boot = Read-M4Raw $inputStream $deadline
        Assert-M4Fields $boot @('v','key_b64','session','binding','root','source_root','identity','profile','policy_sha256','input_sha256','source_manifest_sha','source_sha')
        $wire = New-M4Channel $inputStream $outputStream $boot 'worker_to_engine' 'engine_to_worker' $deadline
        $consoleFacts = Get-M4ConsoleFacts
        Assert-M4ConsoleFacts $consoleFacts
        $root = [string]$boot.root
        $policy = Get-M4Policy $root $SourceRoot $boot
        [void](Get-M4PythonArguments $SourceRoot $boot)
        if ([string]$boot.profile -cne 'M4_PROTECTED_PROPOSAL_STAGING' -or
            $RunDir -cne (Join-Path (Join-Path $root 'runs') ([string]$boot.binding.cycle)) -or
            $PromptPath -cne (Join-Path $RunDir 'prompt.snapshot.txt') -or
            $WorkDir -cne (Join-Path $root 'worktree')) { throw 'M4_WORKER_SCOPE' }
        $self = [Diagnostics.Process]::GetCurrentProcess()
        try { $birth = $self.StartTime.ToUniversalTime().ToFileTimeUtc() }
        finally { $self.Dispose() }
        if ($PID -ne $boot.identity.pid -or $birth -ne $boot.identity.birth) { throw 'M4_WORKER_IDENTITY' }
        $release = Receive-M4 $wire
        if ([string]$release.kind -cne 'EFFECT_RELEASE' -or $release.payload.identity.pid -ne $PID -or
            $release.payload.identity.birth -ne $birth) { throw 'M4_EFFECT_RELEASE' }
        $before = @{stage='worker_before_effect';identity=$boot.identity;console_encoding=$consoleFacts}
        Send-M4 $wire 'EVENT_BARRIER' $before
        $ack = Receive-M4 $wire
        if ([string]$ack.kind -cne 'ACK_BARRIER' -or [string]$ack.payload.stage -cne 'worker_before_effect') { throw 'M4_WORKER_BEFORE_ACK' }
        $inputPath = Join-Path $WorkDir 'INPUT.txt'
        $bytes = [IO.File]::ReadAllBytes($inputPath)
        if ($bytes.Length -gt 65536) { throw 'M4_INPUT_BOUND' }
        $inputSha = Get-M4Sha $bytes
        if ($inputSha -cne [string]$boot.input_sha256) { throw 'M4_WORKER_INPUT_HASH' }
        $newlineCount = 0
        foreach ($item in $bytes) { if ($item -eq 10) { $newlineCount++ } }
        $text = "# MAIA M4 analysis`ncycle: $($boot.binding.cycle)`ninput_sha256: $inputSha`nbytes: $($bytes.Length)`nnewline_count: $newlineCount`n"
        $analysis = $script:M4Utf8.GetBytes($text)
        $artifactSha = Get-M4Sha $analysis
        Write-M4Exclusive (Join-Path $WorkDir 'ANALYSIS.md') $analysis
        Send-M4 $wire 'EVENT_BARRIER' @{stage='worker_after_effect';identity=$boot.identity;artifact_sha256=$artifactSha}
        $ack = Receive-M4 $wire
        if ([string]$ack.kind -cne 'ACK_BARRIER' -or [string]$ack.payload.stage -cne 'worker_after_effect') { throw 'M4_WORKER_AFTER_ACK' }
        Write-M4Exclusive (Join-Path $RunDir 'FINAL.md') ($script:M4Utf8.GetBytes("STAGING_COMPLETE`nM4 protected-proposal fixed local analysis.`n"))
        # FINAL is parser input. Success/exit evidence does not exist until this
        # same strict parser used by the real finalizer has accepted its bytes.
        $manifest = Read-JsonFile (Join-Path (Join-Path $root 'prompts') ([string]$boot.binding.cycle+'.manifest.json'))
        $verdict = Get-StrictVerdict -FinalPath (Join-Path $RunDir 'FINAL.md') -Manifest $manifest -PromptsDir (Join-Path $root 'prompts')
        if (-not $verdict.ok -or [string]$verdict.verdict -cne 'STAGING_COMPLETE') { throw 'M4_WORKER_STRICT_VERDICT' }
        $semantic = [ordered]@{schema=1;binding=$boot.binding;profile='M4_PROTECTED_PROPOSAL_STAGING';status='SUCCESS';is_error=$false;verdict='STAGING_COMPLETE';artifact='worktree/ANALYSIS.md';artifact_sha256=$artifactSha;input_sha256=$inputSha;identity=$boot.identity}
        $meta = @{schema_version=1;worker_pid=$PID;identity=$boot.identity;profile=$boot.profile;binding=$boot.binding;work_dir=$WorkDir;prompt_path=$PromptPath;console_encoding=$consoleFacts}
        Write-M4Exclusive (Join-Path $RunDir 'SESSION.log') ($script:M4Utf8.GetBytes("M4 fixed input analysis completed`ncycle=$($boot.binding.cycle)`nartifact_sha256=$artifactSha`n"))
        Write-M4Exclusive (Join-Path $RunDir 'worker.json') ($script:M4Utf8.GetBytes(($meta|ConvertTo-Json -Depth 12 -Compress)))
        Write-M4Exclusive (Join-Path $RunDir 'semantic-result.json') ($script:M4Utf8.GetBytes(($semantic|ConvertTo-Json -Depth 12 -Compress)))
        Write-M4Exclusive (Join-Path $RunDir 'exit-code.txt') ($script:M4Utf8.GetBytes('0'))
        Send-M4 $wire 'WORKER_RESULT' @{semantic=$semantic}
        exit 0
    } catch {
        if ($null -ne $wire) {
            try { Send-M4 $wire 'REFUSED' @{reason=(Get-M4RefusalReason $_.Exception);ready=$false;replay_permitted=$false;start_capability=$false} } catch {}
        }
        [Console]::Error.WriteLine('M4_WORKER_REFUSED')
        exit 2
    }
}
function Enqueue-M4PromptInternal {
    param($Context)
    # Adapted real Enqueue seam: validation remains in Core; only Store queues.
    $r = Invoke-M4EngineCommand $Context.engine $Context.outer 'ENQUEUE' @{prompt_id=$Context.cycle}
    if ([string]$r.phase -cne 'QUEUED' -or @($r.queue).Count -ne 1 -or [string]$r.queue[0] -cne $Context.cycle) { throw 'M4_ENQUEUE_RESULT' }
    Send-M4 $Context.outer 'RESULT_ENQUEUE' $r
}
function Start-M4Run {
    param($Context)
    # Adapted real Start-Run: exact prompt snapshot, actual worker creation, no JSON launch authority.
    $snapshot = New-M4PromptSnapshot -Preflight $Context.preflight -Cycle $Context.cycle
    $Context.run_dir = $snapshot.run_dir
    $r = Invoke-M4EngineCommand $Context.engine $Context.outer 'START' @{prompt_id=$Context.cycle}
    if ([string]$r.phase -cne 'START_INTENT' -or $r.launch_entries -ne 1 -or $r.created_workers -ne 1 -or
        $r.identity.pid -le 0 -or $r.identity.birth -le 0 -or $r.remote_handle -le 0) { throw 'M4_START_RESULT' }
    Send-M4 $Context.outer 'RESULT_START' $r
    [void](Invoke-M4Barrier $Context.outer 'WORKER_CREATED' $r)
    $Context.identity = $r.identity
    $released = Invoke-M4EngineCommand $Context.engine $Context.outer 'RELEASE' @{}
    if ([string]$released.phase -cne 'STARTED' -or $released.identity.pid -ne $Context.identity.pid -or
        $released.identity.birth -ne $Context.identity.birth) { throw 'M4_RELEASE_RESULT' }
    Send-M4 $Context.outer 'RESULT_RELEASE' $released
}
function Monitor-M4Run {
    param($Context)
    # Adapted real Monitor seam: observation does not mutate state/queue/heartbeat files.
    $r = Invoke-M4EngineCommand $Context.engine $Context.outer 'POLL' @{}
    if ([string]$r.phase -cne 'STARTED' -or $r.effect_observed -isnot [bool] -or -not $r.effect_observed -or
        $r.identity.pid -ne $Context.identity.pid -or $r.identity.birth -ne $Context.identity.birth) { throw 'M4_POLL_RESULT' }
    Send-M4 $Context.outer 'RESULT_POLL' $r
}
function Finalize-M4Run {
    param($Context)
    $r = Invoke-M4EngineCommand $Context.engine $Context.outer 'FINALIZE' @{}
    $semantic = $r.semantic
    Assert-M4Fields $semantic @('schema','binding','profile','status','is_error','verdict','artifact','artifact_sha256','input_sha256','identity')
    if ([string]$r.phase -cne 'COMPLETED' -or $r.worker_exit -ne 0 -or $r.worker_handle_closed -isnot [bool] -or -not $r.worker_handle_closed -or
        $semantic.is_error -isnot [bool] -or $semantic.is_error -or [string]$semantic.status -cne 'SUCCESS' -or
        [string]$semantic.verdict -cne 'STAGING_COMPLETE' -or [string]$semantic.profile -cne 'M4_PROTECTED_PROPOSAL_STAGING' -or
        [string]$semantic.binding.cycle -cne $Context.cycle -or [string]$semantic.binding.source -cne [string]$Context.binding.source -or
        [string]$semantic.binding.inputs -cne [string]$Context.binding.inputs -or
        $semantic.identity.pid -ne $Context.identity.pid -or $semantic.identity.birth -ne $Context.identity.birth -or
        [string]$semantic.artifact -cne 'worktree/ANALYSIS.md' -or
        [string]$semantic.artifact_sha256 -cne (Get-Sha256File (Join-Path $Context.preflight.worktree 'ANALYSIS.md'))) { throw 'M4_SEMANTIC_RESULT' }
    $code = [IO.File]::ReadAllText((Join-Path $Context.run_dir 'exit-code.txt'),$script:M4Utf8).Trim()
    if ($code -cne '0') { throw 'M4_EXIT_EVIDENCE' }
    # Same real strict verdict and transition lookup; technical exit never supplies success.
    $ver = Get-StrictVerdict -FinalPath (Join-Path $Context.run_dir 'FINAL.md') -Manifest $Context.preflight.manifest -PromptsDir $Context.preflight.prompts
    if (-not $ver.ok -or [string]$ver.verdict -cne 'STAGING_COMPLETE' -or
        [string](Get-TransitionTarget -Manifest $Context.preflight.manifest -Verdict $ver.verdict) -cne 'PIPELINE_COMPLETE') { throw 'M4_STRICT_VERDICT' }
    Send-M4 $Context.outer 'RESULT_FINALIZE' $r
    return $r
}
function Run-M4Controller {
    param($Context)
    Enqueue-M4PromptInternal $Context
    $queue = Invoke-M4EngineCommand $Context.engine $Context.outer 'QUEUE' @{}
    if ([string]$queue.phase -cne 'QUEUED' -or @($queue.queue).Count -ne 1 -or [string]$queue.queue[0] -cne $Context.cycle) { throw 'M4_QUEUE_RESULT' }
    Send-M4 $Context.outer 'RESULT_QUEUE' $queue
    # Unlike the legacy consumer, the PS controller never removes a JSON queue item.
    Start-M4Run $Context
    Monitor-M4Run $Context
    $completed = Finalize-M4Run $Context
    $closed = Invoke-M4EngineCommand $Context.engine $Context.outer 'CLOSE' @{}
    Send-M4 $Context.outer 'RESULT_CLOSE' $closed
    return $completed
}
function Invoke-M4Controller {
    param([string]$Action,[string]$Root,[string]$PromptId,[string]$SourceRoot)
    $deadline = [DateTime]::UtcNow.AddSeconds(45)
    $outer = $null; $engine = $null; $process = $null; $engineIdentity = $null
    $engineClosed = $false; $engineExit = $null; $stderrTask = $null
    $engineDiagnostic = $null; $diagnosticPath = $null; $command = $null; $restoredReadOnly = $true; $consoleFacts = $null
    try {
        $inputStream = [Console]::OpenStandardInput(); $outputStream = [Console]::OpenStandardOutput()
        $boot = Read-M4Raw $inputStream $deadline
        Assert-M4Fields $boot @('v','key_b64','session','binding','root','source_root','source_manifest_sha','source_sha','command','policy_sha256')
        $outer = New-M4Channel $inputStream $outputStream $boot 'controller_to_outer' 'outer_to_controller' $deadline
        if ($Action -notin @('Stage','StageStatus','StageRecover')) {
            $consoleFacts = Get-M4ConsoleFacts
            Assert-M4ConsoleFacts $consoleFacts
            [void](Invoke-M4Barrier $outer 'EVENT_BARRIER' @{stage='default_refusal_ready';console_encoding=$consoleFacts})
            throw 'M2_SECTION_BINDING_UNPROVEN'
        }
        $consoleFacts = Get-M4ConsoleFacts
        Assert-M4ConsoleFacts $consoleFacts
        $command = switch ($Action) { 'Stage' {'RUN'} 'StageStatus' {'STATUS'} 'StageRecover' {'RECOVER'} }
        if ([string]$boot.command -cne $command -or $PromptId -cne [string]$boot.binding.cycle) { throw 'M4_ACTION_BINDING' }
        $policy = Get-M4Policy $Root $SourceRoot $boot
        $arguments = Get-M4PythonArguments $SourceRoot $boot
        $preflight = $null
        $restoredReadOnly = [string]$policy.source_root -cne $SourceRoot
        if ($command -ceq 'RUN' -and -not $restoredReadOnly) { $preflight = Test-M4Preflight $Root $PromptId $boot.binding $SourceRoot }
        $startInfo = New-Object Diagnostics.ProcessStartInfo
        $startInfo.FileName = [string]$policy.runtime.python.path
        $startInfo.Arguments = $arguments; $startInfo.WorkingDirectory = $SourceRoot
        $startInfo.UseShellExecute = $false; $startInfo.CreateNoWindow = $true
        $startInfo.RedirectStandardInput = $true; $startInfo.RedirectStandardOutput = $true; $startInfo.RedirectStandardError = $true
        $process = New-Object Diagnostics.Process
        $process.StartInfo = $startInfo
        if (-not $process.Start()) { throw 'M4_ENGINE_CREATE_FALSE' }
        $stderrTask = $process.StandardError.ReadToEndAsync()
        $engineIdentity = @{pid=$process.Id;birth=$process.StartTime.ToUniversalTime().ToFileTimeUtc()}
        $rawHandle = $process.Handle.ToInt64()
        [void](Invoke-M4Barrier $outer 'ENGINE_CREATED' @{identity=$engineIdentity;remote_handle=$rawHandle;console_encoding=$consoleFacts})
        $key = New-Object byte[] 32; $rng = [Security.Cryptography.RandomNumberGenerator]::Create()
        try { $rng.GetBytes($key) } finally { $rng.Dispose() }
        $engineBoot = [ordered]@{v=1;key_b64=[Convert]::ToBase64String($key);session=[Guid]::NewGuid().ToString('N');binding=$boot.binding;root=$Root;source_root=$SourceRoot;source_manifest_sha=$boot.source_manifest_sha;source_sha=$boot.source_sha;command=$command;policy_sha256=$boot.policy_sha256}
        $engineInput = $process.StandardOutput.BaseStream; $engineOutput = $process.StandardInput.BaseStream
        Write-M4Raw $engineOutput $engineBoot $deadline
        $engine = New-M4Channel $engineInput $engineOutput $engineBoot 'controller_to_engine' 'engine_to_controller' $deadline
        if ($command -ceq 'RUN') {
            Receive-M4EngineReady $engine $outer
            if ($restoredReadOnly) { throw 'M4_RESTORED_RUN_FORBIDDEN' }
            $context = @{engine=$engine;outer=$outer;cycle=$PromptId;binding=$boot.binding;preflight=$preflight;run_dir=$null;identity=$null}
            $result = Run-M4Controller $context
            $terminal = @{phase=$result.phase;semantic=$result.semantic;ready=$false;replay_permitted=$false;start_capability=$false}
        } else {
            $reply = Receive-M4 $engine
            if ([string]$reply.kind -cne 'READ_ONLY_RESULT') { throw 'M4_READONLY_RESULT' }
            Send-M4 $outer 'READ_ONLY_RESULT' $reply.payload
            $terminal = @{phase=$reply.payload.view.phase;view=$reply.payload.view;ready=$false;replay_permitted=$false;start_capability=$false}
        }
        $remaining = [int][Math]::Floor(($deadline-[DateTime]::UtcNow).TotalMilliseconds)
        if ($remaining -lt 1 -or -not $process.WaitForExit($remaining)) { throw 'M4_ENGINE_EXIT_TIMEOUT' }
        $engineExit = $process.ExitCode
        try {
            $engineDiagnostic = Get-M4EngineDiagnostic $stderrTask $engineIdentity $engineExit $deadline
            if ($command -ceq 'RUN' -and -not $restoredReadOnly) { $diagnosticPath = Save-M4EngineDiagnostic $Root $engineDiagnostic }
        } finally { $process.Close(); $engineClosed = $true }
        if ($engineExit -ne 0) { throw 'M4_ENGINE_EXIT_NONZERO' }
        $terminal.engine_identity = $engineIdentity; $terminal.engine_exit = $engineExit; $terminal.engine_handle_closed = $engineClosed
        $terminal.engine_diagnostic = $engineDiagnostic; $terminal.engine_diagnostic_path = $diagnosticPath
        $terminal.console_encoding = $consoleFacts
        Send-M4 $outer 'CONTROLLER_RESULT' $terminal
        exit 0
    } catch {
        $primary = Get-M4RefusalReason $_.Exception
        # Preserve the primary error; settlement only observes the retained creator object.
        if ($null -ne $process -and -not $engineClosed) {
            try {
                $settleRemaining = [int][Math]::Floor(($deadline-[DateTime]::UtcNow).TotalMilliseconds)
                $settleWait = [Math]::Min(5000,[Math]::Max(0,$settleRemaining))
                if ($process.WaitForExit($settleWait)) {
                    $engineExit = $process.ExitCode
                    try {
                        if ($null -eq $engineDiagnostic) {
                            $engineDiagnostic = Get-M4EngineDiagnostic $stderrTask $engineIdentity $engineExit $deadline
                            if ($command -ceq 'RUN' -and -not $restoredReadOnly) { $diagnosticPath = Save-M4EngineDiagnostic $Root $engineDiagnostic }
                        }
                    } finally { $process.Close(); $engineClosed = $true }
                }
            } catch {}
        }
        if ($null -ne $outer) {
            try { Send-M4 $outer 'REFUSED' @{reason=$primary;ready=$false;replay_permitted=$false;start_capability=$false;engine_identity=$engineIdentity;engine_exit=$engineExit;engine_handle_closed=$engineClosed;engine_diagnostic=$engineDiagnostic;engine_diagnostic_path=$diagnosticPath;console_encoding=$consoleFacts} } catch {}
        }
        [Console]::Error.WriteLine('M4_CONTROLLER_REFUSED:'+ $primary)
        exit 2
    }
}
Export-ModuleMember -Function *
