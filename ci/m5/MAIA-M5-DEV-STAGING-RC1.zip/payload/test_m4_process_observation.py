"""Portable Win32-boundary controls, never native process/image proof."""
import ctypes as C
import unittest
from unittest.mock import patch
import m4_process_observation as m

class Fake:
    def __init__(self,rows=None,*,first_error=None,next_error=18,close_error=False,unknown=None,bad_handle=False,true_value=1):
        self.rows=rows if rows is not None else [(0,0,'Idle'),(10,1,'powershell.exe'),(11,10,'conhost.exe'),(20,1,'unrelated.exe')]
        self.first_error,self.next_error,self.close_error,self.unknown,self.bad_handle=first_error,next_error,close_error,unknown,bad_handle
        self.calls=[];self.frozen=False;self.at=0;self.closed=0;self.true_value=true_value
    def call(self,name,*args):
        row={'name':name,'state':'ENTERED'};self.calls.append(row)
        if self.unknown==name:self.frozen=True;row['state']='UNKNOWN';raise RuntimeError('unknown native return')
        if name=='CreateToolhelp32Snapshot':
            self.assert_args=args;value,error=(m.native.INVALID,5)if self.bad_handle else (123,0)
        else:
            if name=='Process32FirstW':self.at=0
            else:self.at+=1
            if self.first_error is not None and name=='Process32FirstW':value,error=0,self.first_error
            elif self.at>=len(self.rows):value,error=0,self.next_error
            else:
                entry=C.cast(args[1],C.POINTER(m.PROCESSENTRY32W)).contents
                assert entry.size==568
                pid,parent,image=self.rows[self.at];entry.pid=pid;entry.parent=parent
                for i in range(260):entry.image[i]=0
                encoded=image.encode('utf-16-le','surrogatepass');units=[int.from_bytes(encoded[i:i+2],'little')for i in range(0,len(encoded),2)]
                for i,n in enumerate(units[:260]):entry.image[i]=n
                value,error=self.true_value,0
        row.update(state='RETURNED',raw=value,error=error);return value,error
    def close(self,handle):
        self.closed+=1;self.calls.append({'name':'CloseHandle','state':'RETURNED','raw':0 if self.close_error else 1,'error':6 if self.close_error else 0})
        if self.close_error:raise m.Refusal('CloseHandle:6')

class ToolhelpControls(unittest.TestCase):
    def run_snapshot(self,fake,pids=None):
        with patch.object(m,'_Toolhelp',return_value=fake):return m.snapshot_processes([10,11]if pids is None else pids)
    def test_real_win64_layout_and_only_requested_metadata_no_authority(self):
        f=Fake();value=self.run_snapshot(f)
        self.assertEqual(C.sizeof(m.PROCESSENTRY32W),568);self.assertEqual(m.PROCESSENTRY32W.image.offset,44)
        self.assertEqual(f.assert_args,(2,0));self.assertEqual(value['processes'],[{'pid':10,'parent_pid':1,'image_name':'powershell.exe'},{'pid':11,'parent_pid':10,'image_name':'conhost.exe'}])
        self.assertEqual(value['scope'],'PROCESS_METADATA_ONLY_NO_AUTHORITY');self.assertTrue(value['snapshot_handle_closed']);self.assertEqual(f.closed,1)
        self.assertFalse(any(x['name'] in ('OpenProcess','GetProcessId')for x in f.calls))
    def test_invalid_pid_request_refuses_before_native_io(self):
        for value in (None,[],[0],[True],[10,10],[2**32],list(range(1,18)),(10,)):
            with self.subTest(value=value),patch.object(m,'_Toolhelp')as api,self.assertRaises(m.Refusal):m.snapshot_processes(value)
            api.assert_not_called()
    def test_documented_boolean_success_accepts_nonzero_signed_values(self):
        for value in (2,-1):
            f=Fake(true_value=value)
            with self.subTest(value=value):self.assertTrue(self.run_snapshot(f)['snapshot_handle_closed'])
            self.assertEqual(f.closed,1)
    def test_invalid_creation_handle_is_not_closed(self):
        f=Fake(bad_handle=True)
        with self.assertRaises(m.Refusal):self.run_snapshot(f)
        self.assertEqual(f.closed,0)
    def test_missing_member_or_duplicate_pid_refuses_and_closes_once(self):
        for rows in ([(10,1,'powershell.exe')],[(10,1,'a.exe'),(10,2,'b.exe')]):
            f=Fake(rows)
            with self.subTest(rows=rows),self.assertRaises(m.Refusal):self.run_snapshot(f)
            self.assertEqual(f.closed,1)
    def test_false_native_return_must_be_documented_end_of_list(self):
        for f in (Fake(first_error=5),Fake(next_error=299)):
            with self.assertRaises(m.Refusal):self.run_snapshot(f)
            self.assertEqual(f.closed,1)
    def test_malformed_selected_name_refuses_but_unrelated_names_are_not_exported(self):
        for image in ('a'*260,'bad/path.exe','bad\\path.exe','bad\nname.exe','\ud800.exe',''):
            f=Fake([(10,1,image),(11,10,'conhost.exe')])
            with self.subTest(image=repr(image)),self.assertRaises(m.Refusal):self.run_snapshot(f)
            self.assertEqual(f.closed,1)
        value=self.run_snapshot(Fake([(7,0,'\ud800.exe'),(10,1,'powershell.exe'),(11,10,'conhost.exe')]))
        self.assertEqual(len(value['processes']),2)
    def test_enumeration_bound_refuses_instead_of_partial_success(self):
        f=Fake([(i,1,'a.exe')for i in range(5)])
        with patch.object(m,'MAX_PROCESSES',3),self.assertRaises(m.Refusal):self.run_snapshot(f,[1])
        self.assertEqual(f.closed,1)
    def test_unknown_native_call_freezes_without_retrying_close(self):
        f=Fake(unknown='Process32NextW')
        with self.assertRaises(RuntimeError):self.run_snapshot(f)
        self.assertEqual(f.closed,0);self.assertTrue(f.frozen)
    def test_close_failure_never_claims_closed_and_never_retries(self):
        f=Fake(close_error=True)
        with self.assertRaises(m.Refusal):self.run_snapshot(f)
        self.assertEqual(f.closed,1)

if __name__=='__main__':unittest.main()
