param(
    [ValidateSet("Start","RunLoop","Status","Stop","Pause","Resume","Enqueue","Validate","DryRun","Recover","Stage","StageStatus","StageRecover")]
    [string]$Action = "Status",
    [string]$PromptId,
    [string]$Root = "C:\MAIA\orchestrator"
)

# M4 protected-proposal copy: no legacy/Git route may enter this experiment.
$stageSource = Split-Path -Parent $PSCommandPath
Import-Module (Join-Path $stageSource 'lib\Supervisor.Core.psm1') -Force -DisableNameChecking
Import-Module (Join-Path $stageSource 'lib\M4.Staging.psm1') -Force -DisableNameChecking
Invoke-M4Controller -Action $Action -Root $Root -PromptId $PromptId -SourceRoot $stageSource
return

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

$controllerScript = $PSCommandPath
$modulePath = Join-Path $Root "lib\Supervisor.Core.psm1"
if (-not (Test-Path -LiteralPath $modulePath)) { throw "Supervisor module missing: $modulePath" }
Import-Module $modulePath -Force -DisableNameChecking

$configPath = Join-Path $Root "config\config.json"
$config = Read-JsonFile $configPath

# Validate before any worker can start. Command argument mode must receive an
# already evaluated integer, never an unparenthesized [int] expression.
$pollSeconds = 0
if (-not [int]::TryParse([string]$config.poll_seconds, [ref]$pollSeconds) -or
    $pollSeconds -lt 1 -or $pollSeconds -gt 600) {
    throw 'CONFIG_POLL_SECONDS_INVALID: expected an integer from 1 to 600'
}

# Resolve package-local paths every time; config is not allowed to redirect state outside root.
$promptsDir = Join-Path $Root "prompts"
$runsDir = Join-Path $Root "runs"
$queuePath = Join-Path $Root "queue\queue.json"
$statePath = Join-Path $Root "state\state.json"
$logsDir = Join-Path $Root "logs"
$locksDir = Join-Path $Root "locks"
$workerScript = Join-Path $Root "worker\Run-CodexWorker.ps1"
$controllerLog = Join-Path $logsDir "controller.log"
$pauseReq = Join-Path $Root "state\pause.request"
$stopReq = Join-Path $Root "state\stop.request"
$supervisorPidFile = Join-Path $Root "state\supervisor.pid"

$config | Add-Member -NotePropertyName locks_dir -NotePropertyValue $locksDir -Force

$pendingRecovery = Join-Path $Root 'state\preflight-recovery.pending.json'

function Log-Ctl([string]$Message) {
    $line = "$(Get-UtcNowIso) $Message"
    Add-Content -LiteralPath $controllerLog -Value $line -Encoding UTF8
}

function Load-State { return (Read-JsonFile $statePath) }
function Save-State($s) { Write-JsonAtomic $statePath $s }
function Load-Queue { return (Read-JsonFile $queuePath) }
function Save-Queue($q) { Write-JsonAtomic $queuePath $q }

function Enqueue-PromptInternal([string]$Id) {
    $v = Test-PromptManifest -PromptsDir $promptsDir -PromptId $Id
    if (-not $v.ok) { throw "Cannot enqueue prompt: $($v.reason)" }
    $state = Load-State
    $m = $v.manifest
    if (-not (Test-CanReplayPrompt -Manifest $m -State $state -RunsDir $runsDir)) {
        throw "Replay/idempotency policy prevents enqueue: $Id ($($m.idempotency_policy))"
    }
    $q = Load-Queue
    $items = @($q.items)
    if ($items -contains $Id) { throw "Prompt already queued: $Id" }
    $items += $Id
    $q.items = $items
    Save-Queue $q
    Log-Ctl "ENQUEUE prompt_id=$Id"
}

function Resolve-CodexPath {
    if ($null -ne $config.codex_path -and -not [string]::IsNullOrWhiteSpace([string]$config.codex_path)) {
        return [string]$config.codex_path
    }
    $p = Join-Path $env:APPDATA "npm\codex.cmd"
    if (-not (Test-Path -LiteralPath $p)) { throw "Codex CLI not found: $p" }
    return $p
}

function Validate-All {
    $errors = @()
    $manifests = @(Get-ChildItem -LiteralPath $promptsDir -Filter "*.manifest.json" -File)
    foreach ($mf in $manifests) {
        $id = $mf.BaseName -replace '\.manifest$',''
        $v = Test-PromptManifest -PromptsDir $promptsDir -PromptId $id
        if (-not $v.ok) { $errors += "$id : $($v.reason)"; continue }
        $t = Test-ManifestTransitionTargets -PromptsDir $promptsDir -Manifest $v.manifest
        if (-not $t.ok) { $errors += "$id : $($t.reason)" }
    }
    try { Resolve-CodexPath | Out-Null } catch { $errors += $_.Exception.Message }
    if ($errors.Count -gt 0) {
        Write-Host "VALIDATION FAILED"
        $errors | ForEach-Object { Write-Host " - $_" }
        return $false
    }
    Write-Host "VALIDATION OK ($($manifests.Count) prompt manifests)"
    return $true
}

function Capture-ProcessSnapshot([string]$RunDir,[string]$Worktree,[string]$Reason) {
    $rows = @(Get-ProcessSnapshot -TargetWorktree $Worktree)
    $path = Join-Path $RunDir ("process-snapshot-" + (Get-Date -Format "yyyyMMdd-HHmmss") + ".json")
    Write-JsonAtomic $path ([pscustomobject]@{at_utc=Get-UtcNowIso;reason=$Reason;processes=$rows})
}


# These records narrow PID adoption and accidental integrity drift. They do not
# establish isolation from another process with this user's filesystem rights.
function Get-WorkerProcessEvidence([int]$ProcessId) {
    $native = $null
    try {
        if ($ProcessId -le 0) { throw 'PID_INVALID' }
        Import-Module (Join-Path $PSHOME 'Modules\CimCmdlets\CimCmdlets.psd1') -ErrorAction Stop
        $rows = @(Get-CimInstance Win32_Process -Filter ("ProcessId = " + $ProcessId) -ErrorAction Stop)
        if ($rows.Count -eq 0) { return [pscustomobject]@{ok=$true;alive=$false;reason='ABSENT';process=$null} }
        if ($rows.Count -ne 1) { throw 'PROCESS_QUERY_NOT_UNIQUE' }
        $row = $rows[0]
        if ($null -eq $row.CreationDate -or [string]::IsNullOrWhiteSpace([string]$row.ExecutablePath) -or
            [string]::IsNullOrWhiteSpace([string]$row.CommandLine)) { throw 'PROCESS_FIELDS_UNREADABLE' }
        # Native creation ticks also bind the observed process handle, avoiding
        # CIM's microsecond rounding as the sole process-instance identity.
        $native = Get-Process -Id $ProcessId -ErrorAction Stop
        $nativeTicks = [int64]$native.StartTime.ToUniversalTime().Ticks
        $cimTicks = [int64]$row.CreationDate.ToUniversalTime().Ticks
        if ($native.HasExited -or [Math]::Abs($nativeTicks - $cimTicks) -gt 9) { throw 'PROCESS_CHANGED_DURING_QUERY' }
        return [pscustomobject]@{ok=$true;alive=$true;reason='PRESENT';process=[pscustomobject]@{
            pid=[int]$row.ProcessId;created_ticks=$nativeTicks;cim_created_ticks=$cimTicks;
            executable_path=[IO.Path]::GetFullPath([string]$row.ExecutablePath);
            command_line=[string]$row.CommandLine;command_sha256=Get-Sha256String ([string]$row.CommandLine)
        }}
    } catch { return [pscustomobject]@{ok=$false;alive=$null;reason=('PROCESS_READ_FAILED:'+ $_.Exception.Message);process=$null} }
    finally { if ($null -ne $native) { $native.Dispose() } }
}

function Assert-WorkerBindingPath([string]$Path) {
    $full = [IO.Path]::GetFullPath($Path)
    $item = Get-Item -LiteralPath $full -Force -ErrorAction Stop
    if ($item.PSIsContainer) { throw 'BINDING_NOT_FILE' }
    while ($null -ne $item) {
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'BINDING_REPARSE_REFUSED' }
        $parent = Split-Path $item.FullName -Parent
        if ([string]::IsNullOrEmpty($parent) -or $parent -eq $item.FullName) { break }
        $item = Get-Item -LiteralPath $parent -Force -ErrorAction Stop
    }
    return $full
}

function Get-WorkerInterpreterProof([string]$Executable) {
    $expected = [IO.Path]::GetFullPath((Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'))
    if (-not [string]::Equals([IO.Path]::GetFullPath($Executable),$expected,[StringComparison]::OrdinalIgnoreCase)) {
        throw 'INTERPRETER_PATH_CHANGED'
    }
    [void](Assert-WorkerBindingPath $expected)
    $securityModule = Join-Path $PSHOME 'Modules\Microsoft.PowerShell.Security\Microsoft.PowerShell.Security.psd1'
    Import-Module -Name $securityModule -ErrorAction Stop
    $signature = Get-AuthenticodeSignature -LiteralPath $expected -ErrorAction Stop
    if ([string]$signature.Status -ne 'Valid' -or $null -eq $signature.SignerCertificate -or
        [string]$signature.SignerCertificate.Subject -notmatch '^CN=Microsoft Windows,.*O=Microsoft Corporation,') {
        throw 'INTERPRETER_SIGNATURE_UNVERIFIED'
    }
    return [pscustomobject]@{executable_path=$expected;file_sha256=Get-Sha256File $expected;
        signer_thumbprint=[string]$signature.SignerCertificate.Thumbprint;
        signer_subject=[string]$signature.SignerCertificate.Subject}
}

function Test-WorkerCommandBinding([string]$Command,[string]$Executable,[string]$Arguments) {
    foreach ($prefix in @(('"'+$Executable+'" '),($Executable+' '))) {
        if ($Command.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)) {
            $rest = $Command.Substring($prefix.Length)
            # WinPS 5.1 BuildCommandLine appends one ASCII space. Preserve the
            # complete raw command hash; permit only that observed suffix here.
            if ($rest -ceq $Arguments -or $rest -ceq ($Arguments+' ')) { return $true }
        }
    }
    return $false
}

function Get-WorkerRunBinding($State) {
    $runId = [string]$State.current_run_id; $id = [string]$State.current_prompt_id
    if ($runId -notmatch '^[A-Za-z0-9_-][A-Za-z0-9._-]*$' -or
        $id -notmatch '^[A-Za-z0-9_-][A-Za-z0-9._-]*$') { throw 'RUN_OR_PROMPT_ID_INVALID' }
    $expectedRun = [IO.Path]::GetFullPath((Join-Path $runsDir $runId))
    if (-not [string]::Equals([IO.Path]::GetFullPath([string]$State.current_run_dir),$expectedRun,[StringComparison]::OrdinalIgnoreCase)) {
        throw 'RUN_DIRECTORY_BINDING_CHANGED'
    }
    $prompt = Assert-WorkerBindingPath (Join-Path $expectedRun 'prompt.snapshot.txt')
    $metaPath = Assert-WorkerBindingPath (Join-Path $expectedRun 'supervisor-run.json')
    $m = Test-PromptManifest -PromptsDir $promptsDir -PromptId $id
    if (-not $m.ok) { throw ('PROMPT_BINDING_INVALID:'+ $m.reason) }
    $meta = Read-JsonFile $metaPath; $promptHash = Get-Sha256File $prompt
    if ([string]$meta.run_id -cne $runId -or [string]$meta.prompt_id -cne $id -or
        [string]$meta.prompt_sha256 -cne $promptHash -or [string]$m.manifest.sha256 -cne $promptHash -or
        [string]$meta.worktree -cne [string]$State.current_worktree -or
        [string]$meta.worktree -cne [string]$m.manifest.worktree -or
        [string]$meta.branch -cne [string]$State.current_branch -or
        [string]$meta.stage -cne [string]$State.current_stage) { throw 'RUN_METADATA_BINDING_CHANGED' }
    return [pscustomobject]@{run_id=$runId;prompt_id=$id;run_dir=$expectedRun;prompt_path=$prompt;
        prompt_sha256=$promptHash;supervisor_run_sha256=Get-Sha256File $metaPath}
}

function New-WorkerIdentityRecord($State,$OwnedProcess,[string]$Arguments) {
    $binding = Get-WorkerRunBinding $State
    $evidence = Get-WorkerProcessEvidence ([int]$OwnedProcess.Id)
    if (-not $evidence.ok -or -not $evidence.alive) { throw ('CAPTURE_UNCERTAIN:'+ $evidence.reason) }
    $p = $evidence.process
    if ([int64]$OwnedProcess.StartTime.ToUniversalTime().Ticks -ne [int64]$p.created_ticks -or
        $OwnedProcess.HasExited -or [int]$p.pid -ne [int]$State.current_worker_pid) { throw 'OWNED_LAUNCH_INSTANCE_CHANGED' }
    $proof = Get-WorkerInterpreterProof ([string]$p.executable_path)
    if (-not (Test-WorkerCommandBinding ([string]$p.command_line) ([string]$proof.executable_path) $Arguments)) {
        throw 'OWNED_LAUNCH_COMMAND_CHANGED'
    }
    $worker = Assert-WorkerBindingPath $workerScript
    $controller = Assert-WorkerBindingPath $controllerScript
    $core = Assert-WorkerBindingPath $modulePath
    $record = [pscustomobject]@{schema_version=1;purpose='MAIA_WORKER_IDENTITY';
        run_id=$binding.run_id;prompt_id=$binding.prompt_id;run_dir=$binding.run_dir;
        prompt_path=$binding.prompt_path;prompt_sha256=$binding.prompt_sha256;
        supervisor_run_sha256=$binding.supervisor_run_sha256;pid=$p.pid;created_ticks=$p.created_ticks;
        cim_created_ticks=$p.cim_created_ticks;executable_path=$proof.executable_path;
        executable_sha256=$proof.file_sha256;signer_thumbprint=$proof.signer_thumbprint;signer_subject=$proof.signer_subject;
        command_sha256=$p.command_sha256;launch_arguments=$Arguments;
        worker_script=$worker;worker_sha256=Get-Sha256File $worker;
        controller_script=$controller;controller_sha256=Get-Sha256File $controller;
        core_path=$core;core_sha256=Get-Sha256File $core;captured_utc=Get-UtcNowIso}
    $path = Join-Path $binding.run_dir 'worker-identity.json'
    if (Test-Path -LiteralPath $path) { throw 'IDENTITY_RECORD_ALREADY_EXISTS' }
    Write-JsonAtomic $path $record
    return (Get-Sha256File $path)
}

function Test-WorkerIdentity($State) {
    if ([string]$State.status -ne 'ACTIVE') { return [pscustomobject]@{ok=$true;alive=$null;reason='TERMINAL_NO_ATTACH'} }
    try {
        $prop = $State.PSObject.Properties['current_worker_identity_sha256']
        if ($null -eq $prop -or [string]$prop.Value -notmatch '^[0-9a-f]{64}$') { throw 'IDENTITY_RECORD_BINDING_MISSING' }
        $binding = Get-WorkerRunBinding $State
        $path = Assert-WorkerBindingPath (Join-Path $binding.run_dir 'worker-identity.json')
        if ((Get-Item -LiteralPath $path).Length -gt 16384 -or (Get-Sha256File $path) -cne [string]$prop.Value) {
            throw 'IDENTITY_RECORD_HASH_CHANGED'
        }
        $r = Read-JsonFile $path
        if ([int]$r.schema_version -ne 1 -or [string]$r.purpose -cne 'MAIA_WORKER_IDENTITY' -or
            [string]$r.run_id -cne $binding.run_id -or [string]$r.prompt_id -cne $binding.prompt_id -or
            [string]$r.run_dir -cne $binding.run_dir -or [string]$r.prompt_path -cne $binding.prompt_path -or
            [string]$r.prompt_sha256 -cne $binding.prompt_sha256 -or
            [string]$r.supervisor_run_sha256 -cne $binding.supervisor_run_sha256 -or
            [int]$r.pid -ne [int]$State.current_worker_pid -or [int64]$r.created_ticks -le 0 -or
            [int64]$r.cim_created_ticks -le 0 -or [string]$r.command_sha256 -notmatch '^[0-9a-f]{64}$' -or
            [string]::IsNullOrWhiteSpace([string]$r.launch_arguments)) { throw 'IDENTITY_TUPLE_BINDING_CHANGED' }
        foreach ($pair in @(@($workerScript,$r.worker_script,$r.worker_sha256),
            @($controllerScript,$r.controller_script,$r.controller_sha256),@($modulePath,$r.core_path,$r.core_sha256))) {
            $actual = Assert-WorkerBindingPath ([string]$pair[0])
            if ([string]$pair[1] -cne $actual -or [string]$pair[2] -cne (Get-Sha256File $actual)) { throw 'SCRIPT_INTEGRITY_CHANGED' }
        }
        $proof = Get-WorkerInterpreterProof ([string]$r.executable_path)
        if ([string]$proof.file_sha256 -cne [string]$r.executable_sha256 -or
            [string]$proof.signer_thumbprint -cne [string]$r.signer_thumbprint -or
            [string]$proof.signer_subject -cne [string]$r.signer_subject) { throw 'INTERPRETER_INTEGRITY_CHANGED' }
        $evidence = Get-WorkerProcessEvidence ([int]$r.pid)
        if (-not $evidence.ok) { throw $evidence.reason }
        if (-not $evidence.alive) { return [pscustomobject]@{ok=$true;alive=$false;reason='OWNED_WORKER_ABSENT'} }
        $p = $evidence.process
        if ([int]$p.pid -ne [int]$r.pid -or [int64]$p.created_ticks -ne [int64]$r.created_ticks -or
            [int64]$p.cim_created_ticks -ne [int64]$r.cim_created_ticks -or
            -not [string]::Equals([string]$p.executable_path,[string]$r.executable_path,[StringComparison]::OrdinalIgnoreCase) -or
            [string]$p.command_sha256 -cne [string]$r.command_sha256 -or
            -not (Test-WorkerCommandBinding ([string]$p.command_line) ([string]$r.executable_path) ([string]$r.launch_arguments))) {
            throw 'PROCESS_INSTANCE_CHANGED'
        }
        return [pscustomobject]@{ok=$true;alive=$true;reason='EXACT_OWNED_WORKER'}
    } catch { return [pscustomobject]@{ok=$false;alive=$null;reason=('WORKER_IDENTITY_BLOCKED:'+ $_.Exception.Message)} }
}

function Assert-ActiveWorkerIdentity($State) {
    $identity = Test-WorkerIdentity $State
    if (-not $identity.ok) { throw $identity.reason }
    return $identity
}

function Start-Run([string]$Id) {
    $v = Test-PromptManifest -PromptsDir $promptsDir -PromptId $Id
    if (-not $v.ok) { throw "Prompt validation failed: $($v.reason)" }
    $m = $v.manifest
    $state = Load-State
    if (-not (Test-CanReplayPrompt -Manifest $m -State $state -RunsDir $runsDir)) { throw "Replay policy blocks $Id" }

    $pre = Test-Preflight -Config $config -Manifest $m -PromptsDir $promptsDir -State $state
    if (-not $pre.ok) { throw "Preflight failed: $($pre.reason)" }

    $runId = New-RunId $Id
    $runDir = Join-Path $runsDir $runId
    New-Item -ItemType Directory -Path $runDir -Force | Out-Null

    $srcPrompt = Get-PromptTextPath $promptsDir $m
    $snapshot = Join-Path $runDir "prompt.snapshot.txt"
    Copy-Item -LiteralPath $srcPrompt -Destination $snapshot
    $snapshotHash = Get-Sha256File $snapshot
    if ($snapshotHash -ne ([string]$m.sha256).ToLowerInvariant()) { throw "Snapshot hash mismatch" }
    [System.IO.File]::WriteAllText((Join-Path $runDir "prompt.sha256"), $snapshotHash, (New-Object Text.UTF8Encoding($false)))

    $codex = Resolve-CodexPath
    $cmdDisplay = "powershell.exe -NoProfile -ExecutionPolicy Bypass -File $workerScript -RunDir $runDir -PromptPath $snapshot -CodexPath $codex -WorkDir $($config.codex_workdir)"
    Write-JsonAtomic (Join-Path $runDir "supervisor-run.json") ([pscustomobject]@{
        schema_version=1; run_id=$runId; prompt_id=$Id; prompt_sha256=$snapshotHash;
        milestone=$m.milestone; stage=$m.stage; worktree=$m.worktree; branch=$m.branch;
        idempotency_policy=$m.idempotency_policy; created_utc=Get-UtcNowIso; command=$cmdDisplay
    })

    Save-WorktreeLock -Path ([string]$pre.worktree_lock) -RunId $runId -PromptId $Id -Worktree ([string]$m.worktree)

    $psExe = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
    $workerStdout = Join-Path $runDir "worker.stdout.log"
    $workerStderr = Join-Path $runDir "worker.stderr.log"
    $args = @(
        "-NoProfile","-ExecutionPolicy","Bypass","-File",$workerScript,
        "-RunDir",$runDir,"-PromptPath",$snapshot,"-CodexPath",$codex,"-WorkDir",[string]$config.codex_workdir
    )
    $proc = Start-Process -FilePath $psExe -ArgumentList $args -PassThru -WindowStyle Hidden `
        -RedirectStandardOutput $workerStdout -RedirectStandardError $workerStderr

    $ownedProcessId = $null
    try {
        $ownedProcessId = [int]$proc.Id
        $old = [string]$state.status
        $state.status = "ACTIVE"
        $state.run_health = "OK"
        $state.current_run_id = $runId
        $state.current_prompt_id = $Id
        $state.current_stage = [string]$m.stage
        $state.expected_milestone = [string]$m.milestone
        $state.current_worker_pid = $ownedProcessId
        $state.current_worktree = [string]$m.worktree
        $state.current_branch = [string]$m.branch
        $state.current_run_dir = $runDir
        $state.started_utc = Get-UtcNowIso
        $state.last_heartbeat_utc = Get-UtcNowIso
        $state.last_log_size = 0
        $state.last_log_change_utc = Get-UtcNowIso
        $state.verdict = $null
        $state.exit_code = $null
        $state.stop_reason = $null
        $state = Add-StateTransition $state $old "ACTIVE" $Id "RUN_STARTED:$runId"
        $state | Add-Member -NotePropertyName current_worker_identity_sha256 -NotePropertyValue $null -Force
        $identityHash = New-WorkerIdentityRecord $state $proc ($args -join ' ')
        $state | Add-Member -NotePropertyName current_worker_identity_sha256 -NotePropertyValue $identityHash -Force
        Save-State $state
        Log-Ctl "RUN_START run_id=$runId prompt_id=$Id worker_pid=$ownedProcessId"
        Capture-ProcessSnapshot $runDir ([string]$m.worktree) "RUN_START"
    } catch {
        # All work after a returned launch is outcome-sensitive. Retain the
        # primary exception even if publishing ACTIVE or diagnostics also fails.
        $primaryException = $_.Exception
        $accountingFailure = $null
        try { Save-State $state }
        catch { $accountingFailure = $_.Exception.Message }
        $blocked = 'WORKER_IDENTITY_BLOCKED:POST_LAUNCH:run_id='+$runId+
            ';pid='+[string]$ownedProcessId+';primary='+$primaryException.Message
        if ($null -ne $accountingFailure) { $blocked += ';ACCOUNTING_WRITE_FAILED:'+ $accountingFailure }
        try { Log-Ctl $blocked } catch {}
        throw ([InvalidOperationException]::new($blocked,$primaryException))
    }

}

function Finalize-Run($state) {
    $identity = Assert-ActiveWorkerIdentity $state
    if ($identity.alive -ne $false) { throw 'WORKER_IDENTITY_BLOCKED:FINALIZE_WITHOUT_CONFIRMED_ABSENCE' }
    $runDir = [string]$state.current_run_dir
    $id = [string]$state.current_prompt_id
    $v = Test-PromptManifest -PromptsDir $promptsDir -PromptId $id
    if (-not $v.ok) { throw "Manifest became invalid during run: $($v.reason)" }
    $m = $v.manifest
    $exitFile = Join-Path $runDir "exit-code.txt"
    if (-not (Test-Path -LiteralPath $exitFile)) {
        $state.status = "STOP_HUMAN_REVIEW"
        $state.stop_reason = "WORKER_EXIT_WITHOUT_EXIT_CODE"
        $state = Add-StateTransition $state "ACTIVE" "STOP_HUMAN_REVIEW" $id $state.stop_reason
        Save-State $state
        return $state
    }
    $codeText = ([System.IO.File]::ReadAllText($exitFile)).Trim()
    $code = 999
    if (-not [int]::TryParse($codeText, [ref]$code)) {
        $state.status = "STOP_HUMAN_REVIEW"
        $state.stop_reason = "INVALID_EXIT_CODE"
        $state = Add-StateTransition $state "ACTIVE" "STOP_HUMAN_REVIEW" $id $state.stop_reason
        Save-State $state
        return $state
    }
    $state.exit_code = $code
    if ($code -ne 0) {
        $state.status = "STOP_HUMAN_REVIEW"
        $state.stop_reason = "NONZERO_EXIT:$code"
        $state = Add-StateTransition $state "ACTIVE" "STOP_HUMAN_REVIEW" $id $state.stop_reason
        Save-State $state
        return $state
    }

    $ver = Get-StrictVerdict -FinalPath (Join-Path $runDir "FINAL.md") -Manifest $m -PromptsDir $promptsDir
    if (-not $ver.ok) {
        $state.status = "STOP_HUMAN_REVIEW"
        $state.stop_reason = "VERDICT_PARSE_FAILURE:$($ver.reason)"
        $state = Add-StateTransition $state "ACTIVE" "STOP_HUMAN_REVIEW" $id $state.stop_reason
        Save-State $state
        return $state
    }
    $state.verdict = $ver.verdict
    $target = Get-TransitionTarget -Manifest $m -Verdict $ver.verdict
    if ([string]::IsNullOrWhiteSpace($target)) {
        $state.status = "STOP_HUMAN_REVIEW"
        $state.stop_reason = "NO_TRANSITION_FOR_VERDICT:$($ver.verdict)"
        $state = Add-StateTransition $state "ACTIVE" "STOP_HUMAN_REVIEW" $id $state.stop_reason
        Save-State $state
        return $state
    }

    $summary = [pscustomobject]@{
        run_id=$state.current_run_id; prompt_id=$id; milestone=$m.milestone; stage=$m.stage;
        exit_code=$code; verdict=$ver.verdict; transition_target=$target; finished_utc=Get-UtcNowIso
    }
    Write-JsonAtomic (Join-Path $runDir "summary.json") $summary

    # Release only the lock at this worktree's path with its exact owner tuple.
    # Post-run repository/process state is deliberately not used as a gate.
    if ([string]$state.current_worktree -cne [string]$m.worktree) {
        throw 'RUN_WORKTREE_IDENTITY_CHANGED'
    }
    $ownedLockPath = Get-WorktreeLockPath -LocksDir $locksDir -Worktree ([string]$m.worktree)
    [void](Remove-WorktreeLock -Path $ownedLockPath -RunId ([string]$state.current_run_id) `
        -PromptId $id -Worktree ([string]$m.worktree))

    $old = [string]$state.status
    if ($target -eq "STOP_HUMAN_REVIEW") {
        $state.status = "STOP_HUMAN_REVIEW"
        $state.stop_reason = "VERDICT:$($ver.verdict)"
        $state = Add-StateTransition $state $old "STOP_HUMAN_REVIEW" $id "VERDICT:$($ver.verdict)"
    } elseif ($target -eq "PIPELINE_COMPLETE") {
        $state.status = "PIPELINE_COMPLETE"
        $state.stop_reason = $null
        $state = Add-StateTransition $state $old "PIPELINE_COMPLETE" $id "VERDICT:$($ver.verdict)"
    } else {
        $state.status = "IDLE"
        $state.stop_reason = $null
        $state = Add-StateTransition $state $old "COMPLETED" $id "VERDICT:$($ver.verdict)"
        # Clear run before enqueue validation.
        $state.current_run_id=$null; $state.current_prompt_id=$null; $state.current_stage=$null
        $state.expected_milestone=$null; $state.current_worker_pid=$null; $state.current_worktree=$null
        $state.current_worker_identity_sha256=$null
        $state.current_branch=$null; $state.current_run_dir=$null; $state.started_utc=$null
        Save-State $state
        Enqueue-PromptInternal $target
        return (Load-State)
    }
    Save-State $state
    return $state
}

function Monitor-Run($state) {
    if ([string]$state.status -ne 'ACTIVE') { return $state }
    $runDir = [string]$state.current_run_dir
    $identity = Assert-ActiveWorkerIdentity $state
    $workerProcessId = [int]$state.current_worker_pid
    $alive = [bool]$identity.alive
    # A second identity check inside Finalize must precede heartbeat/state writes.
    if (-not $alive) { return (Finalize-Run $state) }

    $session = Join-Path $runDir "SESSION.log"
    $size = 0
    $mtime = $null
    if (Test-Path -LiteralPath $session) {
        $fi = Get-Item -LiteralPath $session
        $size = [int64]$fi.Length
        $mtime = $fi.LastWriteTimeUtc
    }
    $now = [DateTime]::UtcNow
    if ($size -ne [int64]$state.last_log_size) {
        $state.last_log_size = $size
        $state.last_log_change_utc = $now.ToString("o")
        $state.run_health = "OK"
    } else {
        $lastChange = $now
        try { $lastChange = [DateTime]::Parse([string]$state.last_log_change_utc).ToUniversalTime() } catch {}
        if (($now - $lastChange).TotalSeconds -ge [int]$config.stall_seconds) {
            if ([string]$state.run_health -ne "POSSIBLE_STALL") {
                $state.run_health = "POSSIBLE_STALL"
                Capture-ProcessSnapshot $runDir ([string]$state.current_worktree) "POSSIBLE_STALL"
                Log-Ctl "POSSIBLE_STALL run_id=$($state.current_run_id)"
            }
        }
    }

    $lastHb = $now.AddYears(-1)
    try { $lastHb = [DateTime]::Parse([string]$state.last_heartbeat_utc).ToUniversalTime() } catch {}
    if (($now - $lastHb).TotalSeconds -ge [int]$config.heartbeat_seconds) {
        $hbPath = Join-Path $runDir "heartbeat.jsonl"
        $hb = [pscustomobject]@{
            at_utc=$now.ToString("o"); worker_alive=$alive; worker_pid=$workerProcessId; run_health=$state.run_health;
            session_log_size=$size; session_last_write_utc=if($mtime){$mtime.ToString("o")}else{$null};
            free_bytes_c=Get-FreeBytesC
        }
        ($hb | ConvertTo-Json -Compress -Depth 8) | Add-Content -LiteralPath $hbPath -Encoding UTF8
        $state.last_heartbeat_utc = $now.ToString("o")
        Log-Ctl "HEARTBEAT run_id=$($state.current_run_id) alive=$alive health=$($state.run_health) bytes=$size"
    }
    Save-State $state

    return $state
}

function Run-Controller {
    $mutex = [System.Threading.Mutex]::new($false, "MAIA_Codex_Supervisor_v1")
    $have = $false
    try { $have = $mutex.WaitOne(0) }
    catch [System.Threading.AbandonedMutexException] { $have = $true }
    if (-not $have) { throw "Another MAIA Codex Supervisor is already running." }
    $controllerStarted = $false
    $pidWritten = $false
    try {
        # Refuse an unknown ACTIVE worker before controller/state writes.
        [void](Assert-ActiveWorkerIdentity (Load-State))
        [void](Resolve-PreflightRecoveryMarker -Root $Root)
        [System.IO.File]::WriteAllText($supervisorPidFile,[string]$PID,(New-Object Text.UTF8Encoding($false)))
        $pidWritten = $true
        $s = Load-State
        $s.supervisor_pid = $PID
        Save-State $s
        Log-Ctl "SUPERVISOR_START pid=$PID"
        $controllerStarted = $true

        while ($true) {
            $s = Load-State
            [void](Assert-ActiveWorkerIdentity $s)

            if (Test-Path -LiteralPath $stopReq) {
                if ([string]$s.status -eq "ACTIVE") {
                    $s.stop_reason = "STOP_REQUESTED_AFTER_CURRENT_RUN"
                    Save-State $s
                } else {
                    $s.status = "STOPPED"
                    $s.stop_reason = "STOP_REQUESTED"
                    Save-State $s
                    Remove-Item -LiteralPath $stopReq -Force -ErrorAction SilentlyContinue
                    break
                }
            }

            if ([string]$s.status -eq "ACTIVE") {
                $s = Monitor-Run $s
                if ([string]$s.status -ne "ACTIVE" -and (Test-Path -LiteralPath $stopReq)) {
                    $s.status="STOPPED"; $s.stop_reason="STOP_REQUESTED_AFTER_CURRENT_RUN"; Save-State $s
                    Remove-Item -LiteralPath $stopReq -Force -ErrorAction SilentlyContinue
                    break
                }
            } elseif ([string]$s.status -in @("STOP_HUMAN_REVIEW","PIPELINE_COMPLETE","STOPPED","INTERRUPTED")) {
                break
            } elseif (Test-Path -LiteralPath $pauseReq) {
                if ([string]$s.status -ne "PAUSED") { $s.status="PAUSED"; Save-State $s }
            } else {
                if ([string]$s.status -eq "PAUSED") { $s.status="IDLE"; Save-State $s }
                $q = Load-Queue
                $items = @($q.items)
                if ($items.Count -gt 0) {
                    $next = [string]$items[0]
                    if ($items.Count -eq 1) { $q.items=@() } else { $q.items=@($items[1..($items.Count-1)]) }
                    Save-Queue $q
                    try {
                        Start-Run $next
                    } catch {
                        $startException = $_.Exception
                        if ($startException.Message.StartsWith('WORKER_IDENTITY_BLOCKED:')) {
                            # Do not read/write state or invent START_FAILURE
                            # after a launch whose accounting may be unpublished.
                            try { Log-Ctl $startException.Message } catch {}
                            throw $startException
                        }
                        $s=Load-State
                        $s.status="STOP_HUMAN_REVIEW"
                        $s.stop_reason="START_FAILURE:$($_.Exception.Message)"
                        $s=Add-StateTransition $s ([string]$s.status) "STOP_HUMAN_REVIEW" $next $s.stop_reason
                        Save-State $s
                        Log-Ctl $s.stop_reason
                        break
                    }
                }
            }
            Start-Sleep -Seconds $pollSeconds
        }
    } finally {
        if ($controllerStarted) { try { Log-Ctl "SUPERVISOR_EXIT" } catch {} }
        if ($pidWritten) { Remove-Item -LiteralPath $supervisorPidFile -Force -ErrorAction SilentlyContinue }
        try { $mutex.ReleaseMutex() } catch {}
        $mutex.Dispose()
    }
}

# Guard attach/monitor entry before the existing pending-recovery resolver.
# No legacy identity is inferred from PID or worker-authored metadata.
if ($Action -in @('Start','RunLoop','Recover')) {
    if (Test-Path -LiteralPath $statePath -PathType Leaf) {
        $entryState = Load-State
        if ($Action -eq 'Recover' -and [string]$entryState.status -ne 'ACTIVE') {
            Write-Host "No ACTIVE run to recover. State=$($entryState.status)"
            return
        }
        [void](Assert-ActiveWorkerIdentity $entryState)
    } elseif ($Action -in @('RunLoop','Recover')) {
        throw 'WORKER_IDENTITY_BLOCKED:STATE_MISSING'
    }
}

# Keep the existing bootstrap after identity admission. A failed attach must
# not fabricate missing inputs or mutate evidence before the guard runs.
if (Test-Path -LiteralPath $pendingRecovery) {
    # A pending transaction owns these inputs. Never fabricate a missing file
    # before the resolver has checked its recorded hashes.
    foreach ($d in @($promptsDir,$runsDir,(Split-Path $queuePath -Parent),
        (Split-Path $statePath -Parent),$logsDir,$locksDir)) {
        if (-not (Test-Path -LiteralPath $d -PathType Container)) {
            throw ('PREFLIGHT_RECOVERY_DIRECTORY_MISSING:'+$d)
        }
    }
    foreach ($path in @($statePath,$queuePath,$controllerLog)) {
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
            throw ('PREFLIGHT_RECOVERY_INPUT_MISSING:'+$path)
        }
    }
} else {
    foreach ($d in @($promptsDir,$runsDir,(Split-Path $queuePath -Parent),
        (Split-Path $statePath -Parent),$logsDir,$locksDir)) {
        if (-not (Test-Path -LiteralPath $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
    }
    if (-not (Test-Path -LiteralPath $statePath)) { Write-JsonAtomic $statePath (New-DefaultState) }
    if (-not (Test-Path -LiteralPath $queuePath)) { Write-JsonAtomic $queuePath ([pscustomobject]@{schema_version=1;items=@()}) }
}


if ($Action -in @('Start','Enqueue','Resume','Recover') -and
    (Test-Path -LiteralPath (Join-Path $Root 'state\preflight-recovery.pending.json'))) {
    $recoveryMutex = [Threading.Mutex]::new($false,'MAIA_Codex_Supervisor_v1')
    $recoveryHeld = $false
    try {
        try { $recoveryHeld = $recoveryMutex.WaitOne(0) }
        catch [Threading.AbandonedMutexException] { $recoveryHeld = $true }
        if (-not $recoveryHeld) { throw 'PREFLIGHT_RECOVERY_SUPERVISOR_BUSY' }
        [void](Resolve-PreflightRecoveryMarker -Root $Root)
    } finally {
        if ($recoveryHeld) { try { $recoveryMutex.ReleaseMutex() } catch {} }
        $recoveryMutex.Dispose()
    }
}

switch ($Action) {
    "Validate" {
        if (-not (Validate-All)) { exit 2 }
    }
    "DryRun" {
        if (-not (Validate-All)) { exit 2 }
        $s=Load-State; $q=Load-Queue
        Write-Host "State: $($s.status)"
        Write-Host "Queued prompts: $(@($q.items).Count)"
        foreach($id in @($q.items)) {
            $v=Test-PromptManifest $promptsDir ([string]$id)
            if (-not $v.ok) { throw $v.reason }
            $p=Test-Preflight $config $v.manifest $promptsDir $s
            Write-Host "$id -> preflight=$($p.ok) reason=$($p.reason)"
        }
    }
    "Enqueue" {
        if ([string]::IsNullOrWhiteSpace($PromptId)) { throw "-PromptId required" }
        Enqueue-PromptInternal $PromptId
        Write-Host "Queued: $PromptId"
    }
    "Start" {
        if ($PromptId) { Enqueue-PromptInternal $PromptId }
        if (-not (Validate-All)) { exit 2 }
        if (Test-Path -LiteralPath $supervisorPidFile) {
            $oldPid = 0
            [int]::TryParse(([IO.File]::ReadAllText($supervisorPidFile).Trim()),[ref]$oldPid) | Out-Null
            if ($oldPid -gt 0 -and (Get-Process -Id $oldPid -ErrorAction SilentlyContinue)) {
                throw "Supervisor already running PID=$oldPid"
            }
            Remove-Item -LiteralPath $supervisorPidFile -Force -ErrorAction SilentlyContinue
        }
        $psExe = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
        $stdout = Join-Path $logsDir "supervisor.stdout.log"
        $stderr = Join-Path $logsDir "supervisor.stderr.log"
        $self = $MyInvocation.MyCommand.Path
        $p = Start-Process -FilePath $psExe -ArgumentList @("-NoProfile","-ExecutionPolicy","Bypass","-File",$self,"-Action","RunLoop","-Root",$Root) `
            -PassThru -WindowStyle Hidden -RedirectStandardOutput $stdout -RedirectStandardError $stderr
        Write-Host "Supervisor launched PID=$($p.Id)"
        Write-Host "Use: powershell -ExecutionPolicy Bypass -File `"$self`" -Action Status"
    }
    "RunLoop" { Run-Controller }
    "Status" {
        $s=Load-State; $q=Load-Queue
        $s | Format-List
        Write-Host "Queue: $(@($q.items) -join ', ')"
        if ($s.current_run_dir -and (Test-Path -LiteralPath ([string]$s.current_run_dir))) {
            Write-Host "RunDir: $($s.current_run_dir)"
        }
    }
    "Stop" {
        [IO.File]::WriteAllText($stopReq,(Get-UtcNowIso),(New-Object Text.UTF8Encoding($false)))
        Write-Host "Graceful stop requested. Active Codex run will not be killed."
    }
    "Pause" {
        [IO.File]::WriteAllText($pauseReq,(Get-UtcNowIso),(New-Object Text.UTF8Encoding($false)))
        Write-Host "Pause requested. Active run continues; no next run will start."
    }
    "Resume" {
        Remove-Item -LiteralPath $pauseReq -Force -ErrorAction SilentlyContinue
        $s=Load-State
        if ($s.status -eq "PAUSED") { $s.status="IDLE"; Save-State $s }
        Write-Host "Resume requested."
    }
    "Recover" {
        $s=Load-State
        if ($s.status -ne "ACTIVE") { Write-Host "No ACTIVE run to recover. State=$($s.status)"; break }
        $workerProcessId=0; [int]::TryParse([string]$s.current_worker_pid,[ref]$workerProcessId)|Out-Null
        $identity = Assert-ActiveWorkerIdentity $s
        if ($identity.alive) {
            Write-Host "Exact owned worker PID=$workerProcessId is alive. Start supervisor to attach-monitor."
            & $MyInvocation.MyCommand.Path -Action Start -Root $Root
        } else {
            $s.status="INTERRUPTED"
            $s.stop_reason="RECOVERY_WORKER_NOT_ALIVE_NO_AUTO_REPLAY"
            $s=Add-StateTransition $s "ACTIVE" "INTERRUPTED" ([string]$s.current_prompt_id) $s.stop_reason
            Save-State $s
            Write-Host "Marked INTERRUPTED. Automatic replay is forbidden."
        }
    }
}
