param(
    [Parameter(Mandatory=$true)][string]$RunDir,
    [Parameter(Mandatory=$true)][string]$PromptPath,
    [string]$CodexPath = "",
    [Parameter(Mandatory=$true)][string]$WorkDir,
    [string]$StageProfile = ""
)

# The actual worker copy has one explicit fixed staging operation; no fake Codex.
if ($StageProfile -cne 'M4_PROTECTED_PROPOSAL_STAGING') {
    throw 'M2_SECTION_BINDING_UNPROVEN'
}
$stageSource = Split-Path -Parent (Split-Path -Parent $PSCommandPath)
Import-Module (Join-Path $stageSource 'lib\Supervisor.Core.psm1') -Force -DisableNameChecking
Import-Module (Join-Path $stageSource 'lib\M4.Staging.psm1') -Force -DisableNameChecking
Invoke-M4Worker -RunDir $RunDir -PromptPath $PromptPath -WorkDir $WorkDir -SourceRoot $stageSource
return

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

$session = Join-Path $RunDir "SESSION.log"
$final = Join-Path $RunDir "FINAL.md"
$exitFile = Join-Path $RunDir "exit-code.txt"
$workerMeta = Join-Path $RunDir "worker.json"

$awakeError = $null
try {
    if (-not ('MaiaAwake' -as [type])) {
        Add-Type @"
using System;
using System.Runtime.InteropServices;
public static class MaiaAwake {
    [DllImport("kernel32.dll")]
    public static extern uint SetThreadExecutionState(uint esFlags);
}
"@ -ErrorAction Stop
    }
    # Unsigned decimal avoids the signed hexadecimal conversion trap in PS 5.1.
    $previousExecutionState = [MaiaAwake]::SetThreadExecutionState([uint32]2147483649)
    if ($previousExecutionState -eq 0) { throw 'SetThreadExecutionState failed' }
} catch { $awakeError = $_.Exception.Message }

$meta = [pscustomobject]@{
    schema_version = 1
    worker_pid = $PID
    started_utc = [DateTime]::UtcNow.ToString("o")
    codex_path = $CodexPath
    work_dir = $WorkDir
    prompt_path = $PromptPath
}
$meta | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $workerMeta -Encoding UTF8

$OutputEncoding = New-Object System.Text.UTF8Encoding($false)
[Console]::OutputEncoding = $OutputEncoding
$code = 999

try {
    if ($null -ne $awakeError) { throw ("AWAKE_REQUEST_FAILED: " + $awakeError) }
    # Native stderr can contain normal progress. Preserve it without turning
    # every stderr line into a terminating PowerShell error.
    $ErrorActionPreference = 'Continue'
    Get-Content -LiteralPath $PromptPath -Raw -Encoding UTF8 |
        & $CodexPath --search exec `
            --cd $WorkDir `
            --dangerously-bypass-approvals-and-sandbox `
            --skip-git-repo-check `
            --output-last-message $final `
            - 2>&1 |
        Tee-Object -FilePath $session
    $code = $LASTEXITCODE
} catch {
    # Tee-Object uses UTF-16LE on PS 5.1; preserve its BOM when appending failure evidence.
    $sessionEncoding = 'UTF8'
    if (Test-Path -LiteralPath $session -PathType Leaf) {
        $sessionStream = [System.IO.File]::OpenRead($session)
        try {
            if ($sessionStream.ReadByte() -eq 255 -and $sessionStream.ReadByte() -eq 254) {
                $sessionEncoding = 'Unicode'
            }
        } finally { $sessionStream.Dispose() }
    }
    ("WORKER_EXCEPTION: " + $_.Exception.ToString()) | Add-Content -LiteralPath $session -Encoding $sessionEncoding
    $code = 998
} finally {
    [System.IO.File]::WriteAllText($exitFile, [string]$code, (New-Object System.Text.UTF8Encoding($false)))
    try { [MaiaAwake]::SetThreadExecutionState([uint32]2147483648) | Out-Null } catch {}
}
exit $code
