"""Explicit M4 namespace/DPAPI adapter over byte-identical M3 native primitives."""
import base64
import ctypes as C
import hashlib
import json
import os
from pathlib import Path,PureWindowsPath
import secrets
from baseline_m3 import m3_windows as native

Refusal=native.Refusal
NativeProcess=native.NativeProcess
FilePins=native.FilePins
validate_runtime=native.validate_runtime
PROFILE='M4_PROTECTED_PROPOSAL_STAGING'

class _JobMembers(C.Structure):
    _fields_=[('assigned',native.U32),('count',native.U32),('pids',native.SIZE*16)]

class OwnedJob(native.OwnedJob):
    def accounting(self):
        info=native.ACCOUNTING();used=native.U32()
        self.api.true('QueryInformationJobObject',self._handle(),1,C.byref(info),C.sizeof(info),C.byref(used))
        if used.value!=C.sizeof(info):raise Refusal('job accounting shape')
        # terminated counts Windows limit violations, not every observed exit.
        return {'total_processes':int(info.total),'active_processes':int(info.active),'terminated_processes':int(info.terminated)}

    def members(self):
        """Bounded job membership metadata only; never a process capability."""
        info=_JobMembers();used=native.U32()
        self.api.true('QueryInformationJobObject',self._handle(),3,C.byref(info),C.sizeof(info),C.byref(used))
        count=int(info.count);minimum=_JobMembers.pids.offset+count*C.sizeof(native.SIZE)
        if not 0<=count<=16 or info.assigned!=count or not minimum<=used.value<=C.sizeof(info):raise Refusal('job member list incomplete/bound')
        pids=[int(info.pids[index])for index in range(count)]
        if any(not 0<pid<=0xffffffff for pid in pids)or len(pids)!=len(set(pids)):raise Refusal('job member PID shape')
        return sorted(pids)

RUNTIME_PINS={
    'python':{'path':'C:/Users/PS/AppData/Local/Programs/Python/Python313/python.exe',
              'sha256':'85b71d8c6ec1905935f74be0c9869aae198d00e98f39df699ec66f9c5a84cecd'},
    'powershell':{'path':'C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe',
                  'sha256':'9785001b0dcf755eddb8af294a373c0b87b2498660f724e76c4d53f9c217c7a3'}}

class RuntimePins:
    """Hold only the two fixed runtime files; source/input pin rules are unchanged.

    A serviced Windows executable may have existing WinSxS hardlinks. A retained
    READ/share-READ handle denies write/delete access through every such alias.
    The exact fixed path, SHA and stable file identity remain mandatory. These
    are source-byte pins, never proof of the native section actually executed.
    """
    def __init__(self,runtime):
        if type(runtime)is not dict or set(runtime)!=set(RUNTIME_PINS):raise Refusal('runtime pin map')
        self.runtime={};self.parents=[];self.proof={};self._files={};self._entered=False;self._closed=False
        for kind,fixed in RUNTIME_PINS.items():
            item=runtime[kind]
            if type(item)is not dict or set(item)!={'path','sha256','version'}:raise Refusal('runtime pin fields')
            path=PureWindowsPath(item['path'])if type(item['path'])is str else None
            if path!=PureWindowsPath(fixed['path'])or item['sha256']!=fixed['sha256']:raise Refusal('fixed runtime path/hash differs')
            version=item['version']
            if not(type(version)is str and 0<len(version)<=256 or type(version)is list and 2<=len(version)<=4 and all(type(v)is int and v>=0 for v in version)):raise Refusal('runtime version shape')
            native._relative('/'.join(path.parts[1:]))
            self.runtime[kind]=dict(item)

    @property
    def calls(self):return [call for parent in self.parents for call in parent.calls]

    def __enter__(self):
        if self._entered or self._closed:raise Refusal('runtime pins cannot be reused')
        self._entered=True
        try:
            for kind,item in self.runtime.items():
                path=Path(item['path']);parent=FilePins(path.parent,[]);self.parents.append(parent);parent.__enter__()
                handle=native._open(parent.api,path,access=native.READ,share=native.SHARE_READ,flags=0x200000)
                parent.handles.append(handle)
                info,identity,stable=native._information(parent.api,handle)
                if info.attributes&(native.DIRECTORY|native.REPARSE)or info.links<1 or kind=='python'and info.links!=1:raise Refusal('runtime file type/hardlinks')
                if not 0<identity[2]<=16*1024*1024:raise Refusal('runtime file bound')
                final=native._path_by_handle(parent.api,handle)
                if final.casefold()!=('\\\\?\\'+str(path)).casefold():raise Refusal('runtime final path differs')
                parts=[];remaining=identity[2]
                while remaining:
                    amount=min(remaining,65536);buffer=C.create_string_buffer(amount);got=native.U32()
                    parent.api.true('ReadFile',native.H(handle),C.cast(buffer,native.P),amount,C.byref(got),None)
                    if got.value!=amount:raise Refusal('runtime short read')
                    parts.append(buffer.raw);remaining-=amount
                raw=b''.join(parts);after,after_identity,after_stable=native._information(parent.api,handle)
                if identity!=after_identity or stable!=after_stable:raise Refusal('runtime changed during read')
                if hashlib.sha256(raw).hexdigest()!=item['sha256']:raise Refusal('runtime executable bytes differ')
                self._files[kind]=(parent,handle,identity,stable,final)
                self.proof[kind]={'path':str(path),'sha256':item['sha256'],'bytes':len(raw),'identity':identity,
                    'hard_links':int(info.links),'final_path':final,'share_mode':native.SHARE_READ,
                    'scope':'PINNED_RUNTIME_FILE_BYTES_ONLY_NO_EXECUTED_IMAGE_PROOF'}
            return self
        except BaseException:
            self._close();raise

    def verify(self):
        if not self._entered or self._closed or set(self._files)!=set(RUNTIME_PINS):raise Refusal('runtime pins not held')
        for parent,handle,identity,stable,final in self._files.values():
            _,current_identity,current_stable=native._information(parent.api,handle)
            if current_identity!=identity or current_stable!=stable or native._path_by_handle(parent.api,handle).casefold()!=final.casefold():raise Refusal('retained runtime identity changed')
        return True

    def _close(self):
        if self._closed:raise Refusal('runtime pin close cannot be replayed')
        self._closed=True;failures=[]
        for parent in reversed(self.parents):
            try:parent.__exit__(None,None,None)
            except BaseException as exc:failures.append(type(exc).__name__+':'+str(exc))
        if failures:raise Refusal('runtime pin cleanup:'+','.join(failures))

    def __exit__(self,*exc):self._close()

def fixture_root(root):
    try:p=PureWindowsPath(root)
    except (TypeError,ValueError) as exc:raise Refusal('M4 root shape') from exc
    if not p.is_absolute() or p.anchor.casefold()!='c:\\':raise Refusal('M4 local absolute root')
    native._relative('/'.join(p.parts[1:]))
    parts=tuple(x.casefold() for x in p.parts)
    if len(parts)<5 or parts[:4]!=('c:\\','maia','reports','m4_staging_20261108'):
        raise Refusal('M4 report instance namespace')
    return Path(str(p))

namespace_root=fixture_root

class KeyVaultM4(native.KeyVault):
    """Separate M4 entropy namespace; inherited native DPAPI crypto unchanged."""
    calls=[]
    @staticmethod
    def _entropy(binding):
        return b'MAIA/M4/DPAPI1\x00'+native._canonical(native._binding(binding))
    @classmethod
    def seal(cls,root,binding):
        cls.calls=[];root=fixture_root(root);key=secrets.token_bytes(32);cipher=cls._crypt(key,binding,True)
        pins=FilePins(root,[])
        try:
            with pins:
                api=pins.api;handle=native._open(api,root/'owner.key',access=0x40000000,share=0,disposition=1,flags=0x200080)
                try:
                    payload=b'M4DPAPI1\x00'+cipher;buf=C.create_string_buffer(payload);written=native.U32()
                    api.true('WriteFile',native.H(handle),C.cast(buf,native.P),len(payload),C.byref(written),None)
                    if written.value!=len(payload):raise Refusal('M4 short sealed-key write')
                    api.true('FlushFileBuffers',native.H(handle))
                finally:api.close(handle)
        finally:cls.calls.extend(pins.calls)
        return key
    @classmethod
    def load(cls,root,binding):
        cls.calls=[];root=fixture_root(root);raw=native.ordinary_bytes(root/'owner.key',16384,journal=cls.calls)
        if not raw.startswith(b'M4DPAPI1\x00'):raise Refusal('M4 key header')
        key=cls._crypt(raw[9:],binding,False)
        if len(key)!=32:raise Refusal('M4 owner-key length')
        return key
