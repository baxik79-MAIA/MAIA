"""Portable source/input/semantic controls; native admission is qualified separately."""
import copy
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from baseline_m3.m3_store import canonical,sha,Store
import m4_admission as a

class AdmissionControls(unittest.TestCase):
 def setUp(self):
  # These are portable controls; namespace/Win32 locks have a separate native matrix.
  guard=patch.object(a,'_root',lambda p:Path(p).absolute());guard.start();self.addCleanup(guard.stop)
  pins=patch.object(a,'_pins',lambda root,names:a._PortablePins(root,list(names)));pins.start();self.addCleanup(pins.stop)
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.base=Path(self.tmp.name)
  self.source=self.base/'source';self.source.mkdir();raw=b'# inert unit source\n';(self.source/'stub.py').write_bytes(raw)
  files={'stub.py':{'bytes':len(raw),'sha256':sha(raw)}};self.source_sha=sha(canonical({k:v['sha256'] for k,v in files.items()}))
  (self.source/'SOURCE_MANIFEST.json').write_bytes(canonical({'schema':1,'source_sha256':self.source_sha,'files':files}))
  self.runtime={'python':{'path':'C:/unit/python.exe','sha256':'a'*64,'version':'3.13.15'},'powershell':{'path':'C:/unit/powershell.exe','sha256':'b'*64,'version':'5.1'}}
 def build(self,label='instance'):
  root=self.base/label;meta=a.build_instance(root,self.source,self.source_sha,self.runtime);return root,meta
 def repin(self,root,meta,name,value):
  raw=canonical(value);(root/name).write_bytes(raw);meta['expected'][name]=sha(raw);meta['binding']['inputs']=a.input_digest(meta['expected'])
 def test_fresh_inert_inputs_reproduce_digest_and_actual_manifest(self):
  root,m=self.build();self.assertEqual(len(m['expected']),8)
  self.assertFalse((root/'transaction.sqlite').exists());self.assertFalse((root/'owner.key').exists());self.assertFalse((root/'worktree/ANALYSIS.md').exists())
  self.assertEqual(a.load_inputs(root),m)
  with a.admit(root,m['binding'],m['expected']) as admitted:
   self.assertFalse(admitted.check['ready']);self.assertTrue(admitted.check['staging_admissible'])
   self.assertEqual(admitted.manifest['prompt_id'],m['binding']['cycle'])
   self.assertEqual(admitted.manifest['prompt_file'],'prompt.txt')
   self.assertEqual(admitted.buffers['worktree/INPUT.txt'].count(b'\n'),2)
 def test_existing_instance_never_overwritten(self):
  root,m=self.build();before=(root/'M4_POLICY.json').read_bytes()
  with self.assertRaises(a.Refusal):a.build_instance(root,self.source,self.source_sha,self.runtime)
  self.assertEqual((root/'M4_POLICY.json').read_bytes(),before)
 def test_hash_then_parse_uses_same_pinned_buffers(self):
  root,m=self.build()
  with a.admit(root,m['binding'],m['expected']) as admitted:
   first=admitted.buffers['prompts/prompt.txt']
   # POSIX portable pins deliberately lack Windows sharing prevention. The
   # admitted buffer must still remain the same bytes; native suite checks lock.
   (root/'prompts/prompt.txt').write_bytes(b'later bytes')
   self.assertEqual(admitted.buffers['prompts/prompt.txt'],first)
   self.assertEqual(admitted.manifest['sha256'],sha(first))
  with self.assertRaises(a.Refusal):a.admit(root,m['binding'],m['expected']).__enter__()
 def test_repin_cannot_admit_transitioned_or_changed_policy(self):
  for label,name,mutate in [('state','state.before.json',lambda d:d.update(status='IDLE')),('policy','M4_POLICY.json',lambda d:d.update(operation='ARBITRARY_COMMAND')),('manifest','manifest',lambda d:d.update(idempotency_policy='safe_retry_once'))]:
   root,m=self.build(label)
   if name=='manifest':name='prompts/'+m['binding']['cycle']+'.manifest.json'
   value=json.loads((root/name).read_bytes());mutate(value);self.repin(root,m,name,value)
   with self.subTest(label=label),self.assertRaises(a.Refusal):a.admit(root,m['binding'],m['expected']).__enter__()
 def test_schema_bool_does_not_alias_integer_one(self):
  root,m=self.build();name='prompts/'+m['binding']['cycle']+'.manifest.json';value=json.loads((root/name).read_bytes());value['schema_version']=True;self.repin(root,m,name,value)
  with self.assertRaises(a.Refusal):a.admit(root,m['binding'],m['expected']).__enter__()
 def test_protocol_residue_file_dir_dangling_and_hardlink_refuse(self):
  for label,mutate in [('file',lambda r:(r/'protocol.json').write_bytes(b'partial')),('dir',lambda r:(r/'protocol.json').mkdir()),('dangling',lambda r:(r/'protocol.json').symlink_to(r/'absent')),('hardlink',lambda r:os.link(r/'prompts/prompt.txt',r/'prompts/other.txt'))]:
   root,m=self.build(label);mutate(root)
   with self.subTest(label=label),self.assertRaises(a.Refusal):a.admit(root,m['binding'],m['expected']).__enter__()
 def test_source_instance_overlap_refuses_before_creation(self):
  with self.assertRaises(a.Refusal):a.build_instance(self.source/'inside',self.source,self.source_sha,self.runtime)
  self.assertFalse((self.source/'inside').exists())
 def test_prepared_allows_only_fenced_existing_effect(self):
  root,m=self.build();s=Store.create(root/'transaction.sqlite',m['binding'],(root/'state.before.json').read_bytes(),(root/'queue.before.json').read_bytes());s.close()
  (root/'owner.key').write_bytes(b'opaque test cipher')
  (root/'worktree/ANALYSIS.md').write_bytes(b'prior effect')
  with self.assertRaises(a.Refusal):a.admit(root,m['binding'],m['expected'],True).__enter__()
  s=Store.open_existing(root/'transaction.sqlite',m['binding']);s.claim_receiver('d'*32);s.close()
  with a.admit(root,m['binding'],m['expected'],True) as admitted:self.assertTrue(admitted.check['staging_admissible'])
  s=Store.open_existing(root/'transaction.sqlite',m['binding'])
  try:
   with self.assertRaises(Exception) as e:s.claim_receiver('e'*32)
   self.assertIn('REPLAY',str(e.exception))
  finally:s.close()
 def test_prepared_mode_refuses_directory_wal_before_sqlite_open(self):
  root,m=self.build();(root/'transaction.sqlite-wal').mkdir()
  with self.assertRaises(a.Refusal) as e:a.admit(root,m['binding'],m['expected'],True).__enter__()
  self.assertIn('PREPARED_PROTOCOL_TYPE',str(e.exception))
 def test_input_metadata_cannot_change_binding_or_digest(self):
  root,m=self.build();meta=json.loads((root/'INPUT_MANIFEST.json').read_bytes());meta['files']['M4_POLICY.json']='0'*64;(root/'INPUT_MANIFEST.json').write_bytes(canonical(meta))
  with self.assertRaises(a.Refusal):a.load_inputs(root,m['binding'])
 def test_deterministic_analysis_and_semantic_error_exit_zero_refuses(self):
  root,m=self.build();binding=m['binding'];data=b'alpha\nbeta\n';artifact=a.analysis_bytes(data,binding);identity={'pid':123,'birth':456}
  self.assertEqual(artifact,('# MAIA M4 analysis\ncycle: '+binding['cycle']+'\ninput_sha256: '+sha(data)+'\nbytes: 11\nnewline_count: 2\n').encode())
  result={'schema':1,'binding':binding,'profile':a.PROFILE,'status':'SUCCESS','is_error':False,'verdict':'STAGING_COMPLETE','artifact':'worktree/ANALYSIS.md','artifact_sha256':sha(artifact),'input_sha256':sha(data),'identity':identity}
  self.assertEqual(a.validate_semantic(result,binding,artifact,data,identity),result)
  for field,value in [('is_error',True),('schema',True),('status','FAILED'),('identity',{'pid':124,'birth':456}),('artifact_sha256','0'*64)]:
   bad=dict(result);bad[field]=value
   with self.subTest(field=field),self.assertRaises(a.Refusal):a.validate_semantic(bad,binding,artifact,data,identity)
  with self.assertRaises(a.Refusal):a.validate_semantic(result,binding,artifact+b'x',data,identity)

if __name__=='__main__':unittest.main()
