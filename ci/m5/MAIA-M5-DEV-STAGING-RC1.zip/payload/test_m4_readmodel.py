"""Pure projection and actual HTTP route controls; no Windows native calls."""
import copy
import http.client
import json
from pathlib import Path
import sys
import tempfile
import threading
import time
import types
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'baseline_m3'))
from m4_native import NativeProcess
from m4_readmodel import PROFILE, RetainedObserver, StageReadModel, _project
from maia_panel import start_stage_server

BINDING = {'cycle': 'a' * 32, 'source': 'b' * 64, 'inputs': 'c' * 64}
IDENTITY = {'pid': 12, 'birth': 34}


def history(phase='STARTED'):
    result = {'schema': 1, 'binding': BINDING, 'profile': PROFILE,
              'status': 'SUCCESS', 'is_error': False, 'verdict': 'STAGING_COMPLETE',
              'artifact': 'worktree/ANALYSIS.md', 'artifact_sha256': 'd' * 64,
              'input_sha256': 'e' * 64, 'identity': IDENTITY}
    receipt = {'kind': 'COMPLETED', 'binding': BINDING, 'identity': IDENTITY,
               'worker_exit': 0, 'exit_code': 0, 'profile': PROFILE,
               'executor': 'POWERSHELL_STAGING_WORKER',
               'artifact_sha256': 'd' * 64, 'semantic': result}
    return {'binding': BINDING, 'phase': phase, 'identity': IDENTITY,
            'records': [{'record_sha': 'f' * 64, 'payload': {'receipt': receipt}}],
            'receipts_authenticated': ['STARTED', 'COMPLETED'],
            'semantic': result if phase == 'COMPLETED' else None,
            'receipt_authentication': 'HMAC_VERIFIED_WITH_USER_DPAPI_KEY'}


def retained(identity=IDENTITY, exit_code=None):
    # The observation logic is under test; no native ABI is simulated as proof.
    native = NativeProcess.__new__(NativeProcess)
    native.identity = lambda: dict(identity)
    native.wait = lambda timeout: exit_code
    return RetainedObserver(BINDING, native, threading.RLock())


class ProjectionControls(unittest.TestCase):
    def test_cold_started_is_uncertain_and_has_no_capability(self):
        view = _project(history())
        self.assertEqual(view['view'], 'RECONCILIATION_REQUIRED')
        self.assertEqual(view['custody'], 'NO_CUSTODY')
        for key in ('active', 'ready', 'start_capability', 'launch_capability', 'replay_permitted'):
            self.assertIs(view[key], False)

    def test_exact_live_retained_observation_required(self):
        value = history()
        observation = retained().sample(BINDING, IDENTITY)
        self.assertTrue(_project(value, observation)['active'])
        for observer in (retained({'pid': 12, 'birth': 35}), retained(exit_code=0)):
            self.assertFalse(_project(value, observer.sample(BINDING, IDENTITY))['active'])
        wrong = dict(BINDING, inputs='0' * 64)
        self.assertFalse(_project(value, retained().sample(wrong, IDENTITY))['active'])

    def test_stale_or_future_observation_never_active(self):
        for delta in (-6000, 6000):
            sample = retained().sample(BINDING, IDENTITY)
            sample['observed_monotonic_ms'] += delta
            self.assertFalse(_project(history(), sample)['active'])

    def test_no_arbitrary_callback_or_pid_object(self):
        with self.assertRaises(ValueError):
            StageReadModel('.', BINDING['source'], lambda: {'live': True})
        with self.assertRaises(ValueError):
            RetainedObserver(BINDING, types.SimpleNamespace(pid=12), threading.RLock())

    def test_completion_requires_semantics_receipts_and_native_exit_evidence(self):
        good = history('COMPLETED')
        self.assertEqual(_project(good)['view'], 'STAGING_COMPLETE')
        self.assertFalse(_project(good, retained().sample(BINDING, IDENTITY))['active'])
        cases = []
        for bad_error in (True, 'false', 0, None):
            value = copy.deepcopy(good)
            value['semantic']['is_error'] = bad_error
            cases.append(value)
        value = copy.deepcopy(good)
        value['receipts_authenticated'].remove('COMPLETED')
        cases.append(value)
        for field, bad in (('worker_exit', None), ('worker_exit', True), ('exit_code', 1)):
            value = copy.deepcopy(good)
            value['records'][-1]['payload']['receipt'][field] = bad
            cases.append(value)
        value = copy.deepcopy(good)
        value['semantic']['identity'] = {'pid': 12, 'birth': 35}
        cases.append(value)
        for value in cases:
            self.assertEqual(_project(value)['view'], 'RESULT_UNCONFIRMED')

    def test_quarantine_cannot_be_green(self):
        value = history('COMPLETED')
        value['quarantined'] = True
        view = _project(value)
        self.assertEqual(view['view'], 'QUARANTINED')
        self.assertFalse(view['semantic_success'])
        self.assertFalse(view['active'])

    def test_identity_display_rejects_non_native_or_noncanonical_types(self):
        for bad in (None, {'pid': True, 'birth': 34}, {'pid': 12, 'birth': '34'},
                    {'pid': 0, 'birth': 34}, {'pid': 12, 'birth': 0},
                    {'pid': 2**32, 'birth': 34}, {'pid': 12, 'birth': 2**64},
                    {'pid': 12, 'birth': 34, 'extra': 1}):
            value = history()
            value['identity'] = bad
            self.assertIsNone(_project(value)['identity_display'])


class ActualHTTPControls(unittest.TestCase):
    def test_http_preserves_numeric_identity_and_exact_filetime_display(self):
        exact = {'pid': 12345, 'birth': 134386123456789123}
        value = history()
        value['identity'] = exact
        # Avoid native calls: the actual HTTP route and projection serialization
        # are exercised, while the historical authority input is explicitly stubbed.
        with tempfile.TemporaryDirectory() as root, patch.dict(sys.modules, {'m4_engine': types.SimpleNamespace(read_projection=lambda *a, **k: value)}), patch('m4_native.FilePins', side_effect=OSError('no native log fixture')):
            server = start_stage_server(root, BINDING['source'])
            try:
                connection = http.client.HTTPConnection(*server.server_address, timeout=2)
                connection.request('GET', '/api/status', headers={'X-MAIA-Token': server.token})
                response = connection.getresponse()
                raw = response.read()
                connection.close()
                self.assertEqual(response.status, 200)
                stage = json.loads(raw)['stage']
                self.assertEqual(stage['identity'], exact)
                self.assertIs(type(stage['identity']['birth']), int)
                self.assertEqual(stage['identity_display'], {'pid': '12345', 'birth': '134386123456789123'})
                self.assertIn(b'"birth": 134386123456789123', raw)
                self.assertIn(b'"birth": "134386123456789123"', raw)
                self.assertIs(value['identity'], exact)
                self.assertIs(type(value['identity']['birth']), int)
            finally:
                server.shutdown()
                server.server_close()
                server.stage_thread.join(2)
                self.assertFalse(server.stage_thread.is_alive())

    def test_actual_handler_serves_readonly_stage_and_refuses_service_routes(self):
        calls = []
        def read(root, source, live=False):
            calls.append((root, source, live))
            return {'binding': BINDING, 'phase': 'PREPARED', 'records': [],
                    'identity': None, 'receipts_authenticated': []}
        with tempfile.TemporaryDirectory() as root, patch.dict(sys.modules, {'m4_engine': types.SimpleNamespace(read_projection=read)}):
            server = start_stage_server(root, BINDING['source'])
            try:
                self.assertFalse(hasattr(server, 'missions'))
                self.assertFalse(hasattr(server, 'copilot'))
                self.assertIsNone(server.terminal)
                def request(method, route, auth=True):
                    connection = http.client.HTTPConnection(*server.server_address, timeout=2)
                    headers = {'X-MAIA-Token': server.token} if auth else {}
                    connection.request(method, route, headers=headers)
                    response = connection.getresponse()
                    status, body = response.status, response.read()
                    connection.close()
                    return status, body
                status, body = request('GET', '/api/status')
                self.assertEqual(status, 200)
                self.assertFalse(json.loads(body)['stage']['active'])
                self.assertNotIn(server.token.encode(), body)
                self.assertEqual(request('GET', '/api/status', False)[0], 403)
                for route in ('/api/terminal/run', '/api/missions', '/api/copilot/status', '/api/log'):
                    self.assertEqual(request('GET', route)[0], 403)
                    self.assertEqual(request('POST', route)[0], 403)
                status, html = request('GET', '/')
                self.assertEqual(status, 200)
                self.assertIn(b'<meta name="maia-stage" content="readonly">', html)
                self.assertNotIn(b'__MAIA_TOKEN__', html)
                self.assertEqual(request('GET', '/app.js')[0], 200)
                self.assertEqual(request('GET', '/app.css')[0], 200)
                self.assertEqual(calls[0][1:], (BINDING['source'], False))
            finally:
                server.shutdown()
                server.server_close()
                server.stage_thread.join(2)
                self.assertFalse(server.stage_thread.is_alive())


if __name__ == '__main__':
    unittest.main()
