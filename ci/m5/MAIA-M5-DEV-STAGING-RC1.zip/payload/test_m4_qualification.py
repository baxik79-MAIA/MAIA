"""Portable acceptance-oracle controls; no synthetic native qualification claims."""
import copy
import io
import json
from pathlib import Path
import tempfile
import threading
import time
from types import SimpleNamespace
from unittest.mock import patch
import unittest
import m4_qualification as q


def recovery(phase):
    return dict(phase=phase,quarantined=False,authority_unchanged=True,
                live_process_reauthenticated=False,
                **{name:False for name in q.CAPABILITY_FLAGS})


def execution(terminal='COMPLETED',workers=1,**kw):
    return dict(terminal=terminal,launch_entries=workers,created_workers=workers,
                retained_handles_closed=True,events=[],cut_reached=False,**kw)


def probe(reason=q.COLD_REFUSAL):
    value=execution('REFUSED',0,purpose='COLD_REBOOTSTRAP_REPLAY_PROBE')
    value['events']=[{'kind':'REFUSED','payload':{'reason':reason}}]
    return value


class AcceptanceOracles(unittest.TestCase):
    def test_only_manifest_listed_root_tests_are_selected(self):
        source={'manifest':{'files':{
            'test_m4_wire.py':{},'test_m4_qualification.py':{},
            'baseline_m3/test_m3_store.py':{},'other/test_m4_injected.py':{},
            'test_m4.pyc':{},'test_m4_bad-name.py':{}}}}
        self.assertEqual(q.admitted_test_modules(source,'M3'),['baseline_m3.test_m3_store'])
        self.assertEqual(q.admitted_test_modules(source,'M4'),['test_m4_qualification','test_m4_wire'])
        with self.assertRaises(q.QualificationRefusal):q.admitted_test_modules({'manifest':{'files':{}}},'M4')

    def test_all_declared_rows_require_exact_phase_and_worker_effect_counts(self):
        self.assertEqual(len(q.ROWS),13)
        self.assertEqual(len({r[0] for r in q.ROWS}),13)
        for row in q.ROWS:
            label,cut,phase,effects,created=row
            primary=execution('INJECTED_PROCESS_CRASH' if cut else 'COMPLETED',created)
            primary['cut_reached']=bool(cut)
            executions=[primary,probe()]
            if label=='concurrent_intents':executions.insert(0,execution('REFUSED',0))
            with self.subTest(row=label):
                self.assertTrue(q.check_row(row,executions,recovery(phase),effects)['qualified'])
                for wrong in (effects+1,-1):
                    with self.assertRaises(q.QualificationRefusal):q.check_row(row,executions,recovery(phase),wrong)

    def test_unrelated_refusal_is_not_replay_safety(self):
        row=q.ROWS[0]
        executions=[execution('INJECTED_PROCESS_CRASH',0),probe('M4_LOCAL_ERROR:RuntimeException')]
        executions[0]['cut_reached']=True
        with self.assertRaises(q.QualificationRefusal):q.check_row(row,executions,recovery('PREPARED'),0)

    def test_uncertain_cleanup_phase_or_capability_cannot_qualify(self):
        row=q.ROWS[-1]
        primary=execution('INJECTED_PROCESS_CRASH',1);primary['cut_reached']=True
        good=[primary,probe()]
        for name,value in [('ready',True),('authority_unchanged',False),('quarantined',True),
                           ('live_process_reauthenticated',True),('phase','COMPLETED')]:
            changed=recovery('STARTED');changed[name]=value
            with self.subTest(field=name),self.assertRaises(q.QualificationRefusal):q.check_row(row,good,changed,1)
        for field,value in [('cut_reached',False),('retained_handles_closed',False),('created_workers',0),('launch_entries',0)]:
            changed=copy.deepcopy(good);changed[0][field]=value
            with self.subTest(field=field),self.assertRaises(q.QualificationRefusal):q.check_row(row,changed,recovery('STARTED'),1)

    def test_public_readonly_paths_require_explicit_unknown_outcome_label(self):
        value=execution('READ_ONLY',0)
        view=recovery('STARTED');view.update(view='RECONCILIATION_REQUIRED',outcome_unknown=True)
        value['completion']={'view':view}
        q.require_readonly_unknown(value)
        for name,bad in (('outcome_unknown',False),('view',None),('phase','QUARANTINED')):
            changed=copy.deepcopy(value);changed['completion']['view'][name]=bad
            with self.subTest(field=name),self.assertRaises(q.QualificationRefusal):q.require_readonly_unknown(changed)

    def test_missing_or_double_cold_probe_cannot_qualify(self):
        row=q.ROWS[-2];main=execution()
        for values in ([main],[main,probe(),probe()]):
            with self.assertRaises(q.QualificationRefusal):q.check_row(row,values,recovery('COMPLETED'),1)

    def test_public_report_recursively_removes_private_fields(self):
        value={'key_b64':'PRIVATE','events':[{'token':'PRIVATE','identity':{'pid':1,'birth':2}}],
               'receipt':{'mac':'public-authenticator','binding':{'cycle':'a'*32}}}
        clean=q.public(value)
        self.assertNotIn('PRIVATE',repr(clean))
        self.assertEqual(clean['events'],[{'identity':{'pid':1,'birth':2}}])
        self.assertEqual(clean['receipt'],value['receipt'])


class FailureAndHTTPControls(unittest.TestCase):
    def test_assignment_failure_terminates_and_closes_retained_unjobbed_controller(self):
        from m4_native import NativeProcess
        for scenario in ('known','frozen','query_unknown'):
            with self.subTest(scenario=scenario),tempfile.TemporaryDirectory() as folder:
                state={'live':True,'terminate':0,'close':0}
                child=SimpleNamespace(returncode=None,stdin=io.BytesIO(),stdout=io.BytesIO())
                native=SimpleNamespace(api=SimpleNamespace(frozen=False),closed=False,
                    close_attempted=False,_identity={'pid':12,'birth':34},calls=[])
                def wait(timeout):
                    if state['live']:return None
                    child.returncode=99;return 99
                def terminate():state['terminate']+=1;state['live']=False
                def close():state['close']+=1;native.closed=True;native.close_attempted=True
                native.wait=wait;native.terminate=terminate;native.close=close
                job=SimpleNamespace(closed=False,api=SimpleNamespace(frozen=scenario=='frozen'),
                    assign=lambda native:(_ for _ in ()).throw(q.QualificationRefusal('assign failed')))
                def active():
                    if scenario=='query_unknown':
                        job.api.frozen=True;raise q.QualificationRefusal('job query unknown')
                    return 0
                job.active_processes=active
                instance={'root':Path(folder)/'instance','report_root':Path(folder)/'logs',
                          'binding':{'cycle':'a'*32,'source':'b'*64,'inputs':'c'*64},
                          'policy_sha256':'d'*64,'deadline':time.monotonic()+10}
                source={'root':Path(folder),'manifest_sha256':'e'*64,'source_sha256':'b'*64}
                with patch('m4_native.NativeProcess',return_value=native),patch.object(q.subprocess,'Popen',return_value=child):
                    with self.assertRaisesRegex(q.QualificationRefusal,'assign failed'):
                        q.drive_controller(instance,source,{'powershell':{'path':'fixedPS'}},job,threading.RLock())
                self.assertEqual(state,{'live':False,'terminate':1,'close':1})
                report=json.loads(next((Path(folder)/'logs').glob('*.json')).read_bytes())
                self.assertFalse(report['outer_bootstrap_sent']);self.assertFalse(report['controller_assigned_to_job'])
                self.assertTrue(report['native_processes']['controller']['closed'])

    def test_bootstrap_uncertainty_terminates_owned_job_before_settling_creator(self):
        with tempfile.TemporaryDirectory() as folder:
            state={'live':True,'job_terminate':0,'handle_terminate':0,'close':0}
            child=SimpleNamespace(returncode=None,stdin=io.BytesIO(),stdout=io.BytesIO())
            native=SimpleNamespace(api=SimpleNamespace(frozen=False),closed=False,
                close_attempted=False,_identity={'pid':12,'birth':34},calls=[])
            def wait(timeout):
                if state['live']:return None
                child.returncode=99;return 99
            def job_terminate():state['job_terminate']+=1;state['live']=False
            def close():state['close']+=1;native.closed=True;native.close_attempted=True
            native.wait=wait;native.close=close
            native.terminate=lambda:state.__setitem__('handle_terminate',state['handle_terminate']+1)
            job=SimpleNamespace(closed=False,api=SimpleNamespace(frozen=False),assign=lambda n:None,
                                active_processes=lambda:int(state['live']),terminate=job_terminate)
            instance={'root':Path(folder)/'instance','report_root':Path(folder)/'logs',
                      'binding':{'cycle':'a'*32,'source':'b'*64,'inputs':'c'*64},
                      'policy_sha256':'d'*64,'deadline':time.monotonic()+10}
            source={'root':Path(folder),'manifest_sha256':'e'*64,'source_sha256':'b'*64}
            with patch('m4_native.NativeProcess',return_value=native),patch.object(q.subprocess,'Popen',return_value=child),patch.object(q,'observe_job_processes') as observations,patch('m4_wire.raw_write',side_effect=q.QualificationRefusal('entered bootstrap write uncertain')):
                with self.assertRaisesRegex(q.QualificationRefusal,'bootstrap write uncertain'):
                    q.drive_controller(instance,source,{'powershell':{'path':'fixedPS'}},job,threading.RLock())
            self.assertEqual(state,{'live':False,'job_terminate':1,'handle_terminate':0,'close':1})
            observations.assert_not_called() # No pre-bootstrap controller-host assumption.
            report=json.loads(next((Path(folder)/'logs').glob('*.json')).read_bytes())
            self.assertTrue(report['controller_assigned_to_job']);self.assertFalse(report['outer_bootstrap_sent'])
            self.assertTrue(report['native_processes']['controller']['closed'])

    def test_readonly_child_custody_settles_even_if_job_assignment_or_wrapper_fails(self):
        for wrapper_fails in (False,True):
            with self.subTest(wrapper_fails=wrapper_fails),tempfile.TemporaryDirectory() as folder:
                state={'live':True,'terminate':0,'close':0}
                child=SimpleNamespace(returncode=None,stdin=io.BytesIO())
                def terminate():state['live']=False;state['terminate']+=1
                def wait(timeout):
                    if state['live']:return None
                    child.returncode=99;return 99
                def close():state['close']+=1
                child.terminate=terminate;child.wait=wait;child._handle=SimpleNamespace(Close=close)
                native=SimpleNamespace(api=SimpleNamespace(frozen=False),closed=False,wait=wait,
                                       terminate=terminate,close=close)
                job=SimpleNamespace(api=SimpleNamespace(frozen=False),closed=False,
                    accounting=lambda:{'total_processes':0,'active_processes':0,'terminated_processes':0},
                    active_processes=lambda:0,close=lambda:None)
                def assign(value):
                    job.api.frozen=True
                    raise q.QualificationRefusal('assignment unknown')
                job.assign=assign
                constructor={'side_effect':q.QualificationRefusal('wrapper failed')} if wrapper_fails else {'return_value':native}
                with patch('m4_native.NativeProcess',**constructor),patch('m4_native.OwnedJob',return_value=job),patch('m4_entry.fixed_python_args',return_value=['fixedPython']),patch.object(q.subprocess,'Popen',return_value=child):
                    with self.assertRaisesRegex(q.QualificationRefusal,'wrapper failed' if wrapper_fails else 'assignment unknown'):
                        q.readonly_child_capture({'root':Path(folder)/'instance'},
                            {'root':Path(folder),'source_sha256':'a'*64},{},folder,time.monotonic()+10)
                self.assertEqual(state,{'live':False,'terminate':1,'close':1})
                self.assertTrue(child.stdin.closed)

    def test_readonly_parent_observes_metadata_before_granting_private_readiness_gate(self):
        with tempfile.TemporaryDirectory() as folder:
            order=[];state={'accounting':0}
            (Path(folder)/'RESTORED_HTTP_RESULT.json').write_text('{"qualified":true}')
            child=SimpleNamespace(returncode=None,stdin=io.BytesIO(),stdout=io.BytesIO())
            native=SimpleNamespace(api=SimpleNamespace(frozen=False),closed=False,close_attempted=False,
                                   _identity={'pid':12,'birth':34},calls=[])
            def wait(timeout):order.append('wait');child.returncode=0;return 0
            def close():native.closed=True;native.close_attempted=True
            native.wait=wait;native.close=close
            def accounting():
                state['accounting']+=1
                return {'total_processes':0 if state['accounting']==1 else 1,'active_processes':0,'terminated_processes':0}
            job=SimpleNamespace(api=SimpleNamespace(frozen=False),closed=False,calls=[],accounting=accounting,
                                assign=lambda n:None,active_processes=lambda:0)
            job.close=lambda:setattr(job,'closed',True)
            ready={'v':1,'kind':'READONLY_PRIVATE_READY','source_sha':'a'*64,'pid':12}
            def receive(*args):order.append('ready');return ready
            def observe(*args):order.append('metadata')
            def grant(*args):order.append('grant')
            with patch('m4_native.NativeProcess',return_value=native),patch('m4_native.OwnedJob',return_value=job),patch('m4_entry.fixed_python_args',return_value=['fixedPython']),patch.object(q.subprocess,'Popen',return_value=child),patch('m4_wire.raw_read',side_effect=receive),patch('m4_wire.raw_write',side_effect=grant),patch.object(q,'observe_job_processes',side_effect=observe):
                result=q.readonly_child_capture({'root':Path(folder)/'instance'},
                    {'root':Path(folder),'source_sha256':'a'*64},{},folder,time.monotonic()+10)
            self.assertEqual(order[:4],['ready','metadata','grant','wait'])
            self.assertTrue(result['private_readonly_grant_after_metadata'])
            self.assertEqual(result['job_accounting']['expected_unique_retained_processes'],1)
            self.assertTrue(native.closed);self.assertTrue(child.stdout.closed)

    def test_readonly_child_emits_private_ready_and_rejects_wrong_grant_before_any_capture(self):
        order=[]
        def ready(*args):order.append('ready')
        def grant(*args):order.append('grant');return {'v':1,'permit_readonly':True,'source_sha':'wrong'}
        with patch('m4_wire.raw_write',side_effect=ready),patch('m4_wire.raw_read',side_effect=grant),patch.object(q,'readonly_capture') as capture,patch.dict(q.sys.modules,{'m4_engine':SimpleNamespace(),'maia_panel':SimpleNamespace()}),patch.object(q.sys,'stdin',SimpleNamespace(buffer=io.BytesIO())),patch.object(q.sys,'stdout',SimpleNamespace(buffer=io.BytesIO())):
            with self.assertRaisesRegex(q.QualificationRefusal,'readonly parent grant'):
                q.main(['--readonly-capture','--bootstrap-wait','--root','fixedRoot','--source-sha','a'*64,'--report','fixedReport'])
        self.assertEqual(order,['ready','grant']);capture.assert_not_called()

    def test_loopback_http_opener_disables_proxies_and_redirects(self):
        captured={}
        def build(*handlers):captured['handlers']=handlers;return object()
        with patch.object(q.urllib.request,'build_opener',side_effect=build):q.local_http_opener()
        self.assertEqual(captured['handlers'][0].proxies,{})
        with self.assertRaises(q.QualificationRefusal):captured['handlers'][1].redirect_request(None,None,None,None,None,None)

    def test_http_expected_bytes_bind_frozen_assets_and_token_transformation(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);(root/'ui').mkdir()
            data={'index.html':b'<head>__MAIA_TOKEN__</head>','app.js':b'// source app','app.css':b'/* source CSS */'}
            files={}
            for name,raw in data.items():
                (root/'ui'/name).write_bytes(raw);files['ui/'+name]={'bytes':len(raw),'sha256':q.sha(raw)}
            with patch.object(q,'source_snapshot',return_value={'root':root,'manifest':{'files':files}}):
                expected=q.expected_http_assets('a'*64,'localtoken')
                self.assertEqual(expected['index.html'],b'<head>localtoken<meta name="maia-stage" content="readonly"></head>')
                self.assertEqual(expected['app.js'],data['app.js'])
                (root/'ui/app.js').write_bytes(b'// drift')
                with self.assertRaisesRegex(q.QualificationRefusal,'asset drift'):q.expected_http_assets('a'*64,'localtoken')


class JobAccountingControls(unittest.TestCase):
    def test_entered_unknown_job_termination_is_not_retried_by_another_cleanup(self):
        calls=[]
        def terminate():
            calls.append('entered');raise q.QualificationRefusal('native termination unknown')
        job=SimpleNamespace(terminate=terminate)
        with self.assertRaises(q.QualificationRefusal):q.request_job_termination(job)
        self.assertFalse(q.request_job_termination(job))
        self.assertEqual(calls,['entered'])

    def test_native_job_total_detects_an_unreported_descendant(self):
        before={'total_processes':0,'active_processes':0,'terminated_processes':0}
        execution={'native_processes':{role:{'closed':True,'identity':{'pid':pid,'birth':pid+100}}
                                     for role,pid in (('controller',10),('engine',20),('worker',30))}}
        job=SimpleNamespace(accounting=lambda:{'total_processes':3,'active_processes':0,'terminated_processes':0})
        value=q.settled_job_evidence(job,[execution],before)
        self.assertEqual(value['expected_unique_retained_processes'],3)
        self.assertEqual(value['conhost_allowance'],0)
        # This OS counter concerns limit violations, so zero is valid after exits.
        self.assertEqual(value['after']['terminated_processes'],0)
        for changed in ({'total_processes':4,'active_processes':0,'terminated_processes':0},
                        {'total_processes':3,'active_processes':1,'terminated_processes':0}):
            job.accounting=lambda:changed
            with self.assertRaises(q.QualificationRefusal):q.settled_job_evidence(job,[execution],before)
        job.accounting=lambda:{'total_processes':3,'active_processes':0,'terminated_processes':0}
        duplicate=copy.deepcopy(execution);duplicate['native_processes']['worker']['identity']={'pid':10,'birth':110}
        with self.assertRaises(q.QualificationRefusal):q.settled_job_evidence(job,[duplicate],before)

    def test_host_startup_poll_uses_one_metadata_snapshot_after_actual_extra_member_exists(self):
        job=SimpleNamespace(_m4_observation={
            'known':{10:{'role':'controller','identity':{'pid':10,'birth':110}}},'extras':{},'samples':[]})
        sequences=iter(([10],[10,11],[10,11]))
        job.members=lambda:next(sequences)
        sample={'processes':[{'pid':10,'parent_pid':1,'image_name':'powershell.exe'},
                             {'pid':11,'parent_pid':10,'image_name':'conhost.exe'}],
                'snapshot_handle_closed':True,'native_calls':[],
                'scope':'PROCESS_METADATA_ONLY_NO_AUTHORITY'}
        with patch('m4_process_observation.snapshot_processes',return_value=sample) as capture,patch.object(q.time,'sleep'):
            q.observe_job_processes(job,threading.RLock(),time.monotonic()+5,[10])
        capture.assert_called_once_with([10,11])
        self.assertEqual(list(job._m4_observation['extras']),[11])
        self.assertEqual(len(job._m4_observation['samples']),1)

    def test_late_engine_host_must_actually_arrive_before_engine_barrier_is_released(self):
        known={10:{'role':'controller','identity':{'pid':10,'birth':110}},
               20:{'role':'engine','identity':{'pid':20,'birth':120}}}
        controller_host={'pid':11,'parent_pid':10,'image_name':'conhost.exe'}
        job=SimpleNamespace(_m4_observation={'known':known,'extras':{11:controller_host},'samples':[]})
        before=[10,11,20];after=[10,11,20,21]
        sequence=iter((before,before,after,after));job.members=lambda:next(sequence)
        sample={'processes':[{'pid':10,'parent_pid':1,'image_name':'powershell.exe'},controller_host,
                            {'pid':20,'parent_pid':10,'image_name':'python.exe'},
                            {'pid':21,'parent_pid':20,'image_name':'conhost.exe'}],
                'snapshot_handle_closed':True,'native_calls':[],
                'scope':'PROCESS_METADATA_ONLY_NO_AUTHORITY'}
        with patch('m4_process_observation.snapshot_processes',return_value=sample) as capture,patch.object(q.time,'sleep') as pause:
            q.observe_job_processes(job,threading.RLock(),time.monotonic()+5,[20])
        self.assertEqual(pause.call_count,2)
        capture.assert_called_once_with(after)
        self.assertEqual(job._m4_observation['extras'][21]['parent_pid'],20)

    def test_both_concurrent_engine_hosts_are_observed_when_the_second_arrives_late(self):
        known={10:{'role':'controller','identity':{'pid':10,'birth':110}},
               20:{'role':'engine','identity':{'pid':20,'birth':120}},
               30:{'role':'controller','identity':{'pid':30,'birth':130}},
               40:{'role':'engine','identity':{'pid':40,'birth':140}}}
        fixed=[{'pid':pid,'parent_pid':1,'image_name':'python.exe' if row['role']=='engine' else 'powershell.exe'} for pid,row in known.items()]
        first={'pid':21,'parent_pid':20,'image_name':'conhost.exe'}
        second={'pid':41,'parent_pid':40,'image_name':'conhost.exe'}
        base=[10,20,30,40];one=sorted(base+[21]);both=sorted(base+[21,41])
        sequence=iter((base,one,one,one,both,both))
        job=SimpleNamespace(members=lambda:next(sequence),_m4_observation={'known':known,'extras':{},'samples':[]})
        samples=[{'processes':fixed+[first],'snapshot_handle_closed':True,'native_calls':[]},
                 {'processes':fixed+[first,second],'snapshot_handle_closed':True,'native_calls':[]}]
        with patch('m4_process_observation.snapshot_processes',side_effect=samples) as capture,patch.object(q.time,'sleep'):
            q.observe_job_processes(job,threading.RLock(),time.monotonic()+5,[20,40])
        self.assertEqual([call.args[0] for call in capture.call_args_list],[one,both])
        self.assertEqual({row['parent_pid'] for row in job._m4_observation['extras'].values()},{20,40})

    def test_concurrent_callback_requires_exactly_the_two_enrolled_engine_ids_under_lock(self):
        known={10:{'role':'controller','identity':{'pid':10,'birth':110}},
               20:{'role':'engine','identity':{'pid':20,'birth':120}},
               30:{'role':'controller','identity':{'pid':30,'birth':130}},
               40:{'role':'engine','identity':{'pid':40,'birth':140}}}
        job=SimpleNamespace(_m4_observation={'known':known,'extras':{},'samples':[]});lock=threading.RLock();observations=[]
        def observe(selected_job,selected_lock,deadline,pids):
            self.assertIs(selected_job,job);self.assertIs(selected_lock,lock)
            self.assertTrue(lock._is_owned());observations.append(pids)
        def drive(*args,engine_sync=None,**kwargs):
            engine_sync.wait(timeout=2);return {'diagnostic_fake_only':True}
        with patch.object(q,'drive_controller',side_effect=drive),patch.object(q,'observe_job_processes',side_effect=observe):
            result=q.concurrent_controllers({'deadline':time.monotonic()+5},{},{},job,lock)
        self.assertEqual(observations,[[20,40]]);self.assertEqual(len(result),2)

    def test_only_actual_conhost_with_retained_fixed_runtime_parent_can_be_classified(self):
        known={10:{'role':'controller','identity':{'pid':10,'birth':110}},
               20:{'role':'engine','identity':{'pid':20,'birth':120}},
               30:{'role':'worker','identity':{'pid':30,'birth':130}},
               40:{'role':'readonly_monitor','identity':{'pid':40,'birth':140}}}
        hosts=[{'pid':11,'parent_pid':10,'image_name':'conhost.exe'},
               {'pid':31,'parent_pid':30,'image_name':'CONHOST.EXE'},
               {'pid':21,'parent_pid':20,'image_name':'conhost.exe'},
               {'pid':41,'parent_pid':40,'image_name':'conhost.exe'}]
        self.assertEqual(set(q.classify_job_metadata(known,{},hosts)),{11,21,31,41})
        for wrong in ({'pid':11,'parent_pid':20,'image_name':'rogue.exe'},
                      {'pid':11,'parent_pid':10,'image_name':'powershell.exe'},
                      {'pid':11,'parent_pid':999,'image_name':'conhost.exe'}):
            with self.assertRaises(q.QualificationRefusal):q.classify_job_metadata(known,{},[wrong])
        duplicate_parent=[*hosts,{'pid':12,'parent_pid':10,'image_name':'conhost.exe'}]
        with self.assertRaises(q.QualificationRefusal):q.classify_job_metadata(known,{},duplicate_parent)

    def test_job_total_reconciles_observed_console_host_but_never_a_blanket_allowance(self):
        before={'total_processes':0,'active_processes':0,'terminated_processes':0}
        value={'native_processes':{'controller':{'closed':True,'identity':{'pid':10,'birth':110}}}}
        job=SimpleNamespace(accounting=lambda:{'total_processes':2,'active_processes':0,'terminated_processes':0})
        with self.assertRaises(q.QualificationRefusal):q.settled_job_evidence(job,[value],before)
        job._m4_observation={'known':{10:{'role':'controller','identity':{'pid':10,'birth':110}}},
            'extras':{11:{'pid':11,'parent_pid':10,'image_name':'conhost.exe'}},'samples':[{'actual_metadata_only':True}]}
        report=q.settled_job_evidence(job,[value],before)
        self.assertEqual(report['conhost_allowance'],1)
        self.assertEqual(report['incidental_console_hosts'],[{'pid':11,'parent_pid':10,'image_name':'conhost.exe'}])

    def test_controller_console_host_is_optional_at_the_assignment_boundary(self):
        before={'total_processes':0,'active_processes':0,'terminated_processes':0}
        value={'native_processes':{'controller':{'closed':True,'identity':{'pid':10,'birth':110}}}}
        job=SimpleNamespace(accounting=lambda:{'total_processes':1,'active_processes':0,'terminated_processes':0},
            _m4_observation={'known':{10:{'role':'controller','identity':{'pid':10,'birth':110}}},'extras':{},'samples':[]})
        report=q.settled_job_evidence(job,[value],before)
        self.assertTrue(report['job_total_reconciled'])
        self.assertEqual(report['controller_console_host_boundary'][0]['status'],'NOT_OBSERVED_IN_OWNED_JOB')
        self.assertEqual(report['conhost_allowance'],0)

    def test_unsettled_native_custody_cannot_be_hidden_by_zero_active_job_count(self):
        before={'total_processes':0,'active_processes':0,'terminated_processes':0}
        job=SimpleNamespace(accounting=lambda:{'total_processes':1,'active_processes':0,'terminated_processes':0})
        value={'native_processes':{'controller':{'closed':False,'identity':{'pid':10,'birth':110}}}}
        with self.assertRaises(q.QualificationRefusal):q.settled_job_evidence(job,[value],before)


if __name__=='__main__':unittest.main()
