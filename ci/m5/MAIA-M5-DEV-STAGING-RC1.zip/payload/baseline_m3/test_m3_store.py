"""Behavioral controls for durable one-way transaction/recovery semantics."""
from pathlib import Path
import base64
import concurrent.futures
import json
import os
import sqlite3
import subprocess
import sys
import tempfile
import threading
import unittest

import m3_store as m


BINDING = {'cycle': 'a' * 32, 'source': 'b' * 64, 'inputs': 'c' * 64}
BEFORE = b'{ "status": "PIPELINE_COMPLETE", "note": "exact whitespace retained" }'
EMPTY = b'{ "items": [] }'
AFTER = m.canonical({'status': 'QUEUED', 'cycle': BINDING['cycle']})
QUEUED = m.canonical({'items': [BINDING['cycle']]})


def receipt(phase, **extra):
    return dict(binding=BINDING, kind=phase, identity={'pid': 1234, 'birth': 5678}, mac='d' * 64, **extra)


class StoreTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.path = self.root / 'transaction.sqlite'
        self.stores = []

    def tearDown(self):
        for store in self.stores:
            store.close()
        self.temp.cleanup()

    def create(self, claim=True):
        store = m.Store.create(self.path, BINDING, BEFORE, EMPTY)
        self.stores.append(store)
        if claim:
            store.claim_receiver('e' * 32)
        return store

    def queue(self):
        store = self.create()
        store.enqueue(AFTER, QUEUED)
        return store

    def test_real_transaction_keeps_exact_images_and_dequeues_with_intent(self):
        store = self.create()
        prepared = store.inspect()
        image = prepared['records'][0]['payload']['images']['state']
        self.assertEqual(base64.b64decode(image['raw_b64']), BEFORE)
        self.assertEqual(image['sha256'], m.sha(BEFORE))
        store.enqueue(AFTER, QUEUED)
        self.assertEqual(store.inspect()['queue'], [BINDING['cycle']])
        store.intent()
        self.assertEqual(store.inspect()['queue'], [])
        store.started(receipt('STARTED'))
        store.completed(receipt('COMPLETED', exit_code=0, effect_sha256='e' * 64))
        result = m.recover(self.path, BINDING)
        self.assertEqual(result['phase'], 'COMPLETED')
        self.assertEqual([r['phase'] for r in result['records']], list(m.PHASES))
        self.assertFalse(result['ready'])
        self.assertFalse(result['replay_permitted'])
        self.assertFalse(result['start_capability'])

    def test_recovered_queued_state_never_recreates_start_capability(self):
        self.queue().close()
        result = m.recover(self.path, BINDING)
        self.assertEqual(result['phase'], 'QUEUED')
        self.assertFalse(result['ready'])
        self.assertFalse(result['start_capability'])

    def test_missing_database_recovery_never_recreates_store(self):
        with self.assertRaises(m.Refusal):
            m.recover(self.path, BINDING)
        self.assertFalse(self.path.exists())
        self.assertEqual(list(self.root.iterdir()), [])

    def test_preexisting_file_directory_and_dangling_entry_are_never_replaced(self):
        self.path.write_bytes(b'existing')
        with self.assertRaises(m.Refusal):
            self.create()
        self.assertEqual(self.path.read_bytes(), b'existing')
        self.path.unlink()
        self.path.mkdir()
        with self.assertRaises(m.Refusal):
            self.create()
        self.path.rmdir()
        # Portable unit runner may lack Windows symlink permission; this case is
        # exercised by the native matrix. No skipped method disguises that scope.
        if os.name != 'nt':
            self.path.symlink_to(self.root / 'missing-target')
            with self.assertRaises(m.Refusal):
                self.create()
            self.assertTrue(self.path.is_symlink())

    def test_changed_binding_and_noncanonical_json_refuse(self):
        store = self.create()
        with self.assertRaises(m.Refusal):
            m.Store.open_existing(self.path, {**BINDING, 'inputs': 'f' * 64})
        with self.assertRaises(m.Refusal):
            store.enqueue(b'{"status":"QUEUED","status":"QUEUED","cycle":"' + BINDING['cycle'].encode() + b'"}', QUEUED)
        with self.assertRaises(m.Refusal):
            store.enqueue(b'{"status":"QUEUED","cycle":"' + BINDING['cycle'].encode() + b'","x":NaN}', QUEUED)
        self.assertEqual(store.inspect()['phase'], 'PREPARED')

    def test_wrong_preimage_and_postimage_are_refused(self):
        with self.assertRaises(m.Refusal):
            m.Store.create(self.path, BINDING, b'{"status":"IDLE"}', EMPTY)
        self.assertFalse(self.path.exists())
        store = self.create()
        with self.assertRaises(m.Refusal):
            store.enqueue(AFTER, m.canonical({'items': ['another']}))
        self.assertEqual(store.inspect()['phase'], 'PREPARED')

    def test_readonly_recovery_leaves_authority_bytes_unchanged_and_blocks_mutations(self):
        self.queue()
        def authority():
            return {p.name: m.sha(p.read_bytes()) for p in self.root.iterdir() if p.name in ['transaction.sqlite', 'transaction.sqlite-wal']}
        before = authority()
        reader = m.Store.open_existing(self.path, BINDING, readonly=True)
        self.stores.append(reader)
        self.assertEqual(reader.inspect()['phase'], 'QUEUED')
        with self.assertRaises(m.Refusal):
            reader.intent()
        reader.close()
        self.assertEqual(before, authority())
        self.assertFalse(m.recover(self.path, BINDING)['ready'])
        self.assertEqual(before, authority())

    def test_two_concurrent_receivers_have_exactly_one_intent_winner(self):
        self.create(claim=False)
        barrier = threading.Barrier(2)
        def contender(index):
            store = m.Store.open_existing(self.path, BINDING)
            try:
                barrier.wait(timeout=5)
                try:
                    store.claim_receiver(str(index) * 32)
                    store.enqueue(AFTER, QUEUED)
                    store.intent()
                    return 'winner'
                except m.Refusal:
                    return 'refused'
            finally:
                store.close()
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            results = list(pool.map(contender, range(2)))
        self.assertCountEqual(results, ['winner', 'refused'])
        self.assertEqual(m.recover(self.path, BINDING)['phase'], 'START_INTENT')

    def test_reopen_prepared_or_queued_never_restores_receiver_authority(self):
        store = self.create()
        for phase in ('PREPARED', 'QUEUED'):
            with self.subTest(phase=phase):
                reopened = m.Store.open_existing(self.path, BINDING)
                try:
                    with self.assertRaisesRegex(m.Refusal, 'LIVE_RECEIVER_CLAIM_REQUIRED'):
                        reopened.intent()
                    with self.assertRaisesRegex(m.Refusal, 'CLAIM_REFUSED_NO_REPLAY'):
                        reopened.claim_receiver('f' * 32)
                finally:
                    reopened.close()
            if phase == 'PREPARED':
                store.enqueue(AFTER, QUEUED)
        store.close()
        result = m.recover(self.path, BINDING)
        self.assertEqual(result['receiver']['session'], 'e' * 32)
        self.assertFalse(result['start_capability'])

    def test_lost_receiver_claim_acknowledgement_consumes_fence_without_capability(self):
        store = self.create(claim=False)
        def lost(stage):
            if stage == 'after_commit:RECEIVER_CLAIM':
                raise OSError('claim confirmation lost')
        store.hook = lost
        with self.assertRaises(OSError):
            store.claim_receiver('f' * 32)
        self.assertIsNone(store._claimed_session)
        with self.assertRaisesRegex(m.Refusal, 'UNCERTAIN_NO_REPLAY'):
            store.enqueue(AFTER, QUEUED)
        reopened = m.Store.open_existing(self.path, BINDING)
        try:
            with self.assertRaisesRegex(m.Refusal, 'CLAIM_REFUSED_NO_REPLAY'):
                reopened.claim_receiver('e' * 32)
        finally:
            reopened.close()
        result = m.recover(self.path, BINDING)
        self.assertEqual(result['phase'], 'PREPARED')
        self.assertEqual(result['receiver']['session'], 'f' * 32)
        self.assertFalse(result['start_capability'])

    def test_lost_commit_confirmation_poisoned_caller_cannot_repeat_effect(self):
        store = self.queue()
        def lost(stage):
            if stage == 'after_commit:START_INTENT':
                raise OSError('simulated lost commit confirmation')
        store.hook = lost
        with self.assertRaises(OSError):
            store.intent()
        with self.assertRaisesRegex(m.Refusal, 'UNCERTAIN_NO_REPLAY'):
            store.intent()
        with self.assertRaisesRegex(m.Refusal, 'UNCERTAIN_NO_REPLAY'):
            store.inspect()
        result = m.recover(self.path, BINDING)
        self.assertEqual(result['phase'], 'START_INTENT')
        self.assertEqual(result['queue'], [])
        self.assertFalse(result['start_capability'])

    def test_schema_tamper_and_payload_tamper_are_refused(self):
        self.queue().close()
        conn = sqlite3.connect(self.path)
        conn.execute('DROP TRIGGER records_no_update')
        conn.commit()
        with self.assertRaisesRegex(m.Refusal, 'SCHEMA_CHANGED'):
            m.recover(self.path, BINDING)
        trigger = next(s for s in m.SCHEMA if s.startswith('CREATE TRIGGER records_no_update '))
        # Restore the exact schema but corrupt a payload, so checking only table
        # names or trigger existence cannot pass this fixture.
        conn.execute("UPDATE records SET payload=? WHERE ordinal=2", (m.canonical({'binding': BINDING, 'images': {}}),))
        conn.execute(trigger)
        conn.commit()
        conn.close()
        with self.assertRaises(m.Refusal):
            m.recover(self.path, BINDING)

    def test_receipts_are_structurally_bound_and_completion_identity_cannot_change(self):
        store = self.queue()
        store.intent()
        with self.assertRaises(m.Refusal):
            store.started({**receipt('STARTED'), 'binding': {**BINDING, 'source': 'e' * 64}})
        with self.assertRaises(m.Refusal):
            store.started({**receipt('STARTED'), 'identity': {'pid': True, 'birth': 1}})
        store.started(receipt('STARTED'))
        with self.assertRaisesRegex(m.Refusal, 'IDENTITY_CHANGED'):
            store.completed({**receipt('COMPLETED'), 'identity': {'pid': 1234, 'birth': 5679}})
        self.assertEqual(m.recover(self.path, BINDING)['phase'], 'STARTED')

    def test_real_process_crashes_before_and_after_each_commit_recover_once_without_start(self):
        source = str(Path(m.__file__).resolve().parent)
        script = r'''
import sys,json
sys.path.insert(0,sys.argv[1])
import m3_store as m
path,binding,phase,when,barrier=sys.argv[2],json.loads(sys.argv[3]),sys.argv[4],sys.argv[5],sys.argv[6]
s=m.Store.open_existing(path,binding)
s.claim_receiver('e'*32)
index=m.PHASES.index(phase)
if index>1:s.enqueue(m.canonical(dict(status='QUEUED',cycle=binding['cycle'])),m.canonical(dict(items=[binding['cycle']])))
if index>2:s.intent()
if index>3:s.started(dict(binding=binding,kind='STARTED',identity=dict(pid=1234,birth=5678),mac='d'*64))
def hook(stage):
 if stage==when+':'+phase:
  with open(barrier,'x') as f:f.write(stage)
  sys.stdout.write('BARRIER\n');sys.stdout.flush()
  sys.stdin.buffer.read(1)
s.hook=hook
receipt=dict(binding=binding,kind=phase,identity=dict(pid=1234,birth=5678),mac='d'*64)
if phase=='QUEUED':s.enqueue(m.canonical(dict(status='QUEUED',cycle=binding['cycle'])),m.canonical(dict(items=[binding['cycle']])))
elif phase=='START_INTENT':s.intent()
elif phase=='STARTED':s.started(receipt)
else:s.completed(receipt)
s.close()
'''
        for index, phase in enumerate(m.PHASES[1:], 1):
            for when in ('before_commit', 'after_commit'):
                with self.subTest(phase=phase, when=when):
                    case = self.root / (phase + when)
                    case.mkdir()
                    path = case / 'transaction.sqlite'
                    s = m.Store.create(path, BINDING, BEFORE, EMPTY)
                    s.close()
                    barrier = case / 'barrier.txt'
                    proc = subprocess.Popen([sys.executable, '-I', '-B', '-c', script, source, str(path), json.dumps(BINDING), phase, when, str(barrier)], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                    try:
                        # Wait for the actual commit hook, with a bounded reader.
                        # A failed barrier kills only this retained child before
                        # joining the reader; executor shutdown cannot hang.
                        pool = concurrent.futures.ThreadPoolExecutor(max_workers=1)
                        future = pool.submit(proc.stdout.readline)
                        try:
                            line = future.result(timeout=5)
                        finally:
                            if not future.done() and proc.poll() is None:
                                proc.kill()
                                proc.wait(timeout=5)
                            pool.shutdown(wait=True)
                        self.assertIn(line, (b'BARRIER\n', b'BARRIER\r\n'), proc.stderr.read() if proc.poll() is not None else b'')
                        self.assertEqual(barrier.read_text(), when + ':' + phase)
                        proc.kill()
                        stdout, stderr = proc.communicate(timeout=5)
                        self.assertNotEqual(proc.returncode, 0)
                        self.assertEqual(stderr, b'')
                    finally:
                        if proc.poll() is None:
                            proc.kill()
                            proc.communicate(timeout=5)
                        for stream in [proc.stdin, proc.stdout, proc.stderr]:
                            if stream:
                                stream.close()
                    recovered = m.recover(path, BINDING)
                    expected = phase if when == 'after_commit' else m.PHASES[index - 1]
                    self.assertEqual(recovered['phase'], expected)
                    self.assertEqual(recovered['queue'], [BINDING['cycle']] if expected == 'QUEUED' else [])
                    self.assertFalse(recovered['ready'])
                    self.assertFalse(recovered['replay_permitted'])
                    self.assertFalse(recovered['start_capability'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
