"""Finite broker/worker for an isolated M3 process-crash fixture only."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import secrets
import sqlite3
import subprocess
import sys
import time

from m3_store import Store, Refusal as StoreRefusal, canonical, sha, validate_binding, recover
from m3_protocol import Channel, FramedPipe, ProtocolRefusal, sign_receipt, verify_receipt

TOTAL_SECONDS=40

def source_map():
    return {p.name:sha(p.read_bytes()) for p in sorted(Path(__file__).parent.glob('*.py')) if p.is_file()}
def source_pin():return sha(canonical(source_map()))

def write_fixture_inputs(root,binding):
    """Create the exact six inert before-images. No journal, keys or process."""
    from m3_admission import input_digest
    root=Path(root);root.mkdir(parents=True,exist_ok=False)
    cycle=binding['cycle'];prompt=b'M3 disposable effect: one authenticated fixture marker; no production work.\n'
    worktree=canonical({'fixture':'M3_BEGIN_20261108','production':False})
    values={'prompt.txt':prompt,'worktree-pin.json':worktree,
            'state.before.json':canonical({'status':'PIPELINE_COMPLETE'}),'queue.before.json':canonical({'items':[]}),
            'final.before.txt':b'FIXTURE_APPROVED\n',
            'manifest.json':canonical({'cycle':cycle,'idempotency_policy':'never_replay','prompt_sha256':sha(prompt),'worktree_sha256':sha(worktree),'prior_verdict':'FIXTURE_APPROVED'})}
    for name,data in values.items():
        with (root/name).open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
    expected={name:sha(value) for name,value in values.items()}
    final=dict(binding,inputs=input_digest(expected));validate_binding(final)
    return final,expected

def prepare(root,binding,expected):
    from m3_admission import admit
    from m3_windows import KeyVault
    with admit(root,binding,expected) as admission:
        key=KeyVault.seal(root,binding)
        store=Store.create(Path(root)/'transaction.sqlite',binding,admission.buffers['state.before.json'],admission.buffers['queue.before.json'])
        store.close()
        return key,{'check':admission.check,'inputs':admission.snapshots,'key_vault_calls':list(KeyVault.calls)}

def authority_image(root):
    """DB bytes and every nonempty WAL are authoritative.

    SQLite mode=ro can create an empty WAL while rebuilding volatile reader
    coordination. ONLY absent <-> zero-byte WAL is normalized. A database,
    including an empty database, is never normalized; nonempty WAL removal or
    any data/hash change remains a mismatch.
    """
    root=Path(root);result={}
    for name in ('transaction.sqlite','transaction.sqlite-wal'):
        path=root/name
        if path.exists():
            data=path.read_bytes()
            if name=='transaction.sqlite-wal' and data==b'':continue
            result[name]=sha(data)
    return result

def authenticated_recovery(root,binding):
    """Read-only diagnosis. Known inaccessible/unverifiable evidence quarantines.

    A quarantine result makes NO claim that authority bytes were unchanged or
    receipts authenticated. Unexpected implementation errors still propagate.
    """
    from m3_windows import KeyVault,Refusal as NativeRefusal
    root=Path(root)
    try:
        authority=authority_image(root)
        key=KeyVault.load(root,binding)
        value=recover(root/'transaction.sqlite',binding)
        store=Store.open_existing(root/'transaction.sqlite',binding,readonly=True)
        try:inspection=store.inspect()
        finally:store.close()
        verified=[]
        for event in inspection['records']:
            if event['phase'] in ('STARTED','COMPLETED'):
                receipt=event['payload']['receipt'];verify_receipt(key,receipt,binding,event['phase']);verified.append(event['phase'])
        after=authority_image(root)
        if authority!=after:raise ProtocolRefusal('recovery changed authority DB/WAL bytes')
        return dict(value,receipts_authenticated=verified,receipt_authentication='HMAC_VERIFIED_WITH_USER_DPAPI_KEY',live_process_reauthenticated=False,
                    ready=False,replay_permitted=False,start_capability=False,launch_capability=False,
                    authority_unchanged=True,authority_hashes=after,key_vault_calls=list(KeyVault.calls),recovery_scope='SQL_READ_ONLY_NO_START_NO_DML_SHM_LOCKS_VOLATILE')
    except (StoreRefusal,sqlite3.Error,OSError,NativeRefusal,ProtocolRefusal) as exc:
        return dict(binding=dict(binding),phase='QUARANTINED',quarantined=True,
                    reason={'type':type(exc).__name__,'detail':str(exc)},
                    ready=False,replay_permitted=False,start_capability=False,launch_capability=False,
                    receipts_authenticated=[],receipt_authentication='UNPROVEN_QUARANTINED',
                    live_process_reauthenticated=False,authority_unchanged=None,authority_hashes=None,
                    recovery_scope='KNOWN_RECOVERY_FAILURE_NO_AUTHORITY_NO_START_NO_RETRY')

def live_status(receipt,key,binding,native,now_ms,max_age_ms=10000):
    body=verify_receipt(key,receipt,binding,'STARTED')
    stamp=body.get('observed_monotonic_ms')
    if type(now_ms) is not int or type(stamp) is not int or not 0<=now_ms-stamp<=max_age_ms:
        raise ProtocolRefusal('stale or future live receipt')
    if body['identity']!=native.identity() or native.wait(0) is not None:
        raise ProtocolRefusal('live retained identity differs or process exited')
    return {'live':True,'identity':body['identity'],'scope':'RETAINED_HANDLE_CURRENT_OBSERVATION_ONLY','ready':False}

def stdio_transport():
    # Daemon pipe readers must not hold BufferedReader's shutdown lock.
    stdin=getattr(sys.stdin.buffer,'raw',sys.stdin.buffer)
    stdout=getattr(sys.stdout.buffer,'raw',sys.stdout.buffer)
    return FramedPipe(stdin,stdout)

def _channel_bootstrap():
    transport=stdio_transport();deadline=time.monotonic()+TOTAL_SECONDS
    boot=transport.read(min(deadline,time.monotonic()+10))
    if not isinstance(boot,dict) or set(boot)!={'binding','key','root','source','enqueue','session'}:raise ProtocolRefusal('bootstrap shape')
    binding=validate_binding(boot['binding'])
    if boot['source']!=source_pin() or boot['source']!=binding['source']:raise ProtocolRefusal('source pin differs')
    key=bytes.fromhex(boot['key'])
    if len(key)!=32 or type(boot['enqueue']) is not bool or type(boot['session']) is not str or len(boot['session'])!=32:raise ProtocolRefusal('bootstrap value')
    from m3_windows import fixture_root
    root=fixture_root(boot['root'])
    return boot,root,key,transport,deadline

def _barrier(channel,stage,deadline,**data):
    channel.send('BARRIER',dict(stage=stage,**data),deadline)
    frame=channel.receive(deadline)
    if frame['kind']!='RELEASE' or frame['payload']!={'stage':stage}:raise ProtocolRefusal('barrier release differs')

def _worker(boot,root,key,transport,deadline):
    session=boot['session'];binding=boot['binding']
    channel=Channel(transport,key,binding,'worker:'+session,'broker:'+session)
    command=channel.receive(deadline)
    if command['kind']!='EFFECT_RELEASE' or set(command['payload'])!={'identity'}:raise ProtocolRefusal('worker release shape')
    identity=command['payload']['identity']
    if not isinstance(identity,dict) or identity.get('pid')!=os.getpid():raise ProtocolRefusal('worker PID differs')
    _barrier(channel,'worker_before_effect',deadline,identity=identity)
    result=sign_receipt(key,dict(binding=binding,kind='EFFECT',identity=identity,effect='one-disposable-marker'))
    raw=canonical(result)
    with (root/'EFFECT.json').open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
    _barrier(channel,'worker_after_effect',deadline,identity=identity,effect_sha256=sha(raw))
    channel.send('EFFECT',{'receipt':result,'sha256':sha(raw)},deadline)
    return 0

def _fixed_child_args(role):
    package=Path(__file__).parent.absolute();entry=package/'m3_entry.py'
    manifest_raw=(package/'SOURCE_MANIFEST.json').read_bytes();manifest=json.loads(manifest_raw)
    pin=source_pin()
    if manifest.get('source_sha256')!=pin or manifest.get('schema')!=1:
        raise ProtocolRefusal('child source manifest differs')
    entry_sha=manifest['files']['m3_entry.py']['sha256']
    if entry_sha!=sha(entry.read_bytes()):raise ProtocolRefusal('entry bootstrap pin differs')
    # Read/verify/execute the SAME entry buffer before any package import.
    # m3_entry then loads every sibling module from held verified buffers.
    code='\n'.join([
        'import pathlib,hashlib,sys',
        'p=pathlib.Path('+repr(str(entry))+')',
        'b=p.read_bytes()',
        'if hashlib.sha256(b).hexdigest()!='+repr(entry_sha)+': raise RuntimeError("entry source pin differs")',
        'sys.argv=[str(p)]+sys.argv[1:]',
        'exec(compile(b,str(p),"exec"),{"__name__":"__main__","__file__":str(p)})',
    ])
    return [sys.executable,'-I','-S','-B','-c',code,'--manifest-sha',sha(manifest_raw),'--source-sha',pin,'--entry','m3_execution.py','--','--role',role]

def _broker(boot,root,key,transport,deadline):
    from m3_windows import NativeProcess,Refusal as NativeRefusal
    session=boot['session'];binding=boot['binding']
    channel=Channel(transport,key,binding,'broker:'+session,'harness:'+session)
    worker=None;native=None;store=None;child_pipe=None;worker_stderr=None
    try:
        store=Store.open_existing(root/'transaction.sqlite',binding)
        store.hook=lambda stage:_barrier(channel,stage,deadline)
        store.claim_receiver(session)
        if boot['enqueue']:
            store.enqueue(canonical({'status':'QUEUED','cycle':binding['cycle']}),canonical({'items':[binding['cycle']]}))
            _barrier(channel,'queue_lock_released',deadline)
        channel.send('READY',{},deadline)
        request=channel.receive(deadline)
        if request['kind']!='START' or request['payload']!={}:raise ProtocolRefusal('start request differs')
        _barrier(channel,'request_received',deadline)
        store.intent()
        # This entry journal is independent of the worker's effect ledger.
        _barrier(channel,'launch_enter',deadline,command_kind='PINNED_FIXTURE_WORKER')
        worker_stderr=(root/('worker-'+session+'.stderr')).open('xb')
        worker=subprocess.Popen(_fixed_child_args('worker'),stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=worker_stderr,bufsize=0,cwd=root,close_fds=True)
        native=NativeProcess(worker);identity=native.identity()
        _barrier(channel,'worker_created',deadline,identity=identity,remote_handle=native.handle,native_calls=native.calls)
        child_pipe=FramedPipe(worker.stdout,worker.stdin)
        child_session=secrets.token_hex(16)
        child_pipe.write(dict(binding=binding,key=key.hex(),root=str(root),source=boot['source'],enqueue=False,session=child_session),deadline)
        child=Channel(child_pipe,key,binding,'broker:'+child_session,'worker:'+child_session)
        started=sign_receipt(key,dict(binding=binding,kind='STARTED',identity=identity,broker_session=session,observed_monotonic_ms=int(time.monotonic()*1000)))
        store.started(started)
        child.send('EFFECT_RELEASE',{'identity':identity},deadline)
        while True:
            response=child.receive(deadline)
            if response['kind']=='BARRIER':
                stage=response['payload'].get('stage')
                if stage not in ('worker_before_effect','worker_after_effect') or response['payload'].get('identity')!=identity:raise ProtocolRefusal('worker barrier identity')
                _barrier(channel,stage,deadline,**{k:v for k,v in response['payload'].items() if k!='stage'})
                child.send('RELEASE',{'stage':stage},deadline)
            elif response['kind']=='EFFECT':break
            else:raise ProtocolRefusal('worker response kind')
        body=verify_receipt(key,response['payload'].get('receipt'),binding,'EFFECT')
        if body['identity']!=identity:raise ProtocolRefusal('effect identity differs')
        raw=(root/'EFFECT.json').read_bytes()
        if sha(raw)!=response['payload'].get('sha256') or json.loads(raw)!=response['payload']['receipt']:raise ProtocolRefusal('effect file differs')
        code=native.wait(max(0,min(5,deadline-time.monotonic())))
        if code!=0:raise ProtocolRefusal('worker exit not observed zero')
        completed=sign_receipt(key,dict(binding=binding,kind='COMPLETED',identity=identity,exit_code=code,effect_sha256=sha(raw)))
        store.completed(completed)
        native_calls=list(native.calls);native.close();native_calls.extend(native.calls[len(native_calls):]);native=None
        channel.send('COMPLETED',{'receipt':completed,'worker_native_calls':native_calls,'worker_handle_closed':True},deadline)
        return 0
    except BaseException as exc:
        # No retry, terminalize the one receiver. Parent owns finite job cleanup.
        try:channel.send('REFUSED',{'reason':type(exc).__name__+':'+str(exc),'start_replayed':False},min(deadline,time.monotonic()+2))
        except BaseException:pass
        return 2
    finally:
        if store is not None:store.close()
        # Do not close an unsignaled process handle and invent settlement.
        if native is not None:
            if native.api.frozen:
                print('M3_CLEANUP_UNRESOLVED:NATIVE_BOUNDARY_FROZEN',file=sys.stderr)
            else:
                try:
                    if native.wait(0) is not None:native.close()
                except NativeRefusal as cleanup_error:
                    print('M3_CLEANUP_UNRESOLVED:'+str(cleanup_error),file=sys.stderr)
        if worker is not None and worker.returncode is not None:
            for pipe in (worker.stdin,worker.stdout):
                try:pipe.close()
                except (OSError,ValueError):pass
        if worker_stderr is not None:worker_stderr.close()

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--role',required=True,choices=('broker','worker'));args=parser.parse_args()
    boot,root,key,transport,deadline=_channel_bootstrap()
    return _broker(boot,root,key,transport,deadline) if args.role=='broker' else _worker(boot,root,key,transport,deadline)

if __name__=='__main__':
    try:raise SystemExit(main())
    except (ProtocolRefusal,ValueError,RuntimeError,OSError) as exc:
        print(type(exc).__name__+':'+str(exc),file=sys.stderr);raise SystemExit(2)
