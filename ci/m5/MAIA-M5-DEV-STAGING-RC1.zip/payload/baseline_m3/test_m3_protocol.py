import io
import os
import time
import unittest
from m3_store import canonical
from m3_protocol import (Channel,FramedPipe,ProtocolRefusal,parse,mac,
                          sign_receipt,verify_receipt,MAX_FRAME)
from m3_execution import live_status

B={'cycle':'c'*32,'source':'d'*64,'inputs':'e'*64};KEY=b'k'*32
class MemoryPipe:
    def __init__(self):self.rows=[]
    def write(self,x,deadline):self.rows.append(x)
    def read(self,deadline):return self.rows.pop(0)
class FakeProcess:
    def identity(self):return {'pid':22,'birth':33}
    def wait(self,timeout):return None

class ProtocolTests(unittest.TestCase):
    def pair(self):
        p=MemoryPipe();return p,Channel(p,KEY,B,'sender','receiver'),Channel(p,KEY,B,'receiver','sender')
    def test_direction_sequence_binding_and_mac_roundtrip(self):
        p,a,b=self.pair();a.send('START',{},time.monotonic()+1);self.assertEqual(b.receive(time.monotonic()+1)['sequence'],1)
    def test_duplicate_frame_is_not_a_second_request(self):
        p,a,b=self.pair();a.send('START',{},time.monotonic()+1);p.rows.append(dict(p.rows[0]));b.receive(0)
        with self.assertRaises(ProtocolRefusal):b.receive(0)
        self.assertTrue(b.frozen)
    def test_authenticated_cross_cycle_is_refused(self):
        p,a,b=self.pair();a.send('START',{},0);f=p.rows[0];f['binding']=dict(B,cycle='f'*32);f['mac']=mac(KEY,{k:v for k,v in f.items() if k!='mac'})
        with self.assertRaises(ProtocolRefusal):b.receive(0)
    def test_valid_mac_wrong_direction_refused(self):
        p,a,b=self.pair();a.send('START',{},0);f=p.rows[0];f['direction']='receiver';f['mac']=mac(KEY,{k:v for k,v in f.items() if k!='mac'})
        with self.assertRaises(ProtocolRefusal):b.receive(0)
    def test_changed_payload_refused(self):
        p,a,b=self.pair();a.send('START',{},0);p.rows[0]['payload']={'changed':True}
        with self.assertRaises(ProtocolRefusal):b.receive(0)
    def test_duplicate_keys_nonfinite_noncanonical_refused(self):
        for raw in [b'{"a":1,"a":2}',b'{"a":NaN}',b'{ "a":1}',b'\xff',b'[] '+b' '*(MAX_FRAME)]:
            with self.assertRaises(Exception):parse(raw)
    def test_receipt_mac_binding_and_identity(self):
        r=sign_receipt(KEY,dict(binding=B,kind='STARTED',identity={'pid':22,'birth':33}))
        self.assertEqual(verify_receipt(KEY,r,B,'STARTED')['identity']['birth'],33)
        with self.assertRaises(ProtocolRefusal):verify_receipt(b'j'*32,r,B,'STARTED')
        with self.assertRaises(ProtocolRefusal):verify_receipt(KEY,r,dict(B,inputs='0'*64),'STARTED')
    def test_real_pipe_frame_roundtrip(self):
        ar,aw=os.pipe();br,bw=os.pipe()
        handles=[os.fdopen(ar,'rb',buffering=0),os.fdopen(aw,'wb',buffering=0),os.fdopen(br,'rb',buffering=0),os.fdopen(bw,'wb',buffering=0)]
        try:
            a=Channel(FramedPipe(handles[2],handles[1]),KEY,B,'a','b');b=Channel(FramedPipe(handles[0],handles[3]),KEY,B,'b','a')
            d=time.monotonic()+2;a.send('START',{},d);self.assertEqual(b.receive(d)['kind'],'START');b.send('REPLY',{'value':1},d);self.assertEqual(a.receive(d)['payload'],{'value':1})
        finally:
            for f in [handles[1],handles[3],handles[0],handles[2]]:f.close()
    def test_read_timeout_freezes_no_retry(self):
        r,w=os.pipe();reader=os.fdopen(r,'rb',buffering=0);writer=os.fdopen(w,'wb',buffering=0)
        try:
            p=FramedPipe(reader,io.BytesIO())
            with self.assertRaises(ProtocolRefusal):p.read(time.monotonic()+.02)
            with self.assertRaises(ProtocolRefusal):p.read(time.monotonic()+1)
        finally:writer.close();reader.close()
    def test_expired_write_freezes_no_retry(self):
        class Broken:
            def write(self,data):raise OSError('broken owned pipe')
            def flush(self):pass
        p=FramedPipe(io.BytesIO(b''),Broken())
        with self.assertRaises(ProtocolRefusal):p.write({'x':1},time.monotonic()+1)
        self.assertTrue(p.frozen)
        with self.assertRaises(ProtocolRefusal):p.write({'x':1},time.monotonic()+1)
    def test_live_identity_and_staleness_require_retained_handle(self):
        r=sign_receipt(KEY,dict(binding=B,kind='STARTED',identity={'pid':22,'birth':33},observed_monotonic_ms=100))
        self.assertTrue(live_status(r,KEY,B,FakeProcess(),110)['live'])
        for body,now in [(dict(identity={'pid':22,'birth':34},observed_monotonic_ms=100),110),(dict(identity={'pid':22,'birth':33},observed_monotonic_ms=100),10101)]:
            bad=sign_receipt(KEY,dict(binding=B,kind='STARTED',**body))
            with self.assertRaises(ProtocolRefusal):live_status(bad,KEY,B,FakeProcess(),now)
    def test_child_exits_with_parent_stdin_still_open(self):
        import subprocess,sys,pathlib,queue,threading
        package=str(pathlib.Path(__file__).parent.absolute())
        code='import sys;sys.path.insert(0,'+repr(package)+');from m3_execution import stdio_transport;p=stdio_transport();print("READY",flush=True)'
        child=subprocess.Popen([sys.executable,'-I','-S','-B','-c',code],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,bufsize=0)
        lines=queue.Queue();thread=threading.Thread(target=lambda:lines.put(child.stdout.readline()),daemon=True);thread.start()
        try:
            self.assertEqual(lines.get(timeout=3).strip(),b'READY')
            self.assertEqual(child.wait(timeout=3),0)  # stdin deliberately remains open
            self.assertEqual(child.stderr.read(),b'')
        finally:
            if child.poll() is None:child.kill();child.wait(timeout=3)
            thread.join(timeout=1)
            child.stdin.close();child.stdout.close();child.stderr.close()
    def test_recovery_readonly_open_failure_quarantines_without_claims(self):
        from unittest import mock
        import sqlite3,tempfile,pathlib
        from m3_execution import authenticated_recovery
        with tempfile.TemporaryDirectory() as directory:
            root=pathlib.Path(directory)
            with mock.patch('m3_windows.KeyVault.load',return_value=KEY),mock.patch('m3_execution.recover',side_effect=sqlite3.OperationalError('SQLITE_READONLY_RECOVERY')):
                result=authenticated_recovery(root,B)
            self.assertEqual(result['phase'],'QUARANTINED')
            for key in ('ready','replay_permitted','start_capability','launch_capability'):self.assertIs(result[key],False)
            self.assertIsNone(result['authority_unchanged']);self.assertIsNone(result['authority_hashes']);self.assertEqual(result['receipts_authenticated'],[])
            self.assertEqual(result['reason']['type'],'OperationalError')
    def test_missing_and_corrupt_journal_do_not_reinitialize(self):
        from unittest import mock
        import tempfile,pathlib
        from m3_execution import authenticated_recovery
        with tempfile.TemporaryDirectory() as directory:
            root=pathlib.Path(directory);db=root/'transaction.sqlite'
            with mock.patch('m3_windows.KeyVault.load',return_value=KEY):
                absent=authenticated_recovery(root,B);self.assertEqual(absent['phase'],'QUARANTINED');self.assertFalse(db.exists())
                raw=b'deliberately corrupt disposable journal';db.write_bytes(raw)
                corrupt=authenticated_recovery(root,B);self.assertEqual(corrupt['phase'],'QUARANTINED');self.assertEqual(db.read_bytes(),raw)
    def test_key_read_error_has_no_authority_claim(self):
        from unittest import mock
        import tempfile,pathlib
        from m3_execution import authenticated_recovery
        with tempfile.TemporaryDirectory() as directory:
            with mock.patch('m3_windows.KeyVault.load',side_effect=OSError('owned key unreadable')):
                result=authenticated_recovery(pathlib.Path(directory),B)
            self.assertEqual(result['reason']['type'],'OSError');self.assertEqual(result['phase'],'QUARANTINED');self.assertIsNone(result['authority_unchanged'])
    def test_unexpected_recovery_implementation_error_propagates(self):
        from unittest import mock
        import tempfile,pathlib
        from m3_execution import authenticated_recovery
        with tempfile.TemporaryDirectory() as directory:
            with mock.patch('m3_windows.KeyVault.load',return_value=KEY),mock.patch('m3_execution.recover',side_effect=ValueError('unexpected implementation fault')):
                with self.assertRaisesRegex(ValueError,'unexpected implementation fault'):authenticated_recovery(pathlib.Path(directory),B)
    def test_first_actual_sqlite_readonly_open_accepts_created_empty_wal(self):
        from unittest import mock
        import tempfile,pathlib
        from m3_store import Store,sha
        from m3_execution import authenticated_recovery
        with tempfile.TemporaryDirectory() as directory:
            root=pathlib.Path(directory);db=root/'transaction.sqlite';wal=root/'transaction.sqlite-wal'
            store=Store.create(db,B,canonical({'status':'PIPELINE_COMPLETE'}),canonical({'items':[]}));store.close()
            self.assertFalse(wal.exists());before=db.read_bytes()
            with mock.patch('m3_windows.KeyVault.load',return_value=KEY):result=authenticated_recovery(root,B)
            self.assertEqual(result['phase'],'PREPARED');self.assertIs(result['authority_unchanged'],True)
            self.assertEqual(db.read_bytes(),before);self.assertEqual(result['authority_hashes'],{'transaction.sqlite':sha(before)})
            self.assertTrue(wal.exists());self.assertEqual(wal.read_bytes(),b'')
            self.assertIs(result['ready'],False);self.assertIs(result['replay_permitted'],False)
    def test_authority_normalizes_only_absent_or_zero_wal(self):
        import tempfile,pathlib
        from m3_execution import authority_image
        with tempfile.TemporaryDirectory() as directory:
            root=pathlib.Path(directory);db=root/'transaction.sqlite';wal=root/'transaction.sqlite-wal'
            db.write_bytes(b'database');baseline=authority_image(root)
            wal.write_bytes(b'');self.assertEqual(authority_image(root),baseline)
            wal.write_bytes(b'nonempty WAL');nonempty=authority_image(root);self.assertNotEqual(nonempty,baseline)
            wal.unlink();self.assertNotEqual(authority_image(root),nonempty)
            db.write_bytes(b'');self.assertNotEqual(authority_image(root),baseline)
            empty_db=authority_image(root);db.unlink();self.assertNotEqual(authority_image(root),empty_db)
    def test_nonempty_wal_disappearing_during_recovery_still_quarantines(self):
        from unittest import mock
        import tempfile,pathlib
        import m3_execution
        from m3_store import Store
        with tempfile.TemporaryDirectory() as directory:
            root=pathlib.Path(directory);db=root/'transaction.sqlite';wal=root/'transaction.sqlite-wal'
            store=Store.create(db,B,canonical({'status':'PIPELINE_COMPLETE'}),canonical({'items':[]}));store.close()
            wal.write_bytes(b'nonempty authority bytes must never be normalized')
            real_recover=m3_execution.recover
            def lose_wal_then_read(path,binding):
                wal.unlink()  # controlled loss after authority snapshot
                return real_recover(path,binding)
            with mock.patch('m3_windows.KeyVault.load',return_value=KEY),mock.patch('m3_execution.recover',side_effect=lose_wal_then_read):
                result=m3_execution.authenticated_recovery(root,B)
            self.assertEqual(result['phase'],'QUARANTINED');self.assertIn('authority DB/WAL',result['reason']['detail'])
            self.assertIsNone(result['authority_unchanged']);self.assertIs(result['ready'],False)
    def test_oversize_frame_never_written(self):
        p=FramedPipe(io.BytesIO(b''),io.BytesIO())
        with self.assertRaises(ProtocolRefusal):p.write({'x':'a'*MAX_FRAME},time.monotonic()+1)

if __name__=='__main__':unittest.main()
