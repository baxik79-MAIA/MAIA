"""Bounded inherited-pipe transport for one disposable M3 fixture.

The initial secret bootstrap uses the already-owned inherited pipe. Subsequent
frames authenticate direction, sequence, binding and content. No network or
same-principal-hostile-process security is claimed.
"""
from __future__ import annotations
import hashlib
import hmac
import json
import queue
import struct
import threading
import time
from m3_store import canonical, validate_binding

MAX_FRAME = 65536
class ProtocolRefusal(Exception): pass

def _pairs(items):
    result={}
    for key,value in items:
        if key in result: raise ProtocolRefusal('duplicate JSON key')
        result[key]=value
    return result

def parse(data):
    if not isinstance(data,bytes) or not 0<len(data)<=MAX_FRAME: raise ProtocolRefusal('frame bound')
    try:
        value=json.loads(data.decode('ascii'),object_pairs_hook=_pairs,
                         parse_constant=lambda _: (_ for _ in ()).throw(ProtocolRefusal('nonfinite JSON')))
        if canonical(value)!=data: raise ProtocolRefusal('noncanonical frame')
    except (UnicodeError,ValueError,TypeError,RecursionError) as exc: raise ProtocolRefusal('frame JSON') from exc
    return value

def mac(key,value):
    if not isinstance(key,bytes) or len(key)!=32: raise ProtocolRefusal('key shape')
    return hmac.new(key,canonical(value),hashlib.sha256).hexdigest()

def sign_receipt(key,value):
    if not isinstance(value,dict) or 'mac' in value: raise ProtocolRefusal('receipt shape')
    return dict(value,mac=mac(key,value))

def verify_receipt(key,value,binding,kind=None):
    if not isinstance(value,dict) or 'mac' not in value: raise ProtocolRefusal('receipt missing MAC')
    body={k:v for k,v in value.items() if k!='mac'}
    actual=value['mac']
    if not isinstance(actual,str) or len(actual)!=64 or not hmac.compare_digest(actual,mac(key,body)):
        raise ProtocolRefusal('receipt authentication')
    if body.get('binding')!=validate_binding(binding) or kind is not None and body.get('kind')!=kind:
        raise ProtocolRefusal('receipt binding or kind')
    identity=body.get('identity')
    if not isinstance(identity,dict) or set(identity)!={'pid','birth'} or any(type(identity[k]) is not int or identity[k]<=0 for k in identity):
        raise ProtocolRefusal('receipt process identity')
    return body

class FramedPipe:
    """A daemon reader and bounded writer avoid blocking the caller indefinitely.

    Timeout poisons this transport. It never retries a possibly entered write.
    Parent must settle its own child/job and close pipes after a poisoned call.
    """
    def __init__(self,reader,writer):
        self.reader,self.writer=reader,writer;self.inbox=queue.Queue(maxsize=2)
        self.frozen=False;self._write_lock=threading.Lock()
        self.thread=threading.Thread(target=self._reader,daemon=True);self.thread.start()
    def _exact(self,count):
        parts=[];remaining=count
        while remaining:
            b=self.reader.read(remaining)
            if not b: raise EOFError('inherited pipe EOF')
            parts.append(b);remaining-=len(b)
        return b''.join(parts)
    def _reader(self):
        try:
            while True:
                length=struct.unpack('>I',self._exact(4))[0]
                if not 0<length<=MAX_FRAME: raise ProtocolRefusal('frame length')
                self.inbox.put((True,self._exact(length)))
        except BaseException as exc:
            self.inbox.put((False,type(exc).__name__+':'+str(exc)))
    def read(self,deadline):
        if self.frozen: raise ProtocolRefusal('transport frozen')
        if time.monotonic()>=deadline:self.frozen=True;raise ProtocolRefusal('read deadline; no replay')
        try:ok,value=self.inbox.get(timeout=max(0,deadline-time.monotonic()))
        except queue.Empty:
            self.frozen=True;raise ProtocolRefusal('read deadline; no replay')
        if not ok:self.frozen=True;raise ProtocolRefusal(value)
        return parse(value)
    def write(self,value,deadline):
        if self.frozen: raise ProtocolRefusal('transport frozen')
        if time.monotonic()>=deadline:self.frozen=True;raise ProtocolRefusal('write deadline before entry')
        data=canonical(value)
        if not 0<len(data)<=MAX_FRAME: raise ProtocolRefusal('frame bound')
        if not self._write_lock.acquire(blocking=False):raise ProtocolRefusal('overlapping write')
        done=queue.Queue(maxsize=1)
        def write_once():
            try:
                view=memoryview(struct.pack('>I',len(data))+data)
                while view:
                    n=self.writer.write(view)
                    if type(n) is not int or n<=0: raise ProtocolRefusal('short pipe write')
                    view=view[n:]
                self.writer.flush();done.put((True,None))
            except BaseException as exc:done.put((False,type(exc).__name__+':'+str(exc)))
        threading.Thread(target=write_once,daemon=True).start()
        try:
            try:ok,error=done.get(timeout=max(0,deadline-time.monotonic()))
            except queue.Empty:self.frozen=True;raise ProtocolRefusal('write deadline; no replay')
            if not ok:self.frozen=True;raise ProtocolRefusal(error)
        finally:self._write_lock.release()

class Channel:
    def __init__(self,pipe,key,binding,send_direction,receive_direction):
        self.pipe,self.key,self.binding=pipe,key,validate_binding(binding)
        if send_direction==receive_direction:raise ProtocolRefusal('direction collision')
        self.send_direction,self.receive_direction=send_direction,receive_direction
        self.sent=0;self.received=0;self.frozen=False
    def send(self,kind,payload,deadline):
        if self.frozen:raise ProtocolRefusal('channel frozen')
        self.sent+=1
        body=dict(binding=self.binding,direction=self.send_direction,sequence=self.sent,kind=kind,payload=payload)
        try:self.pipe.write(dict(body,mac=mac(self.key,body)),deadline)
        except BaseException:self.frozen=True;raise
    def receive(self,deadline):
        if self.frozen:raise ProtocolRefusal('channel frozen')
        try:
            frame=self.pipe.read(deadline)
            if not isinstance(frame,dict) or set(frame)!={'binding','direction','sequence','kind','payload','mac'}:raise ProtocolRefusal('frame shape')
            body={k:v for k,v in frame.items() if k!='mac'}
            if type(frame['sequence']) is not int or frame['sequence']!=self.received+1 or frame['binding']!=self.binding or frame['direction']!=self.receive_direction:raise ProtocolRefusal('frame binding/sequence/direction')
            if not isinstance(frame['kind'],str) or not 0<len(frame['kind'])<=80 or not isinstance(frame['payload'],dict):raise ProtocolRefusal('frame content')
            if not isinstance(frame['mac'],str) or not hmac.compare_digest(frame['mac'],mac(self.key,body)):raise ProtocolRefusal('frame authentication')
            self.received+=1;return frame
        except BaseException:self.frozen=True;raise
