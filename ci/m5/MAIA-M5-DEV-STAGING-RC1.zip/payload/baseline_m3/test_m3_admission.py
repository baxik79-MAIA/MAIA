import unittest,tempfile,json,hashlib,os
from pathlib import Path
from m3_admission import *
class AdmissionTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.binding={'cycle':'a'*32,'source':source_pin(),'inputs':'0'*64};self.make()
 def tearDown(self):self.tmp.cleanup()
 def make(self):
  blobs={'prompt.txt':b'bounded disposable effect','state.before.json':b'{"status":"PIPELINE_COMPLETE"}','queue.before.json':b'{"items":[]}','final.before.txt':b'FIXTURE_APPROVED\n','worktree-pin.json':b'{"fixture":"disposable"}'}
  blobs['manifest.json']=json.dumps({'cycle':self.binding['cycle'],'idempotency_policy':'never_replay','prompt_sha256':sha(blobs['prompt.txt']),'worktree_sha256':sha(blobs['worktree-pin.json']),'prior_verdict':'FIXTURE_APPROVED'}).encode()
  for n,b in blobs.items():(self.root/n).write_bytes(b)
  self.expected={n:sha(b) for n,b in blobs.items()};self.binding['inputs']=input_digest(self.expected)
 def test_fresh_exact_bytes_is_fixture_only(self):
  with admit(self.root,self.binding,self.expected) as a:self.assertFalse(a.check['ready']);self.assertTrue(a.check['fixture_admissible']);self.assertEqual(a.buffers['queue.before.json'],b'{"items":[]}')
 def test_residues_file_directory_and_dangling_all_refuse(self):
  for n in RESIDUES:
   p=self.root/n;p.mkdir();self.assertFalse(check(self.root,self.binding,self.expected)['fixture_admissible']);p.rmdir();p.write_bytes(b'x');self.assertFalse(check(self.root,self.binding,self.expected)['fixture_admissible']);p.unlink()
  if os.name!='nt':
   p=self.root/'protocol.json';p.symlink_to(self.root/'absent');self.assertFalse(check(self.root,self.binding,self.expected)['fixture_admissible']);p.unlink()
 def test_hash_drift_refuses_without_repin(self):
  (self.root/'prompt.txt').write_bytes(b'changed');self.assertFalse(check(self.root,self.binding,self.expected)['fixture_admissible'])
 def test_repin_cannot_admit_transitioned_state(self):
  p=self.root/'state.before.json';p.write_bytes(b'{"status":"IDLE"}');self.expected[p.name]=sha(p.read_bytes());self.binding['inputs']=input_digest(self.expected);self.assertFalse(check(self.root,self.binding,self.expected)['fixture_admissible'])
 def test_duplicate_keys_refused_despite_matching_hash(self):
  p=self.root/'queue.before.json';p.write_bytes(b'{"items":[],"items":[]}');self.expected[p.name]=sha(p.read_bytes());self.binding['inputs']=input_digest(self.expected);self.assertFalse(check(self.root,self.binding,self.expected)['fixture_admissible'])
 def test_source_input_cycle_bindings_are_not_inferred(self):
  for key in ['cycle','inputs','source']:
   b=dict(self.binding);b[key]='c'*len(b[key]);self.assertFalse(check(self.root,b,self.expected)['fixture_admissible'])
 def test_mandatory_input_directory_refused(self):
  p=self.root/'prompt.txt';p.unlink();p.mkdir();self.assertFalse(check(self.root,self.binding,self.expected)['fixture_admissible'])
 def test_input_link_and_parent_link_refused(self):
  if os.name=='nt':return
  p=self.root/'prompt.txt';q=self.root/'other';q.write_bytes(p.read_bytes());p.unlink();p.symlink_to(q);self.assertFalse(check(self.root,self.binding,self.expected)['fixture_admissible'])
if __name__=='__main__':unittest.main()
