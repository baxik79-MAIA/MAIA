"""One-cycle transaction journal for the disposable M3 native adapter.

This module confers no execution authority and does not verify receipt HMACs:
that belongs to the trusted receiver/key adapter. Recovery is SQL read-only
(mode=ro, query_only); SQLite may maintain volatile shared-memory lock metadata.
No power-loss, hostile same-user, or production Begin/Apply claim is made.
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
from pathlib import Path
import re
import sqlite3
import stat
from typing import Any


class Refusal(RuntimeError):
    pass


MAX_IMAGE = 256 * 1024
MAX_PAYLOAD = 1024 * 1024
MAX_DATABASE = 16 * 1024 * 1024
APP_ID = 0x4D33424A
PHASES = ('PREPARED', 'QUEUED', 'START_INTENT', 'STARTED', 'COMPLETED')
HEX64 = re.compile(r'[0-9a-f]{64}\Z')


def sha(data: bytes) -> str:
    if type(data) is not bytes:
        raise Refusal('BYTE_BUFFER_REQUIRED')
    return hashlib.sha256(data).hexdigest()


def _tree(value: Any, depth: int = 0) -> None:
    if depth > 24:
        raise Refusal('JSON_DEPTH')
    if value is None or type(value) is bool:
        return
    if type(value) is int:
        if not -(1 << 63) <= value < (1 << 64):
            raise Refusal('JSON_INTEGER_BOUND')
        return
    if type(value) is str:
        if len(value) > MAX_PAYLOAD:
            raise Refusal('JSON_STRING_BOUND')
        return
    if type(value) is list:
        if len(value) > 4096:
            raise Refusal('JSON_LIST_BOUND')
        for item in value:
            _tree(item, depth + 1)
        return
    if type(value) is dict:
        if len(value) > 256 or any(type(k) is not str or len(k) > 128 for k in value):
            raise Refusal('JSON_OBJECT_BOUND')
        for item in value.values():
            _tree(item, depth + 1)
        return
    raise Refusal('JSON_TYPE')


def canonical(value: Any) -> bytes:
    _tree(value)
    try:
        data = json.dumps(value, sort_keys=True, ensure_ascii=True,
                          separators=(',', ':'), allow_nan=False).encode('ascii')
    except (ValueError, TypeError, UnicodeError) as exc:
        raise Refusal('JSON_ENCODING') from exc
    if len(data) > MAX_PAYLOAD:
        raise Refusal('JSON_BYTE_BOUND')
    return data


def _pairs(items):
    out = {}
    for key, value in items:
        if key in out:
            raise Refusal('DUPLICATE_JSON_KEY')
        out[key] = value
    return out


def _reject_constant(value):
    raise Refusal('JSON_NONFINITE')


def _json(data: bytes, limit: int = MAX_PAYLOAD):
    if type(data) is not bytes or len(data) > limit:
        raise Refusal('JSON_BYTE_BOUND')
    try:
        value = json.loads(data.decode('utf-8'), object_pairs_hook=_pairs,
                           parse_constant=_reject_constant)
    except (ValueError, UnicodeError, RecursionError) as exc:
        raise Refusal('JSON_PARSE') from exc
    _tree(value)
    return value


def validate_binding(binding: dict) -> dict:
    if type(binding) is not dict or set(binding) != {'cycle', 'source', 'inputs'}:
        raise Refusal('BINDING_KEYS')
    if type(binding['cycle']) is not str or not re.fullmatch('[0-9a-f]{32}', binding['cycle']):
        raise Refusal('CYCLE_BINDING')
    if any(type(binding[k]) is not str or not HEX64.fullmatch(binding[k]) for k in ('source', 'inputs')):
        raise Refusal('DIGEST_BINDING')
    return dict(binding)


def _images(state: bytes, queue: bytes, binding: dict, phase: str) -> dict:
    # Hash and parse the exact same caller buffers; never reopen a path here.
    state_hash, queue_hash = sha(state), sha(queue)
    s, q = _json(state, MAX_IMAGE), _json(queue, MAX_IMAGE)
    if type(s) is not dict or type(q) is not dict or type(q.get('items')) is not list:
        raise Refusal('IMAGE_SHAPE')
    if phase == 'PREPARED':
        if s.get('status') != 'PIPELINE_COMPLETE' or q['items'] != []:
            raise Refusal('PREIMAGE_NOT_FRESH')
    elif phase == 'QUEUED':
        if s.get('status') != 'QUEUED' or s.get('cycle') != binding['cycle'] or q['items'] != [binding['cycle']]:
            raise Refusal('POSTIMAGE_BINDING')
    else:
        raise Refusal('IMAGE_PHASE')
    return {'state': {'raw_b64': base64.b64encode(state).decode('ascii'), 'sha256': state_hash},
            'queue': {'raw_b64': base64.b64encode(queue).decode('ascii'), 'sha256': queue_hash}}


def _receipt(receipt: dict, binding: dict, phase: str) -> dict:
    if type(receipt) is not dict or receipt.get('binding') != binding or receipt.get('kind') != phase:
        raise Refusal('RECEIPT_BINDING')
    identity = receipt.get('identity')
    if type(identity) is not dict or set(identity) != {'pid', 'birth'}:
        raise Refusal('RECEIPT_IDENTITY')
    if any(type(identity[k]) is not int or identity[k] <= 0 for k in identity):
        raise Refusal('RECEIPT_IDENTITY')
    if type(receipt.get('mac')) is not str or not HEX64.fullmatch(receipt['mac']):
        raise Refusal('RECEIPT_MAC_SHAPE')
    return _json(canonical(receipt))


# All schema objects are compared exactly on every reopen and transaction.
SCHEMA = (
    'CREATE TABLE binding (singleton INTEGER PRIMARY KEY CHECK(singleton=1), cycle TEXT NOT NULL, source TEXT NOT NULL, inputs TEXT NOT NULL)',
    'CREATE TABLE records (ordinal INTEGER PRIMARY KEY CHECK(ordinal BETWEEN 1 AND 5), phase TEXT NOT NULL UNIQUE, payload BLOB NOT NULL, previous_sha TEXT NOT NULL, record_sha TEXT NOT NULL UNIQUE)',
    'CREATE TABLE queue (singleton INTEGER PRIMARY KEY CHECK(singleton=1), cycle TEXT NOT NULL)',
    'CREATE TABLE receiver (singleton INTEGER PRIMARY KEY CHECK(singleton=1), session TEXT NOT NULL, cycle TEXT NOT NULL, source TEXT NOT NULL, inputs TEXT NOT NULL)',
    "CREATE TRIGGER receiver_no_update BEFORE UPDATE ON receiver BEGIN SELECT RAISE(ABORT,'immutable receiver'); END",
    "CREATE TRIGGER receiver_no_delete BEFORE DELETE ON receiver BEGIN SELECT RAISE(ABORT,'immutable receiver'); END",
    "CREATE TRIGGER receiver_insert_guard BEFORE INSERT ON receiver WHEN EXISTS(SELECT 1 FROM receiver) OR (SELECT phase FROM records ORDER BY ordinal DESC LIMIT 1) IS NOT 'PREPARED' BEGIN SELECT RAISE(ABORT,'receiver already claimed'); END",
    "CREATE TRIGGER binding_no_update BEFORE UPDATE ON binding BEGIN SELECT RAISE(ABORT,'immutable binding'); END",
    "CREATE TRIGGER binding_no_delete BEFORE DELETE ON binding BEGIN SELECT RAISE(ABORT,'immutable binding'); END",
    "CREATE TRIGGER binding_no_reinsert BEFORE INSERT ON binding WHEN EXISTS(SELECT 1 FROM binding) BEGIN SELECT RAISE(ABORT,'immutable binding'); END",
    "CREATE TRIGGER records_no_update BEFORE UPDATE ON records BEGIN SELECT RAISE(ABORT,'append only'); END",
    "CREATE TRIGGER records_no_delete BEFORE DELETE ON records BEGIN SELECT RAISE(ABORT,'append only'); END",
    "CREATE TRIGGER records_order BEFORE INSERT ON records WHEN NEW.ordinal != COALESCE((SELECT MAX(ordinal)+1 FROM records),1) OR NEW.phase != CASE NEW.ordinal WHEN 1 THEN 'PREPARED' WHEN 2 THEN 'QUEUED' WHEN 3 THEN 'START_INTENT' WHEN 4 THEN 'STARTED' WHEN 5 THEN 'COMPLETED' END OR NEW.previous_sha != COALESCE((SELECT record_sha FROM records ORDER BY ordinal DESC LIMIT 1),'') BEGIN SELECT RAISE(ABORT,'record order'); END",
    "CREATE TRIGGER queue_no_update BEFORE UPDATE ON queue BEGIN SELECT RAISE(ABORT,'immutable queue'); END",
    "CREATE TRIGGER queue_insert_guard BEFORE INSERT ON queue WHEN (SELECT phase FROM records ORDER BY ordinal DESC LIMIT 1) IS NOT 'QUEUED' OR NEW.cycle != (SELECT cycle FROM binding WHERE singleton=1) BEGIN SELECT RAISE(ABORT,'queue phase'); END",
    "CREATE TRIGGER queue_delete_guard BEFORE DELETE ON queue WHEN (SELECT phase FROM records ORDER BY ordinal DESC LIMIT 1) IS NOT 'START_INTENT' BEGIN SELECT RAISE(ABORT,'dequeue phase'); END",
)


def _master(conn):
    return conn.execute("SELECT type,name,tbl_name,sql FROM sqlite_master WHERE name NOT LIKE 'sqlite_%' ORDER BY type,name").fetchall()


def _expected_master():
    conn = sqlite3.connect(':memory:')
    try:
        for sql in SCHEMA:
            conn.execute(sql)
        return _master(conn)
    finally:
        conn.close()


EXPECTED_MASTER = _expected_master()


def _regular(path: Path):
    try:
        info = path.lstat()
    except OSError as exc:
        raise Refusal('DATABASE_MISSING_OR_INACCESSIBLE') from exc
    if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or getattr(info, 'st_file_attributes', 0) & 0x400:
        raise Refusal('DATABASE_NOT_ORDINARY')
    if info.st_size > MAX_DATABASE:
        raise Refusal('DATABASE_SIZE')
    return info


def _connect(path: Path, readonly: bool):
    _regular(path)
    uri = path.absolute().as_uri() + ('?mode=ro' if readonly else '?mode=rw')
    conn = None
    try:
        conn = sqlite3.connect(uri, uri=True, timeout=0.5, isolation_level=None)
        conn.execute('PRAGMA trusted_schema=OFF')
        conn.execute('PRAGMA busy_timeout=500')
        conn.execute('PRAGMA foreign_keys=ON')
        if readonly:
            conn.execute('PRAGMA query_only=ON')
        else:
            conn.execute('PRAGMA synchronous=FULL')
        return conn
    except sqlite3.Error as exc:
        if conn is not None:
            conn.close()
        raise Refusal('DATABASE_OPEN') from exc


class Store:
    """An error on a mutating call permanently poisons this instance.

    The caller must discard any launch capability after an error. Opening a
    fresh store for diagnostics does not authorize retry of an effect.
    """

    def __init__(self, path: Path, binding: dict, connection, readonly: bool):
        self.path = path
        self.binding = validate_binding(binding)
        self._conn = connection
        self.readonly = readonly
        self.hook = None
        self._poisoned = False
        self._closed = False
        self._claimed_session = None

    @classmethod
    def create(cls, path, binding: dict, before_state: bytes, before_queue: bytes):
        """Initialize a fresh database in the native caller's owned fixture.

        O_EXCL establishes a fresh directory entry, not an identity pin after
        the descriptor is closed: sqlite3 cannot adopt that descriptor and
        reopens the pathname. The native prepare caller MUST hold validated
        root/ancestor pins and use a fresh, exclusively owned disposable fixture.
        Those pins prevent ancestor redirection, not replacement of a child
        entry by a hostile same-user filesystem actor. Such hostile child-entry
        replacement is outside this fixture's declared trust boundary.
        """
        binding = validate_binding(binding)
        images = _images(before_state, before_queue, binding, 'PREPARED')
        path = Path(path)
        # Exclusive creation deliberately leaves residue on any later failure.
        # Parent pins do not preserve this child file's identity across reopen.
        try:
            fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_RDWR | getattr(os, 'O_BINARY', 0), 0o600)
        except OSError as exc:
            raise Refusal('DATABASE_CREATE_RESIDUE_OR_ACCESS') from exc
        os.close(fd)
        conn = None
        try:
            conn = _connect(path, False)
            if conn.execute('PRAGMA journal_mode=WAL').fetchone() != ('wal',):
                raise Refusal('WAL_UNAVAILABLE')
            conn.execute('BEGIN IMMEDIATE')
            for sql in SCHEMA:
                conn.execute(sql)
            conn.execute(f'PRAGMA application_id={APP_ID}')
            conn.execute('PRAGMA user_version=1')
            conn.execute('INSERT INTO binding VALUES(1,?,?,?)', (binding['cycle'], binding['source'], binding['inputs']))
            store = cls(path, binding, conn, False)
            store._insert('PREPARED', {'binding': binding, 'images': images}, '', 1)
            store._validate()
            conn.execute('COMMIT')
            return store
        except BaseException:
            if conn is not None:
                conn.close()
            raise

    @classmethod
    def open_existing(cls, path, binding: dict, readonly=False):
        binding = validate_binding(binding)
        if type(readonly) is not bool:
            raise Refusal('READONLY_TYPE')
        path = Path(path)
        conn = _connect(path, readonly)
        store = cls(path, binding, conn, readonly)
        try:
            store.inspect()
            return store
        except BaseException:
            conn.close()
            store._closed = True
            raise

    def _usable(self, write=False):
        if self._closed:
            raise Refusal('STORE_CLOSED')
        if self._poisoned:
            raise Refusal('STORE_UNCERTAIN_NO_REPLAY')
        if write and self.readonly:
            raise Refusal('READONLY_STORE')
        if write and self._claimed_session is None:
            raise Refusal('LIVE_RECEIVER_CLAIM_REQUIRED')

    def _insert(self, phase, payload, previous, ordinal):
        raw = canonical(payload)
        digest = sha(canonical({'ordinal': ordinal, 'phase': phase, 'payload': payload, 'previous_sha': previous}))
        self._conn.execute('INSERT INTO records VALUES(?,?,?,?,?)', (ordinal, phase, raw, previous, digest))

    def _validate(self):
        conn = self._conn
        if _master(conn) != EXPECTED_MASTER:
            raise Refusal('DATABASE_SCHEMA_CHANGED')
        if conn.execute('PRAGMA application_id').fetchone() != (APP_ID,) or conn.execute('PRAGMA user_version').fetchone() != (1,):
            raise Refusal('DATABASE_IDENTITY')
        if conn.execute('PRAGMA journal_mode').fetchone() != ('wal',):
            raise Refusal('DATABASE_NOT_WAL')
        if conn.execute('PRAGMA quick_check(1)').fetchall() != [('ok',)]:
            raise Refusal('DATABASE_INTEGRITY')
        rows = conn.execute('SELECT singleton,cycle,source,inputs FROM binding').fetchall()
        if rows != [(1, self.binding['cycle'], self.binding['source'], self.binding['inputs'])]:
            raise Refusal('DATABASE_BINDING')
        rows = conn.execute('SELECT ordinal,phase,payload,previous_sha,record_sha FROM records ORDER BY ordinal').fetchall()
        if not 1 <= len(rows) <= len(PHASES):
            raise Refusal('RECORD_COUNT')
        records = []
        previous = ''
        identity = None
        for index, (ordinal, phase, raw, prev, digest) in enumerate(rows, 1):
            if type(ordinal) is not int or ordinal != index or phase != PHASES[index - 1] or type(raw) is not bytes or prev != previous:
                raise Refusal('RECORD_ORDER_OR_TYPE')
            payload = _json(raw)
            if canonical(payload) != raw or type(payload) is not dict or payload.get('binding') != self.binding:
                raise Refusal('RECORD_PAYLOAD')
            if phase in ('PREPARED', 'QUEUED'):
                if set(payload) != {'binding', 'images'} or type(payload['images']) is not dict or set(payload['images']) != {'state', 'queue'}:
                    raise Refusal('IMAGE_RECORD')
                buffers = {}
                for name, image in payload['images'].items():
                    if type(image) is not dict or set(image) != {'raw_b64', 'sha256'} or type(image['raw_b64']) is not str:
                        raise Refusal('IMAGE_RECORD')
                    try:
                        buffers[name] = base64.b64decode(image['raw_b64'], validate=True)
                    except (ValueError, TypeError) as exc:
                        raise Refusal('IMAGE_ENCODING') from exc
                    if base64.b64encode(buffers[name]).decode('ascii') != image['raw_b64'] or sha(buffers[name]) != image['sha256']:
                        raise Refusal('IMAGE_HASH')
                if _images(buffers['state'], buffers['queue'], self.binding, phase) != payload['images']:
                    raise Refusal('IMAGE_CONTENT')
            elif phase == 'START_INTENT':
                if payload != {'binding': self.binding, 'dequeued': self.binding['cycle']}:
                    raise Refusal('INTENT_RECORD')
            else:
                if set(payload) != {'binding', 'receipt'}:
                    raise Refusal('RECEIPT_RECORD')
                receipt = _receipt(payload['receipt'], self.binding, phase)
                if phase == 'STARTED':
                    identity = receipt['identity']
                elif receipt['identity'] != identity:
                    raise Refusal('COMPLETION_IDENTITY_CHANGED')
            if type(digest) is not str or not HEX64.fullmatch(digest) or digest != sha(canonical({'ordinal': ordinal, 'phase': phase, 'payload': payload, 'previous_sha': prev})):
                raise Refusal('RECORD_HASH_CHAIN')
            records.append({'ordinal': ordinal, 'phase': phase, 'payload': payload,
                            'previous_sha': prev, 'record_sha': digest})
            previous = digest
        phase = records[-1]['phase']
        queue = conn.execute('SELECT singleton,cycle FROM queue').fetchall()
        expected_queue = [(1, self.binding['cycle'])] if phase == 'QUEUED' else []
        if queue != expected_queue:
            raise Refusal('QUEUE_POSTIMAGE')
        receiver_rows = conn.execute('SELECT singleton,session,cycle,source,inputs FROM receiver').fetchall()
        receiver = None
        if receiver_rows:
            if len(receiver_rows) != 1:
                raise Refusal('RECEIVER_ROW_COUNT')
            singleton, session, cycle, source, inputs = receiver_rows[0]
            if singleton != 1 or type(session) is not str or not re.fullmatch('[0-9a-f]{32}', session) or (cycle, source, inputs) != (self.binding['cycle'], self.binding['source'], self.binding['inputs']):
                raise Refusal('RECEIVER_BINDING')
            receiver = {'session': session, 'binding': dict(self.binding)}
        elif phase != 'PREPARED':
            raise Refusal('RECEIVER_MISSING')
        return {'binding': dict(self.binding), 'phase': phase, 'receiver': receiver,
                'queue': [x[1] for x in queue], 'records': records}

    def inspect(self):
        self._usable()
        try:
            self._conn.execute('BEGIN')
            result = self._validate()
            self._conn.execute('COMMIT')
            return result
        except BaseException as exc:
            if self._conn.in_transaction:
                self._conn.execute('ROLLBACK')
            if isinstance(exc, sqlite3.Error):
                raise Refusal('DATABASE_READ') from exc
            raise

    def claim_receiver(self, session):
        """Persist a once-only receiver fence, then grant this live instance.

        Reopening the database never restores this process-local capability.
        A committed fence without an acknowledgement permanently refuses a new
        receiver, even if the journal still says PREPARED or QUEUED.
        """
        self._usable()
        if self.readonly:
            raise Refusal('READONLY_STORE')
        if type(session) is not str or not re.fullmatch('[0-9a-f]{32}', session):
            raise Refusal('RECEIVER_SESSION')
        try:
            self._conn.execute('BEGIN IMMEDIATE')
            current = self._validate()
            if self._claimed_session is not None or current['phase'] != 'PREPARED' or current['receiver'] is not None:
                raise Refusal('RECEIVER_CLAIM_REFUSED_NO_REPLAY')
            self._conn.execute('INSERT INTO receiver VALUES(1,?,?,?,?)',
                               (session, self.binding['cycle'], self.binding['source'], self.binding['inputs']))
            self._validate()
            if self.hook:
                self.hook('before_commit:RECEIVER_CLAIM')
            self._conn.execute('COMMIT')
            if self.hook:
                self.hook('after_commit:RECEIVER_CLAIM')
            self._claimed_session = session
        except BaseException as exc:
            self._poisoned = True
            if self._conn.in_transaction:
                self._conn.execute('ROLLBACK')
            if isinstance(exc, sqlite3.Error):
                raise Refusal('RECEIVER_CLAIM_UNCERTAIN_NO_REPLAY') from exc
            raise

    def _append(self, phase, payload):
        self._usable(write=True)
        try:
            self._conn.execute('BEGIN IMMEDIATE')
            current = self._validate()
            if current['receiver'] is None or current['receiver']['session'] != self._claimed_session:
                raise Refusal('LIVE_RECEIVER_FENCE_DIFFERS')
            ordinal = PHASES.index(phase) + 1
            if len(current['records']) != ordinal - 1:
                raise Refusal('PHASE_CAS_REFUSED')
            previous = current['records'][-1]['record_sha']
            self._insert(phase, payload, previous, ordinal)
            if phase == 'QUEUED':
                self._conn.execute('INSERT INTO queue VALUES(1,?)', (self.binding['cycle'],))
            elif phase == 'START_INTENT':
                if self._conn.execute('DELETE FROM queue WHERE singleton=1 AND cycle=?', (self.binding['cycle'],)).rowcount != 1:
                    raise Refusal('DEQUEUE_CAS_REFUSED')
            self._validate()
            if self.hook:
                self.hook('before_commit:' + phase)
            self._conn.execute('COMMIT')
            if self.hook:
                self.hook('after_commit:' + phase)
        except BaseException as exc:
            # Even an exception after COMMIT permanently consumes this caller's
            # capability. Never label it rolled back or attempt the effect again.
            self._poisoned = True
            if self._conn.in_transaction:
                self._conn.execute('ROLLBACK')
            if isinstance(exc, sqlite3.Error):
                raise Refusal('TRANSACTION_UNCERTAIN_NO_REPLAY') from exc
            raise

    def enqueue(self, after_state: bytes, after_queue: bytes):
        images = _images(after_state, after_queue, self.binding, 'QUEUED')
        self._append('QUEUED', {'binding': self.binding, 'images': images})

    def intent(self):
        self._append('START_INTENT', {'binding': self.binding, 'dequeued': self.binding['cycle']})

    def started(self, receipt: dict):
        receipt = _receipt(receipt, self.binding, 'STARTED')
        self._append('STARTED', {'binding': self.binding, 'receipt': receipt})

    def completed(self, receipt: dict):
        receipt = _receipt(receipt, self.binding, 'COMPLETED')
        self._append('COMPLETED', {'binding': self.binding, 'receipt': receipt})

    def close(self):
        if not self._closed:
            self._closed = True
            self._conn.close()


def recover(path, binding: dict):
    store = Store.open_existing(path, binding, readonly=True)
    try:
        result = store.inspect()
        return {**result, 'ready': False, 'replay_permitted': False,
                'start_capability': False, 'receipt_authentication': 'REQUIRES_TRUSTED_KEY_ADAPTER',
                'scope': 'READ_ONLY_TRANSACTION_DIAGNOSIS_NOT_EXECUTION_AUTHORITY'}
    finally:
        store.close()
