"""One finite native M3 disposable fixture matrix. Never replay an ATTEMPT."""
from __future__ import annotations
import argparse
import concurrent.futures
import json
import os
from pathlib import Path
import secrets
import subprocess
import sys
import time

from m3_store import Store,canonical,sha,validate_binding
from m3_protocol import FramedPipe,Channel,ProtocolRefusal,sign_receipt,verify_receipt
from m3_execution import (source_map,source_pin,write_fixture_inputs,prepare,
                          authenticated_recovery,authority_image,live_status,_fixed_child_args)

ROWS=(
 ('normal',None,'COMPLETED',1,1),
 ('receiver_committed','after_commit:RECEIVER_CLAIM','PREPARED',0,0),
 ('queue_before_commit','before_commit:QUEUED','PREPARED',0,0),
 ('queue_committed','after_commit:QUEUED','QUEUED',0,0),
 ('db_lock_released','queue_lock_released','QUEUED',0,0),
 ('start_request_uncertain','request_received','QUEUED',0,0),
 ('intent_committed','after_commit:START_INTENT','START_INTENT',0,0),
 ('create_before_started','worker_created','START_INTENT',0,1),
 ('started_before_release','after_commit:STARTED','STARTED',0,1),
 ('worker_before_effect','worker_before_effect','STARTED',0,1),
 ('worker_after_effect','worker_after_effect','STARTED',1,1),
 ('completed_before_reply','after_commit:COMPLETED','COMPLETED',1,1),
 ('concurrent_intents',None,'COMPLETED',1,1),
)


def _until_job_empty(job,deadline):
    while job.active_processes():
        if time.monotonic()>=deadline:raise ProtocolRefusal('owned job did not settle')
        time.sleep(.01)

def _close_pipe(pipe):
    try:pipe.close()
    except (OSError,ValueError):pass

def _liveness_controls(root,binding,key,worker):
    store=Store.open_existing(root/'transaction.sqlite',binding,readonly=True)
    try:receipt=store.inspect()['records'][-1]['payload']['receipt']
    finally:store.close()
    now=int(time.monotonic()*1000);actual=live_status(receipt,key,binding,worker,now)
    cases=[]
    for label,field in [('wrong_pid','pid'),('wrong_birth','birth')]:
        body={k:v for k,v in receipt.items() if k!='mac'};body['identity']=dict(body['identity']);body['identity'][field]+=1
        bad=sign_receipt(key,body)
        try:live_status(bad,key,binding,worker,now)
        except ProtocolRefusal:cases.append(label)
        else:raise ProtocolRefusal('accepted '+label)
    body={k:v for k,v in receipt.items() if k!='mac'};body['observed_monotonic_ms']=now-10001
    try:live_status(sign_receipt(key,body),key,binding,worker,now)
    except ProtocolRefusal:cases.append('stale_receipt')
    else:raise ProtocolRefusal('accepted stale receipt')
    bad=dict(receipt,mac=('0' if receipt['mac'][0]!='0' else '1')+receipt['mac'][1:])
    try:live_status(bad,key,binding,worker,now)
    except ProtocolRefusal:cases.append('forged_mac')
    else:raise ProtocolRefusal('accepted forged MAC')
    return {'actual':actual,'negative_refusals':cases}


def _drive(root,binding,key,job,cut,session,enqueue,shared,inject_assignment_refusal=False):
    from m3_windows import NativeProcess,Refusal as NativeRefusal
    deadline=time.monotonic()+45
    stderr=(root/('broker-'+session+'.stderr')).open('xb')
    child=subprocess.Popen(_fixed_child_args('broker'),stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=stderr,bufsize=0,cwd=root,close_fds=True)
    try:native=NativeProcess(child)
    except BaseException:
        # Original retained Popen capability; never a PID reopen. No bootstrap sent.
        try:child.terminate();child.wait(timeout=5)
        finally:
            stderr.close();_close_pipe(child.stdin);_close_pipe(child.stdout)
            if child.returncode is not None:child._handle.Close()
        raise
    worker=None;events=[];completed=None;terminal=None;cut_seen=False;live=None
    shared.append(native)
    try:
        try:
            if inject_assignment_refusal:raise NativeRefusal('INJECTED_ASSIGNMENT_REFUSAL_BEFORE_NATIVE_CALL')
            job.assign(native)
        except NativeRefusal as assignment_error:
            if job.api.frozen or native.api.frozen:raise
            native.terminate()
            code=native.wait(5)
            if code is None:raise ProtocolRefusal('unassigned owned broker did not settle')
            native.close()
            return dict(terminal='ASSIGNMENT_REFUSED',reason=str(assignment_error),assignment_injected=inject_assignment_refusal,
                        assignment_native_call_entered=any(x['name']=='AssignProcessToJobObject' for x in job.calls),
                        bootstrap_entries=0,launch_entries=0,created_workers=0,effect_count=0,events=[],
                        broker_identity=native._identity,broker_exit=code,broker_native_calls=list(native.calls),
                        worker_identity=None,worker_exit=None,worker_native_calls=[],retained_handles_closed=True)
        transport=FramedPipe(child.stdout,child.stdin)
        transport.write(dict(binding=binding,key=key.hex(),root=str(root),source=binding['source'],enqueue=enqueue,session=session),deadline)
        channel=Channel(transport,key,binding,'harness:'+session,'broker:'+session)
        while True:
            frame=channel.receive(deadline);kind=frame['kind'];payload=frame['payload']
            if kind=='BARRIER':
                stage=payload.get('stage');events.append(dict(kind=kind,payload=payload))
                if stage=='worker_created':
                    if worker is not None:raise ProtocolRefusal('second worker creation')
                    worker=NativeProcess.from_remote(native,payload['remote_handle'],payload['identity']);shared.append(worker)
                    if worker.identity()!=payload['identity']:raise ProtocolRefusal('independent worker identity')
                if stage=='after_commit:STARTED':
                    if worker is None:raise ProtocolRefusal('STARTED without retained worker')
                    live=_liveness_controls(root,binding,key,worker)
                if stage==cut:
                    cut_seen=True;job.terminate();terminal='INJECTED_PROCESS_CRASH';break
                channel.send('RELEASE',{'stage':stage},deadline)
            elif kind=='READY':
                events.append(dict(kind=kind,payload=payload));channel.send('START',{},deadline)
            elif kind=='COMPLETED':
                verify_receipt(key,payload['receipt'],binding,'COMPLETED')
                if worker is None or payload['receipt']['identity']!=worker.identity() or payload.get('worker_handle_closed') is not True:raise ProtocolRefusal('completion retained identity/close')
                completed=payload;terminal='COMPLETED';break
            elif kind=='REFUSED':terminal='REFUSED';events.append(dict(kind=kind,payload=payload));break
            else:raise ProtocolRefusal('unexpected broker frame '+kind)
        if cut and not cut_seen:raise ProtocolRefusal('intended crash barrier not reached')
        broker_code=native.wait(max(0,min(5,deadline-time.monotonic())))
        if broker_code is None:raise ProtocolRefusal('broker not signaled')
        if not cut and broker_code!=(0 if terminal=='COMPLETED' else 2):raise ProtocolRefusal('broker code differs')
        worker_code=worker.wait(5) if worker else None
        if worker and worker_code is None:raise ProtocolRefusal('worker not signaled')
        if completed and worker_code!=0:raise ProtocolRefusal('completed worker exit differs')
        native_calls=list(native.calls)
        worker_calls=list(worker.calls) if worker else []
        if worker:worker.close();worker_calls=list(worker.calls)
        native.close();native_calls=list(native.calls)
        return dict(terminal=terminal,cut=cut,cut_reached=cut_seen,events=events,completion=completed,
                    launch_entries=sum(e['kind']=='BARRIER' and e['payload'].get('stage')=='launch_enter' for e in events),
                    created_workers=sum(e['kind']=='BARRIER' and e['payload'].get('stage')=='worker_created' for e in events),
                    broker_identity=native._identity,broker_exit=broker_code,broker_native_calls=native_calls,
                    worker_identity=worker._identity if worker else None,worker_exit=worker_code,worker_native_calls=worker_calls,
                    retained_handles_closed=True,liveness_controls=live)
    finally:
        stderr.close()
        # Parent batch owns job/retained handles and completes cleanup on error.
        if child.returncode is not None:
            _close_pipe(child.stdin);_close_pipe(child.stdout)


def run_row(base,label,cut,expected_phase,effect_count,created_count,pin):
    from m3_windows import OwnedJob
    root=Path(base)/label;binding,expected=write_fixture_inputs(root,dict(cycle=secrets.token_hex(16),source=pin,inputs='0'*64))
    key,admission=prepare(root,binding,expected);job=OwnedJob();owned=[];results=[];cleanup=[]
    started=time.monotonic();error=None;primary_job_calls=[]
    try:
        if label=='concurrent_intents':
            with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
                futures=[pool.submit(_drive,root,binding,key,job,None,secrets.token_hex(16),True,owned) for _ in range(2)]
                results=[f.result(timeout=50) for f in futures]
            if sorted(x['terminal'] for x in results)!=['COMPLETED','REFUSED']:raise ProtocolRefusal('concurrent broker winners differ')
        else:results=[_drive(root,binding,key,job,cut,secrets.token_hex(16),True,owned)]
        if any(r['terminal']=='ASSIGNMENT_REFUSED' for r in results):raise ProtocolRefusal('assignment refused before bootstrap; no cold same-cycle probe')
        _until_job_empty(job,time.monotonic()+3)
        job.close();primary_job_calls=list(job.calls);cleanup.append('PRIMARY_JOB_EMPTY_AND_CLOSED')
        job=OwnedJob()
        # Re-bootstrap with the valid fixture key after a lost or completed
        # receiver session MUST refuse the persisted claim before enqueue/start.
        restart=_drive(root,binding,key,job,None,secrets.token_hex(16),True,owned)
        if restart['terminal']!='REFUSED' or restart['launch_entries'] or restart['created_workers']:
            raise ProtocolRefusal('cold receiver replay was not refused before launch')
        reasons=[e['payload'].get('reason','') for e in restart['events'] if e['kind']=='REFUSED']
        if not reasons or not any('RECEIVER' in reason and 'REPLAY' in reason for reason in reasons):
            raise ProtocolRefusal('cold receiver refused for unrelated reason')
        restart['purpose']='COLD_REBOOTSTRAP_REPLAY_PROBE';results.append(restart)
        _until_job_empty(job,time.monotonic()+3)
        recovery=authenticated_recovery(root,binding)
        if recovery['phase']!=expected_phase or recovery['ready'] or recovery['replay_permitted']:raise ProtocolRefusal('recovery state differs')
        effect=root/'EFFECT.json';effect_present=int(effect.exists())
        if effect_present!=effect_count:raise ProtocolRefusal('effect presence differs')
        if effect_present:
            value=json.loads(effect.read_bytes());verify_receipt(key,value,binding,'EFFECT')
            identities=[r['worker_identity'] for r in results if r['worker_identity']]
            if value['identity'] not in identities:raise ProtocolRefusal('effect identity not actual child')
        launches=sum(x['launch_entries'] for x in results);creates=sum(x['created_workers'] for x in results)
        if launches!=created_count or creates!=created_count:raise ProtocolRefusal('independent launch/create counts differ')
        job.close();cleanup.append('RECOVERY_PROBE_JOB_EMPTY_AND_CLOSED')
        result=dict(row=label,qualified=True,binding=binding,admission=admission,expected_phase=expected_phase,
                    recovery=recovery,effect_count=effect_present,launch_entries=launches,created_workers=creates,
                    executions=results,primary_job_calls=primary_job_calls,recovery_probe_job_calls=job.calls,cleanup=cleanup,elapsed_seconds=time.monotonic()-started,
                    ready=False,replay_permitted=False,apply_permitted=False,power_loss_proven=False)
    except BaseException as exc:
        error=type(exc).__name__+':'+str(exc)
        try:
            if not job.closed and not job.api.frozen and job.active_processes():job.terminate();cleanup.append('OWNED_JOB_TERMINATED_ON_UNEXPECTED_ERROR')
            if job.api.frozen:cleanup.append('UNRESOLVED_JOB_BOUNDARY_FROZEN')
            for native in owned:
                if not native.closed:
                    if native.api.frozen:
                        cleanup.append('UNRESOLVED_PROCESS_BOUNDARY_FROZEN');continue
                    if native.wait(0) is None and native.child is not None:
                        native.terminate();cleanup.append('OWN_RETAINED_HANDLE_TERMINATED')
                    if native.wait(5) is None:raise ProtocolRefusal('retained process remained live')
                    native.close()
            if not job.closed and not job.api.frozen:_until_job_empty(job,time.monotonic()+3);job.close()
        except BaseException as clean:cleanup.append('UNRESOLVED:'+type(clean).__name__+':'+str(clean))
        result=dict(row=label,qualified=False,error=error,executions=results,cleanup=cleanup,job_calls=job.calls,
                    elapsed_seconds=time.monotonic()-started,replay_permitted=False,ready=False)
    (root/'RESULT.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    return result


def _authority_hashes(root):
    return authority_image(root)

def _require_quarantine(report):
    if report.get('phase')!='QUARANTINED' or any(report.get(k) is not False for k in ('ready','replay_permitted','start_capability','launch_capability')):
        raise ProtocolRefusal('recovery failure did not quarantine')
    if report.get('authority_unchanged') is not None or report.get('authority_hashes') is not None or report.get('receipts_authenticated')!=[]:
        raise ProtocolRefusal('quarantine inflated authority claim')

def run_failure_controls(base,pin):
    """Real native-fixture setup; injected read-open and assignment boundaries
    are explicitly labelled. Missing/corrupt journal failures are actual bytes.
    """
    import sqlite3
    from unittest import mock
    from m3_windows import OwnedJob
    from m3_admission import check
    base=Path(base);base.mkdir(exist_ok=False);results=[]
    for label in ('readonly_open_injected','missing_journal','corrupt_journal'):
        root=base/label;binding,expected=write_fixture_inputs(root,dict(cycle=secrets.token_hex(16),source=pin,inputs='0'*64))
        key,admission=prepare(root,binding,expected)
        if label=='missing_journal':(root/'transaction.sqlite').unlink()
        if label=='corrupt_journal':(root/'transaction.sqlite').write_bytes(b'M3 deliberately corrupt disposable journal\x00')
        before=_authority_hashes(root)
        if label=='readonly_open_injected':
            with mock.patch('m3_execution.recover',side_effect=sqlite3.OperationalError('SQLITE_READONLY_RECOVERY: injected exact read-only-open boundary')):
                report=authenticated_recovery(root,binding)
        else:report=authenticated_recovery(root,binding)
        _require_quarantine(report)
        after=_authority_hashes(root)
        if before!=after or label=='missing_journal' and (root/'transaction.sqlite').exists():raise ProtocolRefusal('failed recovery modified/recreated journal')
        result=dict(row=label,qualified=True,boundary_injected=label=='readonly_open_injected',actual_native_fixture=True,
                    authority_bytes_unchanged_by_harness_comparison=True,recovery=report,launch_entries=0,effect_count=0,admission=admission)
        (root/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');results.append(result)
    root=base/'assignment_refused';binding,expected=write_fixture_inputs(root,dict(cycle=secrets.token_hex(16),source=pin,inputs='0'*64))
    key,admission=prepare(root,binding,expected);job=OwnedJob();owned=[]
    try:
        execution=_drive(root,binding,key,job,None,secrets.token_hex(16),True,owned,inject_assignment_refusal=True)
        if execution['terminal']!='ASSIGNMENT_REFUSED' or execution['bootstrap_entries'] or execution['launch_entries'] or execution['created_workers'] or execution['assignment_native_call_entered']:
            raise ProtocolRefusal('assignment refusal did not stop before bootstrap')
        if (root/'EFFECT.json').exists():raise ProtocolRefusal('assignment refusal produced effect')
        _until_job_empty(job,time.monotonic()+3);job.close()
        store=Store.open_existing(root/'transaction.sqlite',binding,readonly=True)
        try:inspection=store.inspect()
        finally:store.close()
        if inspection['phase']!='PREPARED' or inspection.get('receiver') is not None:raise ProtocolRefusal('unbootstrapped broker touched journal')
        recheck=check(root,binding,expected)
        if recheck.get('fixture_admissible') or recheck.get('ready'):raise ProtocolRefusal('partial fixture readmitted after assignment refusal')
        result=dict(row='assignment_refused',qualified=True,boundary_injected=True,assignment_native_call_entered=False,
                    actual_broker_created=True,broker_terminated_by_own_retained_handle=True,execution=execution,
                    phase='PREPARED',receiver_claimed=False,cold_probe_performed=False,admission_recheck=recheck,
                    job_calls=list(job.calls),launch_entries=0,effect_count=0)
        (root/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');results.append(result)
    finally:
        for native in owned:
            if not native.closed and not native.api.frozen:
                if native.wait(0) is None:native.terminate()
                if native.wait(5) is None:raise ProtocolRefusal('assignment control broker unresolved')
                native.close()
        if not job.closed and not job.api.frozen:
            if job.active_processes():job.terminate()
            _until_job_empty(job,time.monotonic()+3);job.close()
    final=dict(all_qualified=len(results)==4 and all(r['qualified'] for r in results),rows=results,ready=False,replay_permitted=False)
    (base/'RESULT.json').write_text(json.dumps(final,indent=2)+'\n');return final

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--root',required=True);parser.add_argument('--source-sha',required=True);args=parser.parse_args()
    if os.name!='nt':raise ProtocolRefusal('native Windows matrix required')
    from m3_windows import FilePins,fixture_root
    base=fixture_root(args.root);pin=source_pin()
    if args.source_sha!=pin:raise ProtocolRefusal('trusted source digest differs')
    package=Path(__file__).parent;names=sorted(source_map())
    if base.exists():raise ProtocolRefusal('matrix stage already exists; no replay')
    base.mkdir(parents=True,exist_ok=False)
    with (base/'ATTEMPT.json').open('x') as f:json.dump(dict(source_sha256=pin,source_files=source_map(),rows=[dict(row=x[0],cut=x[1],expected_phase=x[2],effect=x[3],created=x[4]) for x in ROWS],failure_controls=['readonly_open_injected','missing_journal','corrupt_journal','assignment_refused_before_bootstrap'],no_replay=True,started_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())),f,indent=2)
    results=[];failure_controls=None;started=time.monotonic()
    with FilePins(package,names) as pins:
        if {k:v['sha256'] for k,v in pins.snapshots.items()}!=source_map():raise ProtocolRefusal('held source pin differs')
        failure_controls=run_failure_controls(base/'failure_controls',pin)
        if not failure_controls['all_qualified']:raise ProtocolRefusal('recovery/assignment controls failed')
        for row in ROWS:
            if time.monotonic()-started>500:raise ProtocolRefusal('batch deadline')
            result=run_row(base,*row,pin);results.append(result)
            print(json.dumps({k:result.get(k) for k in ('row','qualified','error','elapsed_seconds')}),flush=True)
            if not result['qualified']:break
    final=dict(status='MATRIX_ENDED',all_rows_qualified=len(results)==len(ROWS) and all(x['qualified'] for x in results),rows=results,source_sha256=pin,elapsed_seconds=time.monotonic()-started,
               failure_controls=failure_controls,process_crash_fixture_only=True,power_loss_proven=False,production_begin_ready=False,apply_permitted=False,replay_permitted=False)
    with (base/'RESULT.json').open('x') as f:json.dump(final,f,indent=2,allow_nan=False)
    print(json.dumps({k:v for k,v in final.items() if k!='rows'}));return 0 if final['all_rows_qualified'] else 2

if __name__=='__main__':
    try:raise SystemExit(main())
    except (ProtocolRefusal,OSError,RuntimeError) as exc:print(type(exc).__name__+':'+str(exc),file=sys.stderr);raise SystemExit(2)
