"""Exact-buffer admission for the isolated M3 adapter. No launch capability."""
from __future__ import annotations
import hashlib,json,os,re,stat
from pathlib import Path
from contextlib import AbstractContextManager

INPUTS=('manifest.json','prompt.txt','state.before.json','queue.before.json','final.before.txt','worktree-pin.json')
RESIDUES=('transaction.sqlite','transaction.sqlite-wal','transaction.sqlite-shm','protocol.json','preimage.json','EFFECT.json','owner.key')
MAX_BYTES=1024*1024
class Refusal(RuntimeError): pass

def sha(data):return hashlib.sha256(data).hexdigest()
def pairs(items):
 d={}
 for k,v in items:
  if k in d:raise Refusal('DUPLICATE_JSON_KEY')
  d[k]=v
 return d
def parse(data):
 try:return json.loads(data.decode('utf-8'),object_pairs_hook=pairs,parse_constant=lambda v:(_ for _ in ()).throw(Refusal('NONFINITE_JSON')))
 except (ValueError,UnicodeError,RecursionError) as e:raise Refusal('INPUT_JSON') from e

def binding_check(binding):
 if type(binding) is not dict or set(binding)!=set(('cycle','source','inputs')):raise Refusal('BINDING_KEYS')
 for k,n in [('cycle',32),('source',64),('inputs',64)]:
  if type(binding[k]) is not str or not re.fullmatch('[a-f0-9]{'+str(n)+'}',binding[k]):raise Refusal('BINDING_VALUE')

def input_digest(expected):
 if type(expected) is not dict or set(expected)!=set(INPUTS) or any(type(v) is not str or not re.fullmatch('[a-f0-9]{64}',v) for v in expected.values()):raise Refusal('INPUT_PIN_SET')
 return sha(json.dumps(expected,sort_keys=True,separators=(',',':'),ensure_ascii=True).encode())

def source_pin():
 from m3_store import canonical
 files={p.name:sha(p.read_bytes()) for p in sorted(Path(__file__).parent.glob('*.py'))}
 return sha(canonical(files))

def exists_entry(p):
 try:p.lstat();return True
 except FileNotFoundError:return False
 except OSError as e:raise Refusal('RESIDUE_UNREADABLE') from e

class _PortablePins(AbstractContextManager):
 """Unit-control fallback only; Windows acceptance uses held native FilePins."""
 def __init__(self,root,names):self.root=root;self.names=names;self.buffers={};self.snapshots={};self.handles=[]
 def __enter__(self):
  for parent in [self.root,*self.root.parents]:
   s=parent.lstat()
   if not stat.S_ISDIR(s.st_mode) or stat.S_ISLNK(s.st_mode):raise Refusal('PARENT_TYPE')
  try:
   for name in self.names:
    p=self.root/name;s=p.lstat()
    if not stat.S_ISREG(s.st_mode) or s.st_nlink!=1 or s.st_size>MAX_BYTES:raise Refusal('INPUT_TYPE_SIZE')
    fd=os.open(p,os.O_RDONLY|getattr(os,'O_NOFOLLOW',0));self.handles.append(fd);a=os.fstat(fd)
    chunks=[];left=MAX_BYTES+1
    while left:
     b=os.read(fd,min(65536,left))
     if not b:break
     chunks.append(b);left-=len(b)
    data=b''.join(chunks);z=os.fstat(fd)
    if len(data)>MAX_BYTES or (a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns)!=(z.st_dev,z.st_ino,z.st_size,z.st_mtime_ns) or a.st_ino!=s.st_ino:raise Refusal('INPUT_CHANGED')
    self.buffers[name]=data;self.snapshots[name]={'bytes':len(data),'sha256':sha(data),'identity':[a.st_dev,a.st_ino,a.st_size]}
   return self
  except BaseException:self.__exit__(None,None,None);raise
 def __exit__(self,*args):
  for fd in reversed(self.handles):os.close(fd)
  self.handles=[]

class Admission(AbstractContextManager):
 def __init__(self,root,binding,expected):
  self.root=Path(root).absolute();binding_check(binding);self.binding=dict(binding);self.expected=dict(expected);self.pins=None
  if input_digest(expected)!=binding['inputs']:raise Refusal('INPUT_DIGEST')
 def _no_residue(self):
  if any(exists_entry(self.root/n) for n in RESIDUES):raise Refusal('PROTOCOL_RESIDUE')
 def __enter__(self):
  if not self.root.is_dir():raise Refusal('ROOT_MISSING')
  if self.binding['source']!=source_pin():raise Refusal('SOURCE_PIN')
  self._no_residue()
  if os.name=='nt':
   from m3_windows import FilePins
   self.pins=FilePins(self.root,INPUTS)
  else:self.pins=_PortablePins(self.root,INPUTS)
  try:
   self.pins.__enter__();self.buffers=self.pins.buffers;self.snapshots=self.pins.snapshots
   if any(self.snapshots[n]['sha256']!=self.expected[n] for n in INPUTS):raise Refusal('INPUT_HASH')
   self._no_residue()
   m=parse(self.buffers['manifest.json']);state=parse(self.buffers['state.before.json']);queue=parse(self.buffers['queue.before.json']);worktree=parse(self.buffers['worktree-pin.json'])
   if type(m) is not dict or set(m)!=set(('cycle','idempotency_policy','prompt_sha256','worktree_sha256','prior_verdict')):raise Refusal('MANIFEST_KEYS')
   if m['cycle']!=self.binding['cycle'] or m['idempotency_policy']!='never_replay' or m['prompt_sha256']!=sha(self.buffers['prompt.txt']) or m['worktree_sha256']!=sha(self.buffers['worktree-pin.json']):raise Refusal('MANIFEST_BINDING')
   if type(state) is not dict or state!={'status':'PIPELINE_COMPLETE'} or queue!={'items':[]}:raise Refusal('PREIMAGE_TRANSITIONED')
   if type(worktree) is not dict or not worktree or m['prior_verdict']!='FIXTURE_APPROVED' or self.buffers['final.before.txt'].decode('utf-8').splitlines()[0]!=m['prior_verdict']:raise Refusal('PRIOR_VERDICT')
   if not self.buffers['prompt.txt'] or len(self.buffers['prompt.txt'])>65536:raise Refusal('PROMPT_SIZE')
   self.check={'ready':False,'fixture_admissible':True,'reason':'ISOLATED_TRANSACTION_FIXTURE_ONLY','production_image_gate':'SECTION_BINDING_UNPROVEN','replay_permitted':False,'binding':self.binding}
   return self
  except BaseException:
   if self.pins:self.pins.__exit__(None,None,None);self.pins=None
   raise
 def __exit__(self,*args):
  if self.pins:self.pins.__exit__(*args);self.pins=None

def admit(root,binding,expected):return Admission(root,binding,expected)

def check(root,binding,expected):
 try:
  with admit(root,binding,expected) as admission:return admission.check
 except (Refusal,OSError,RuntimeError,IndexError,UnicodeError) as e:return {'ready':False,'fixture_admissible':False,'replay_permitted':False,'reason':type(e).__name__+':'+str(e)}
