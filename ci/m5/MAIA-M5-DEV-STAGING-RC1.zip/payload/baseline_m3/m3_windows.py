"""Windows primitives for the disposable M3 adapter.

No exports bind on import; no PID-based reopen or global cleanup exists here.
The trust boundary excludes hostile same-user memory access and administrators.
Process-crash checks do not prove survival of hardware/power loss.
"""
from __future__ import annotations
import ctypes as C
import hashlib
import json
import math
import os
from pathlib import Path, PurePosixPath, PureWindowsPath
import secrets
import stat
import subprocess
import sys


class Refusal(RuntimeError):
    pass

U32=C.c_uint32; I32=C.c_int32; U64=C.c_uint64; SIZE=C.c_size_t
H=C.c_void_p; P=C.c_void_p; INVALID=(1 << (C.sizeof(H)*8))-1
READ=0x80000000; SHARE_READ=1; OPEN_EXISTING=3
DIRECTORY=0x10; REPARSE=0x400; LOCAL_DRIVE=3
MAX_FILE=1024*1024


class FILETIME(C.Structure):
    _fields_=[('low',U32),('high',U32)]


class FILE_INFO(C.Structure):
    _fields_=[('attributes',U32),('created',FILETIME),('accessed',FILETIME),
              ('written',FILETIME),('volume',U32),('size_high',U32),
              ('size_low',U32),('links',U32),('index_high',U32),('index_low',U32)]


class BASIC_LIMIT(C.Structure):
    _fields_=[('process_time',C.c_int64),('job_time',C.c_int64),('flags',U32),
              ('minimum',SIZE),('maximum',SIZE),('active_limit',U32),
              ('affinity',SIZE),('priority',U32),('scheduling',U32)]


class IO_COUNTERS(C.Structure):
    _fields_=[(n,U64) for n in ('read_ops','write_ops','other_ops','read_bytes','write_bytes','other_bytes')]


class EXTENDED_LIMIT(C.Structure):
    _fields_=[('basic',BASIC_LIMIT),('io',IO_COUNTERS),('process_memory',SIZE),
              ('job_memory',SIZE),('peak_process',SIZE),('peak_job',SIZE)]


class ACCOUNTING(C.Structure):
    _fields_=[('user',C.c_int64),('kernel',C.c_int64),('period_user',C.c_int64),
              ('period_kernel',C.c_int64),('faults',U32),('total',U32),
              ('active',U32),('terminated',U32)]


class DATA_BLOB(C.Structure):
    _fields_=[('size',U32),('data',P)]


def _canonical(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode('ascii')


def _binding(value):
    if type(value) is not dict or set(value)!={'cycle','source','inputs'}:
        raise Refusal('binding shape')
    for name,length in [('cycle',32),('source',64),('inputs',64)]:
        s=value[name]
        if type(s) is not str or len(s)!=length or any(c not in '0123456789abcdef' for c in s):
            raise Refusal('binding value')
    return dict(value)


def _timeout(value):
    if type(value) not in (int,float) or not math.isfinite(value) or not 0 <= value <= 60:
        raise Refusal('finite timeout must be 0..60 seconds')
    return max(0,math.ceil(value*1000))


def _relative(name):
    if type(name) is not str or not name or '\\' in name or ':' in name:
        raise Refusal('relative file name')
    p=PurePosixPath(name)
    if p.is_absolute() or any(x in ('','.','..') for x in name.split('/')):
        raise Refusal('relative file name')
    reserved={'CON','PRN','AUX','NUL'}|{x+str(i) for x in ('COM','LPT') for i in range(1,10)}
    if any(any(c in '<>\"|?*' or ord(c)<32 for c in segment) or segment.endswith((' ','.')) or segment.split('.')[0].upper() in reserved for segment in p.parts):
        raise Refusal('noncanonical Windows name')
    return p.parts


def _fixture_path(root):
    """Portable lexical admission, including Win32 trailing-dot/space aliases."""
    try:p=PureWindowsPath(root)
    except (TypeError,ValueError) as exc:raise Refusal('fixture path type') from exc
    if not p.is_absolute() or p.anchor.casefold()!='c:\\':
        raise Refusal('fixture absolute local path')
    # Check every component before conversion, opening, mkdir or any other
    # filesystem action. Win32 normalizes e.g. ".. " into a parent traversal.
    _relative('/'.join(p.parts[1:]))
    parts=tuple(x.casefold() for x in p.parts)
    prefixes=[('c:\\','maia',kind,'m3_begin_20261108') for kind in ('worktrees','reports')]
    if not any(parts[:4]==prefix and len(parts)>4 for prefix in prefixes):
        raise Refusal('outside disposable M3 fixture namespace')
    return p


def fixture_root(root):
    """Admit only descendants of the two named disposable M3 namespaces."""
    p=_fixture_path(root)
    if os.name!='nt':raise Refusal('Windows required')
    return Path(str(p))


def validate_runtime():
    """Verify the explicit runtime/handle contract before the first launch."""
    if os.name!='nt' or C.sizeof(P)!=8:
        raise Refusal('runtime requires 64-bit Windows')
    if sys.implementation.name!='cpython' or tuple(sys.version_info[:2])!=(3,13):
        raise Refusal('runtime requires CPython 3.13')
    handle=getattr(subprocess,'Handle',None)
    if handle is None or any(not callable(getattr(handle,name,None)) for name in ('Detach','Close')):
        raise Refusal('CPython Popen Handle Detach/Close contract unavailable')
    return {'implementation':'cpython','version':list(sys.version_info[:3]),
            'pointer_bits':64,'platform':'Windows','popen_handle_api':['Detach','Close'],
            'scope':'RUNTIME_API_CONTRACT_ONLY'}


class _Native:
    """One call journal; no secret buffers or cryptographic key bytes recorded."""
    def __init__(self):
        if os.name!='nt' or C.sizeof(P)!=8:
            raise Refusal('64-bit Windows required')
        self.calls=[];self.frozen=False
        self.k=C.WinDLL('kernel32',use_last_error=True)
        self.crypt=C.WinDLL('crypt32',use_last_error=True)
        signatures={
            'CreateFileW':([C.c_wchar_p,U32,U32,P,U32,U32,H],H),
            'GetFileInformationByHandle':([H,C.POINTER(FILE_INFO)],I32),
            'GetFileSizeEx':([H,C.POINTER(C.c_int64)],I32),
            'ReadFile':([H,P,U32,C.POINTER(U32),P],I32),
            'WriteFile':([H,P,U32,C.POINTER(U32),P],I32),
            'FlushFileBuffers':([H],I32),
            'GetFinalPathNameByHandleW':([H,P,U32,U32],U32),
            'GetVolumeInformationByHandleW':([H,P,U32,C.POINTER(U32),C.POINTER(U32),C.POINTER(U32),P,U32],I32),
            'GetDriveTypeW':([C.c_wchar_p],U32),
            'CloseHandle':([H],I32),
            'GetProcessId':([H],U32),
            'GetCurrentProcess':([],H),
            'DuplicateHandle':([H,H,H,C.POINTER(H),U32,I32,U32],I32),
            'GetProcessTimes':([H,C.POINTER(FILETIME),C.POINTER(FILETIME),C.POINTER(FILETIME),C.POINTER(FILETIME)],I32),
            'WaitForSingleObject':([H,U32],U32),
            'GetExitCodeProcess':([H,C.POINTER(U32)],I32),
            'TerminateProcess':([H,U32],I32),
            'CreateJobObjectW':([P,C.c_wchar_p],H),
            'SetInformationJobObject':([H,I32,P,U32],I32),
            'AssignProcessToJobObject':([H,H],I32),
            'QueryInformationJobObject':([H,I32,P,U32,C.POINTER(U32)],I32),
            'TerminateJobObject':([H,U32],I32),
            'LocalFree':([H],H),
        }
        for name,(args,ret) in signatures.items():
            fn=getattr(self.k,name);fn.argtypes=args;fn.restype=ret
        args=[C.POINTER(DATA_BLOB),C.c_wchar_p,C.POINTER(DATA_BLOB),P,P,U32,C.POINTER(DATA_BLOB)]
        self.crypt.CryptProtectData.argtypes=args;self.crypt.CryptProtectData.restype=I32
        args=[C.POINTER(DATA_BLOB),P,C.POINTER(DATA_BLOB),P,P,U32,C.POINTER(DATA_BLOB)]
        self.crypt.CryptUnprotectData.argtypes=args;self.crypt.CryptUnprotectData.restype=I32

    def call(self,name,*args,crypt=False):
        if self.frozen:raise Refusal('native boundary frozen after UNKNOWN')
        entry={'name':name,'state':'ENTERED'};self.calls.append(entry)
        C.set_last_error(0)
        try:
            raw=getattr(self.crypt if crypt else self.k,name)(*args)
        except BaseException:
            entry['state']='UNKNOWN';self.frozen=True;raise
        error=C.get_last_error();entry.update(state='RETURNED',raw=raw,error=error)
        return raw,error

    def true(self,name,*args,crypt=False):
        raw,error=self.call(name,*args,crypt=crypt)
        if raw==0:raise Refusal(name+':'+str(error))
        return raw

    def close(self,handle):
        self.true('CloseHandle',H(handle))


def _valid_handle(raw):
    return type(raw) is int and raw not in (0,-1,INVALID)


def _open(api,path,access=READ,share=SHARE_READ,disposition=OPEN_EXISTING,flags=0x200000):
    raw,error=api.call('CreateFileW',str(path),access,share,None,disposition,flags,None)
    if not _valid_handle(raw):raise Refusal('CreateFileW:'+str(error))
    return raw


def _information(api,handle):
    info=FILE_INFO();api.true('GetFileInformationByHandle',H(handle),C.byref(info))
    size=(int(info.size_high)<<32)|int(info.size_low)
    identity=[int(info.volume),(int(info.index_high)<<32)|int(info.index_low),size]
    stable=[int(info.attributes),int(info.links),int(info.created.low),int(info.created.high),int(info.written.low),int(info.written.high)]
    return info,identity,stable


def _path_by_handle(api,handle):
    b=C.create_unicode_buffer(32768)
    n,error=api.call('GetFinalPathNameByHandleW',H(handle),C.cast(b,P),len(b),0)
    if not 0<n<len(b):raise Refusal('GetFinalPathNameByHandleW:'+str(error))
    return b.value


def _ntfs(api,handle,anchor):
    if api.call('GetDriveTypeW',anchor)[0]!=LOCAL_DRIVE:raise Refusal('local fixed drive required')
    serial=U32();component=U32();flags=U32();fs=C.create_unicode_buffer(64)
    api.true('GetVolumeInformationByHandleW',H(handle),None,0,C.byref(serial),C.byref(component),C.byref(flags),C.cast(fs,P),len(fs))
    if fs.value!='NTFS':raise Refusal('NTFS required')


class FilePins:
    """Keep parents nondeletable and files read/share-read until context exit.

    `.buffers` are the exact immutable bytes to hash AND parse. `.snapshots`
    expose lengths and observed identity. Last-access time is intentionally not
    a content stability field. Namespace writes are separately fixture-admitted.
    """
    def __init__(self,root,relative_names,max_bytes=MAX_FILE):
        if type(max_bytes) is not int or not 0<max_bytes<=MAX_FILE:raise Refusal('read bound')
        if not isinstance(relative_names,(list,tuple)):raise Refusal('explicit pin file list required')
        self.root=Path(root);self.names=list(relative_names);self.max_bytes=max_bytes
        if not self.root.is_absolute():raise Refusal('absolute root required')
        if len(self.names)>64 or len(self.names)!=len(set(n.casefold() if isinstance(n,str) else n for n in self.names)):raise Refusal('pin file count/duplicates')
        for name in self.names:_relative(name)
        self.api=None;self.calls=[];self.handles=[];self.buffers={};self.snapshots={};self._entered=False

    def __enter__(self):
        if self._entered:raise Refusal('pins cannot be reused')
        self._entered=True;self.api=_Native();self.calls=self.api.calls
        if self.root.anchor.lower()!='c:\\':raise Refusal('local C drive required')
        directories=set();p=self.root
        while True:
            directories.add(p)
            if p==p.parent:break
            p=p.parent
        for name in self.names:
            target=self.root.joinpath(*_relative(name))
            p=target.parent
            while True:
                directories.add(p)
                if p==p.parent:break
                p=p.parent
        try:
            for p in sorted(directories,key=lambda v:len(v.parts)):
                handle=_open(self.api,p,access=0x80,share=3,flags=0x2200000);self.handles.append(handle)
                info,_,_=_information(self.api,handle)
                if not info.attributes&DIRECTORY or info.attributes&REPARSE:raise Refusal('directory/reparse refused')
                expected='\\\\?\\'+str(p)
                if _path_by_handle(self.api,handle).casefold().rstrip('\\')!=expected.casefold().rstrip('\\'):
                    raise Refusal('directory path differs')
            _ntfs(self.api,self.handles[0],self.root.anchor)
            for name in self.names:
                p=self.root.joinpath(*_relative(name));handle=_open(self.api,p);self.handles.append(handle)
                info,identity,stable=_information(self.api,handle)
                if info.attributes&(DIRECTORY|REPARSE) or info.links!=1:raise Refusal('ordinary single-link file required')
                if identity[2]>self.max_bytes:raise Refusal('file bound exceeded')
                if _path_by_handle(self.api,handle).casefold()!=('\\\\?\\'+str(p)).casefold():raise Refusal('file path differs')
                parts=[];remaining=identity[2]
                while remaining:
                    amount=min(remaining,65536);buf=C.create_string_buffer(amount);got=U32()
                    self.api.true('ReadFile',H(handle),C.cast(buf,P),amount,C.byref(got),None)
                    if got.value!=amount:raise Refusal('short read')
                    parts.append(buf.raw);remaining-=amount
                raw=b''.join(parts);after,identity_after,stable_after=_information(self.api,handle)
                if identity!=identity_after or stable!=stable_after:raise Refusal('file changed during read')
                self.buffers[name]=raw;self.snapshots[name]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'identity':identity}
            return self
        except BaseException:
            self._close();raise

    def _close(self):
        failures=[]
        while self.handles:
            h=self.handles.pop()
            try:self.api.close(h)
            except BaseException as e:failures.append(type(e).__name__+':'+str(e))
        if failures:raise Refusal('pin cleanup:'+','.join(failures))

    def __exit__(self,*exc):
        self._close()


def ordinary_bytes(path,max_bytes=MAX_FILE,*,journal=None):
    p=Path(path);pins=FilePins(p.parent,[p.name],max_bytes=max_bytes)
    try:
        with pins:return pins.buffers[p.name]
    finally:
        # Include exit/cleanup facts, even when a read or close refuses.
        ordinary_bytes.calls=list(pins.calls)
        if journal is not None:journal.extend(pins.calls)


ordinary_bytes.calls=[]


class KeyVault:
    """Current-user DPAPI sealed key; no plaintext key is written to disk.

    `.calls` aggregates cryptographic and file phase facts including closes.
    One fixture authority owns this class in each process; it is not a shared
    concurrent key-service API.
    """
    calls=[]
    @staticmethod
    def _entropy(binding):return b'MAIA/M3/DPAPI1\x00'+_canonical(_binding(binding))

    @classmethod
    def _crypt(cls,data,binding,protect):
        api=_Native()
        if type(data) is not bytes or not 0<len(data)<=16384:raise Refusal('DPAPI data bound')
        ent=cls._entropy(binding);db=C.create_string_buffer(data);eb=C.create_string_buffer(ent)
        source=DATA_BLOB(len(data),C.cast(db,P));entropy=DATA_BLOB(len(ent),C.cast(eb,P));out=DATA_BLOB()
        name='CryptProtectData' if protect else 'CryptUnprotectData'
        args=[C.byref(source),'MAIA M3 disposable owner key' if protect else None,C.byref(entropy),None,None,1,C.byref(out)]
        try:
            api.true(name,*args,crypt=True)
            try:
                if not out.data or not 0<out.size<=16384:raise Refusal('DPAPI output bound')
                return C.string_at(out.data,out.size)
            finally:
                raw,error=api.call('LocalFree',H(out.data))
                if raw:raise Refusal('LocalFree:'+str(error))
        finally:
            cls.calls.extend(api.calls)

    @classmethod
    def seal(cls,root,binding):
        cls.calls=[];root=fixture_root(root);key=secrets.token_bytes(32);cipher=cls._crypt(key,binding,True)
        # Filesystem mutations only in the admitted disposable directory. Parent
        # pin handles prevent rename/reparse replacement throughout creation.
        pins=FilePins(root,[])
        try:
            with pins:
                api=pins.api;handle=_open(api,root/'owner.key',access=0x40000000,share=0,disposition=1,flags=0x200080)
                try:
                    payload=b'M3DPAPI1\x00'+cipher;buf=C.create_string_buffer(payload);written=U32()
                    api.true('WriteFile',H(handle),C.cast(buf,P),len(payload),C.byref(written),None)
                    if written.value!=len(payload):raise Refusal('short key write')
                    api.true('FlushFileBuffers',H(handle))
                finally:api.close(handle)
        finally:
            cls.calls.extend(pins.calls)
        return key

    @classmethod
    def load(cls,root,binding):
        cls.calls=[];root=fixture_root(root);raw=ordinary_bytes(root/'owner.key',16384,journal=cls.calls)
        if not raw.startswith(b'M3DPAPI1\x00'):raise Refusal('key header')
        key=cls._crypt(raw[9:],binding,False)
        if len(key)!=32:raise Refusal('owner key length')
        return key


class NativeProcess:
    """Own one original Popen handle; never reopen a PID."""
    def __init__(self,child):
        self.api=_Native();self.calls=self.api.calls;self.child=child
        handle=getattr(child,'_handle',None)
        if handle is None or not _valid_handle(int(handle)) or not callable(getattr(handle,'Detach',None)):
            raise Refusal('retained Popen handle required')
        self.handle=int(handle);self.closed=False;self.close_attempted=False;self.termination_attempted=False
        self._identity=self._read_identity()
        if self._identity['pid']!=child.pid:raise Refusal('Popen identity differs')

    @classmethod
    def from_remote(cls,source,raw_handle,expected_identity):
        """Duplicate an observer handle from a retained owned broker.

        Call only while the authenticated broker barrier still retains that
        exact source handle; acknowledgements must follow successful duplication.
        """
        if not isinstance(source,NativeProcess) or not _valid_handle(raw_handle):
            raise Refusal('retained remote source/handle required')
        if type(expected_identity) is not dict or set(expected_identity)!={'pid','birth'} or any(type(x) is not int or x<=0 for x in expected_identity.values()):
            raise Refusal('expected native identity shape')
        obj=cls.__new__(cls);obj.api=_Native();obj.calls=obj.api.calls;obj.child=None
        obj.closed=False;obj.close_attempted=False;obj.termination_attempted=False;obj.handle=None
        target=H();current,error=obj.api.call('GetCurrentProcess')
        if not current:raise Refusal('current process pseudo-handle missing')
        obj.api.true('DuplicateHandle',source._live_handle(),H(raw_handle),H(current),C.byref(target),0,False,2)
        if not _valid_handle(target.value):raise Refusal('remote duplicate invalid')
        obj.handle=target.value
        try:
            obj._identity=obj._read_identity()
            if obj._identity!=expected_identity:raise Refusal('remote retained process identity differs')
        except BaseException:
            # This is our newly returned observation copy, not process cleanup.
            obj.close_attempted=True;obj.api.close(obj.handle);obj.closed=True;raise
        return obj

    def _live_handle(self):
        if self.closed or self.close_attempted or getattr(self.api,'frozen',False):raise Refusal('process handle unavailable or native boundary frozen')
        return H(self.handle)

    def _read_identity(self):
        h=self._live_handle();pid=self.api.true('GetProcessId',h)
        born=FILETIME();ended=FILETIME();kernel=FILETIME();user=FILETIME()
        self.api.true('GetProcessTimes',h,C.byref(born),C.byref(ended),C.byref(kernel),C.byref(user))
        birth=(int(born.high)<<32)|int(born.low)
        if not birth:raise Refusal('process birth missing')
        return {'pid':int(pid),'birth':birth}

    def identity(self):
        observed=self._read_identity()
        if observed!=self._identity:raise Refusal('retained process identity changed')
        return dict(observed)

    def wait(self,timeout):
        raw,error=self.api.call('WaitForSingleObject',self._live_handle(),_timeout(timeout))
        if raw==258:return None
        if raw!=0:raise Refusal('process wait:'+str(error))
        code=U32();self.api.true('GetExitCodeProcess',self._live_handle(),C.byref(code))
        if self.child is not None:self.child.returncode=int(code.value)
        return int(code.value)

    def terminate(self,code=0xE0330002):
        """One bounded termination request using only this retained capability."""
        if type(code) is not int or not 0<=code<=0xffffffff:
            raise Refusal('process termination code')
        handle=self._live_handle()
        if self.termination_attempted:raise Refusal('process termination cannot be replayed')
        self.termination_attempted=True
        self.api.true('TerminateProcess',handle,code)
        return True

    def close(self):
        if self.close_attempted:raise Refusal('process close cannot be replayed')
        if self.wait(0) is None:raise Refusal('process still alive')
        self.close_attempted=True
        if self.child is not None:
            raw=self.child._handle.Detach()
            if int(raw)!=self.handle:raise Refusal('detached process handle differs')
        self.api.close(self.handle);self.closed=True
        return True


class OwnedJob:
    def __init__(self):
        self.api=_Native();self.calls=self.api.calls;self.handle=None;self.close_attempted=False;self.closed=False
        raw,error=self.api.call('CreateJobObjectW',None,None)
        if not _valid_handle(raw):raise Refusal('CreateJobObjectW:'+str(error))
        self.handle=raw;limits=EXTENDED_LIMIT();limits.basic.flags=0x2000
        try:self.api.true('SetInformationJobObject',H(raw),9,C.byref(limits),C.sizeof(limits))
        except BaseException:
            self.close_attempted=True;self.api.close(raw);self.closed=True;raise

    def _handle(self):
        if self.closed or self.close_attempted:raise Refusal('job unavailable')
        return H(self.handle)

    def assign(self,process):
        if not isinstance(process,NativeProcess):raise Refusal('owned retained process required')
        self.api.true('AssignProcessToJobObject',self._handle(),process._live_handle())

    def active_processes(self):
        info=ACCOUNTING();used=U32()
        self.api.true('QueryInformationJobObject',self._handle(),1,C.byref(info),C.sizeof(info),C.byref(used))
        if used.value!=C.sizeof(info):raise Refusal('job accounting shape')
        return int(info.active)

    def terminate(self,code=0xE0330001):
        if type(code) is not int or not 0<=code<=0xffffffff:raise Refusal('termination code')
        self.api.true('TerminateJobObject',self._handle(),code)

    def close(self):
        if self.close_attempted:raise Refusal('job close cannot be replayed')
        if self.active_processes()!=0:raise Refusal('job still populated')
        self.close_attempted=True;self.api.close(self.handle);self.closed=True
        return True
