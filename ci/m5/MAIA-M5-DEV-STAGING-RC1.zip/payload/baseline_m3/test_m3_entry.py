"""Pure source-capsule regressions; no native source admission claim."""
import hashlib,importlib,importlib.util,json,os,py_compile,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
spec=importlib.util.spec_from_file_location('entry_control_alias',Path(__file__).with_name('m3_entry.py'))
entry=importlib.util.module_from_spec(spec);spec.loader.exec_module(entry)
class FakePins:
 def __init__(self,root):self.root=root;self.facts=[];self.closed=False
 def __enter__(self):return self
 def read(self,name,bound):
  raw=(self.root/name).read_bytes()
  if len(raw)>bound:raise entry.EntryRefusal('bound')
  return raw
 def __exit__(self,*args):self.closed=True
class SourceCapsuleControls(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
  (self.root/'m3_entry.py').write_bytes(b'# pinned entry fixture\n')
  (self.root/'capsule_probe.py').write_bytes(b'RESULT="FRESH"\n')
 def tearDown(self):sys.modules.pop('capsule_probe',None);self.tmp.cleanup()
 def manifest(self):
  files={p.name:{'bytes':p.stat().st_size,'sha256':entry._sha(p.read_bytes())} for p in self.root.glob('*.py')}
  source=entry._sha(entry._canonical({n:p['sha256'] for n,p in files.items()}));raw=entry._canonical({'schema':1,'files':files,'source_sha256':source});(self.root/'SOURCE_MANIFEST.json').write_bytes(raw)
  return entry._sha(raw),source
 def test_stale_timestamp_valid_bytecode_cannot_replace_verified_source(self):
  p=self.root/'capsule_probe.py';p.write_bytes(b'RESULT="STALE"\n');fixed=1700000000;os.utime(p,(fixed,fixed));py_compile.compile(str(p),doraise=True);p.write_bytes(b'RESULT="FRESH"\n');os.utime(p,(fixed,fixed));mh,source=self.manifest()
  with patch.object(entry,'_Pins',FakePins):
   with entry.Capsule(self.root,mh,source):self.assertEqual(importlib.import_module('capsule_probe').RESULT,'FRESH')
 def test_extra_source_and_changed_source_refuse_before_import(self):
  mh,source=self.manifest();extra=self.root/'extra.py';extra.write_bytes(b'raise RuntimeError("must not run")')
  with patch.object(entry,'_Pins',FakePins):
   with self.assertRaises(entry.EntryRefusal):
    with entry.Capsule(self.root,mh,source):self.fail('unexpected admission')
   extra.unlink();(self.root/'capsule_probe.py').write_bytes(b'raise RuntimeError("must not run")')
   with self.assertRaises(entry.EntryRefusal):
    with entry.Capsule(self.root,mh,source):self.fail('unexpected admission')
  self.assertNotIn('capsule_probe',sys.modules)
 def test_manifest_digest_and_preimported_sibling_refuse(self):
  mh,source=self.manifest()
  with patch.object(entry,'_Pins',FakePins):
   with self.assertRaises(entry.EntryRefusal):
    with entry.Capsule(self.root,'0'*64,source):self.fail('unexpected admission')
   sys.modules['capsule_probe']=type(sys)('capsule_probe')
   with self.assertRaises(entry.EntryRefusal):
    with entry.Capsule(self.root,mh,source):self.fail('unexpected admission')
 def test_win64_file_information_offsets(self):
  self.assertEqual(entry.C.sizeof(entry._Info),52);self.assertEqual(entry._Info.created.offset,4);self.assertEqual(entry._Info.volume.offset,28)
if __name__=='__main__':unittest.main()
