"""Read-only Win64 source capsule. Invoke through an independently SHA-pinned boot.

The boot hashes and compiles the SAME m3_entry.py buffer. This entry then holds
manifest/source/ancestor handles and imports sibling modules only from verified
in-memory source buffers. -B alone is insufficient: existing pyc is never used.
"""
from __future__ import annotations
import argparse
import ctypes as C
import hashlib
import importlib.abc
import importlib.util
import json
import os
from pathlib import Path
import re
import sys
import types

MAX_SOURCE=512*1024
MAX_MANIFEST=65536
MAX_TOTAL=8*1024*1024
NAME=re.compile(r'[a-z0-9_]+\.py\Z')
DIGEST=re.compile(r'[0-9a-f]{64}\Z')
CURRENT=None


class EntryRefusal(RuntimeError):
    pass


def _sha(raw):return hashlib.sha256(raw).hexdigest()
def _canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode('ascii')
def _pairs(items):
    value={}
    for k,v in items:
        if k in value:raise EntryRefusal('duplicate manifest key')
        value[k]=v
    return value


class _Info(C.Structure):
    # BY_HANDLE_FILE_INFORMATION: DWORD + three FILETIMEs + six DWORDs.
    _fields_=[('attributes',C.c_uint32),('created',C.c_uint64),('accessed',C.c_uint64),('written',C.c_uint64),('volume',C.c_uint32),('size_high',C.c_uint32),('size_low',C.c_uint32),('links',C.c_uint32),('index_high',C.c_uint32),('index_low',C.c_uint32)]
    _pack_=4


class _Pins:
    def __init__(self,root):
        if os.name!='nt' or C.sizeof(C.c_void_p)!=8:raise EntryRefusal('Win64 source capsule required')
        self.root=Path(root).absolute();self.handles=[];self.facts=[]
        if self.root.anchor.casefold()!='c:\\':raise EntryRefusal('local C source path required')
        for segment in self.root.parts[1:]:
            if segment.endswith((' ','.')) or any(c in '<>\"|?*:' or ord(c)<32 for c in segment):raise EntryRefusal('source path alias refused')
        self.k=C.WinDLL('kernel32',use_last_error=True)
        signatures={
            'CreateFileW':([C.c_wchar_p,C.c_uint32,C.c_uint32,C.c_void_p,C.c_uint32,C.c_uint32,C.c_void_p],C.c_void_p),
            'GetFileInformationByHandle':([C.c_void_p,C.POINTER(_Info)],C.c_int32),
            'GetFinalPathNameByHandleW':([C.c_void_p,C.c_void_p,C.c_uint32,C.c_uint32],C.c_uint32),
            'ReadFile':([C.c_void_p,C.c_void_p,C.c_uint32,C.POINTER(C.c_uint32),C.c_void_p],C.c_int32),
            'CloseHandle':([C.c_void_p],C.c_int32),
        }
        for name,(args,ret) in signatures.items():
            f=getattr(self.k,name);f.argtypes=args;f.restype=ret

    def _call(self,name,*args):
        C.set_last_error(0);raw=getattr(self.k,name)(*args);error=C.get_last_error()
        self.facts.append({'name':name,'raw':raw,'error':error})
        return raw,error

    def _true(self,name,*args):
        raw,error=self._call(name,*args)
        if not raw:raise EntryRefusal(name+':'+str(error))
        return raw

    def _open(self,path,directory=False):
        h,error=self._call('CreateFileW',str(path),0x80 if directory else 0x80000000,3 if directory else 1,None,3,0x2200000 if directory else 0x200000,None)
        if h in (None,0,-1,(1<<64)-1):raise EntryRefusal('source open:'+str(error))
        self.handles.append(h)
        info=self._info(h)
        if info.attributes&0x400 or bool(info.attributes&0x10)!=directory or not directory and info.links!=1:raise EntryRefusal('source reparse/type/hardlink refused')
        pathbuf=C.create_unicode_buffer(32768)
        n,error=self._call('GetFinalPathNameByHandleW',h,C.cast(pathbuf,C.c_void_p),len(pathbuf),0)
        expected='\\\\?\\'+str(path)
        if not 0<n<len(pathbuf) or pathbuf.value.casefold().rstrip('\\')!=expected.casefold().rstrip('\\'):raise EntryRefusal('source namespace differs')
        return h,info

    def _info(self,h):
        info=_Info();self._true('GetFileInformationByHandle',h,C.byref(info));return info

    @staticmethod
    def _stable(info):
        return (info.attributes,info.created,info.written,info.volume,info.size_high,info.size_low,info.links,info.index_high,info.index_low)

    def __enter__(self):
        try:
            for directory in reversed([self.root,*self.root.parents]):self._open(directory,True)
            return self
        except BaseException:
            self.__exit__(None,None,None);raise

    def read(self,name,bound):
        h,before=self._open(self.root/name)
        size=(int(before.size_high)<<32)|int(before.size_low)
        if size>bound:raise EntryRefusal('source size bound')
        parts=[];remaining=size
        while remaining:
            amount=min(65536,remaining);buffer=C.create_string_buffer(amount);got=C.c_uint32()
            self._true('ReadFile',h,C.cast(buffer,C.c_void_p),amount,C.byref(got),None)
            if got.value!=amount:raise EntryRefusal('source short read')
            parts.append(buffer.raw);remaining-=amount
        if self._stable(before)!=self._stable(self._info(h)):raise EntryRefusal('source changed during read')
        return b''.join(parts)

    def __exit__(self,*args):
        failures=[]
        while self.handles:
            h=self.handles.pop()
            try:self._true('CloseHandle',h)
            except BaseException as exc:failures.append(str(exc))
        if failures:raise EntryRefusal('source pin close:'+','.join(failures))


class _Buffers(importlib.abc.MetaPathFinder,importlib.abc.Loader):
    def __init__(self,root,buffers):self.root=root;self.buffers=buffers
    def find_spec(self,fullname,path=None,target=None):
        name=fullname+'.py'
        if '.' not in fullname and name in self.buffers:return importlib.util.spec_from_loader(fullname,self,origin=str(self.root/name))
        return None
    def create_module(self,spec):return None
    def exec_module(self,module):
        name=module.__name__+'.py';path=str(self.root/name)
        module.__file__=path;module.__cached__=None
        exec(compile(self.buffers[name],path,'exec',dont_inherit=True),module.__dict__)


class Capsule:
    def __init__(self,root,manifest_sha,source_sha):
        if type(manifest_sha) is not str or not DIGEST.fullmatch(manifest_sha) or type(source_sha) is not str or not DIGEST.fullmatch(source_sha):raise EntryRefusal('trusted digest shape')
        self.root=Path(root).absolute();self.manifest_sha=manifest_sha;self.source_sha=source_sha;self.pins=None;self.loader=None
    def __enter__(self):
        self.pins=_Pins(self.root);self.pins.__enter__()
        try:
            raw=self.pins.read('SOURCE_MANIFEST.json',MAX_MANIFEST)
            if _sha(raw)!=self.manifest_sha:raise EntryRefusal('trusted manifest differs')
            try:manifest=json.loads(raw.decode('utf-8'),object_pairs_hook=_pairs,parse_constant=lambda x:(_ for _ in ()).throw(EntryRefusal('manifest nonfinite')))
            except (ValueError,UnicodeError,RecursionError) as exc:raise EntryRefusal('manifest parse') from exc
            if type(manifest) is not dict or set(manifest)!={'schema','files','source_sha256'} or type(manifest['schema']) is not int or manifest['schema']!=1:raise EntryRefusal('manifest schema')
            files=manifest['files']
            if type(files) is not dict or not 1<=len(files)<=40 or any(type(n) is not str or not NAME.fullmatch(n) for n in files):raise EntryRefusal('manifest source names')
            if 'm3_entry.py' not in files:raise EntryRefusal('entry source absent')
            if {p.name for p in self.root.glob('*.py')}!=set(files):raise EntryRefusal('source set differs')
            self.buffers={};digests={};total=0
            for name,pin in sorted(files.items()):
                if type(pin) is not dict or set(pin)!={'bytes','sha256'} or type(pin['bytes']) is not int or not 0<=pin['bytes']<=MAX_SOURCE or type(pin['sha256']) is not str or not DIGEST.fullmatch(pin['sha256']):raise EntryRefusal('source pin shape')
                data=self.pins.read(name,MAX_SOURCE);total+=len(data)
                if total>MAX_TOTAL or len(data)!=pin['bytes'] or _sha(data)!=pin['sha256']:raise EntryRefusal('source hash/length differs:'+name)
                self.buffers[name]=data;digests[name]=_sha(data)
            if manifest['source_sha256']!=self.source_sha or _sha(_canonical(digests))!=self.source_sha:raise EntryRefusal('source map differs')
            if {p.name for p in self.root.glob('*.py')}!=set(files):raise EntryRefusal('source set changed')
            if any(name[:-3] in sys.modules for name in files):raise EntryRefusal('package module imported before source capsule')
            self.loader=_Buffers(self.root,self.buffers);sys.meta_path.insert(0,self.loader)
            return self
        except BaseException:
            self.pins.__exit__(None,None,None);self.pins=None;raise
    def run(self,entry_script,argv):
        if type(entry_script) is not str or entry_script not in self.buffers or entry_script=='m3_entry.py':raise EntryRefusal('entry script not admitted')
        old_argv=sys.argv;old_main=sys.modules.get('__main__')
        module=types.ModuleType('__main__');module.__file__=str(self.root/entry_script)
        module.__package__=None;module.__cached__=None
        sys.argv=[module.__file__,*argv];sys.modules['__main__']=module
        try:exec(compile(self.buffers[entry_script],module.__file__,'exec',dont_inherit=True),module.__dict__)
        finally:
            sys.argv=old_argv
            if old_main is not None:sys.modules['__main__']=old_main
            else:sys.modules.pop('__main__',None)
    def __exit__(self,*args):
        if self.loader in sys.meta_path:sys.meta_path.remove(self.loader)
        if self.pins:self.pins.__exit__(*args);self.pins=None


def run(entry_script,argv):
    if CURRENT is None:raise EntryRefusal('no active source capsule')
    return CURRENT.run(entry_script,argv)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest-sha',required=True);parser.add_argument('--source-sha',required=True);parser.add_argument('--entry',required=True)
    parser.add_argument('args',nargs=argparse.REMAINDER);args=parser.parse_args()
    tail=args.args[1:] if args.args[:1]==['--'] else args.args
    global CURRENT
    with Capsule(Path(__file__).absolute().parent,args.manifest_sha,args.source_sha) as capsule:
        CURRENT=capsule
        try:return run(args.entry,tail)
        finally:CURRENT=None


if __name__=='__main__':
    try:main()
    except EntryRefusal as exc:raise SystemExit('M3_ENTRY_REFUSED:'+str(exc))
