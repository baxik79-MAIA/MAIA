"""Portable ownership/ABI controls; these are not native Windows observations."""
import ctypes as C
import os
from pathlib import Path, PureWindowsPath
import unittest
from types import SimpleNamespace
from unittest.mock import patch
import m3_windows as w


class Handle(int):
    def __new__(cls,value):
        obj=int.__new__(cls,value);obj.detaches=0;return obj
    def Detach(self):
        self.detaches+=1;return int(self)


class Child:
    def __init__(self):self._handle=Handle(100);self.pid=123;self.returncode=None


class API:
    identities={100:(123,2**40+7),200:(456,2**40+8)}
    waits=0;close_ok=True
    def __init__(self):self.calls=[]
    def call(self,name,*args,crypt=False):
        self.calls.append({'name':name,'state':'RETURNED'})
        if name=='WaitForSingleObject':return self.waits,0
        if name=='GetCurrentProcess':return w.INVALID,0
        if name=='CreateJobObjectW':return 300,0
        return 1,0
    def true(self,name,*args,crypt=False):
        self.calls.append({'name':name,'state':'RETURNED'})
        if name=='GetProcessId':return self.identities[args[0].value][0]
        if name=='GetProcessTimes':
            birth=self.identities[args[0].value][1];args[1]._obj.low=birth&0xffffffff;args[1]._obj.high=birth>>32
        elif name=='GetExitCodeProcess':args[1]._obj.value=17
        elif name=='DuplicateHandle':args[3]._obj.value=200
        elif name=='QueryInformationJobObject':args[2]._obj.active=0;args[4]._obj.value=C.sizeof(w.ACCOUNTING)
        return 1
    def close(self,h):
        self.calls.append({'name':'CloseHandle','handle':h,'state':'RETURNED'})
        if not self.close_ok:raise w.Refusal('close failed')


class FileAPI(API):
    content=b'{"exact":true}';links=1;changed=False;short=False;reparse=False
    def __init__(self):super().__init__();self.handles={};self.next=400;self.reads=0
    def call(self,name,*args,crypt=False):
        if name=='CreateFileW':
            self.next+=1;self.handles[self.next]=(args[0],bool(args[5]&0x2000000))
            self.calls.append({'name':name,'state':'RETURNED','raw':self.next});return self.next,0
        if name=='GetFinalPathNameByHandleW':
            path='\\\\?\\'+self.handles[args[0].value][0];b=C.create_unicode_buffer(path)
            C.memmove(args[1],b,C.sizeof(b));return len(path),0
        if name=='GetDriveTypeW':return 3,0
        return super().call(name,*args,crypt=crypt)
    def true(self,name,*args,crypt=False):
        if name=='GetFileInformationByHandle':
            p,isdir=self.handles[args[0].value];i=args[1]._obj
            i.attributes=0x10 if isdir else (0x400 if self.reparse else 32)
            i.volume=1;i.links=self.links;i.index_low=args[0].value;i.created.low=1
            i.written.low=2 if self.changed and self.reads else 1
            i.size_low=0 if isdir else len(self.content)
            return 1
        if name=='GetVolumeInformationByHandleW':
            b=C.create_unicode_buffer('NTFS');C.memmove(args[6],b,C.sizeof(b));return 1
        if name=='ReadFile':
            self.reads+=1;count=len(self.content)-(1 if self.short else 0)
            C.memmove(args[1],self.content,count);args[3]._obj.value=count;return 1
        return super().true(name,*args,crypt=crypt)


class Contracts(unittest.TestCase):
    def setUp(self):
        self.p=patch.object(w,'_Native',API);self.p.start();self.addCleanup(self.p.stop)
        API.identities={100:(123,2**40+7),200:(456,2**40+8)};API.waits=0;API.close_ok=True

    def test_fixed_width_structures_match_win64(self):
        self.assertEqual(C.sizeof(w.FILETIME),8);self.assertEqual(C.sizeof(w.FILE_INFO),52)
        self.assertEqual(C.sizeof(w.ACCOUNTING),48)
        if C.sizeof(C.c_void_p)==8:
            self.assertEqual(C.sizeof(w.EXTENDED_LIMIT),144);self.assertEqual(C.sizeof(w.DATA_BLOB),16)

    def test_process_identity_uses_retained_handle_and_detects_change(self):
        p=w.NativeProcess(Child());self.assertEqual(p.identity(),{'pid':123,'birth':2**40+7})
        API.identities[100]=(123,2**40+9)
        with self.assertRaises(w.Refusal):p.identity()
        self.assertFalse(any(x['name']=='OpenProcess' for x in p.calls))

    def test_live_close_does_not_detach_then_one_settled_close(self):
        child=Child();p=w.NativeProcess(child);API.waits=258
        with self.assertRaises(w.Refusal):p.close()
        self.assertEqual(child._handle.detaches,0)
        API.waits=0;self.assertTrue(p.close());self.assertEqual(child._handle.detaches,1)
        with self.assertRaises(w.Refusal):p.close()
        self.assertEqual(len([x for x in p.calls if x['name']=='CloseHandle']),1)

    def test_failed_close_latches_no_replay(self):
        child=Child();p=w.NativeProcess(child);API.close_ok=False
        with self.assertRaises(w.Refusal):p.close()
        with self.assertRaises(w.Refusal):p.close()
        self.assertEqual(child._handle.detaches,1)
        self.assertEqual(len([x for x in p.calls if x['name']=='CloseHandle']),1)

    def test_remote_duplication_bound_to_retained_source(self):
        source=w.NativeProcess(Child());p=w.NativeProcess.from_remote(source,77,{'pid':456,'birth':2**40+8})
        self.assertEqual(p.identity()['pid'],456);self.assertEqual(p.wait(0),17);self.assertTrue(p.close())
        self.assertEqual(len([x for x in p.calls if x['name']=='DuplicateHandle']),1)

    def test_remote_wrong_birth_closes_only_new_observer_copy(self):
        source=w.NativeProcess(Child())
        with self.assertRaises(w.Refusal):w.NativeProcess.from_remote(source,77,{'pid':456,'birth':1})
        self.assertFalse(source.closed);self.assertEqual(source.identity()['pid'],123)

    def test_unknown_or_infinite_wait_never_enters_wait(self):
        p=w.NativeProcess(Child())
        for v in [True,-1,float('inf'),float('nan'),61,None]:
            before=len(p.calls)
            with self.assertRaises(w.Refusal):p.wait(v)
            self.assertEqual(len(p.calls),before)

    def test_process_termination_uses_retained_handle_once(self):
        class TerminateAPI(API):
            def true(self,name,*args,crypt=False):
                if name=='TerminateProcess':self.termination=(args[0].value,args[1])
                return super().true(name,*args,crypt=crypt)
        with patch.object(w,'_Native',TerminateAPI):
            p=w.NativeProcess(Child());self.assertTrue(p.terminate())
            self.assertEqual(p.api.termination,(100,0xE0330002))
            with self.assertRaises(w.Refusal):p.terminate()
            self.assertEqual(len([x for x in p.calls if x['name']=='TerminateProcess']),1)
            self.assertFalse(any(x['name']=='OpenProcess' for x in p.calls))

    def test_failed_termination_is_not_replayed_and_frozen_is_noop(self):
        class FailedAPI(API):
            def true(self,name,*args,crypt=False):
                if name=='TerminateProcess':
                    self.calls.append({'name':name,'state':'RETURNED','raw':0})
                    raise w.Refusal('TerminateProcess:5')
                return super().true(name,*args,crypt=crypt)
        with patch.object(w,'_Native',FailedAPI):
            p=w.NativeProcess(Child())
            for _ in range(2):
                with self.assertRaises(w.Refusal):p.terminate(33)
            self.assertEqual(len([x for x in p.calls if x['name']=='TerminateProcess']),1)
        p=w.NativeProcess(Child());p.api.frozen=True;before=len(p.calls)
        with self.assertRaises(w.Refusal):p.terminate()
        self.assertEqual(len(p.calls),before)
        self.assertFalse(p.termination_attempted)

    def test_runtime_guard_pins_platform_implementation_version_and_handle_api(self):
        with patch.object(w.os,'name','nt'),patch.object(w.sys,'implementation',SimpleNamespace(name='cpython')),patch.object(w.sys,'version_info',(3,13,9)),patch.object(w.subprocess,'Handle',Handle,create=True):
            # Our test Handle initially lacks Close; no launch contract is inferred.
            with self.assertRaises(w.Refusal):w.validate_runtime()
            with patch.object(Handle,'Close',lambda self:None,create=True):
                facts=w.validate_runtime();self.assertEqual(facts['version'],[3,13,9])
                self.assertEqual(facts['popen_handle_api'],['Detach','Close'])
                with patch.object(w.sys,'version_info',(3,14,0)):
                    with self.assertRaises(w.Refusal):w.validate_runtime()
                with patch.object(w.sys,'implementation',SimpleNamespace(name='pypy')):
                    with self.assertRaises(w.Refusal):w.validate_runtime()
                with patch.object(w.os,'name','posix'):
                    with self.assertRaises(w.Refusal):w.validate_runtime()

    def test_windows_names_reject_escape_aliases_and_alternate_streams(self):
        for name in ['/absolute','../escape','a/../b','a//b','a\\b','a:stream','a.','a ','CON','a/NUL.txt','x?']:
            with self.subTest(name=name),self.assertRaises(w.Refusal):w._relative(name)
        self.assertEqual(w._relative('input/state.json'),('input','state.json'))

    def test_fixture_admission_rejects_win32_parent_aliases_before_platform_or_io(self):
        bad=['C:/MAIA/worktrees/M3_BEGIN_20261108/.. /.. /outside',
             'C:/MAIA/reports/M3_BEGIN_20261108/fixture/.. /outside',
             'C:/MAIA/worktrees/M3_BEGIN_20261108/.../outside',
             'C:/MAIA/worktrees/M3_BEGIN_20261108/fixture./outside',
             'C:/MAIA/worktrees/M3_BEGIN_20261108/fixture /outside',
             'C:/MAIA/worktrees/M3_BEGIN_20261108/fixture:stream',
             'C:/MAIA/worktrees/M3_BEGIN_20261108/../outside',
             'C:/MAIA/orchestrator/fixture',
             '//server/share/MAIA/worktrees/M3_BEGIN_20261108/fixture',
             'C:MAIA/worktrees/M3_BEGIN_20261108/fixture']
        for path in bad:
            with self.subTest(path=path),self.assertRaises(w.Refusal) as caught:
                w.fixture_root(path)
            self.assertNotEqual(str(caught.exception),'Windows required')
        good='C:/MAIA/worktrees/M3_BEGIN_20261108/fixture'
        self.assertEqual(w._fixture_path(good),PureWindowsPath(good))
        with patch.object(w,'Path',PureWindowsPath),patch.object(w.os,'name','nt'):
            self.assertEqual(w.fixture_root(good),PureWindowsPath(good))

    def test_binding_is_exact_and_not_caller_label(self):
        good={'cycle':'a'*32,'source':'b'*64,'inputs':'c'*64};self.assertEqual(w._binding(good),good)
        for bad in [{**good,'trusted':True},{**good,'cycle':'A'*32},{**good,'inputs':1}]:
            with self.assertRaises(w.Refusal):w.KeyVault._entropy(bad)
        self.assertNotEqual(w.KeyVault._entropy(good),w.KeyVault._entropy({**good,'cycle':'d'*32}))

    def test_pin_list_is_explicit_and_case_collisions_refused(self):
        for names in ['ab',['one','ONE'],['a/../b']]:
            with self.assertRaises(w.Refusal):w.FilePins(Path.cwd(),names)

    def test_job_close_must_not_replay(self):
        job=w.OwnedJob();p=w.NativeProcess(Child());job.assign(p)
        self.assertEqual(job.active_processes(),0);self.assertTrue(job.close())
        with self.assertRaises(w.Refusal):job.close()
        self.assertEqual(len([x for x in job.calls if x['name']=='CloseHandle']),1)


class FilePinControls(unittest.TestCase):
    def setUp(self):
        self.p=patch.object(w,'_Native',FileAPI);self.p.start();self.addCleanup(self.p.stop)
        self.q=patch.object(w,'Path',PureWindowsPath);self.q.start();self.addCleanup(self.q.stop)
        FileAPI.links=1;FileAPI.changed=False;FileAPI.short=False;FileAPI.reparse=False

    def test_same_returned_buffer_hash_and_pin_lifetime(self):
        pins=w.FilePins('C:/MAIA/worktrees/M3_BEGIN_20261108/fixture',['state.json'])
        with pins:
            self.assertEqual(pins.buffers['state.json'],FileAPI.content)
            self.assertEqual(pins.snapshots['state.json']['sha256'],w.hashlib.sha256(FileAPI.content).hexdigest())
            self.assertTrue(pins.handles)
            self.assertFalse(any(x['name']=='CloseHandle' for x in pins.calls))
        self.assertFalse(pins.handles)
        self.assertEqual(len([x for x in pins.calls if x['name']=='CloseHandle']),6)

    def test_hardlink_reparse_short_and_changed_fail_closed(self):
        for field,value in [('links',2),('reparse',True),('short',True),('changed',True)]:
            with self.subTest(field=field):
                setattr(FileAPI,field,value)
                pins=w.FilePins('C:/MAIA/worktrees/M3_BEGIN_20261108/fixture',['state.json'])
                with self.assertRaises(w.Refusal):pins.__enter__()
                self.assertFalse(pins.handles)
                setattr(FileAPI,field,1 if field=='links' else False)


class VaultJournals(unittest.TestCase):
    def test_seal_and_load_keep_phase_and_context_exit_facts(self):
        class VAPI(API):
            def call(self,name,*args,crypt=False):
                self.calls.append({'name':name,'state':'RETURNED'})
                return (777,0) if name=='CreateFileW' else (1,0)
            def true(self,name,*args,crypt=False):
                self.calls.append({'name':name,'state':'RETURNED'})
                if name=='WriteFile':args[3]._obj.value=args[2]
                return 1
        class Pins:
            def __init__(self,*args,**kw):
                self.api=VAPI();self.calls=self.api.calls;self.buffers={'owner.key':b'M3DPAPI1\x00cipher'}
            def __enter__(self):
                self.calls.append({'name':'ReadOrPin','state':'RETURNED'});return self
            def __exit__(self,*exc):
                self.calls.append({'name':'CloseParentPins','state':'RETURNED'})
        def crypt(cls,data,binding,protect):
            cls.calls.extend([{'name':'CryptProtectData' if protect else 'CryptUnprotectData','state':'RETURNED'}, {'name':'LocalFree','state':'RETURNED'}])
            return b'cipher' if protect else b'k'*32
        good={'cycle':'a'*32,'source':'b'*64,'inputs':'c'*64}
        with patch.object(w,'fixture_root',lambda p:Path(p)),patch.object(w,'FilePins',Pins),patch.object(w.KeyVault,'_crypt',classmethod(crypt)):
            self.assertEqual(len(w.KeyVault.seal(Path.cwd(),good)),32)
            seal=[x['name'] for x in w.KeyVault.calls]
            self.assertEqual(seal[:2],['CryptProtectData','LocalFree'])
            self.assertEqual(seal[-1],'CloseParentPins')
            self.assertIn('FlushFileBuffers',seal);self.assertIn('CloseHandle',seal)
            self.assertEqual(w.KeyVault.load(Path.cwd(),good),b'k'*32)
            load=[x['name'] for x in w.KeyVault.calls]
            self.assertEqual(load,['ReadOrPin','CloseParentPins','CryptUnprotectData','LocalFree'])


if __name__=='__main__':unittest.main()
