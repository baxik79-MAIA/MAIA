"""One finite native admission matrix, only fresh named disposable fixtures."""
import ctypes as C
import json,os,subprocess,sys,time,uuid
from pathlib import Path
from m3_admission import INPUTS,RESIDUES,admit,check,sha,input_digest,source_pin
from m3_store import canonical
from m3_windows import fixture_root,FilePins

def inputs(root,source):
 root.mkdir();cycle=uuid.uuid4().hex
 b={'prompt.txt':b'one bounded disposable effect','state.before.json':b'{"status":"PIPELINE_COMPLETE"}','queue.before.json':b'{"items":[]}','final.before.txt':b'FIXTURE_APPROVED\n','worktree-pin.json':b'{"fixture":"M3_ONLY"}'}
 b['manifest.json']=canonical({'cycle':cycle,'idempotency_policy':'never_replay','prompt_sha256':sha(b['prompt.txt']),'worktree_sha256':sha(b['worktree-pin.json']),'prior_verdict':'FIXTURE_APPROVED'})
 for n,data in b.items():(root/n).write_bytes(data)
 expected={n:sha(data) for n,data in b.items()};binding={'cycle':cycle,'source':source,'inputs':input_digest(expected)}
 return binding,expected

def tool(command):
 r=subprocess.run(command,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=10)
 if r.returncode:raise RuntimeError('fixture tool refused '+str(r.returncode)+':'+r.stderr.decode(errors='replace')[:200])
 return {'exit':r.returncode,'stdout_sha256':sha(r.stdout),'stderr_sha256':sha(r.stderr)}

def run(root,source):
 root=fixture_root(root);root.mkdir();results=[];start=time.monotonic()
 with (root/'ATTEMPT.json').open('x') as f:json.dump({'source':source,'no_replay':True},f)
 def row(name,mutation):
  p=root/name;binding,expected=inputs(p,source);facts=mutation(p,binding,expected)
  outcome=check(p,binding,expected)
  if outcome['fixture_admissible']:raise RuntimeError(name+' unexpectedly admissible')
  results.append({'row':name,'outcome':outcome,'facts':facts,'binding':binding})
 def drift(p,b,e):
  (p/'prompt.txt').write_bytes(b'drifted');return {'kind':'actual bytes changed'}
 def transitioned(p,b,e):
  v=canonical({'status':'IDLE'});(p/'state.before.json').write_bytes(v);e['state.before.json']=sha(v);b['inputs']=input_digest(e);return {'kind':'repinned transitioned input'}
 row('hash_drift',drift);row('transitioned_state',transitioned)
 row('missing_input',lambda p,b,e:((p/'prompt.txt').unlink(),{'missing':True})[1])
 row('input_pin_mismatch',lambda p,b,e:(b.update(inputs='0'*64),{'changed':'input digest'})[1])
 row('source_mismatch',lambda p,b,e:(b.update(source='0'*64),{'changed':'source'})[1])
 row('cycle_mismatch',lambda p,b,e:(b.update(cycle='0'*32),{'changed':'cycle'})[1])
 for kind in ['file','directory','junction','dangling_junction']:
  def mutate(p,b,e,kind=kind):
   q=p/'protocol.json'
   if kind=='file':q.write_bytes(b'partial')
   elif kind=='directory':q.mkdir()
   else:
    target=p/'target'
    if kind=='junction':target.mkdir()
    return tool([str(Path(os.environ['SystemRoot'])/'System32/cmd.exe'),'/d','/c','mklink','/J',str(q),str(target)])
   return {'kind':kind}
  row('residue_'+kind,mutate)
 p=root/'held_input_writer';binding,expected=inputs(p,source)
 k=C.WinDLL('kernel32',use_last_error=True);k.CreateFileW.argtypes=[C.c_wchar_p,C.c_uint32,C.c_uint32,C.c_void_p,C.c_uint32,C.c_uint32,C.c_void_p];k.CreateFileW.restype=C.c_void_p;k.CloseHandle.argtypes=[C.c_void_p];k.CloseHandle.restype=C.c_int32
 with admit(p,binding,expected) as a:
  C.set_last_error(0);h=k.CreateFileW(str(p/'prompt.txt'),0x40000000,7,None,3,0x80,None);error=C.get_last_error()
  if h not in (None,0,-1,(1<<64)-1):k.CloseHandle(h);raise RuntimeError('input writer opened across held pin')
  if error!=32:raise RuntimeError('expected sharing refusal32')
  results.append({'row':'held_input_writer','error':error,'raw':h,'pins':a.snapshots,'native_calls':a.pins.calls,'ready':a.check['ready']})
 p=root/'acl_denied';binding,expected=inputs(p,source);icacls=str(Path(os.environ['SystemRoot'])/'System32/icacls.exe');target=str(p/'prompt.txt');deny=tool([icacls,target,'/deny','*S-1-1-0:(R)'])
 try:
  outcome=check(p,binding,expected)
  if outcome['fixture_admissible'] or '5' not in outcome['reason']:raise RuntimeError('ACL denial not observed:'+str(outcome))
  results.append({'row':'acl_denied','outcome':outcome,'deny':deny})
 finally:
  restore=tool([icacls,target,'/remove:d','*S-1-1-0'])
  if sha((p/'prompt.txt').read_bytes())!=expected['prompt.txt']:raise RuntimeError('ACL fixture bytes changed')
  results[-1]['acl_restored']=restore
 p=root/'fresh';binding,expected=inputs(p,source)
 with admit(p,binding,expected) as a:
  results.append({'row':'fresh','check':a.check,'pins':a.snapshots,'native_calls':a.pins.calls})
 output={'status':'PASS','rows':results,'elapsed_seconds':time.monotonic()-start,'production_execution':False,'power_loss_proven':False}
 with (root/'RESULT.json').open('x') as f:json.dump(output,f,indent=2)
 print(json.dumps({'status':output['status'],'rows':len(results),'elapsed_seconds':output['elapsed_seconds']}))
if __name__=='__main__':
 if os.name!='nt':raise SystemExit('Windows only')
 if len(sys.argv)!=3:raise SystemExit('usage: run_input_matrix.py fresh-root source-sha')
 package=Path(__file__).resolve().parent
 with FilePins(package,[p.name for p in sorted(package.glob('*.py'))]):
  if source_pin()!=sys.argv[2]:raise SystemExit('source pin differs')
  run(Path(sys.argv[1]),sys.argv[2])
