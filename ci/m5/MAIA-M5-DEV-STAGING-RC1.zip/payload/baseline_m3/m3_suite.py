"""One finite qualification package: controls, native admission, native crash matrix."""
import argparse,datetime,json,os,sys,time,unittest
from pathlib import Path
from m3_store import canonical,sha
from m3_execution import source_pin,source_map
from m3_windows import fixture_root,validate_runtime

def main():
 p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--source-sha',required=True);args=p.parse_args()
 runtime=validate_runtime()
 root=fixture_root(args.root)
 if source_pin()!=args.source_sha:raise RuntimeError('SUITE_SOURCE_PIN')
 if root.exists():raise RuntimeError('SUITE_ALREADY_ATTEMPTED_NO_REPLAY')
 root.mkdir(parents=True)
 with (root/'ATTEMPT.json').open('x') as f:json.dump({'source':args.source_sha,'files':source_map(),'no_replay':True,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},f,indent=2)
 started=time.monotonic();result={'status':'INCOMPLETE','runtime_contract':runtime,'source':args.source_sha,'production_execution':False,'apply_permitted':False,'replay_permitted':False}
 try:
  tests=unittest.defaultTestLoader.discover(str(Path(__file__).parent),pattern='test_m3*.py')
  with (root/'PURE_TESTS.log').open('x',encoding='utf-8') as log:r=unittest.TextTestRunner(stream=log,verbosity=2).run(tests)
  result['controls']={'tests':r.testsRun,'errors':len(r.errors),'failures':len(r.failures),'skipped':len(r.skipped),'passed':r.wasSuccessful()}
  if not r.wasSuccessful() or r.skipped:raise RuntimeError('PURE_CONTROLS_REFUSED')
  print(json.dumps({'phase':'CONTROLS','tests':r.testsRun,'passed':True}),flush=True)
  import run_input_matrix
  run_input_matrix.run(root/'input_matrix',args.source_sha)
  result['input_matrix']=json.loads((root/'input_matrix/RESULT.json').read_bytes())
  import run_native_matrix
  before=list(sys.argv)
  try:sys.argv=['run_native_matrix.py','--root',str(root/'crash_matrix'),'--source-sha',args.source_sha];code=run_native_matrix.main()
  finally:sys.argv=before
  result['crash_matrix']=json.loads((root/'crash_matrix/RESULT.json').read_bytes())
  if code!=0 or not result['crash_matrix']['all_rows_qualified']:raise RuntimeError('NATIVE_CRASH_MATRIX_REFUSED')
  if source_pin()!=args.source_sha:raise RuntimeError('SOURCE_DRIFT')
  result['status']='PASS'
 except BaseException as e:
  result['error']=type(e).__name__+':'+str(e);result['status']='STOPPED_NO_REPLAY'
 finally:
  result['elapsed_seconds']=time.monotonic()-started
  with (root/'RESULT.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2,allow_nan=False)
 print(json.dumps({k:v for k,v in result.items() if k not in ('input_matrix','crash_matrix')}),flush=True)
 return 0 if result['status']=='PASS' else 2
if __name__=='__main__':raise SystemExit(main())
