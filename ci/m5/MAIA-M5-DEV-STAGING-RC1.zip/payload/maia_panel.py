#!/usr/bin/env python3
"""MAIA Mission Control v0.3.2 — local monitor and supervised Codex missions.

PowerShell commands require explicit user action. A single approved mission
may run several Codex CLI steps; no existing MAIA Supervisor operation is started.
Standard library only; Python >= 3.9.
"""
from __future__ import annotations

import argparse
import base64
import codecs
import ctypes
import datetime as dt
import http.server
import json
import os
import pathlib
import re
import secrets
import shutil
import stat
import subprocess
import sys
import threading
import time
import urllib.parse
import uuid
import webbrowser
from typing import Any, Optional


VERSION = "0.3.2"
HERE = pathlib.Path(__file__).resolve().parent
RUN_ID_PATTERN = re.compile(r"^[a-zA-Z0-9._-]{1,160}$")
ANSI_PATTERN = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")
MAX_TERMINAL_OUTPUT = 160_000


def read_json(path: pathlib.Path, default: Any = None) -> Any:
    try:
        with path.open("r", encoding="utf-8-sig") as f:
            return json.load(f)
    except (OSError, ValueError, UnicodeError):
        return default


def last_bytes(path: pathlib.Path, limit: int = 24_576) -> str:
    try:
        with path.open("rb") as f:
            f.seek(0, 2)
            size = f.tell()
            start = max(0, size - limit)
            f.seek(start)
            blob = f.read(limit)
        if start:
            sep = blob.find(b"\n")
            if sep >= 0:
                blob = blob[sep + 1:]
        return blob.decode("utf-8-sig", errors="replace")
    except OSError:
        return ""


def last_session_text(path: pathlib.Path, limit: int = 24_576) -> str:
    """Read a tail of Codex SESSION.log in its actual Windows encoding."""
    try:
        with path.open("rb") as f:
            utf16 = f.read(2) == b"\xff\xfe"
            if not utf16:
                return last_bytes(path, limit)
            f.seek(0, 2)
            start = max(2, f.tell() - limit)
            start += start % 2
            f.seek(start)
            blob = f.read(limit)
        if start > 2:
            sep = blob.find(b"\n\x00")
            if sep >= 0:
                blob = blob[sep + 2:]
        return blob.decode("utf-16-le", errors="replace")
    except OSError:
        return ""


def parse_timestamp(s: Any) -> Optional[dt.datetime]:
    if not isinstance(s, str) or not s:
        return None
    try:
        d = dt.datetime.fromisoformat(s.replace("Z", "+00:00"))
        if d.tzinfo is None:
            d = d.replace(tzinfo=dt.timezone.utc)
        return d
    except ValueError:
        return None


def seconds_since(when: Optional[dt.datetime]) -> Optional[float]:
    if when is None:
        return None
    return max(0.0, (dt.datetime.now(dt.timezone.utc) - when).total_seconds())


MAX_CYCLE_PROGRESS_BYTES = 16_384
CYCLE_PROGRESS_STATUSES = frozenset(("active", "waiting", "complete", "error"))


def read_cycle_progress(maia_root: pathlib.Path) -> dict[str, Any]:
    """Read a bounded operator checkpoint; it never supplies supervisor authority."""
    base = maia_root.resolve()
    folder = base / "mission-control-data"
    path = folder / "cycle-progress.json"
    result: dict[str, Any] = {"available": False, "source": str(path), "validation_error": None}

    def reject(reason: str) -> dict[str, Any]:
        return {**result, "validation_error": reason}

    def safe_path() -> bool:
        for entry in (folder, path):
            info = entry.lstat()
            if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400):
                return False
        return folder.resolve(strict=True) == folder and path.resolve(strict=True) == path

    def unique_object(pairs):
        value = {}
        for key, item in pairs:
            if key in value:
                raise ValueError("duplicate JSON key")
            value[key] = item
        return value

    try:
        if not safe_path():
            return reject("reparse_path")
        with path.open("rb") as stream:
            if not stat.S_ISREG(os.fstat(stream.fileno()).st_mode):
                return reject("not_regular_file")
            data = stream.read(MAX_CYCLE_PROGRESS_BYTES + 1)
        if not safe_path():
            return reject("reparse_path")
    except FileNotFoundError:
        return result
    except OSError:
        return reject("read_failed")
    if len(data) > MAX_CYCLE_PROGRESS_BYTES:
        return reject("oversized")
    try:
        record = json.loads(data.decode("utf-8-sig"), object_pairs_hook=unique_object)
    except (ValueError, UnicodeError):
        return reject("malformed_json")
    if not isinstance(record, dict) or type(record.get("schema_version")) is not int or record["schema_version"] != 1:
        return reject("invalid_schema")
    fields = {"cycle_id": 128, "task": 300, "current_action": 1600, "status": 16,
              "updated_utc": 40, "check_result": 1600, "next_step": 1600,
              "checkpoint": 1024, "blocker": 1600}
    for name, limit in fields.items():
        value = record.get(name)
        if not isinstance(value, str) or len(value) > limit or (name != "blocker" and not value.strip()):
            return reject("invalid_field:" + name)
        if any(ord(c) < 32 and c not in "\r\n\t" for c in value):
            return reject("invalid_field:" + name)
    if not RUN_ID_PATTERN.fullmatch(record["cycle_id"]) or record["status"] not in CYCLE_PROGRESS_STATUSES:
        return reject("invalid_cycle_or_status")
    files = record.get("changed_files")
    if not isinstance(files, list) or len(files) > 30 or any(
        not isinstance(value, str) or not value.strip() or len(value) > 1024 or any(ord(c) < 32 for c in value)
        for value in files
    ):
        return reject("invalid_field:changed_files")
    try:
        updated = dt.datetime.fromisoformat(record["updated_utc"].replace("Z", "+00:00"))
    except ValueError:
        return reject("invalid_updated_utc")
    if updated.tzinfo is None or updated.utcoffset() != dt.timedelta(0):
        return reject("invalid_updated_utc")
    now = dt.datetime.now(dt.timezone.utc)
    if updated > now:
        return reject("future_updated_utc")
    age = max(0.0, (now - updated).total_seconds())
    return {**result, "available": True, "schema_version": 1,
            **{name: record[name] for name in fields}, "changed_files": list(files),
            "age_seconds": age, "stale_active": record["status"] == "active" and age > 120,
            "operator_checkpoint": True}


def pid_alive(pid: Any) -> Optional[bool]:
    """True/False, or None where process status cannot be determined."""
    try:
        val = int(pid)
        if val < 1:
            return None
    except (TypeError, ValueError, OverflowError):
        return None
    if os.name == "nt":
        try:
            from ctypes import wintypes
            kernel = ctypes.WinDLL("kernel32", use_last_error=True)
            kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
            kernel.OpenProcess.restype = wintypes.HANDLE
            kernel.GetExitCodeProcess.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
            kernel.GetExitCodeProcess.restype = wintypes.BOOL
            kernel.CloseHandle.argtypes = [wintypes.HANDLE]
            kernel.CloseHandle.restype = wintypes.BOOL
            handle = kernel.OpenProcess(0x1000, False, val)
            if not handle:
                err = ctypes.get_last_error()
                return False if err == 87 else None  # invalid parameter (PID absent)
            try:
                code = wintypes.DWORD()
                if not kernel.GetExitCodeProcess(handle, ctypes.byref(code)):
                    return None
                return code.value == 259  # STILL_ACTIVE
            finally:
                kernel.CloseHandle(handle)
        except Exception:
            return None
    try:
        os.kill(val, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return None
    except (OSError, ValueError):
        return None


def file_info(p: pathlib.Path) -> dict[str, Any]:
    try:
        s = p.stat()
        return {
            "bytes": s.st_size,
            "modified_utc": dt.datetime.fromtimestamp(s.st_mtime, tz=dt.timezone.utc).isoformat(),
            "age_seconds": max(0, time.time() - s.st_mtime),
        }
    except OSError:
        return {"bytes": 0, "modified_utc": None, "age_seconds": None}


def latest_heartbeat(path: pathlib.Path) -> dict[str, Any]:
    last_good: dict[str, Any] = {}
    for line in last_bytes(path, 8192).splitlines()[-12:]:
        try:
            record = json.loads(line)
            if isinstance(record, dict) and record.get("at_utc"):
                last_good = record
        except (ValueError, TypeError):
            pass
    when = parse_timestamp(last_good.get("at_utc"))
    return {
        "at_utc": last_good.get("at_utc"),
        "age_seconds": seconds_since(when),
        "worker_alive_at_sample": last_good.get("worker_alive"),
        "run_health_at_sample": last_good.get("run_health"),
        "source": "heartbeat.jsonl" if last_good else "not_available",
    }


def last_codex_report(session_tail: str) -> str:
    """Best effort extraction; never infer a phase from a regex alone."""
    lines = ANSI_PATTERN.sub("", session_tail).splitlines()
    for i in range(len(lines) - 1, -1, -1):
        if lines[i].strip().lower() in ("codex", "assistant"):
            collected = []
            for line in lines[i + 1:i + 12]:
                cleaned = line.strip()
                if cleaned.startswith(("exec", "diff --git", "index ", "--- ", "+++ ", "@@ ")):
                    break
                if not cleaned and collected:
                    break
                if cleaned and not cleaned.startswith(("• Ran", "• Edited", "diff --git")):
                    collected.append(cleaned)
            if collected:
                return " ".join(collected)[:600]
    return "Brak nowego komunikatu opisowego. Szczegóły w logu wykonywania."


class Monitor:
    def __init__(self, root: pathlib.Path, *, stage_source_pin=None, observer=None):
        self.root = root.resolve()
        self.runs = self.root / "runs"
        self.stage_reader = None
        if stage_source_pin is not None:
            from m4_readmodel import StageReadModel
            self.stage_reader = StageReadModel(self.root, stage_source_pin, observer)

    def _safe_run_id(self, run_id: Any) -> Optional[str]:
        if isinstance(run_id, str) and RUN_ID_PATTERN.fullmatch(run_id):
            return run_id
        return None

    def run_dir(self, run_id: str) -> Optional[pathlib.Path]:
        safe = self._safe_run_id(run_id)
        if safe is None:
            return None
        folder = self.runs / safe
        try:
            resolved = folder.resolve()
            if os.path.normcase(str(resolved.parent)) != os.path.normcase(str(self.runs.resolve())):
                return None
        except OSError:
            return None
        return resolved

    def _latest_run(self) -> Optional[str]:
        try:
            candidates = (
                p for p in self.runs.iterdir()
                if p.is_dir() and not p.is_symlink() and self._safe_run_id(p.name)
            )
            newest = max(candidates, key=lambda p: p.stat().st_mtime, default=None)
            return newest.name if newest is not None else None
        except OSError:
            return None

    def snapshot(self) -> dict[str, Any]:
        if self.stage_reader is not None:
            return self.stage_reader.snapshot()
        state = read_json(self.root / "state" / "state.json", {})
        if not isinstance(state, dict):
            state = {}
        queue = read_json(self.root / "queue" / "queue.json", {})
        items = queue.get("items", []) if isinstance(queue, dict) else queue if isinstance(queue, list) else []
        if not isinstance(items, list):
            items = []
        current_id = self._safe_run_id(state.get("current_run_id"))
        displayed_id = current_id or self._latest_run()
        folder = self.run_dir(displayed_id) if displayed_id else None
        log = folder / "SESSION.log" if folder else None
        heartbeat = folder / "heartbeat.jsonl" if folder else None
        logfile = file_info(log) if log else file_info(pathlib.Path("__absent__"))
        hb = latest_heartbeat(heartbeat) if heartbeat else latest_heartbeat(pathlib.Path("__absent__"))
        hb["run_id"] = displayed_id if hb.get("at_utc") else None
        hb["historical"] = False
        # After a STOP, the latest run may not have heartbeat.jsonl. Surface the
        # last *historical* sample from preceding runs, never as a live heartbeat.
        if not hb.get("at_utc") and self.runs.is_dir():
            recent = []
            try:
                for candidate in self.runs.iterdir():
                    if candidate.is_dir() and not candidate.is_symlink() and self._safe_run_id(candidate.name):
                        sample = latest_heartbeat(candidate / "heartbeat.jsonl")
                        sample_time = parse_timestamp(sample.get("at_utc"))
                        if sample_time:
                            recent.append((sample_time, candidate.name, sample))
            except OSError:
                pass
            if recent:
                _, historical_id, hb = max(recent, key=lambda r: r[0])
                hb["run_id"] = historical_id
                hb["historical"] = True
        status = str(state.get("status") or "UNKNOWN")
        process_ids_historical = status != "ACTIVE"
        worker_live = None if process_ids_historical else pid_alive(state.get("current_worker_pid"))
        supervisor_live = None if process_ids_historical else pid_alive(state.get("supervisor_pid"))
        if hb.get("at_utc") and (process_ids_historical or hb.get("run_id") != current_id):
            hb["historical"] = True
        # The state-level heartbeat can be stale while the per-run heartbeat is fresh.
        hb_from_state = state.get("last_heartbeat_utc")
        hb["state_heartbeat_utc"] = hb_from_state
        try:
            disk = shutil.disk_usage(self.root if self.root.exists() else self.root.anchor)
            disk_data = {
                "free_gb": round(disk.free / (1024 ** 3), 2),
                "total_gb": round(disk.total / (1024 ** 3), 2),
            }
        except OSError:
            disk_data = {"free_gb": None, "total_gb": None}
        events = [line.strip() for line in last_bytes(self.root / "logs" / "controller.log", 24000).splitlines() if line.strip()][-18:]
        log_tail = last_session_text(log, 512000) if log else ""
        stop_reason = str(state.get("stop_reason") or "")
        closure_report = last_bytes(folder / "FINAL.md", 1800) if folder else ""
        # This is only a *reported* result. The supervisor's verdict is authoritative.
        candidate = None
        candidate_source = None
        for source_name, source_text in (("FINAL.md", closure_report), ("SESSION.log", log_tail)):
            for verdict_name in ("CLOSED_READY", "READY_FOR_INDEPENDENT_REVIEW", "APPROVED_WITH_NONBLOCKING_FOLLOWUP", "APPROVED", "CHANGES_REQUIRED"):
                if re.search(r"(?<![A-Za-z0-9_])" + verdict_name + r"(?![A-Za-z0-9_])", source_text):
                    candidate = verdict_name
                    candidate_source = source_name
                    break
            if candidate:
                break
        active_flag = status.upper() == "ACTIVE"
        activity_age = logfile["age_seconds"]
        if not active_flag:
            attention = "stopped" if "STOP" in status.upper() else "idle"
        elif supervisor_live is False or worker_live is False:
            attention = "process_exited"
        elif activity_age is not None and activity_age < 40:
            attention = "output_live"
        elif not hb.get("historical") and hb["age_seconds"] is not None and hb["age_seconds"] < 50:
            attention = "heartbeat_live"
        elif activity_age is not None and activity_age < 150:
            attention = "quiet"
        else:
            attention = "no_recent_evidence"
        accepted_verdict = state.get("verdict")
        if status == "PIPELINE_COMPLETE" and isinstance(accepted_verdict, str) and accepted_verdict.strip():
            report = accepted_verdict
            report_source = "supervisor.verdict"
        else:
            report = last_codex_report(log_tail)
            report_source = "SESSION.log"
        return {
            "server_time_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
            "root": str(self.root),
            "source_available": (self.root / "state" / "state.json").is_file(),
            "state": {k: state.get(k) for k in (
                "status", "run_health", "current_run_id", "current_prompt_id",
                "current_stage", "expected_milestone", "current_worker_pid",
                "supervisor_pid", "current_worktree", "current_branch",
                "started_utc", "last_heartbeat_utc", "stop_reason", "verdict", "exit_code")},
            "queue": [str(v) for v in items][:30],
            "displayed_run_id": displayed_id,
            "displayed_run_is_current": not process_ids_historical and current_id is not None and displayed_id == current_id,
            "run_dir": str(folder) if folder else None,
            "supervisor_alive": supervisor_live,
            "worker_alive": worker_live,
            "process_ids_historical": process_ids_historical,
            "heartbeat": hb,
            "session_log": logfile,
            "last_report": report,
            "last_report_source": report_source,
            "cycle_progress": read_cycle_progress(self.root.parent),
            "closure_diagnostic": {
                "parser_rejected": "VERDICT_PARSE_FAILURE" in stop_reason,
                "reason": stop_reason,
                "reported_candidate": candidate,
                "candidate_source": candidate_source,
                "candidate_is_accepted": False if "VERDICT_PARSE_FAILURE" in stop_reason else None,
                "final_md_available": bool(closure_report),
            },
            "disk": disk_data,
            "attention": attention,
            "events": events,
        }

    def log_chunk(self, run_id: str, cursor: Optional[int], max_bytes: int = 131072) -> dict[str, Any]:
        folder = self.run_dir(run_id)
        if folder is None:
            return {"error": "invalid_run_id", "text": "", "cursor": 0}
        path = folder / "SESSION.log"
        try:
            with path.open("rb") as f:
                utf16 = f.read(2) == b"\xff\xfe"
                f.seek(0, 2)
                end = f.tell()
                truncated = cursor is not None and cursor > end
                if cursor is None or truncated:
                    start = max(2 if utf16 else 0, end - 82_000)
                    if utf16:
                        start += start % 2
                    f.seek(start)
                    data = f.read(max_bytes)
                    if start > (2 if utf16 else 0):
                        sep = b"\n\x00" if utf16 else b"\n"
                        pos = data.find(sep)
                        if pos != -1:
                            data = data[pos + len(sep):]
                    next_cursor = f.tell()
                else:
                    start = max(0, int(cursor))
                    if utf16:
                        start = max(2, start + start % 2)
                    f.seek(start)
                    data = f.read(max_bytes)
                    next_cursor = f.tell()
                return {
                    "text": data.decode("utf-16-le" if utf16 else "utf-8", errors="replace"),
                    "cursor": next_cursor,
                    "reset": cursor is None or truncated,
                    "total_bytes": end,
                }
        except OSError:
            return {"text": "", "cursor": 0, "reset": True, "total_bytes": 0}


def clean_powershell_clixml(output: str) -> str:
    """Hide nonessential PS progress XML, retaining any serialized errors."""
    if '#< CLIXML' not in output:
        return output
    head, raw = output.rsplit('#< CLIXML', 1)
    try:
        import xml.etree.ElementTree as ET
        root = ET.fromstring(raw.strip())
        warnings = []
        for item in root.iter():
            if item.tag.split('}')[-1] == 'S' and item.attrib.get('S') in ('Error', 'Warning'):
                text = (item.text or '').strip()
                text = re.sub(r'_x([0-9a-fA-F]{4})_',
                              lambda m: chr(int(m.group(1), 16)), text)
                if text:
                    warnings.append(text)
        return head.rstrip() + (('\n' if head.strip() else '') + ''.join(warnings) if warnings else '') + '\n'
    except Exception:
        # Retain original content if xml is truncated or malformed; do not hide errors.
        return output


class TerminalJob:
    def __init__(self, command: str):
        self.id = uuid.uuid4().hex[:12]
        self.command = command
        self.started = time.monotonic()
        self.buffer = ""
        self.done = False
        self.exit_code: Optional[int] = None
        self.error: Optional[str] = None
        self.pid: Optional[int] = None
        self.proc: Optional[subprocess.Popen] = None
        self.lock = threading.Lock()

    def append(self, data: str) -> None:
        with self.lock:
            self.buffer += data
            if len(self.buffer) > MAX_TERMINAL_OUTPUT:
                self.buffer = "[...starszy wynik pominięty...]\n" + self.buffer[-(MAX_TERMINAL_OUTPUT - 40):]

    def result(self) -> dict[str, Any]:
        with self.lock:
            return {
                "id": self.id,
                "output": self.buffer,
                "done": self.done,
                "exit_code": self.exit_code,
                "error": self.error,
                "pid": self.pid,
                "elapsed_seconds": round(time.monotonic() - self.started, 1),
            }


class Terminal:
    def __init__(self, root: pathlib.Path, executable: Optional[str] = None):
        self.root = root
        self.shell = executable or shutil.which("powershell.exe") or shutil.which("pwsh.exe")
        self.lock = threading.Lock()
        self.job: Optional[TerminalJob] = None

    def start(self, command: str) -> tuple[Optional[TerminalJob], Optional[str]]:
        if not self.shell:
            return None, "powershell.exe nie jest dostępny w PATH"
        if not isinstance(command, str) or not command.strip() or len(command) > 5000:
            return None, "Polecenie musi mieć od 1 do 5000 znaków"
        with self.lock:
            if self.job and not self.job.result()["done"]:
                return None, "Poprzednie polecenie PowerShell nadal jest wykonywane"
            job = TerminalJob(command)
            self.job = job
            thread = threading.Thread(target=self._execute, args=(job,), daemon=True)
            thread.start()
            return job, None

    def _execute(self, job: TerminalJob) -> None:
        # Separate noninteractive PowerShell process per command; independent of Codex.
        # -EncodedCommand avoids quoting and non-ASCII command corruption.
        ps_script = (
            "[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false); "
            "$OutputEncoding = [System.Text.UTF8Encoding]::new($false); "
            + job.command
        )
        encoded = base64.b64encode(ps_script.encode("utf-16-le")).decode("ascii")
        args = [self.shell, "-NoLogo", "-NoProfile", "-NonInteractive", "-EncodedCommand", encoded]
        kwargs: dict[str, Any] = {
            "cwd": str(self.root) if self.root.is_dir() else None,
            "stdin": subprocess.DEVNULL,
            "stdout": subprocess.PIPE,
            "stderr": subprocess.STDOUT,
            "bufsize": 0,
        }
        if os.name == "nt":
            kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        try:
            proc = subprocess.Popen(args, **kwargs)
            with job.lock:
                job.proc = proc
                job.pid = proc.pid
            decoder = codecs.getincrementaldecoder("utf-8")("replace")
            assert proc.stdout is not None
            while True:
                raw = os.read(proc.stdout.fileno(), 4096)
                if not raw:
                    break
                job.append(decoder.decode(raw))
            job.append(decoder.decode(b"", final=True))
            code = proc.wait()
            proc.stdout.close()
            with job.lock:
                job.buffer = clean_powershell_clixml(job.buffer)
                job.exit_code = code
        except Exception as exc:
            with job.lock:
                job.error = "%s: %s" % (type(exc).__name__, exc)
        finally:
            with job.lock:
                job.done = True

    def status(self, job_id: str) -> Optional[dict[str, Any]]:
        with self.lock:
            if self.job is None or self.job.id != job_id:
                return None
            return self.job.result()

    def cancel(self, job_id: str) -> bool:
        """Stop only a PowerShell process created by this panel, never a MAIA worker."""
        with self.lock:
            job = self.job
            if job is None or job.id != job_id:
                return False
            with job.lock:
                proc = job.proc
                if job.done:
                    return True
            if proc is None:
                return False
            if proc.poll() is None:
                proc.terminate()
            return True


class PanelHTTP(http.server.ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, address: tuple[str, int], monitor: Monitor, terminal=None, *, staging=False):
        super().__init__(address, Handler)
        self.monitor = monitor
        self.terminal = terminal
        self.token = secrets.token_urlsafe(32)
        self.staging = staging
        if staging:
            return
        global TASK_ID
        from maia_copilot import Copilot
        from maia_ops import Missions, TASK_ID
        self.copilot = Copilot(monitor)
        self.missions = Missions(monitor.root)
        self.missions.busy_checker = lambda: bool(self.copilot.job and not self.copilot.job.result()["done"] and self.copilot.job.provider == "codex")


class Handler(http.server.BaseHTTPRequestHandler):
    server: PanelHTTP
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt: str, *args: Any) -> None:
        # Do not echo commands or tokens to console.
        if sys.stderr:
            sys.stderr.write("[MAIA Panel] %s\n" % (fmt % args).split("?", 1)[0])

    def _authorized(self) -> bool:
        return secrets.compare_digest(self.headers.get("X-MAIA-Token", ""), self.server.token)

    def _origin_ok(self) -> bool:
        origin = self.headers.get("Origin")
        expected = "http://127.0.0.1:%d" % self.server.server_address[1]
        return not origin or origin == expected

    def _host_ok(self) -> bool:
        return self.headers.get("Host") == "127.0.0.1:%d" % self.server.server_address[1]

    def _send(self, payload: bytes, ctype: str, status: int = 200) -> None:
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
        self.end_headers()
        self.wfile.write(payload)

    def _json(self, data: Any, status: int = 200) -> None:
        self._send(json.dumps(data, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8", status)

    def do_GET(self) -> None:
        if not self._host_ok():
            return self._json({"error": "invalid_host"}, 403)
        parsed = urllib.parse.urlsplit(self.path)
        route = parsed.path
        if self.server.staging and route not in ("/", "/app.css", "/app.js", "/api/status", "/favicon.ico"):
            return self._json({"error": "staging_read_only"}, 403)
        if route in ("/", "/app.css", "/app.js"):
            sources = {
                "/": (HERE / "ui" / "index.html", "text/html; charset=utf-8"),
                "/app.css": (HERE / "ui" / "app.css", "text/css; charset=utf-8"),
                "/app.js": (HERE / "ui" / "app.js", "application/javascript; charset=utf-8"),
            }
            path, ctype = sources[route]
            try:
                content = path.read_bytes()
            except OSError:
                return self._json({"error": "missing_ui_asset"}, 500)
            if route == "/":
                content = content.replace(b"__MAIA_TOKEN__", self.server.token.encode("ascii"))
                if self.server.staging:
                    content = content.replace(b"</head>", b'<meta name="maia-stage" content="readonly"></head>', 1)
            return self._send(content, ctype)
        if route == "/favicon.ico":
            return self._send(b"", "image/x-icon", 204)
        if not self._authorized() or not self._origin_ok():
            return self._json({"error": "unauthorized"}, 403)
        args = urllib.parse.parse_qs(parsed.query)
        if route == "/api/status":
            return self._json(self.server.monitor.snapshot())
        if route == "/api/log":
            run_id = args.get("run", [""])[0]
            raw_cursor = args.get("cursor", [None])[0]
            try:
                cursor = None if raw_cursor is None else int(raw_cursor)
                if cursor is not None and (cursor < 0 or cursor > 10 ** 12):
                    raise ValueError("invalid cursor")
            except ValueError:
                return self._json({"error": "invalid_cursor"}, 400)
            result = self.server.monitor.log_chunk(run_id, cursor)
            return self._json(result, 400 if result.get("error") else 200)
        if route == "/api/missions/capabilities":
            return self._json(self.server.missions.capabilities())
        if route == "/api/missions":
            return self._json(self.server.missions.summary())
        if route == "/api/missions/detail":
            task = self.server.missions.detail(args.get("id", [""])[0])
            return self._json(task if task else {"error":"no_such_mission"}, 200 if task else 404)
        if route == "/api/missions/log":
            value = self.server.missions.log(args.get("id", [""])[0])
            return self._json(value, 404 if value.get("error") else 200)
        if route == "/api/missions/changes":
            value = self.server.missions.changes(args.get("id", [""])[0])
            return self._json(value, 404 if value.get("error") else 200)
        if route == "/api/copilot/capabilities":
            return self._json(self.server.copilot.capabilities())
        if route == "/api/copilot/status":
            job = self.server.copilot.status(args.get("job", [""])[0])
            return self._json(job if job is not None else {"error": "no_such_job"}, 200 if job else 404)
        if route == "/api/terminal/status":
            job = self.server.terminal.status(args.get("job", [""])[0])
            return self._json(job if job is not None else {"error": "no_such_job"}, 200 if job else 404)
        return self._json({"error": "not_found"}, 404)

    def do_POST(self) -> None:
        if self.server.staging:
            self.close_connection = True
            return self._json({"error": "staging_read_only"}, 403)
        if not self._host_ok() or not self._authorized() or not self._origin_ok():
            self.close_connection = True
            return self._json({"error": "unauthorized"}, 403)
        route = urllib.parse.urlsplit(self.path).path
        if route not in ("/api/terminal/run", "/api/terminal/cancel", "/api/copilot/ask", "/api/copilot/cancel",
                         "/api/missions/create", "/api/missions/control") :
            return self._json({"error": "not_found"}, 404)
        try:
            count = int(self.headers.get("Content-Length", "0"))
            if count <= 0 or count > (65_000 if route.startswith("/api/copilot/") else 16_000):
                self.close_connection = True
                return self._json({"error": "invalid_size"}, 413)
            obj = json.loads(self.rfile.read(count).decode("utf-8"))
            if route == "/api/missions/create":
                if self.server.copilot.job and not self.server.copilot.job.result()["done"] and self.server.copilot.job.provider == "codex":
                    return self._json({"error":"Copilot Codex is running; wait or stop before starting a mission"}, 409)
                task, error = self.server.missions.create(obj)
                return self._json({"error": error} if error else task, 409 if error else 202)
            if route == "/api/missions/control":
                if not isinstance(obj, dict):
                    return self._json({"error":"invalid_payload"}, 400)
                task, error = self.server.missions.request(str(obj.get("id", "")), str(obj.get("action", "")))
                return self._json({"error": error} if error else task, 409 if error else 200)
            if route == "/api/copilot/cancel":
                job_id = obj.get("id", "") if isinstance(obj, dict) else ""
                cancelled = self.server.copilot.cancel(job_id)
                return self._json({"cancelled": cancelled}, 200 if cancelled else 404)
            if route == "/api/copilot/ask":
                if isinstance(obj, dict) and obj.get("provider") == "codex" and self.server.missions.has_busy():
                    return self._json({"error":"Another Codex mission is running, paused or requires recovery"}, 409)
                job, error = self.server.copilot.start(obj)
                if error:
                    return self._json({"error": error}, 409)
                return self._json({"id": job.id, "provider": job.provider}, 202)
            if route == "/api/terminal/cancel":
                job_id = obj.get("id", "") if isinstance(obj, dict) else ""
                cancelled = self.server.terminal.cancel(job_id)
                return self._json({"cancelled": cancelled}, 200 if cancelled else 404)
            command = obj.get("command") if isinstance(obj, dict) else None
            job, error = self.server.terminal.start(command)
            if error:
                return self._json({"error": error}, 409)
            return self._json({"id": job.id}, 202)
        except (ValueError, UnicodeError) as exc:
            return self._json({"error": "invalid_json"}, 400)



def start_stage_server(root, source_pin, observer=None):
    """Start the actual read-only monitor/Handler on an ephemeral loopback port."""
    monitor = Monitor(pathlib.Path(root), stage_source_pin=source_pin, observer=observer)
    server = PanelHTTP(("127.0.0.1", 0), monitor, staging=True)
    server.ui_url = "http://127.0.0.1:%d/" % server.server_address[1]
    server.stage_thread = threading.Thread(target=server.serve_forever, daemon=True)
    server.thread = server.stage_thread
    server.stage_thread.start()
    return server


def open_panel_window(url: str) -> None:
    """On Windows prefer a lightweight Edge app window, otherwise use browser."""
    if os.name == "nt":
        candidates = [shutil.which("msedge.exe")]
        for key in ("PROGRAMFILES(X86)", "PROGRAMFILES", "LOCALAPPDATA"):
            base = os.environ.get(key)
            if base:
                candidates.append(os.path.join(base, "Microsoft", "Edge", "Application", "msedge.exe"))
        for executable in candidates:
            if executable and os.path.isfile(executable):
                try:
                    subprocess.Popen([executable, "--app=" + url, "--window-size=1440,900"],
                                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    return
                except OSError:
                    pass
    webbrowser.open(url)


def main() -> int:
    parser = argparse.ArgumentParser(description="MAIA Mission Control (local monitoring)")
    parser.add_argument("--root", default=r"C:\MAIA\orchestrator")
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--stage-source-pin", help="Pinned M4 source digest; read-only staging only")
    parser.add_argument("--port", type=int, default=0)
    args = parser.parse_args()
    root = pathlib.Path(args.root)
    if not (root / "state" / "state.json").is_file():
        print("UWAGA: Nie znaleziono state/state.json w %s" % root)
        print("Panel otworzy się, ale pokaże brak źródła danych. Sprawdź --root.")
    monitor = Monitor(root, stage_source_pin=args.stage_source_pin)
    terminal = None if args.stage_source_pin else Terminal(root)
    if not 0 <= args.port <= 65535:
        parser.error("--port must be between 0 and 65535")
    server = PanelHTTP(("127.0.0.1", args.port), monitor, terminal, staging=bool(args.stage_source_pin))
    url = "http://127.0.0.1:%d/" % server.server_address[1]
    print("=" * 67)
    print(" MAIA MISSION CONTROL v%s — monitoring, misje, PowerShell i AI" % VERSION)
    print(" Źródło: %s" % monitor.root)
    print(" Adres: %s" % url)
    print(" Ctrl+C zatrzymuje panel i jego wlasnego agenta; supervisor MAIA pozostaje nietkniety.")
    print("=" * 67, flush=True)
    if not args.no_browser:
        threading.Timer(0.65, lambda: open_panel_window(url)).start()
    try:
        server.serve_forever(poll_interval=0.4)
    except KeyboardInterrupt:
        print("\nZamknięto panel. Supervisor MAIA pozostał nietknięty; aktywne misje panelu proszą o STOP.")
    finally:
        if not server.staging:
            server.missions.close()
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
