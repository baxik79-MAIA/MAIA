"""Portable native-boundary controls; no actual Windows share denial claimed."""
import copy,ctypes as C,hashlib,unittest
from pathlib import PureWindowsPath
from unittest.mock import patch
import m4_native as m

class RuntimeAPI:
    instances=[];content={'python':b'fixed Python runtime bytes','powershell':b'fixed PowerShell runtime bytes'}
    links={'python':1,'powershell':2};fault=None
    def __init__(self):
        self.calls=[];self.handles={};self.reads={};self.next=100;self.frozen=False;type(self).instances.append(self)
    def kind(self,path):return 'powershell'if PureWindowsPath(path).name.casefold()=='powershell.exe'else 'python'
    def call(self,name,*args,crypt=False):
        row={'name':name,'state':'RETURNED'};self.calls.append(row)
        if name=='CreateFileW':
            self.next+=1;self.handles[self.next]=(args[0],bool(args[5]&0x2000000));self.reads[self.next]=0
            row.update(path=args[0],access=args[1],share=args[2],flags=args[5],handle=self.next)
            return self.next,0
        if name=='GetFinalPathNameByHandleW':
            path,isdir=self.handles[args[0].value]
            if self.fault=='final_path'and not isdir:path=str(PureWindowsPath(path).parent/'other.exe')
            value='\\\\?\\'+path;buffer=C.create_unicode_buffer(value);C.memmove(args[1],buffer,C.sizeof(buffer));return len(value),0
        if name=='GetDriveTypeW':return 3,0
        raise AssertionError(name)
    def true(self,name,*args,crypt=False):
        self.calls.append({'name':name,'state':'RETURNED'})
        if name=='GetFileInformationByHandle':
            handle=args[0].value;path,isdir=self.handles[handle];kind=self.kind(path);info=args[1]._obj
            info.attributes=0x10 if isdir else 32
            if self.fault=='parent_reparse'and isdir or self.fault=='file_reparse'and not isdir:info.attributes|=0x400
            if self.fault=='file_directory'and not isdir:info.attributes|=0x10
            info.links=1 if isdir else self.links[kind];info.volume=11;info.index_low=handle;info.created.low=1;info.written.low=2
            info.size_low=0 if isdir else len(self.content[kind])
            if self.fault=='oversize'and not isdir:info.size_low=16*1024*1024+1
            if self.reads[handle]and not isdir:
                if self.fault=='changed_identity':info.index_low+=1
                if self.fault=='changed_size':info.size_low+=1
                if self.fault=='changed_links':info.links+=1
                if self.fault=='changed_written':info.written.low+=1
            return 1
        if name=='GetVolumeInformationByHandleW':
            buffer=C.create_unicode_buffer('NTFS');C.memmove(args[6],buffer,C.sizeof(buffer));return 1
        if name=='ReadFile':
            handle=args[0].value;path,isdir=self.handles[handle];kind=self.kind(path);offset=self.reads[handle]
            raw=self.content[kind][offset:offset+args[2]]
            if self.fault=='short':raw=raw[:-1]
            C.memmove(args[1],raw,len(raw));args[3]._obj.value=len(raw);self.reads[handle]+=len(raw);return 1
        raise AssertionError(name)
    def close(self,handle):
        self.calls.append({'name':'CloseHandle','state':'RETURNED','handle':handle})
        if self.fault=='close'and not self.handles[handle][1]:raise m.Refusal('simulated close refused')

class RuntimeControls(unittest.TestCase):
    def setUp(self):
        RuntimeAPI.instances=[];RuntimeAPI.links={'python':1,'powershell':2};RuntimeAPI.fault=None
        RuntimeAPI.content={'python':b'fixed Python runtime bytes','powershell':b'fixed PowerShell runtime bytes'}
        self.fixed={kind:dict(pin,sha256=hashlib.sha256(RuntimeAPI.content[kind]).hexdigest())for kind,pin in m.RUNTIME_PINS.items()}
        self.runtime={kind:dict(pin,version='fixture')for kind,pin in self.fixed.items()}
        for p in (patch.object(m,'RUNTIME_PINS',self.fixed),patch.object(m,'Path',PureWindowsPath),patch.object(m.native,'Path',PureWindowsPath),patch.object(m.native,'_Native',RuntimeAPI)):
            p.start();self.addCleanup(p.stop)
    def assert_closed_once(self,pins):
        for api in RuntimeAPI.instances:
            opened=[row['handle']for row in api.calls if row['name']=='CreateFileW']
            closed=[row['handle']for row in api.calls if row['name']=='CloseHandle']
            self.assertCountEqual(closed,opened);self.assertEqual(len(closed),len(set(closed)))
    def test_fixed_serviced_powershell_hardlinks_are_pinned_and_held_to_context_exit(self):
        pins=m.RuntimePins(self.runtime)
        with pins:
            self.assertTrue(pins.verify());self.assertEqual(pins.proof['powershell']['hard_links'],2)
            self.assertEqual(pins.proof['python']['hard_links'],1)
            self.assertEqual(pins.proof['powershell']['sha256'],self.fixed['powershell']['sha256'])
            self.assertEqual(pins.proof['powershell']['identity'][0],11)
            self.assertFalse(any(row['name']=='CloseHandle'for row in pins.calls))
            files=[row for row in pins.calls if row['name']=='CreateFileW'and not row['flags']&0x2000000]
            self.assertEqual(len(files),2)
            for row in files:self.assertEqual((row['access'],row['share'],row['flags']),(m.native.READ,1,0x200000))
        self.assert_closed_once(pins)
        with self.assertRaises(m.Refusal):pins.verify()
        before=list(pins.calls)
        with self.assertRaises(m.Refusal):pins.__exit__(None,None,None)
        self.assertEqual(before,pins.calls)
    def test_fixed_path_and_sha_admission_precede_every_native_call(self):
        for kind,field,value in [('powershell','path','C:/other/powershell.exe'),('powershell','sha256','0'*64),('python','path','C:/other/python.exe'),('python','sha256','0'*64)]:
            runtime=copy.deepcopy(self.runtime);runtime[kind][field]=value
            with self.subTest(kind=kind,field=field),self.assertRaises(m.Refusal):m.RuntimePins(runtime)
        self.assertEqual(RuntimeAPI.instances,[])
    def test_runtime_map_and_version_shape_are_exact(self):
        for runtime in ({'python':self.runtime['python']},{**self.runtime,'extra':self.runtime['python']},dict(self.runtime,powershell={**self.runtime['powershell'],'version':True}),dict(self.runtime,powershell={**self.runtime['powershell'],'version':[5,True]})):
            with self.subTest(runtime=runtime),self.assertRaises(m.Refusal):m.RuntimePins(runtime)
        self.assertEqual(RuntimeAPI.instances,[])
    def test_only_fixed_powershell_may_have_multiple_existing_hardlinks(self):
        RuntimeAPI.links['python']=2;pins=m.RuntimePins(self.runtime)
        with self.assertRaises(m.Refusal):pins.__enter__()
        self.assert_closed_once(pins)
        RuntimeAPI.links['python']=1;RuntimeAPI.links['powershell']=0;pins=m.RuntimePins(self.runtime)
        with self.assertRaises(m.Refusal):pins.__enter__()
        self.assert_closed_once(pins)
        RuntimeAPI.links['powershell']=4
        with m.RuntimePins(self.runtime)as pins:self.assertEqual(pins.proof['powershell']['hard_links'],4)
    def test_actual_bytes_must_match_fixed_pin(self):
        RuntimeAPI.content['powershell']=b'changed runtime';pins=m.RuntimePins(self.runtime)
        with self.assertRaisesRegex(m.Refusal,'runtime executable bytes differ'):pins.__enter__()
        self.assert_closed_once(pins)
    def test_reparse_type_path_and_size_fail_closed(self):
        for fault in ('parent_reparse','file_reparse','file_directory','final_path','oversize','short'):
            RuntimeAPI.fault=fault;pins=m.RuntimePins(self.runtime)
            with self.subTest(fault=fault),self.assertRaises(m.Refusal):pins.__enter__()
            self.assert_closed_once(pins)
    def test_identity_size_links_and_write_time_are_stable_during_read(self):
        for fault in ('changed_identity','changed_size','changed_links','changed_written'):
            RuntimeAPI.fault=fault;pins=m.RuntimePins(self.runtime)
            with self.subTest(fault=fault),self.assertRaisesRegex(m.Refusal,'runtime changed during read'):pins.__enter__()
            self.assert_closed_once(pins)
    def test_retained_verification_detects_later_metadata_change_without_reopen(self):
        with m.RuntimePins(self.runtime)as pins:
            opens=sum(row['name']=='CreateFileW'for row in pins.calls);RuntimeAPI.fault='changed_written'
            with self.assertRaisesRegex(m.Refusal,'retained runtime identity changed'):pins.verify()
            self.assertEqual(sum(row['name']=='CreateFileW'for row in pins.calls),opens)
        self.assert_closed_once(pins)
    def test_source_input_filepins_remain_single_link(self):
        path=PureWindowsPath(self.fixed['powershell']['path']);pins=m.FilePins(path.parent,[path.name])
        with self.assertRaisesRegex(m.Refusal,'ordinary single-link file required'):pins.__enter__()
        self.assert_closed_once(pins)
    def test_failed_close_is_journaled_once_and_never_replayed(self):
        pins=m.RuntimePins(self.runtime);pins.__enter__();RuntimeAPI.fault='close'
        with self.assertRaisesRegex(m.Refusal,'runtime pin cleanup'):pins.__exit__(None,None,None)
        before=list(pins.calls);self.assert_closed_once(pins)
        with self.assertRaises(m.Refusal):pins.__exit__(None,None,None)
        self.assertEqual(before,pins.calls)

class JobAccountingAPI:
    short=False;member_fault=None
    def __init__(self):self.calls=[];self.frozen=False
    def call(self,name,*args,**kwargs):
        self.calls.append({'name':name,'state':'RETURNED'})
        if name=='CreateJobObjectW':return 101,0
        raise AssertionError(name)
    def true(self,name,*args,**kwargs):
        self.calls.append({'name':name,'state':'RETURNED'})
        if name=='SetInformationJobObject':return 1
        if name=='QueryInformationJobObject':
            info=args[2]._obj
            if args[1]==1:
                info.total=3;info.active=0;info.terminated=0
                args[4]._obj.value=C.sizeof(info)-(1 if self.short else 0);return 1
            if args[1]==3:
                info.assigned=2;info.count=2;info.pids[0]=456;info.pids[1]=123
                args[4]._obj.value=m._JobMembers.pids.offset+2*C.sizeof(m.native.SIZE)
                if self.member_fault=='partial':info.assigned=3
                if self.member_fault=='overflow':info.count=17;info.assigned=17
                if self.member_fault=='duplicate':info.pids[1]=456
                if self.member_fault=='zero':info.pids[1]=0
                if self.member_fault=='pid_overflow':info.pids[1]=0x100000000
                if self.member_fault=='short':args[4]._obj.value-=1
                return 1
            raise AssertionError('wrong job accounting class')
        raise AssertionError(name)
    def close(self,handle):self.calls.append({'name':'CloseHandle','state':'RETURNED'})

class JobAccountingControls(unittest.TestCase):
    def test_os_total_and_active_are_independent_of_limit_termination_counter(self):
        with patch.object(m.native,'_Native',JobAccountingAPI):
            job=m.OwnedJob();proof=job.accounting()
            self.assertEqual(proof,{'total_processes':3,'active_processes':0,'terminated_processes':0})
            self.assertTrue(all(type(v)is int for v in proof.values()));job.close()
            before=list(job.calls)
            with self.assertRaises(m.Refusal):job.accounting()
            self.assertEqual(job.calls,before)
    def test_short_native_accounting_result_cannot_be_used_as_count_evidence(self):
        with patch.object(m.native,'_Native',JobAccountingAPI):
            job=m.OwnedJob();JobAccountingAPI.short=True
            try:
                with self.assertRaisesRegex(m.Refusal,'job accounting shape'):job.accounting()
            finally:JobAccountingAPI.short=False;job.close()
    def test_bounded_job_member_metadata_does_not_reopen_any_process(self):
        with patch.object(m.native,'_Native',JobAccountingAPI):
            job=m.OwnedJob();self.assertEqual(job.members(),[123,456])
            self.assertFalse(any(row['name']=='OpenProcess'for row in job.calls));job.close()
            before=list(job.calls)
            with self.assertRaises(m.Refusal):job.members()
            self.assertEqual(before,job.calls)
    def test_partial_duplicate_invalid_or_short_membership_cannot_reconcile_counts(self):
        with patch.object(m.native,'_Native',JobAccountingAPI):
            for fault in ('partial','overflow','duplicate','zero','pid_overflow','short'):
                job=m.OwnedJob();JobAccountingAPI.member_fault=fault
                try:
                    with self.subTest(fault=fault),self.assertRaises(m.Refusal):job.members()
                finally:JobAccountingAPI.member_fault=None;job.close()

if __name__=='__main__':unittest.main()
