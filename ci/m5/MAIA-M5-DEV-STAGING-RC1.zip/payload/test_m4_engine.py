"""Portable transaction/port controls, not native staging execution evidence."""
import base64,io,json,subprocess,sys,tempfile,time,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from baseline_m3 import m3_store as store_module
sys.modules.setdefault('m3_store',store_module) # Unchanged legacy module's documented flat import.
import m4_engine as e
from m4_admission import analysis_bytes

class Pins:
 def __init__(self,root,names):self.root=Path(root);self.names=names
 def __enter__(self):
  self.buffers={n:(self.root/n).read_bytes()for n in self.names};self.snapshots={n:{'sha256':e.sha(b)}for n,b in self.buffers.items()};return self
 def __exit__(self,*exc):pass
class Outer:
 session='a'*32
 def __init__(self,cut=None):self.events=[];self.stage=None;self.cut=cut
 def send(self,kind,payload,deadline):
  self.events.append((kind,payload));self.stage=payload.get('stage')
  if self.stage==self.cut:raise RuntimeError('simulated outer interruption')
 def receive(self,deadline):return {'kind':'ACK_BARRIER','payload':{'stage':self.stage}}
class Proc:
 def __init__(self):self.stdin=io.BytesIO();self.stdout=io.BytesIO();self.returncode=None
class Native:
 def __init__(self,proc):self.child=proc;self.handle=123;self.calls=[];self.api=SimpleNamespace(frozen=False)
 def identity(self):return {'pid':99,'birth':12345}
 def wait(self,timeout):self.child.returncode=0;return 0
 def close(self):self.calls.append({'name':'CloseHandle','state':'RETURNED','raw':1});return True

class EngineControls(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name);self.binding={'cycle':'b'*32,'source':'c'*64,'inputs':'d'*64};self.key=b'k'*32
  for n in ('prompts','worktree','runs/'+self.binding['cycle']):(self.root/n).mkdir(parents=True,exist_ok=True)
  (self.root/'prompts/prompt.txt').write_bytes(b'prompt');(self.root/'runs'/self.binding['cycle']/'prompt.snapshot.txt').write_bytes(b'prompt');(self.root/'worktree/INPUT.txt').write_bytes(b'input\n');(self.root/'M4_POLICY.json').write_bytes(b'{}')
  (self.root/'prompts'/f"{self.binding['cycle']}.manifest.json").write_bytes(e.canonical({'allowed_verdicts':['STAGING_COMPLETE']}))
  (self.root/'SOURCE_MANIFEST.json').write_bytes(b'{}')
  s=e.Store.create(self.root/'transaction.sqlite',self.binding,e.canonical({'status':'PIPELINE_COMPLETE'}),e.canonical({'items':[]}));s.close()
  self.policy={'runtime':{'powershell':{'path':'C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe'}},'worker_relative':'worker/Run-CodexWorker.ps1'}
  self.outer=Outer();self.engine=e.Engine(self.root,self.root,self.binding,self.key,self.outer,time.monotonic()+45,self.policy);self.engine.open();self.addCleanup(self.engine.close)
 def drive_to_started(self):
  self.engine.command('ENQUEUE',{'prompt_id':self.binding['cycle']});self.engine.command('QUEUE',{})
  with patch.object(e,'FilePins',Pins),patch.object(e,'NativeProcess',Native),patch.object(e.subprocess,'Popen',return_value=Proc())as popen:
   started=self.engine.command('START',{'prompt_id':self.binding['cycle']});args=popen.call_args.args[0]
   self.assertEqual(popen.call_args.kwargs['creationflags'],0x08000000)
  self.assertEqual(self.engine.phase(),'START_INTENT');self.assertEqual(started['remote_handle'],123);self.assertNotIn('-ExecutionPolicy',args);self.assertNotIn('CodexPath',args)
  self.assertEqual(self.engine.launch_entries,1)
  engine=self.engine
  class WorkerWire:
   def __init__(self,*args):self.i=0
   def send(self,kind,payload,deadline):
    if kind=='EFFECT_RELEASE':self_test.assertEqual(engine.phase(),'STARTED')
   def receive(self,deadline):
    self.i+=1;identity={'pid':99,'birth':12345}
    if self.i==1:return {'kind':'EVENT_BARRIER','payload':{'stage':'worker_before_effect','identity':identity}}
    artifact=analysis_bytes(b'input\n',engine.binding)
    if self.i==2:
     (engine.root/'worktree/ANALYSIS.md').write_bytes(artifact)
     return {'kind':'EVENT_BARRIER','payload':{'stage':'worker_after_effect','identity':identity,'artifact_sha256':e.sha(artifact)}}
    semantic={'schema':1,'binding':engine.binding,'profile':e.PROFILE,'status':'SUCCESS','is_error':False,'verdict':'STAGING_COMPLETE','artifact':'worktree/ANALYSIS.md','artifact_sha256':e.sha(artifact),'input_sha256':e.sha(b'input\n'),'identity':identity}
    run=engine.root/'runs'/engine.binding['cycle']
    for n,b in {'semantic-result.json':e.canonical(semantic),'FINAL.md':b'STAGING_COMPLETE\r\n','exit-code.txt':b'0','worker.json':e.canonical({'binding':engine.binding,'worker_pid':99}),'SESSION.log':b'bound result'}.items():(run/n).write_bytes(b)
    return {'kind':'WORKER_RESULT','payload':{'semantic':semantic}}
  self_test=self
  with patch.object(e,'Wire',WorkerWire):self.engine.command('RELEASE',{})
 def test_worker_transport_key_is_distinct_from_dpapi_receipt_key(self):
  self.drive_to_started();self.assertEqual(len(self.engine.worker_key),32);self.assertNotEqual(self.engine.worker_key,self.key)
  e.verify_receipt(self.key,self.engine.started_receipt,self.binding,'STARTED')
  with self.assertRaises(e.ProtocolRefusal):e.verify_receipt(self.engine.worker_key,self.engine.started_receipt,self.binding,'STARTED')
 def test_main_keeps_ephemeral_engine_key_separate_from_receipt_authority(self):
  source=self.root;transport=b't'*32;receipt=b'r'*32;seen={}
  class Admission:
   policy={'source_root':str(source)}
   def __enter__(self):return self
   def __exit__(self,*exc):pass
  class OuterWire:
   def __init__(self,reader,writer,key,*args):self.frozen=False;seen['transport']=key
   def send(self,*args):pass
   def receive(self,*args):return {'kind':'CLOSE','payload':{}}
  class Port:
   def __init__(self,root,source,binding,key,*args):seen['receipt']=key
   def open(self):pass
   def command(self,*args):return {'phase':'COMPLETED'}
   def close(self):pass
  boot={'command':'RUN','session':'a'*32}
  with patch.object(e,'_bootstrap',return_value=(boot,self.root,source,self.binding,transport,time.monotonic()+5)),patch.object(e,'Wire',OuterWire),patch.object(e,'load_inputs',return_value={'expected':{}}),patch.object(e,'admit',return_value=Admission()),patch.object(e,'_runtime'),patch.object(e.KeyVaultM4,'load',return_value=receipt),patch.object(e,'Engine',Port),patch.object(e.sys,'argv',['engine','--role','engine']),patch.object(e.sys,'stdin',SimpleNamespace(buffer=io.BytesIO())),patch.object(e.sys,'stdout',SimpleNamespace(buffer=io.BytesIO())):
   with patch.object(e,'_refuse_restored_run'):code=e.main()
  self.assertEqual(code,0);self.assertEqual(seen,{'transport':transport,'receipt':receipt})
 def test_runtime_pins_outlive_store_work_and_close_once_on_success_or_refusal(self):
  for fail in (False,True):
   with self.subTest(refused=fail):
    source=self.root;events=[];frames=[]
    class Admission:
     policy={'source_root':str(source)}
     def __enter__(self):return self
     def __exit__(self,*exc):events.append('admission_closed')
    class Runtime:
     proof={'powershell':{'hard_links':2}};calls=[]
     def __enter__(self):events.append('runtime_held');return self
     def verify(self):events.append('runtime_verified');return True
     def __exit__(self,*exc):events.append('runtime_closed');self.calls=[{'name':'CloseHandle','state':'RETURNED'}]
    runtime=Runtime()
    class OuterWire:
     frozen=False
     def __init__(self,*args):pass
     def send(self,kind,payload,*args):events.append(kind);frames.append((kind,payload))
     def receive(self,*args):return {'kind':'CLOSE','payload':{}}
    class Port:
     def __init__(self,*args):self.closed=False
     def open(self):events.append('store_work_started')
     def command(self,*args):
      if fail:raise e.Refusal('test forced refusal')
      return {'phase':'COMPLETED'}
     def close(self):
      if not self.closed:self.closed=True;events.append('store_work_settled')
    boot={'command':'RUN','session':'a'*32}
    with patch.object(e,'_bootstrap',return_value=(boot,self.root,source,self.binding,b't'*32,time.monotonic()+5)),patch.object(e,'Wire',OuterWire),patch.object(e,'load_inputs',return_value={'expected':{}}),patch.object(e,'admit',return_value=Admission()),patch.object(e,'_runtime',return_value=runtime),patch.object(e.KeyVaultM4,'load',return_value=b'r'*32),patch.object(e,'Engine',Port),patch.object(e.sys,'argv',['engine','--role','engine']),patch.object(e.sys,'stdin',SimpleNamespace(buffer=io.BytesIO())),patch.object(e.sys,'stdout',SimpleNamespace(buffer=io.BytesIO())):
     with patch.object(e,'_refuse_restored_run'):code=e.main()
    self.assertEqual(code,2 if fail else 0);self.assertEqual(events.count('runtime_closed'),1)
    self.assertLess(events.index('runtime_held'),events.index('store_work_started'))
    self.assertLess(events.index('store_work_settled'),events.index('runtime_closed'))
    if not fail:
     self.assertLess(events.index('runtime_verified'),events.index('runtime_closed'));self.assertLess(events.index('runtime_closed'),events.index('RESULT_CLOSE'))
     payload=dict(frames)['RESULT_CLOSE'];self.assertEqual(payload['runtime_pin_proof'],runtime.proof);self.assertEqual(payload['runtime_pin_calls'],runtime.calls)
 def test_complete_sequence_commits_only_after_semantic_exit_and_closes_once(self):
  self.drive_to_started()
  with patch.object(e,'FilePins',Pins):
   polled=self.engine.command('POLL',{});self.assertTrue(polled['effect_observed']);self.assertEqual(self.engine.phase(),'STARTED')
   final=self.engine.command('FINALIZE',{})
  self.assertEqual(final['phase'],'COMPLETED');self.assertTrue(final['worker_handle_closed']);self.assertEqual(final['worker_exit'],0)
  self.assertEqual([c['name']for c in final['native_calls']],['CloseHandle'])
  self.assertEqual(self.engine.command('CLOSE',{})['phase'],'COMPLETED')
  with self.assertRaises(e.Refusal):self.engine.command('START',{'prompt_id':self.binding['cycle']})
 def test_exit_zero_with_conflicting_core_verdict_cannot_commit_completed(self):
  self.drive_to_started()
  with patch.object(e,'FilePins',Pins):
   self.engine.command('POLL',{});receive=self.engine.worker_wire.receive
   def conflicting(deadline):
    response=receive(deadline)
    # Core accepts UTF8 BOM, case-insensitive property names and scalar strings.
    (self.root/'prompts'/'conflict.manifest.json').write_bytes(b'\xef\xbb\xbf{"ALLOWED_VERDICTS":"REFUSED"}')
    (self.root/'runs'/self.binding['cycle']/'FINAL.md').write_bytes(b'STAGING_COMPLETE\r\nREFUSED\r\n')
    return response
   self.engine.worker_wire.receive=conflicting
   with self.assertRaisesRegex(e.Refusal,'CONFLICTING_VERDICTS'):self.engine.command('FINALIZE',{})
  self.assertEqual(self.engine.worker.returncode,0);self.assertEqual(self.engine.phase(),'STARTED');self.assertIsNone(self.engine.completed_receipt)
  self.assertNotIn('COMPLETED',[r['phase']for r in self.engine.store.inspect()['records']])
 def test_completed_projection_rejects_conflicting_final_postimage_and_stays_not_green(self):
  self.drive_to_started()
  with patch.object(e,'FilePins',Pins):self.engine.command('POLL',{});self.engine.command('FINALIZE',{})
  self.engine.store.close();before=e.authority_image(self.root)
  (self.root/'prompts'/'conflict.manifest.json').write_bytes(e.canonical({'allowed_verdicts':['REFUSED']}))
  (self.root/'runs'/self.binding['cycle']/'FINAL.md').write_bytes(b'STAGING_COMPLETE\nREFUSED\n')
  buffers={'worktree/INPUT.txt':b'input\n','prompts/'+self.binding['cycle']+'.manifest.json':(self.root/'prompts'/f"{self.binding['cycle']}.manifest.json").read_bytes()};info={'binding':self.binding}
  with patch.object(e,'load_inputs',return_value=info),patch.object(e,'_read_inputs',return_value=(info,buffers,{})),patch.object(e.KeyVaultM4,'load',return_value=self.key):value=e.read_projection(self.root,self.binding)
  self.assertEqual(value['phase'],'QUARANTINED');self.assertEqual(value['view'],'QUARANTINED');self.assertIsNone(value['semantic']);self.assertTrue(value['outcome_unknown'])
  from m4_readmodel import _project
  stage=_project(value);self.assertFalse(stage['semantic_success']);self.assertFalse(stage['active']);self.assertEqual(stage['view'],'QUARANTINED')
  self.assertEqual(e.authority_image(self.root),before)
 def test_interruption_after_effect_keeps_started_and_cold_receiver_refuses(self):
  self.drive_to_started();self.outer.cut='worker_after_effect'
  with patch.object(e,'FilePins',Pins),self.assertRaises(RuntimeError):self.engine.command('POLL',{})
  self.assertTrue((self.root/'worktree/ANALYSIS.md').is_file());self.assertEqual(self.engine.phase(),'STARTED')
  fresh=e.Store.open_existing(self.root/'transaction.sqlite',self.binding)
  try:
   with self.assertRaises(StoreRefusal):fresh.claim_receiver('f'*32)
  finally:fresh.close()
 def test_out_of_order_command_cannot_launch_or_enqueue(self):
  with self.assertRaises(e.Refusal):self.engine.command('START',{'prompt_id':self.binding['cycle']})
  self.assertEqual(self.engine.phase(),'PREPARED');self.assertEqual(self.engine.launch_entries,0)
 def test_readonly_projection_preserves_start_phase_and_receipt(self):
  self.drive_to_started();self.engine.store.close();before=e.authority_image(self.root)
  info={'binding':self.binding};buffers={'worktree/INPUT.txt':b'input\n'}
  with patch.object(e,'load_inputs',return_value=info),patch.object(e,'_read_inputs',return_value=(info,buffers,{})),patch.object(e.KeyVaultM4,'load',return_value=self.key):
   value=e.read_projection(self.root,self.binding)
  self.assertEqual(value['phase'],'STARTED');self.assertEqual(value['receipts_authenticated'],['STARTED']);self.assertFalse(value['launch_capability']);self.assertEqual(e.authority_image(self.root),before)
  self.assertEqual(value['view'],'RECONCILIATION_REQUIRED');self.assertTrue(value['outcome_unknown'])

class StrictVerdictControls(unittest.TestCase):
 def test_core_header_normalization_and_global_conflict_rule(self):
  manifest={'allowed_verdicts':['STAGING_COMPLETE']};universe=['STAGING_COMPLETE','REFUSED']
  value=e.strict_verdict(b'\n## **`STAGING_COMPLETE`**\r\nfixed analysis\r\n',manifest,universe)
  self.assertEqual(value,{'ok':True,'verdict':'STAGING_COMPLETE','reason':'OK'})
  self.assertEqual(e.normalize_verdict_line(' **GO - READY** '),'GO \u2014 READY')
  self.assertTrue(e.strict_verdict(b'staging_complete\n',manifest,universe)['ok'])
  value=e.strict_verdict(b'STAGING_COMPLETE\n'+b'body\n'*20+b'REFUSED\n',manifest,universe)
  self.assertFalse(value['ok']);self.assertTrue(value['reason'].startswith('CONFLICTING_VERDICTS:'))
  self.assertTrue(e.strict_verdict(b'STAGING_COMPLETE\nUNREGISTERED_WORD\n',manifest,universe)['ok'])
 def test_core_header_window_counts_nonempty_lines_and_refuses_missing_primary(self):
  manifest={'allowed_verdicts':['STAGING_COMPLETE']}
  self.assertTrue(e.strict_verdict(b'\n'*20+b'body\n'*11+b'STAGING_COMPLETE\n',manifest,['STAGING_COMPLETE'])['ok'])
  self.assertEqual(e.strict_verdict(b'body\n'*12+b'STAGING_COMPLETE\n',manifest,['STAGING_COMPLETE'])['reason'],'PRIMARY_VERDICT_NOT_FOUND_IN_HEADER')
  self.assertEqual(e.strict_verdict(b' \r\n',manifest,[])['reason'],'FINAL_EMPTY')

class RestoredScopeControls(unittest.TestCase):
 def test_restored_run_only_refuses_a_consumed_authenticated_receiver_and_never_opens_rw(self):
  with tempfile.TemporaryDirectory()as folder:
   root=Path(folder);source=root/'restored';source.mkdir();binding={'cycle':'a'*32,'source':'b'*64,'inputs':'c'*64}
   raw=e.canonical({'source_root':str(root/'historical')});(root/'M4_POLICY.json').write_bytes(raw);info={'policy_sha256':e.sha(raw)}
   for quarantined,receiver in ((False,{'session':'d'*32}),(False,None),(True,{'session':'d'*32})):
    view={'binding':binding,'receiver':receiver,'quarantined':quarantined}
    with self.subTest(view=view),patch.object(e,'fixture_root',return_value=source),patch.object(e,'_read_inputs')as read,patch.object(e,'read_projection',return_value=view)as projection,patch.object(e.Store,'open_existing',side_effect=AssertionError('no direct Store open permitted')):
     if receiver is not None and not quarantined:
      with self.assertRaisesRegex(e.StoreRefusal,'^RECEIVER_CLAIM_REFUSED_NO_REPLAY$'):e._refuse_restored_run(root,source,binding,info)
     else:
      with self.assertRaisesRegex(e.Refusal,'restored RUN forbidden'):e._refuse_restored_run(root,source,binding,info)
     read.assert_called_once_with(root,binding,source);projection.assert_called_once_with(root,binding,live=False)

class ColdRefusalWALControls(unittest.TestCase):
 def test_consumed_crashed_receiver_refuses_without_checkpointing_nonempty_wal(self):
  # A real child leaves committed STARTED records in a nonempty WAL by exiting
  # without closing SQLite. A cold RUN refusal must preserve those bytes for S3.
  binding={'cycle':'1'*32,'source':'2'*64,'inputs':'3'*64}
  script='''import json,os,pathlib,sys
sys.path.insert(0,sys.argv[1])
from baseline_m3 import m3_store
sys.modules['m3_store']=m3_store
from baseline_m3.m3_store import Store,canonical
from baseline_m3.m3_protocol import sign_receipt
root=pathlib.Path(sys.argv[2]);binding=json.loads(sys.argv[3])
store=Store.open_existing(root/'transaction.sqlite',binding)
store.claim_receiver('4'*32)
store.enqueue(canonical({'status':'QUEUED','cycle':binding['cycle']}),canonical({'items':[binding['cycle']]}))
store.intent()
store.started(sign_receipt(b'k'*32,dict(binding=binding,kind='STARTED',identity={'pid':123,'birth':456},profile='M4_PROTECTED_PROPOSAL_STAGING',executor='POWERSHELL_STAGING_WORKER')))
(root/'ANALYSIS.fixture').write_bytes(b'one prior effect, no replay')
os._exit(9)
'''
  with tempfile.TemporaryDirectory()as folder:
   root=Path(folder);store=e.Store.create(root/'transaction.sqlite',binding,e.canonical({'status':'PIPELINE_COMPLETE'}),e.canonical({'items':[]}));store.close()
   child=subprocess.run([sys.executable,'-I','-S','-B','-c',script,str(Path(__file__).parent),str(root),json.dumps(binding)],stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=10)
   self.assertEqual(child.returncode,9,child.stderr.decode('utf-8',errors='replace'))
   wal=root/'transaction.sqlite-wal';self.assertGreater(wal.stat().st_size,0)
   before=e.authority_image(root);self.assertIn('transaction.sqlite-wal',before)
   effect=(root/'ANALYSIS.fixture').read_bytes();outer=Outer()
   cold=e.Engine(root,Path(__file__).parent,binding,b'k'*32,outer,time.monotonic()+5,{})
   try:
    with self.assertRaisesRegex(e.StoreRefusal,'^RECEIVER_CLAIM_REFUSED_NO_REPLAY$'):cold.open()
   finally:cold.close()
   self.assertEqual(e.authority_image(root),before)
   self.assertEqual((root/'ANALYSIS.fixture').read_bytes(),effect)
   self.assertEqual((cold.launch_entries,cold.created),(0,0));self.assertIsNone(cold.native)
   self.assertEqual(outer.events,[])
   reader=e.Store.open_existing(root/'transaction.sqlite',binding,readonly=True)
   try:
    recovered=reader.inspect();self.assertEqual(recovered['phase'],'STARTED');self.assertEqual(recovered['receiver']['session'],'4'*32)
   finally:reader.close()
   self.assertEqual(e.authority_image(root),before)

StoreRefusal=store_module.Refusal
if __name__=='__main__':unittest.main()
