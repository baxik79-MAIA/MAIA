"""One persistent transactional/native port driven by the actual staged PS controller."""
from __future__ import annotations
import argparse,base64,hashlib,hmac,json,os,re,secrets,sqlite3,subprocess,sys,time
from pathlib import Path
from baseline_m3.m3_store import Store,Refusal as StoreRefusal,canonical,sha,validate_binding
from baseline_m3.m3_protocol import sign_receipt,verify_receipt,ProtocolRefusal
from m4_wire import Wire,raw_read,Refusal as WireRefusal
from m4_native import KeyVaultM4,NativeProcess,FilePins,RuntimePins,fixture_root,Refusal as NativeRefusal,validate_runtime
from m4_admission import (PROFILE,load_inputs,admit,input_names,parse,analysis_bytes,validate_semantic,_pins,_policy,Refusal as AdmissionRefusal)

class Refusal(RuntimeError):pass
BOOT_KEYS={'v','key_b64','session','binding','root','source_root','source_manifest_sha','source_sha','command','policy_sha256'}
_WS='\t\n\v\f\r \x85\xa0\u1680'+''.join(chr(n)for n in range(0x2000,0x200b))+'\u2028\u2029\u202f\u205f\u3000'
_WS_RE='['+re.escape(_WS)+']'

def normalize_verdict_line(line):
 s=line.strip(_WS);s=re.sub('^'+_WS_RE+'*#{1,6}'+_WS_RE+'*','',s).strip(_WS)
 while len(s)>=4 and(s.startswith('**')and s.endswith('**')or s.startswith('__')and s.endswith('__')):s=s[2:-2].strip(_WS)
 if len(s)>=2 and s[0]=='`'and s[-1]=='`':s=s[1:-1].strip(_WS)
 return re.sub(_WS_RE+'+-'+_WS_RE+'+',' \u2014 ',s.replace('\u2013','\u2014'))

def strict_verdict(final_bytes,manifest,universe):
 """Pure port of Core Get-StrictVerdict for the pinned staging UTF8 inputs."""
 try:text=final_bytes.decode('utf-8-sig')
 except UnicodeError:raise Refusal('strict verdict UTF8')
 if not text.strip(_WS):return {'ok':False,'verdict':None,'reason':'FINAL_EMPTY'}
 allowed=[normalize_verdict_line(v)for v in manifest['allowed_verdicts']]
 if not allowed:return {'ok':False,'verdict':None,'reason':'NO_ALLOWED_VERDICTS'}
 lines=[s for line in re.split('\r?\n',text)if(s:=normalize_verdict_line(line)).strip(_WS)]
 primary=next((line for line in lines[:12]if line.casefold()in{v.casefold()for v in allowed}),None)
 if primary is None:return {'ok':False,'verdict':None,'reason':'PRIMARY_VERDICT_NOT_FOUND_IN_HEADER'}
 known={normalize_verdict_line(v).casefold()for v in universe};distinct={line.casefold():line for line in lines if line.casefold()in known}
 if len(distinct)>1:return {'ok':False,'verdict':None,'reason':'CONFLICTING_VERDICTS:'+'|'.join(distinct[k]for k in sorted(distinct))}
 return {'ok':True,'verdict':primary,'reason':'OK'}

def _strict_final(root,binding,raw,manifest):
 names=sorted('prompts/'+p.name for p in (Path(root)/'prompts').iterdir()if p.is_file()and p.name.casefold().endswith('.manifest.json'))
 own='prompts/'+binding['cycle']+'.manifest.json'
 if own not in names:raise Refusal('strict verdict manifest missing')
 with _pins(root,names)as pins:
  if parse(pins.buffers[own])!=manifest:raise Refusal('strict verdict manifest drift')
  universe=[]
  for name in names:
   try:
    candidate=json.loads(pins.buffers[name].decode('utf-8-sig'),parse_constant=lambda _:(_ for _ in ()).throw(Refusal('strict universe nonfinite')))
   except (ValueError,UnicodeError):raise Refusal('strict universe unparseable manifest')
   if type(candidate)is not dict:continue
   fields=[v for k,v in candidate.items()if k.casefold()=='allowed_verdicts']
   if len(fields)>1:raise Refusal('strict universe ambiguous manifest properties')
   if not fields:continue
   values=fields[0]if type(fields[0])is list else [fields[0]]
   if any(v is not None and type(v)is not str for v in values):raise Refusal('strict universe verdict type')
   universe.extend(v for v in values if v is not None and v.strip(_WS))
  result=strict_verdict(raw,manifest,universe)
 if not result['ok']or result['verdict']!='STAGING_COMPLETE':raise Refusal('strict verdict:'+result['reason'])
 return result

def authority_image(root):
 root=Path(root);out={}
 for name in ('transaction.sqlite','transaction.sqlite-wal'):
  p=root/name
  if p.exists():
   raw=p.read_bytes()
   if name.endswith('-wal')and raw==b'':continue
   out[name]=sha(raw)
 return out

def _read_inputs(root,binding,actual_source_root):
 info=load_inputs(root,binding);names=input_names(binding['cycle'])
 with _pins(root,names) as pins:
  if any(pins.snapshots[n]['sha256']!=info['expected'][n] for n in names):raise Refusal('projection input drift')
  buffers=dict(pins.buffers);policy=parse(buffers['M4_POLICY.json'])
  # A byte-identical read-only restored capsule may replace the historical
  # source directory. This changes no persisted input or execution permission.
  verified=_policy(dict(policy,source_root=str(actual_source_root)),Path(root),binding)
 return info,buffers,policy

def read_projection(root,binding_or_source_sha,live=False):
 root=Path(root);binding=None
 try:
  info=load_inputs(root);binding=info['binding']
  if isinstance(binding_or_source_sha,dict):
   if validate_binding(binding_or_source_sha)!=binding:raise Refusal('projection binding differs')
  elif type(binding_or_source_sha)is not str or binding['source']!=binding_or_source_sha:raise Refusal('projection source differs')
  if type(live)is not bool:raise Refusal('projection live flag')
  before=authority_image(root) if not live else None
  info,buffers,policy=_read_inputs(root,binding,Path(__file__).parent.absolute())
  key=KeyVaultM4.load(root,binding)
  store=Store.open_existing(root/'transaction.sqlite',binding,readonly=True)
  try:value=store.inspect()
  finally:store.close()
  verified=[];identity=None;semantic=None
  for event in value['records']:
   if event['phase']in ('STARTED','COMPLETED'):
    receipt=event['payload']['receipt'];body=verify_receipt(key,receipt,binding,event['phase'])
    if body.get('profile')!=PROFILE or body.get('executor')!='POWERSHELL_STAGING_WORKER':raise Refusal('historical executor binding')
    identity=body['identity'];verified.append(event['phase'])
    if event['phase']=='COMPLETED':
     if type(body.get('worker_exit'))is not int or body['worker_exit']!=0 or body.get('exit_code')!=0:raise Refusal('historical worker exit')
     with _pins(root,['worktree/ANALYSIS.md','runs/'+binding['cycle']+'/semantic-result.json','runs/'+binding['cycle']+'/FINAL.md']) as resultpins:
      artifact=resultpins.buffers['worktree/ANALYSIS.md'];semantic=parse(resultpins.buffers['runs/'+binding['cycle']+'/semantic-result.json'])
      _strict_final(root,binding,resultpins.buffers['runs/'+binding['cycle']+'/FINAL.md'],parse(buffers['prompts/'+binding['cycle']+'.manifest.json']))
     validate_semantic(semantic,binding,artifact,buffers['worktree/INPUT.txt'],identity)
     if semantic!=body.get('semantic') or sha(artifact)!=body.get('artifact_sha256'):raise Refusal('completion postimage differs')
  after=authority_image(root) if not live else None
  if not live and before!=after:raise Refusal('recovery changed authority bytes')
  view={'STARTED':'RECONCILIATION_REQUIRED','START_INTENT':'START_UNCERTAIN','COMPLETED':'STAGING_COMPLETE'}.get(value['phase'],value['phase'])
  return dict(value,profile=PROFILE,identity=identity,semantic=semantic,view=view,outcome_unknown=value['phase']in('STARTED','START_INTENT'),log_path=str(root/'runs'/binding['cycle']/'SESSION.log'),
              receipts_authenticated=verified,receipt_authentication='HMAC_VERIFIED_WITH_USER_DPAPI_KEY',
              ready=False,replay_permitted=False,start_capability=False,launch_capability=False,live_process_reauthenticated=False,
              authority_hashes=after,authority_unchanged=True if not live else None,key_vault_calls=list(KeyVaultM4.calls),
              scope='READ_ONLY_STAGING_PROJECTION_NO_EXECUTION_AUTHORITY')
 except (StoreRefusal,sqlite3.Error,OSError,NativeRefusal,AdmissionRefusal,ProtocolRefusal,Refusal) as exc:
  return dict(binding=binding,profile=PROFILE,phase='QUARANTINED',view='QUARANTINED',outcome_unknown=True,quarantined=True,identity=None,semantic=None,records=[],queue=[],
              reason={'type':type(exc).__name__,'detail':str(exc)},ready=False,replay_permitted=False,start_capability=False,launch_capability=False,
              receipts_authenticated=[],receipt_authentication='UNPROVEN_QUARANTINED',live_process_reauthenticated=False,
              authority_hashes=None,authority_unchanged=None)

def _bootstrap(reader):
 deadline=time.monotonic()+45;boot=raw_read(reader,min(deadline,time.monotonic()+10))
 if set(boot)!=BOOT_KEYS or type(boot['v'])is not int or boot['v']!=1:raise Refusal('engine bootstrap shape')
 binding=validate_binding(boot['binding'])
 if boot['source_sha']!=binding['source'] or boot['command']not in ('RUN','STATUS','RECOVER'):raise Refusal('engine bootstrap binding/mode')
 if type(boot['session'])is not str or not re.fullmatch('[0-9a-f]{32}',boot['session']):raise Refusal('engine session')
 try:key=base64.b64decode(boot['key_b64'],validate=True)
 except (ValueError,TypeError) as exc:raise Refusal('bootstrap key encoding')from exc
 if len(key)!=32:raise Refusal('bootstrap key length')
 root=fixture_root(boot['root']);source=Path(boot['source_root']).absolute();actual=Path(__file__).parent.absolute()
 if str(source).casefold()!=str(actual).casefold():raise Refusal('actual capsule source path differs')
 from m4_entry import source_manifest
 raw,manifest=source_manifest(actual)
 if sha(raw)!=boot['source_manifest_sha'] or manifest['source_sha256']!=binding['source']:raise Refusal('actual capsule source digest differs')
 info=load_inputs(root,binding)
 if info['policy_sha256']!=boot['policy_sha256'] or info['source_manifest_sha']!=boot['source_manifest_sha']:raise Refusal('input/source evidence differs')
 return boot,root,source,binding,key,deadline

def _runtime(policy):
 facts=validate_runtime();version=list(sys.version_info[:3]);declared=policy['runtime']['python']
 if declared['version']not in (version,'.'.join(map(str,version)),sys.version):raise Refusal('Python version policy differs')
 if os.path.normcase(declared['path'])!=os.path.normcase(sys.executable):raise Refusal('Python path policy differs')
 return RuntimePins(policy['runtime'])

def _refuse_restored_run(root,source,binding,info):
 # A restored capsule may diagnose a consumed fence, never obtain RUN rights.
 with _pins(root,['M4_POLICY.json'])as pins:
  raw=pins.buffers['M4_POLICY.json']
  if sha(raw)!=info['policy_sha256']:raise Refusal('RUN policy hash differs')
  policy=parse(raw)
 if type(policy)is not dict or type(policy.get('source_root'))is not str:raise Refusal('RUN source policy shape')
 if str(Path(policy['source_root']).absolute()).casefold()==str(source).casefold():return
 fixture_root(source) # Only the separately declared report-namespace restoration.
 _read_inputs(root,binding,source) # Revalidate the whole pinned input/policy map.
 view=read_projection(root,binding,live=False) # DPAPI-authenticated historical authority.
 if not view.get('quarantined')and view.get('binding')==binding and view.get('receiver')is not None:
  raise StoreRefusal('RECEIVER_CLAIM_REFUSED_NO_REPLAY')
 raise Refusal('restored RUN forbidden without consumed authenticated receiver')

class Engine:
 def __init__(self,root,source,binding,key,wire,deadline,policy):
  self.root,self.source,self.binding,self.key,self.wire,self.deadline,self.policy=root,source,binding,key,wire,deadline,policy
  self.store=None;self.worker=None;self.native=None;self.worker_wire=None;self.stderr=None
  self.last=None;self.effect=None;self.semantic=None;self.started_receipt=None;self.completed_receipt=None
  self.launch_entries=0;self.created=0;self.native_final=[]
 def barrier(self,stage,**data):
  self.wire.send('EVENT_BARRIER',dict(stage=stage,**data),self.deadline)
  ack=self.wire.receive(self.deadline)
  if ack!={'kind':'ACK_BARRIER','payload':{'stage':stage}}:raise Refusal('barrier ACK differs')
 def open(self):
  # A crashed owner may leave its committed authority in a nonempty WAL.
  # Even a refused RW reopen can checkpoint it on close. Diagnose an already
  # consumed fence through mode=ro first, preserving same-instance S3 bytes.
  # This grants no capability: fresh contenders still race on the atomic claim.
  previous=Store.open_existing(self.root/'transaction.sqlite',self.binding,readonly=True)
  try:
   if previous.inspect()['receiver'] is not None:raise StoreRefusal('RECEIVER_CLAIM_REFUSED_NO_REPLAY')
  finally:previous.close()
  self.store=Store.open_existing(self.root/'transaction.sqlite',self.binding)
  self.store.hook=lambda stage:self.barrier(stage)
  self.store.claim_receiver(self.wire.session)
 def phase(self):return self.store.inspect()['phase']
 def command(self,kind,payload):
  if type(payload)is not dict:raise Refusal('command payload')
  if kind in ('ENQUEUE','START'):
   if payload!={'prompt_id':self.binding['cycle']}:raise Refusal('command prompt binding')
  elif payload!={}:raise Refusal('command fields')
  allowed={None:'ENQUEUE','ENQUEUE':'QUEUE','QUEUE':'START','START':'RELEASE','RELEASE':'POLL','POLL':'FINALIZE','FINALIZE':'CLOSE'}
  if allowed.get(self.last)!=kind:raise Refusal('command order/no replay')
  if kind=='ENQUEUE':
   self.store.enqueue(canonical({'status':'QUEUED','cycle':self.binding['cycle']}),canonical({'items':[self.binding['cycle']]}));self.barrier('queue_lock_released');result={'phase':'QUEUED','queue':[self.binding['cycle']]}
  elif kind=='QUEUE':result={'phase':self.phase(),'queue':self.store.inspect()['queue']}
  elif kind=='START':result=self.start()
  elif kind=='RELEASE':result=self.release()
  elif kind=='POLL':result=self.poll()
  elif kind=='FINALIZE':result=self.finalize()
  elif kind=='CLOSE':result={'phase':self.phase(),'worker_handle_closed':self.native is None,'native_calls':self.native_final}
  else:raise Refusal('unknown command')
  self.last=kind;return result
 def start(self):
  self.barrier('request_received');self.store.intent();self.barrier('launch_enter',command_kind='PINNED_ACTUAL_PS_WORKER')
  policy=self.policy;script=self.source/policy['worker_relative'];run=self.root/'runs'/self.binding['cycle']
  if not run.is_dir():raise Refusal('controller run snapshot directory missing')
  with FilePins(self.root,['runs/'+self.binding['cycle']+'/prompt.snapshot.txt'])as pins:
   if pins.snapshots['runs/'+self.binding['cycle']+'/prompt.snapshot.txt']['sha256']!=sha((self.root/'prompts/prompt.txt').read_bytes()):raise Refusal('controller prompt snapshot differs')
  argv=[policy['runtime']['powershell']['path'],'-NoLogo','-NoProfile','-NonInteractive','-File',str(script),'-StageProfile',PROFILE,'-RunDir',str(run),'-PromptPath',str(run/'prompt.snapshot.txt'),'-WorkDir',str(self.root/'worktree')]
  self.stderr=(run/'worker.stderr.log').open('xb');self.launch_entries+=1
  self.worker=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self.stderr,bufsize=0,cwd=self.root,close_fds=True,creationflags=0x08000000)
  self.native=NativeProcess(self.worker);self.created+=1;identity=self.native.identity()
  return dict(phase='START_INTENT',identity=identity,remote_handle=self.native.handle,launch_entries=self.launch_entries,created_workers=self.created,native_calls=list(self.native.calls))
 def release(self):
  identity=self.native.identity();session=secrets.token_hex(16);self.worker_key=secrets.token_bytes(32)
  boot={'v':1,'key_b64':base64.b64encode(self.worker_key).decode('ascii'),'session':session,'binding':self.binding,'root':str(self.root),'source_root':str(self.source),'identity':identity,'profile':PROFILE,'policy_sha256':sha((self.root/'M4_POLICY.json').read_bytes()),'input_sha256':sha((self.root/'worktree/INPUT.txt').read_bytes()),'source_manifest_sha':sha((self.source/'SOURCE_MANIFEST.json').read_bytes()),'source_sha':self.binding['source']}
  from m4_wire import raw_write
  raw_write(self.worker.stdin,boot,self.deadline)
  self.worker_wire=Wire(self.worker.stdout,self.worker.stdin,self.worker_key,session,'engine_to_worker','worker_to_engine')
  self.started_receipt=sign_receipt(self.key,dict(binding=self.binding,kind='STARTED',identity=identity,broker_session=self.wire.session,observed_monotonic_ms=int(time.monotonic()*1000),profile=PROFILE,executor='POWERSHELL_STAGING_WORKER'))
  self.store.started(self.started_receipt)
  self.worker_wire.send('EFFECT_RELEASE',{'identity':identity},self.deadline)
  return dict(phase='STARTED',identity=identity,receipt=self.started_receipt)
 def poll(self):
  identity=self.native.identity()
  for expected in ('worker_before_effect','worker_after_effect'):
   response=self.worker_wire.receive(self.deadline)
   if response['kind']!='EVENT_BARRIER' or response['payload'].get('stage')!=expected or response['payload'].get('identity')!=identity:raise Refusal('worker barrier shape/identity')
   if expected=='worker_after_effect':
    with FilePins(self.root,['worktree/ANALYSIS.md'])as pins:self.effect=pins.buffers['worktree/ANALYSIS.md']
    expectedbytes=analysis_bytes((self.root/'worktree/INPUT.txt').read_bytes(),self.binding)
    if self.effect!=expectedbytes or response['payload'].get('artifact_sha256')!=sha(self.effect):raise Refusal('worker effect postimage differs')
   self.barrier(expected,**{k:v for k,v in response['payload'].items()if k!='stage'})
   if expected=='worker_before_effect':self.worker_wire.send('ACK_BARRIER',{'stage':expected},self.deadline)
  return dict(phase='STARTED',identity=identity,artifact_sha256=sha(self.effect),effect_observed=True)
 def finalize(self):
  identity=self.native.identity();self.worker_wire.send('ACK_BARRIER',{'stage':'worker_after_effect'},self.deadline)
  response=self.worker_wire.receive(self.deadline)
  if response['kind']!='WORKER_RESULT' or set(response['payload'])!={'semantic'}:raise Refusal('worker result frame')
  code=self.native.wait(max(0,min(5,self.deadline-time.monotonic())))
  if code!=0:raise Refusal('actual worker exit not zero')
  cycle=self.binding['cycle'];names=['worktree/ANALYSIS.md',f'prompts/{cycle}.manifest.json',*(f'runs/{cycle}/{n}'for n in ('semantic-result.json','FINAL.md','exit-code.txt','worker.json','SESSION.log'))]
  with FilePins(self.root,names)as pins:
   artifact=pins.buffers['worktree/ANALYSIS.md'];semantic=parse(pins.buffers[f'runs/{cycle}/semantic-result.json'])
   validate_semantic(semantic,self.binding,artifact,(self.root/'worktree/INPUT.txt').read_bytes(),identity)
   if response['payload']['semantic']!=semantic:raise Refusal('semantic frame/file differs')
   _strict_final(self.root,self.binding,pins.buffers[f'runs/{cycle}/FINAL.md'],parse(pins.buffers[f'prompts/{cycle}.manifest.json']))
   if pins.buffers[f'runs/{cycle}/exit-code.txt'].strip()!=b'0':raise Refusal('strict verdict/exit evidence')
   meta=parse(pins.buffers[f'runs/{cycle}/worker.json'])
   if meta.get('binding')!=self.binding or meta.get('worker_pid')!=identity['pid']:raise Refusal('worker metadata binding')
  self.semantic=semantic
  self.completed_receipt=sign_receipt(self.key,dict(binding=self.binding,kind='COMPLETED',identity=identity,worker_exit=0,exit_code=0,artifact_sha256=sha(artifact),semantic=semantic,profile=PROFILE,executor='POWERSHELL_STAGING_WORKER'))
  self.store.completed(self.completed_receipt);self.native.close();self.native_final=list(self.native.calls);self.native=None
  return dict(phase='COMPLETED',receipt=self.completed_receipt,semantic=semantic,identity=identity,artifact_sha256=sha(artifact),worker_exit=0,worker_handle_closed=True,native_calls=self.native_final)
 def close(self):
  if self.store:self.store.close()
  if self.native is not None:
   if not self.native.api.frozen and self.native.wait(0)is not None:self.native.close();self.native_final=list(self.native.calls);self.native=None
  if self.worker is not None and self.worker.returncode is not None:
   for pipe in (self.worker.stdin,self.worker.stdout):pipe.close()
  if self.stderr:self.stderr.close()

def main():
 p=argparse.ArgumentParser();p.add_argument('--role',required=True,choices=['engine']);p.parse_args()
 reader=getattr(sys.stdin.buffer,'raw',sys.stdin.buffer);writer=getattr(sys.stdout.buffer,'raw',sys.stdout.buffer)
 boot,root,source,binding,key,deadline=_bootstrap(reader);wire=Wire(reader,writer,key,boot['session'],'engine_to_controller','controller_to_engine')
 engine=None;admission=None;runtime=None;runtime_held=False
 try:
  if boot['command']!='RUN':
   # Restored runtime must be the same complete source set; bootstrap checked it.
   result=read_projection(root,binding,live=False);wire.send('READ_ONLY_RESULT',{'view':result},deadline);return 0 if not result.get('quarantined')else 2
  info=load_inputs(root,binding);_refuse_restored_run(root,source,binding,info)
  admission=admit(root,binding,info['expected'],allow_prepared=True);admission.__enter__()
  if str(Path(admission.policy['source_root']).absolute()).casefold()!=str(source).casefold():raise Refusal('RUN source root differs from pinned policy')
  runtime=_runtime(admission.policy);runtime.__enter__();runtime_held=True
  loaded=KeyVaultM4.load(root,binding)
  engine=Engine(root,source,binding,loaded,wire,deadline,admission.policy);engine.open();wire.send('ENGINE_READY',{},deadline)
  while True:
   request=wire.receive(deadline);kind=request['kind'];result=engine.command(kind,request['payload'])
   if kind=='CLOSE':
    # All mutation-capable descendants and Store work have settled before the
    # runtime handles close. Outer custody keeps its own runtime pins to exit.
    engine.close();runtime.verify();runtime_held=False;runtime.__exit__(None,None,None)
    result.update(runtime_pin_proof=runtime.proof,runtime_pin_calls=runtime.calls)
   wire.send('RESULT_'+kind,result,deadline)
   if kind=='CLOSE':return 0
 except (Refusal,StoreRefusal,sqlite3.Error,OSError,NativeRefusal,AdmissionRefusal,ProtocolRefusal,WireRefusal,ValueError)as exc:
  if not wire.frozen:
   try:wire.send('REFUSED',{'reason':type(exc).__name__+':'+str(exc),'ready':False,'replay_permitted':False},min(deadline,time.monotonic()+2))
   except BaseException:pass
  return 2
 finally:
  try:
   if engine:engine.close()
  finally:
   try:
    if admission:admission.__exit__(None,None,None)
   finally:
    if runtime_held:runtime_held=False;runtime.__exit__(None,None,None)
if __name__=='__main__':raise SystemExit(main())
