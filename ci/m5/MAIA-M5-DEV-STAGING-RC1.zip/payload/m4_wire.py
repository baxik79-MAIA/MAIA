"""Bounded M4 inherited-pipe wire. No network, command dispatch or key logging.

A completed read consumes exactly one frame and leaves no background reader.
Timeout poisons the underlying stream; a possibly entered operation is never
retried. Daemon I/O operates on unbuffered FileIO to avoid CPython shutdown locks.
"""
from __future__ import annotations
import base64
import hashlib
import hmac
import json
import math
import queue
import re
import struct
import threading
import time

MAX_FRAME=65536
MAX_SEQUENCE=2**31-1
DIRECTIONS={
 'outer_to_controller':'controller_to_outer','controller_to_outer':'outer_to_controller',
 'controller_to_engine':'engine_to_controller','engine_to_controller':'controller_to_engine',
 'engine_to_worker':'worker_to_engine','worker_to_engine':'engine_to_worker',
}


class Refusal(RuntimeError):pass


def _pairs(items):
 result={}
 for key,value in items:
  if key in result:raise Refusal('WIRE_DUPLICATE_JSON_KEY')
  result[key]=value
 return result


def _constant(value):raise Refusal('WIRE_NONFINITE_JSON')


def _tree(value,depth=0):
 if depth>32:raise Refusal('WIRE_JSON_DEPTH')
 if value is None or type(value) in (bool,str):return
 if type(value) is int:
  if not -(2**63)<=value<2**64:raise Refusal('WIRE_INTEGER_BOUND')
  return
 if type(value) is float:
  if not math.isfinite(value):raise Refusal('WIRE_NONFINITE_JSON')
  return
 if type(value) in (list,dict):
  if len(value)>4096:raise Refusal('WIRE_COLLECTION_BOUND')
  if type(value) is dict and any(type(k) is not str for k in value):raise Refusal('WIRE_JSON_KEY_TYPE')
  for item in (value.values() if type(value)is dict else value):_tree(item,depth+1)
  return
 raise Refusal('WIRE_JSON_TYPE')


def canonical(value):
 _tree(value)
 try:return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode('utf-8')
 except (TypeError,ValueError,UnicodeError) as exc:raise Refusal('WIRE_JSON_ENCODING') from exc


def parse(data):
 if type(data)is not bytes or not 0<len(data)<=MAX_FRAME:raise Refusal('WIRE_FRAME_BOUND')
 try:value=json.loads(data.decode('utf-8'),object_pairs_hook=_pairs,parse_constant=_constant)
 except (UnicodeError,ValueError,TypeError,RecursionError) as exc:raise Refusal('WIRE_JSON_PARSE') from exc
 _tree(value)
 if type(value)is not dict:raise Refusal('WIRE_OBJECT_REQUIRED')
 return value


_registry_lock=threading.Lock()
_registry={}


def _raw(stream):return getattr(stream,'raw',stream)


def _state(stream,direction):
 stream=_raw(stream);key=(id(stream),direction)
 with _registry_lock:
  state=_registry.get(key)
  if state is None:
   # Keep a strong reference so a poisoned stream's id cannot be reused.
   state={'stream':stream,'lock':threading.Lock(),'frozen':False};_registry[key]=state
 return state


def _remaining(deadline):
 if type(deadline)not in (int,float) or not math.isfinite(deadline):raise Refusal('WIRE_DEADLINE_TYPE')
 remaining=deadline-time.monotonic()
 if remaining<=0:raise Refusal('WIRE_DEADLINE_BEFORE_ENTRY')
 return remaining


def _operation(stream,direction,deadline,operation):
 state=_state(stream,direction)
 if state['frozen']:raise Refusal('WIRE_STREAM_FROZEN')
 _remaining(deadline)
 if not state['lock'].acquire(blocking=False):raise Refusal('WIRE_OVERLAPPING_'+direction.upper())
 done=queue.Queue(maxsize=1)
 def run_once():
  try:done.put((True,operation(state['stream'])))
  except BaseException as exc:done.put((False,exc))
 try:
  if state['frozen']:raise Refusal('WIRE_STREAM_FROZEN')
  _remaining(deadline)
  # No buffered stream object is read/written inside this daemon thread.
  threading.Thread(target=run_once,daemon=True).start()
  try:ok,value=done.get(timeout=max(0,deadline-time.monotonic()))
  except queue.Empty:
   state['frozen']=True;raise Refusal('WIRE_'+direction.upper()+'_TIMEOUT_NO_REPLAY')
  if not ok:
   state['frozen']=True
   if isinstance(value,Refusal):raise value
   raise Refusal('WIRE_'+direction.upper()+'_FAILED:'+type(value).__name__) from value
  return value
 except BaseException:
  state['frozen']=True;raise
 finally:state['lock'].release()


def raw_read(reader,deadline):
 def receive(stream):
  def exact(count):
   parts=[];left=count
   while left:
    data=stream.read(left)
    if type(data)is not bytes or not data:raise Refusal('WIRE_EOF_OR_READ_TYPE')
    if len(data)>left:raise Refusal('WIRE_OVERREAD')
    parts.append(data);left-=len(data)
   return b''.join(parts)
  length=struct.unpack('>I',exact(4))[0]
  if not 0<length<=MAX_FRAME:raise Refusal('WIRE_FRAME_LENGTH')
  return parse(exact(length))
 return _operation(reader,'read',deadline,receive)


def raw_write(writer,value,deadline):
 if type(value)is not dict:raise Refusal('WIRE_OBJECT_REQUIRED')
 data=canonical(value)
 if not 0<len(data)<=MAX_FRAME:raise Refusal('WIRE_FRAME_BOUND')
 packet=struct.pack('>I',len(data))+data
 def send(stream):
  view=memoryview(packet)
  while view:
   count=stream.write(view)
   if type(count)is not int or not 0<count<=len(view):raise Refusal('WIRE_SHORT_WRITE')
   view=view[count:]
  stream.flush()
 return _operation(writer,'write',deadline,send)


def _mac(key,session,direction,sequence,body_b64):
 message=(session+'|'+direction+'|'+str(sequence)+'|'+body_b64).encode('utf-8')
 return hmac.new(key,message,hashlib.sha256).hexdigest()


class Wire:
 def __init__(self,reader,writer,key,session,send_direction,receive_direction):
  if type(key)is not bytes or len(key)!=32:raise Refusal('WIRE_KEY_SHAPE')
  if type(session)is not str or not re.fullmatch('[0-9a-f]{32}',session):raise Refusal('WIRE_SESSION_SHAPE')
  if type(send_direction)is not str or type(receive_direction)is not str or DIRECTIONS.get(send_direction)!=receive_direction:raise Refusal('WIRE_DIRECTION_PAIR')
  self.reader,self.writer,self.key,self.session=_raw(reader),_raw(writer),key,session
  self.send_direction,self.receive_direction=send_direction,receive_direction
  self.sent=0;self.received=0;self.frozen=False;self.facts=[]
  self._send_lock=threading.Lock();self._receive_lock=threading.Lock()
  self._usable()

 def _poison(self):
  self.frozen=True
  _state(self.reader,'read')['frozen']=True
  _state(self.writer,'write')['frozen']=True

 def _usable(self):
  if self.frozen or _state(self.reader,'read')['frozen'] or _state(self.writer,'write')['frozen']:
   self._poison();raise Refusal('WIRE_PAIRED_TRANSPORT_FROZEN')

 def send(self,kind,payload,deadline):
  self._usable()
  if type(kind)is not str or not re.fullmatch('[A-Z][A-Z0-9_]{0,79}',kind) or type(payload)is not dict:raise Refusal('WIRE_BODY_SHAPE')
  if self.sent>MAX_SEQUENCE:raise Refusal('WIRE_SEQUENCE_BOUND')
  if not self._send_lock.acquire(blocking=False):raise Refusal('WIRE_OVERLAPPING_SEND')
  try:
   body=canonical({'kind':kind,'payload':payload});encoded=base64.b64encode(body).decode('ascii')
   envelope={'v':1,'session':self.session,'direction':self.send_direction,'seq':self.sent,'body_b64':encoded,
             'mac':_mac(self.key,self.session,self.send_direction,self.sent,encoded)}
   raw_write(self.writer,envelope,deadline)
   self.facts.append({'direction':self.send_direction,'seq':self.sent,'kind':kind,'body_sha256':hashlib.sha256(body).hexdigest(),'state':'RETURNED'})
   self.sent+=1
  except BaseException:
   self._poison();raise
  finally:self._send_lock.release()

 def receive(self,deadline):
  self._usable()
  if not self._receive_lock.acquire(blocking=False):raise Refusal('WIRE_OVERLAPPING_RECEIVE')
  try:
   frame=raw_read(self.reader,deadline)
   if set(frame)!={'v','session','direction','seq','body_b64','mac'}:raise Refusal('WIRE_ENVELOPE_SHAPE')
   if type(frame['v'])is not int or frame['v']!=1 or frame['session']!=self.session or frame['direction']!=self.receive_direction:raise Refusal('WIRE_ENVELOPE_BINDING')
   if type(frame['seq'])is not int or frame['seq']!=self.received or not 0<=frame['seq']<=MAX_SEQUENCE:raise Refusal('WIRE_SEQUENCE')
   encoded=frame['body_b64'];tag=frame['mac']
   if type(encoded)is not str or type(tag)is not str or not re.fullmatch('[0-9a-f]{64}',tag):raise Refusal('WIRE_MAC_SHAPE')
   expected=_mac(self.key,self.session,self.receive_direction,self.received,encoded)
   if not hmac.compare_digest(tag,expected):raise Refusal('WIRE_AUTHENTICATION')
   try:body_bytes=base64.b64decode(encoded,validate=True)
   except (ValueError,TypeError) as exc:raise Refusal('WIRE_BODY_BASE64') from exc
   if base64.b64encode(body_bytes).decode('ascii')!=encoded:raise Refusal('WIRE_BODY_BASE64_CANONICAL')
   body=parse(body_bytes)
   if set(body)!={'kind','payload'} or type(body['kind'])is not str or not re.fullmatch('[A-Z][A-Z0-9_]{0,79}',body['kind']) or type(body['payload'])is not dict:raise Refusal('WIRE_BODY_SHAPE')
   self.facts.append({'direction':self.receive_direction,'seq':self.received,'kind':body['kind'],'body_sha256':hashlib.sha256(body_bytes).hexdigest(),'state':'RETURNED'})
   self.received+=1;return body
  except BaseException:
   self._poison();raise
  finally:self._receive_lock.release()
