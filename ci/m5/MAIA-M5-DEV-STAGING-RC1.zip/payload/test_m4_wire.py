"""Portable wire authentication, exact framing and process-shutdown controls."""
import base64
import hashlib
import hmac
import io
import json
import os
from pathlib import Path
import struct
import subprocess
import sys
import threading
import time
import unittest
import m4_wire as w

KEY=b'k'*32;SESSION='a'*32
D=lambda:time.monotonic()+2

def frame(value):
 raw=json.dumps(value,separators=(',',':'),ensure_ascii=False).encode('utf-8')
 return struct.pack('>I',len(raw))+raw

def envelope(body=None,**changes):
 if body is None:body={'kind':'QUEUE','payload':{}}
 encoded=base64.b64encode(json.dumps(body,ensure_ascii=False).encode()).decode()
 out={'v':1,'session':SESSION,'direction':'engine_to_controller','seq':0,'body_b64':encoded}
 out.update(changes)
 out['mac']=hmac.new(KEY,(out['session']+'|'+out['direction']+'|'+str(out['seq'])+'|'+out['body_b64']).encode(),hashlib.sha256).hexdigest()
 return out

class Controls(unittest.TestCase):
 def receive(self,value):return w.Wire(io.BytesIO(frame(value)),io.BytesIO(),KEY,SESSION,'controller_to_engine','engine_to_controller')

 def test_raw_bootstrap_then_wire_consumes_only_next_frame(self):
  stream=io.BytesIO(frame({'boot':True})+frame(envelope()))
  self.assertEqual(w.raw_read(stream,D()),{'boot':True})
  wire=w.Wire(stream,io.BytesIO(),KEY,SESSION,'controller_to_engine','engine_to_controller')
  self.assertEqual(wire.receive(D()),{'kind':'QUEUE','payload':{}})
  self.assertEqual(wire.received,1)

 def test_ps_json_order_whitespace_utf8_body_is_opaque_authenticated(self):
  value=envelope({'payload':{'text':'zażółć'},'kind':'RESULT_QUEUE'})
  wire=self.receive(value)
  self.assertEqual(wire.receive(D())['payload'],{'text':'zażółć'})
  self.assertNotIn('key',str(wire.facts).lower())

 def test_sequence_zero_and_exact_increments(self):
  stream=io.BytesIO(frame(envelope())+frame(envelope(seq=1)))
  wire=w.Wire(stream,io.BytesIO(),KEY,SESSION,'controller_to_engine','engine_to_controller')
  self.assertEqual(wire.receive(D())['kind'],'QUEUE');self.assertEqual(wire.receive(D())['kind'],'QUEUE')
  out=io.BytesIO();sender=w.Wire(io.BytesIO(),out,KEY,SESSION,'controller_to_engine','engine_to_controller')
  sender.send('ENQUEUE',{'prompt_id':'a'*32},D());sender.send('QUEUE',{},D())
  packets=io.BytesIO(out.getvalue());self.assertEqual(w.raw_read(packets,D())['seq'],0);self.assertEqual(w.raw_read(packets,D())['seq'],1)

 def test_wrong_binding_seq_version_and_mac_freeze_channel(self):
  variants=[envelope(seq=1),envelope(seq=True),envelope(v=True),envelope(v=2),envelope(session='b'*32),envelope(direction='worker_to_engine')]
  tampered=envelope();tampered['body_b64']=base64.b64encode(b'{"kind":"START","payload":{}}').decode();variants.append(tampered)
  for value in variants:
   with self.subTest(value=value):
    wire=self.receive(value)
    with self.assertRaises(w.Refusal):wire.receive(D())
    self.assertTrue(wire.frozen)
    with self.assertRaises(w.Refusal):wire.receive(D())

 def test_duplicate_fields_nonfinite_invalid_utf8_and_size_refused(self):
  for raw in [b'{"kind":1,"kind":2}',b'{"number":NaN}',b'{"text":"\xff"}',b'{"n":18446744073709551616}',b'{}'*40000]:
   with self.subTest(raw=raw[:25]),self.assertRaises(w.Refusal):w.parse(raw)
  for size in [0,65537]:
   with self.assertRaises(w.Refusal):w.raw_read(io.BytesIO(struct.pack('>I',size)),D())
  with self.assertRaises(w.Refusal):w.raw_write(io.BytesIO(),{'s':'x'*65536},D())

 def test_authenticated_invalid_base64_body_and_schema_refused(self):
  for value in [envelope(body_b64='@@@'),envelope({'kind':'START','payload':[]}),envelope({'kind':'start','payload':{}}),envelope({'kind':'START','payload':{},'extra':1})]:
   with self.assertRaises(w.Refusal):self.receive(value).receive(D())

 def test_partial_io_completes_exactly_without_second_frame_read(self):
  class Reader:
   def __init__(self,data):self.data=data;self.calls=0
   def read(self,n):self.calls+=1;part=self.data[:min(n,2)];self.data=self.data[len(part):];return part
  class Writer:
   def __init__(self):self.data=b''
   def write(self,b):n=min(len(b),3);self.data+=bytes(b[:n]);return n
   def flush(self):pass
  output=Writer();w.raw_write(output,{'one':1},D());source=Reader(output.data+frame({'two':2}))
  self.assertEqual(w.raw_read(source,D()),{'one':1});self.assertEqual(source.data,frame({'two':2}))

 def test_timeout_poisons_stream_even_if_new_wire_is_constructed(self):
  event=threading.Event()
  class Reader:
   def read(self,n):event.wait(2);return b''
  stream=Reader()
  try:
   with self.assertRaises(w.Refusal):w.raw_read(stream,time.monotonic()+.01)
   with self.assertRaises(w.Refusal):w.raw_read(stream,D())
   with self.assertRaises(w.Refusal):w.Wire(stream,io.BytesIO(),KEY,SESSION,'controller_to_engine','engine_to_controller')
  finally:event.set()

 def test_authentication_failure_poisons_both_streams_and_replacement_send(self):
  value=envelope();value['mac']='0'*64
  incoming=io.BytesIO(frame(value));outgoing=io.BytesIO()
  wire=w.Wire(incoming,outgoing,KEY,SESSION,'controller_to_engine','engine_to_controller')
  with self.assertRaises(w.Refusal):wire.receive(D())
  self.assertTrue(wire.frozen)
  with self.assertRaises(w.Refusal):wire.send('START',{},D())
  with self.assertRaises(w.Refusal):w.Wire(incoming,outgoing,KEY,SESSION,'controller_to_engine','engine_to_controller')
  with self.assertRaises(w.Refusal):w.Wire(io.BytesIO(),outgoing,KEY,SESSION,'controller_to_engine','engine_to_controller')
  self.assertEqual(outgoing.getvalue(),b'')

 def test_entered_write_failure_has_no_retry(self):
  class Writer:
   def __init__(self):self.calls=0
   def write(self,b):self.calls+=1;raise OSError('closed')
   def flush(self):pass
  out=Writer()
  for _ in range(2):
   with self.assertRaises(w.Refusal):w.raw_write(out,{'cmd':'START'},D())
  self.assertEqual(out.calls,1)

 def test_direction_types_refuse_before_transport(self):
  for wrong in ([],{},None,True):
   with self.assertRaises(w.Refusal):w.Wire(io.BytesIO(),io.BytesIO(),KEY,SESSION,wrong,'engine_to_controller')

 def test_child_raw_stdin_shutdown_is_clean(self):
  root=str(Path(__file__).parent)
  code='import sys,time;sys.path.insert(0,'+repr(root)+');from m4_wire import raw_read,raw_write;v=raw_read(sys.stdin.buffer,time.monotonic()+2);raw_write(sys.stdout.buffer,{"done":True},time.monotonic()+2)'
  child=subprocess.Popen([sys.executable,'-I','-S','-B','-c',code],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  try:
   w.raw_write(child.stdin,{'boot':True},D());self.assertEqual(w.raw_read(child.stdout,D()),{'done':True})
   self.assertEqual(child.wait(timeout=3),0);self.assertEqual(child.stderr.read(),b'')
  finally:
   if child.poll()is None:child.kill();child.wait(timeout=3)
   for pipe in (child.stdin,child.stdout,child.stderr):pipe.close()

if __name__=='__main__':unittest.main()
