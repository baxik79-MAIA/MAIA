"""Pinned inert inputs and semantic contract for named M4 staging only."""
from __future__ import annotations
import base64
from contextlib import AbstractContextManager, nullcontext
import hashlib
import json
import os
from pathlib import Path, PureWindowsPath
import re
import secrets
import stat
from baseline_m3.m3_store import Store,canonical,sha,validate_binding

PROFILE='M4_PROTECTED_PROPOSAL_STAGING'
HEX=re.compile('[0-9a-f]{64}\\Z')
MAX_INPUT=65536
RESIDUES=('transaction.sqlite','transaction.sqlite-wal','transaction.sqlite-shm','owner.key','protocol.json','preimage.json','worktree/ANALYSIS.md')
POLICY_KEYS={'schema','profile','operation','source_sha','source_root','instance_root','runtime','worker_relative','controller_relative','input_relative','artifact_relative','deadline_seconds','max_input_bytes'}
class Refusal(RuntimeError):pass

def _pairs(items):
 out={}
 for k,v in items:
  if k in out:raise Refusal('DUPLICATE_JSON_KEY')
  out[k]=v
 return out

def parse(raw):
 if type(raw) is not bytes or len(raw)>1024*1024:raise Refusal('INPUT_SIZE')
 try:
  value=json.loads(raw.decode('utf-8'),object_pairs_hook=_pairs,parse_constant=lambda _:(_ for _ in ()).throw(Refusal('NONFINITE_JSON')))
  canonical(value);return value
 except (ValueError,UnicodeError,TypeError,RecursionError) as e:raise Refusal('INPUT_JSON') from e

def _root(root):
 if os.name=='nt':
  from m4_native import fixture_root
  return fixture_root(root)
 return Path(root).absolute() # Portable controls only; native suite requires Win64.

def _entry_exists(path):
 try:path.lstat();return True
 except FileNotFoundError:return False

def input_names(cycle):
 validate_binding({'cycle':cycle,'source':'0'*64,'inputs':'0'*64})
 return ('prompts/'+cycle+'.manifest.json','prompts/prompt.txt','M4_POLICY.json','state.before.json','queue.before.json','final.before.txt','worktree-pin.json','worktree/INPUT.txt')

def input_digest(expected):
 if type(expected) is not dict or len(expected)!=8:raise Refusal('INPUT_MAP_SHAPE')
 names=list(expected)
 if any(type(n) is not str for n in names):raise Refusal('INPUT_MAP_PATHS')
 manifests=[n for n in names if re.fullmatch('prompts/[a-f0-9]{32}\\.manifest\\.json',n)]
 if len(manifests)!=1 or set(expected)!=set(input_names(manifests[0][8:-14])):raise Refusal('INPUT_MAP_PATHS')
 if any(type(v) is not str or not HEX.fullmatch(v) for v in expected.values()):raise Refusal('INPUT_MAP_SHA')
 return sha(canonical(expected))

def _runtime(runtime):
 if type(runtime) is not dict or set(runtime)!={'python','powershell'}:raise Refusal('RUNTIME_KEYS')
 for item in runtime.values():
  if type(item) is not dict or set(item)!={'path','sha256','version'}:raise Refusal('RUNTIME_SHAPE')
  if type(item['path']) is not str or not item['path'] or len(item['path'])>1024 or type(item['sha256']) is not str or not HEX.fullmatch(item['sha256']):raise Refusal('RUNTIME_PIN')
  path=PureWindowsPath(item['path'])
  if not path.is_absolute() or path.anchor.casefold()!='c:\\' or any(segment.endswith((' ','.')) or segment=='..' or ':' in segment for segment in path.parts[1:]):raise Refusal('RUNTIME_PATH')
  version=item['version']
  if not (type(version) is str and 0<len(version)<=256 or type(version) is list and 2<=len(version)<=4 and all(type(x) is int and x>=0 for x in version)):raise Refusal('RUNTIME_VERSION')
 return parse(canonical(runtime))

def _source_manifest(source_root,source_sha):
 if type(source_sha) is not str or not HEX.fullmatch(source_sha):raise Refusal('SOURCE_SHA')
 raw=(Path(source_root)/'SOURCE_MANIFEST.json').read_bytes();value=parse(raw)
 if type(value) is not dict or type(value.get('schema')) is not int or value.get('schema')!=1 or value.get('source_sha256')!=source_sha or type(value.get('files')) is not dict:raise Refusal('SOURCE_MANIFEST')
 pins=value['files']
 if not pins or any(type(n) is not str or type(v) is not dict or type(v.get('sha256')) is not str or not HEX.fullmatch(v['sha256']) for n,v in pins.items()):raise Refusal('SOURCE_MANIFEST_FILES')
 if sha(canonical({n:v['sha256'] for n,v in pins.items()}))!=source_sha:raise Refusal('SOURCE_MAP')
 return sha(raw)

def _state():
 result={'schema_version':1,'status':'PIPELINE_COMPLETE','run_health':'OK','transitions':[]}
 for n in ('current_run_id','current_prompt_id','current_stage','expected_milestone','current_worker_pid','current_worktree','current_branch','current_run_dir','started_utc','last_heartbeat_utc','last_log_size','last_log_change_utc','verdict','exit_code','stop_reason','supervisor_pid','current_worker_identity_sha256'):result[n]=None
 return result

def _write_new(path,raw):
 with path.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())

def build_instance(root,source_root,source_sha,runtime):
 """Create inert inputs only. No key, journal, process, queue or effect."""
 root=_root(root);source_root=Path(source_root).absolute();runtime=_runtime(runtime)
 if root==source_root or root.is_relative_to(source_root) or source_root.is_relative_to(root):raise Refusal('SOURCE_INSTANCE_OVERLAP')
 manifest_sha=_source_manifest(source_root,source_sha)
 if _entry_exists(root):raise Refusal('INSTANCE_EXISTS_NO_REPLAY')
 cycle=secrets.token_hex(16);worktree=root/'worktree'
 policy={'schema':1,'profile':PROFILE,'operation':'FIXED_INPUT_ANALYSIS_V1','source_sha':source_sha,'source_root':str(source_root),'instance_root':str(root),'runtime':runtime,'worker_relative':'worker/Run-CodexWorker.ps1','controller_relative':'MAIA-Codex-Supervisor.ps1','input_relative':'worktree/INPUT.txt','artifact_relative':'worktree/ANALYSIS.md','deadline_seconds':45,'max_input_bytes':MAX_INPUT}
 prompt=b'Analyze the pinned local INPUT.txt once; write only the fixed M4 analysis artifact.\n'
 data=b'MAIA M4 staging integration\nReliability and no replay.\n'
 manifest={'schema_version':1,'prompt_id':cycle,'milestone':'M4','stage':'M4STAGING','prompt_file':'prompt.txt','sha256':sha(prompt),'worktree':str(worktree),'branch':'NON_GIT_STAGING','idempotency_policy':'never_replay','allowed_verdicts':['STAGING_COMPLETE'],'transitions':{'STAGING_COMPLETE':'PIPELINE_COMPLETE'},'stage_profile':PROFILE}
 buffers={'prompts/'+cycle+'.manifest.json':canonical(manifest),'prompts/prompt.txt':prompt,'M4_POLICY.json':canonical(policy),'state.before.json':canonical(_state()),'queue.before.json':canonical({'items':[]}),'final.before.txt':b'FIXTURE_APPROVED\n','worktree-pin.json':canonical({'schema':1,'profile':PROFILE,'worktree':str(worktree),'input_relative':'INPUT.txt','input_sha256':sha(data)}),'worktree/INPUT.txt':data}
 expected={n:sha(v) for n,v in buffers.items()};binding=validate_binding({'cycle':cycle,'source':source_sha,'inputs':input_digest(expected)})
 if not root.parent.is_dir():raise Refusal('INSTANCE_PARENT_MISSING')
 if os.name=='nt':
  from m4_native import FilePins
  parent=FilePins(root.parent,[])
 else:parent=nullcontext()
 with parent:
  root.mkdir();
  for n in ('prompts','worktree','runs','locks'):(root/n).mkdir()
  for n,raw in buffers.items():_write_new(root/n,raw)
  _write_new(root/'binding.json',canonical(binding))
  _write_new(root/'INPUT_MANIFEST.json',canonical({'schema':1,'binding':binding,'files':expected,'source_manifest_sha':manifest_sha}))
 return {'binding':binding,'expected':expected,'policy_sha256':expected['M4_POLICY.json'],'source_manifest_sha':manifest_sha}

class _PortablePins(AbstractContextManager):
 """Portable regression controls, never Windows qualification evidence."""
 def __init__(self,root,names):self.root=root;self.names=names;self.buffers={};self.snapshots={};self.handles=[]
 def __enter__(self):
  for p in (self.root,*self.root.parents):
   i=p.lstat()
   if not stat.S_ISDIR(i.st_mode) or stat.S_ISLNK(i.st_mode):raise Refusal('PARENT_TYPE')
  try:
   for n in self.names:
    p=self.root/n
    for parent in p.parents:
     if parent==self.root.parent:break
     i=parent.lstat()
     if not stat.S_ISDIR(i.st_mode) or stat.S_ISLNK(i.st_mode):raise Refusal('INPUT_PARENT_TYPE')
    before=p.lstat()
    if not stat.S_ISREG(before.st_mode) or before.st_nlink!=1 or before.st_size>1024*1024:raise Refusal('INPUT_TYPE')
    fd=os.open(p,os.O_RDONLY|getattr(os,'O_NOFOLLOW',0));self.handles.append(fd);a=os.fstat(fd)
    chunks=[];left=1024*1024+1
    while left:
     b=os.read(fd,min(left,65536))
     if not b:break
     chunks.append(b);left-=len(b)
    raw=b''.join(chunks);z=os.fstat(fd)
    if len(raw)>1024*1024 or (a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns)!=(z.st_dev,z.st_ino,z.st_size,z.st_mtime_ns) or a.st_ino!=before.st_ino:raise Refusal('INPUT_CHANGED')
    self.buffers[n]=raw;self.snapshots[n]={'bytes':len(raw),'sha256':sha(raw),'identity':[a.st_dev,a.st_ino,a.st_size]}
   return self
  except BaseException:self.__exit__(None,None,None);raise
 def __exit__(self,*exc):
  for fd in self.handles:os.close(fd)
  self.handles=[]

def _pins(root,names):
 if os.name=='nt':
  from m4_native import FilePins
  return FilePins(root,list(names))
 return _PortablePins(root,list(names))

def load_inputs(root,binding=None):
 root=_root(root)
 with _pins(root,['binding.json','INPUT_MANIFEST.json']) as pins:
  b=validate_binding(parse(pins.buffers['binding.json']));meta=parse(pins.buffers['INPUT_MANIFEST.json'])
  if binding is not None and b!=validate_binding(binding):raise Refusal('BINDING_EVIDENCE_DIFFERS')
  if type(meta) is not dict or set(meta)!={'schema','binding','files','source_manifest_sha'} or type(meta['schema']) is not int or meta['schema']!=1 or meta['binding']!=b:raise Refusal('INPUT_MANIFEST')
  if input_digest(meta['files'])!=b['inputs'] or type(meta['source_manifest_sha']) is not str or not HEX.fullmatch(meta['source_manifest_sha']):raise Refusal('INPUT_MANIFEST_BINDING')
  return {'binding':b,'expected':dict(meta['files']),'policy_sha256':meta['files']['M4_POLICY.json'],'source_manifest_sha':meta['source_manifest_sha']}

def _policy(value,root,binding):
 if type(value) is not dict or set(value)!=POLICY_KEYS:raise Refusal('POLICY_KEYS')
 fixed={'schema':1,'profile':PROFILE,'operation':'FIXED_INPUT_ANALYSIS_V1','source_sha':binding['source'],'instance_root':str(root),'worker_relative':'worker/Run-CodexWorker.ps1','controller_relative':'MAIA-Codex-Supervisor.ps1','input_relative':'worktree/INPUT.txt','artifact_relative':'worktree/ANALYSIS.md','deadline_seconds':45,'max_input_bytes':MAX_INPUT}
 if any(value.get(k)!=v or type(value.get(k)) is not type(v) for k,v in fixed.items()):raise Refusal('POLICY_VALUE')
 _runtime(value['runtime']);source=Path(value['source_root']).absolute()
 if source==root or root.is_relative_to(source) or source.is_relative_to(root):raise Refusal('SOURCE_INSTANCE_OVERLAP')
 if _source_manifest(source,binding['source']) is None:raise Refusal('SOURCE_MANIFEST')
 return value

class Admission(AbstractContextManager):
 def __init__(self,root,binding,expected,allow_prepared=False):
  self.root=_root(root);self.binding=validate_binding(binding);self.expected=dict(expected);self.allow_prepared=allow_prepared;self.pins=None
  if type(allow_prepared) is not bool or input_digest(expected)!=self.binding['inputs'] or set(expected)!=set(input_names(self.binding['cycle'])):raise Refusal('INPUT_DIGEST')
 def _residue(self):
  for n in RESIDUES:
   if not _entry_exists(self.root/n):continue
   if self.allow_prepared and n in ('transaction.sqlite','transaction.sqlite-wal','transaction.sqlite-shm','owner.key'):
    info=(self.root/n).lstat()
    if not stat.S_ISREG(info.st_mode) or info.st_nlink!=1 or getattr(info,'st_file_attributes',0)&0x400:raise Refusal('PREPARED_PROTOCOL_TYPE:'+n)
    continue
   if self.allow_prepared and n=='worktree/ANALYSIS.md':
    info=(self.root/n).lstat()
    if not stat.S_ISREG(info.st_mode) or info.st_nlink!=1 or getattr(info,'st_file_attributes',0)&0x400:raise Refusal('PREPARED_EFFECT_TYPE')
    store=Store.open_existing(self.root/'transaction.sqlite',self.binding,readonly=True)
    try:consumed=store.inspect()['receiver'] is not None
    finally:store.close()
    if consumed:continue
   raise Refusal('PROTOCOL_RESIDUE:'+n)
 def __enter__(self):
  self._residue();names=input_names(self.binding['cycle']);self.pins=_pins(self.root,names)
  try:
   self.pins.__enter__();self.buffers=self.pins.buffers;self.snapshots=self.pins.snapshots
   if any(self.snapshots[n]['sha256']!=self.expected[n] for n in names):raise Refusal('INPUT_HASH')
   self._residue();self.policy=_policy(parse(self.buffers['M4_POLICY.json']),self.root,self.binding)
   self.manifest=parse(self.buffers[names[0]]);m=self.manifest
   required={'schema_version':1,'prompt_id':self.binding['cycle'],'milestone':'M4','stage':'M4STAGING','prompt_file':'prompt.txt','sha256':sha(self.buffers['prompts/prompt.txt']),'worktree':str(self.root/'worktree'),'branch':'NON_GIT_STAGING','idempotency_policy':'never_replay','allowed_verdicts':['STAGING_COMPLETE'],'transitions':{'STAGING_COMPLETE':'PIPELINE_COMPLETE'},'stage_profile':PROFILE}
   if type(m) is not dict or set(m)!=set(required) or canonical(m)!=canonical(required):raise Refusal('MANIFEST_BINDING')
   if canonical(parse(self.buffers['state.before.json']))!=canonical(_state()) or parse(self.buffers['queue.before.json'])!={'items':[]}:raise Refusal('PREIMAGE_TRANSITIONED')
   w=parse(self.buffers['worktree-pin.json'])
   if canonical(w)!=canonical({'schema':1,'profile':PROFILE,'worktree':str(self.root/'worktree'),'input_relative':'INPUT.txt','input_sha256':sha(self.buffers['worktree/INPUT.txt'])}):raise Refusal('WORKTREE_BINDING')
   if self.buffers['final.before.txt']!=b'FIXTURE_APPROVED\n' or not 0<len(self.buffers['prompts/prompt.txt'])<=MAX_INPUT or len(self.buffers['worktree/INPUT.txt'])>MAX_INPUT:raise Refusal('INPUT_BOUND_OR_VERDICT')
   self.check={'ready':False,'staging_admissible':True,'profile':PROFILE,'production_image_gate':'SECTION_BINDING_UNPROVEN','replay_permitted':False,'binding':self.binding}
   return self
  except BaseException:
   if self.pins:self.pins.__exit__(None,None,None);self.pins=None
   raise
 def __exit__(self,*exc):
  if self.pins:self.pins.__exit__(*exc);self.pins=None

def admit(root,binding,expected,allow_prepared=False):return Admission(root,binding,expected,allow_prepared)

def prepare_instance(root,binding,expected):
 from m4_native import KeyVaultM4
 with admit(root,binding,expected) as admission:
  key=KeyVaultM4.seal(root,binding)
  store=Store.create(Path(root)/'transaction.sqlite',binding,admission.buffers['state.before.json'],admission.buffers['queue.before.json'])
  store.close()
  return {'admission':{'check':admission.check,'inputs':admission.snapshots,'key_vault_calls':list(KeyVaultM4.calls),'input_pin_calls':getattr(admission.pins,'calls',[])},'key_b64':base64.b64encode(key).decode('ascii')}

def analysis_bytes(input_bytes,binding):
 validate_binding(binding)
 if type(input_bytes) is not bytes or len(input_bytes)>MAX_INPUT:raise Refusal('ANALYSIS_INPUT_BOUND')
 return ('# MAIA M4 analysis\ncycle: '+binding['cycle']+'\ninput_sha256: '+sha(input_bytes)+'\nbytes: '+str(len(input_bytes))+'\nnewline_count: '+str(input_bytes.count(b'\n'))+'\n').encode('utf-8')

def validate_semantic(result,binding,artifactbytes,inputbytes,identity):
 binding=validate_binding(binding)
 expected={'schema':1,'binding':binding,'profile':PROFILE,'status':'SUCCESS','is_error':False,'verdict':'STAGING_COMPLETE','artifact':'worktree/ANALYSIS.md','artifact_sha256':sha(artifactbytes),'input_sha256':sha(inputbytes),'identity':identity}
 if type(result) is not dict or set(result)!=set(expected) or any(type(result[k]) is not type(v) or result[k]!=v for k,v in expected.items()):raise Refusal('SEMANTIC_RESULT')
 if type(identity) is not dict or set(identity)!={'pid','birth'} or any(type(v) is not int or v<=0 for v in identity.values()):raise Refusal('SEMANTIC_IDENTITY')
 if artifactbytes!=analysis_bytes(inputbytes,binding):raise Refusal('ANALYSIS_POSTIMAGE')
 return dict(result)
