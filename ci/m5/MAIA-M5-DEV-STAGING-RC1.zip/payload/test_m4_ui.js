// Execute the actual copied app.js in a minimal DOM, including its real poll.
// This checks UI decisions; it does not claim browser layout qualification.
'use strict';
const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const elements=new Map(),timers=[];
class Element{
 constructor(tag){this.tagName=tag;this.children=[];this.dataset={};this.textContent='';}
 set id(value){this._id=value;elements.set(value,this);}get id(){return this._id;}
 append(...values){this.children.push(...values);}replaceChildren(...values){this.children=values;}
}
const body=new Element('body');
let response={stage:{schema:1,phase:'STARTED',view:'RECONCILIATION_REQUIRED',active:false,
 custody:'NO_CUSTODY',quarantined:false,start_capability:false,replay_permitted:false}};
const document={body,createElement:tag=>new Element(tag),getElementById:id=>elements.get(id),
 querySelector:selector=>selector.includes('maia-stage')?{content:'readonly'}:{content:'test-token'}};
const context={document,console,Date,Number,String,JSON,Object,Array,Map,Set,RegExp,Error,
 setInterval:callback=>timers.push(callback),setTimeout:()=>{},
 fetch:async()=>({ok:true,json:async()=>response})};
vm.createContext(context);
vm.runInContext(fs.readFileSync(path.join(__dirname,'ui/app.js'),'utf8'),context);
setImmediate(()=>{
 assert.equal(body.children[0].id,'m4-stage-card');
 assert.equal(elements.get('m4-stage-card').dataset.active,'false');
 assert.equal(elements.get('m4-status').textContent,'RECONCILIATION_REQUIRED');
 const base={schema:1,phase:'STARTED',view:'ACTIVE',active:true,custody:'RETAINED_HANDLE_CURRENT',
 quarantined:false,start_capability:false,replay_permitted:false,observed_utc:new Date().toISOString()};
 const render=value=>{context.testData={stage:value};vm.runInContext('render(testData)',context);};
 render(base);assert.equal(elements.get('m4-stage-card').dataset.active,'true');
 for(const change of [{custody:'NO_CUSTODY'},{observed_utc:new Date(Date.now()-6000).toISOString()},
                      {phase:'COMPLETED'},{active:false},{quarantined:true}]){
  render({...base,...change});assert.equal(elements.get('m4-stage-card').dataset.active,'false');
  assert.notEqual(elements.get('m4-status').textContent,'ACTIVE');
 }
 render({...base,start_capability:true});
 assert.equal(elements.get('m4-stage-card').dataset.active,'false');
 assert.match(elements.get('m4-status').textContent,/NIEPOTWIERDZONE/);
 // The numeric authority field stays a JSON Number on the wire. JSON.parse
 // rounds FILETIME, so the view must use only its separate exact decimal text.
 const wire='{"identity":{"pid":12345,"birth":134386123456789123},"identity_display":{"pid":"12345","birth":"134386123456789123"},"semantic":{"status":"SUCCESS","is_error":false,"verdict":"STAGING_COMPLETE","artifact":"worktree/ANALYSIS.md","artifact_sha256":"dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd","identity":{"pid":12345,"birth":134386123456789123}}}';
 const parsed=JSON.parse(wire);
 assert.equal(typeof parsed.identity.birth,'number');
 assert.notEqual(String(parsed.identity.birth),'134386123456789123');
 render({...base,...parsed});
 assert.equal(elements.get('m4-identity').textContent,'12345 / 134386123456789123');
 const semanticText=elements.get('m4-semantic').textContent;
 assert.match(semanticText,/Status: SUCCESS.*is_error: false.*Werdykt: STAGING_COMPLETE.*Artefakt: worktree\/ANALYSIS\.md.*SHA256: d{64}/);
 assert(!semanticText.includes(String(parsed.semantic.identity.birth)));
 assert(!semanticText.includes('birth'));
 assert.equal(typeof parsed.semantic.identity.birth,'number');
 for(const bad of [undefined,null,{pid:12345,birth:parsed.identity.birth},
                  {pid:'12345',birth:'0134386123456789123'},
                  {pid:'12345',birth:'134386123456789123x'},
                  {pid:'12345',birth:'18446744073709551616'},
                  {pid:'12345',birth:'134386123456789123',extra:'x'}]){
  render({...base,identity:parsed.identity,identity_display:bad});
  assert.equal(elements.get('m4-identity').textContent,'Niepotwierdzona / brak');
 }
 console.log('PASS actual app.js staging DOM: cold/current/stale/wrong custody/terminal/quarantine/capability/exact FILETIME display');
});
