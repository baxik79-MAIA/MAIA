"""M4 generalized same-buffer source capsule for Python/PS/assets; no image proof."""
import argparse,hashlib,importlib.abc,importlib.util,importlib.machinery,json,os,re,sys,types
from pathlib import Path,PurePosixPath
BASE_ENTRY_SHA='96e65473921c22895af02174f2d6104bbc1cb0ed2d8f04389ae1bf5f1b4cc50b'
MAX_FILE=1024*1024;MAX_TOTAL=16*1024*1024
class Refusal(RuntimeError):pass

def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode('ascii')
def sha(b):return hashlib.sha256(b).hexdigest()
def _pairs(rows):
 d={}
 for k,v in rows:
  if k in d:raise Refusal('source duplicatekey')
  d[k]=v
 return d

def _relative(name):
 if type(name)is not str or not name or '\\'in name or ':'in name or name.startswith('/') or any(s in ('','.','..') or s.endswith((' ','.')) or any(c in '<>"|?*' or ord(c)<32 for c in s) for s in name.split('/')):raise Refusal('source relative name')
 if PurePosixPath(name).suffix.lower() not in ('.py','.ps1','.psm1','.json','.html','.css','.js','.md','.txt','.yaml'):raise Refusal('source extension')
 return name

def _baseline_pinner(root):
 p=Path(root)/'baseline_m3/m3_entry.py';raw=p.read_bytes()
 if sha(raw)!=BASE_ENTRY_SHA:raise Refusal('baseline pinner bytes differ')
 m=types.ModuleType('_m4_frozen_source_pinner');m.__file__=str(p)
 exec(compile(raw,str(p),'exec'),m.__dict__)
 return m._Pins

class _Alias(importlib.abc.Loader):
 def __init__(self,name):self.name=name
 def create_module(self,spec):return __import__('importlib').import_module('baseline_m3.'+self.name)
 def exec_module(self,module):pass

class _Buffers(importlib.abc.MetaPathFinder,importlib.abc.Loader):
 def __init__(self,root,buffers):self.root=root;self.buffers=buffers
 def _name(self,fullname):
  path=fullname.replace('.','/')+'.py'
  if path in self.buffers:return path
  alias='baseline_m3/'+fullname+'.py'
  if '.'not in fullname and alias in self.buffers:return alias
  return None
 def find_spec(self,fullname,path=None,target=None):
  if fullname=='baseline_m3':return importlib.util.spec_from_loader(fullname,self,is_package=True)
  n=self._name(fullname)
  if n and n.startswith('baseline_m3/') and '.'not in fullname:return importlib.util.spec_from_loader(fullname,_Alias(fullname),origin=str(self.root/n))
  if n:return importlib.util.spec_from_loader(fullname,self,origin=str(self.root/n))
  if fullname.startswith('baseline_m3.'):raise Refusal('unlisted baseline module')
  fallback=importlib.machinery.PathFinder.find_spec(fullname,path)
  locations=([fallback.origin]if fallback and fallback.origin not in (None,'built-in','frozen')else [])+list(fallback.submodule_search_locations or [])if fallback else []
  for origin in locations:
   try:Path(origin).absolute().relative_to(self.root)
   except ValueError:continue
   raise Refusal('unlisted package filesystem import')
  return None
 def create_module(self,spec):return None
 def exec_module(self,module):
  if module.__name__=='baseline_m3':module.__path__=[];return
  n=self._name(module.__name__);p=str(self.root/n);module.__file__=p;module.__cached__=None
  exec(compile(self.buffers[n],p,'exec',dont_inherit=True),module.__dict__)

class Capsule:
 def __init__(self,root,manifest_sha,source_sha):self.root=Path(root).absolute();self.manifest_sha=manifest_sha;self.source_sha=source_sha;self.pins=None;self.loader=None
 def __enter__(self):
  for d in (self.manifest_sha,self.source_sha):
   if type(d)is not str or not re.fullmatch('[0-9a-f]{64}',d):raise Refusal('trusted source pin')
  self.pins=_baseline_pinner(self.root)(self.root);self.pins.__enter__()
  try:
   raw=self.pins.read('SOURCE_MANIFEST.json',65536)
   if sha(raw)!=self.manifest_sha:raise Refusal('M4 manifest pin')
   manifest=json.loads(raw.decode('utf-8'),object_pairs_hook=_pairs,parse_constant=lambda x:(_ for _ in ()).throw(Refusal('nonfinite source manifest')))
   if type(manifest)is not dict or set(manifest)!={'schema','source_sha256','files'} or type(manifest['schema'])is not int or manifest['schema']!=1:raise Refusal('manifest schema')
   files=manifest['files']
   if type(files)is not dict or not 1<=len(files)<=64:raise Refusal('source count')
   if 'm4_entry.py'not in files or 'baseline_m3/m3_entry.py'not in files:raise Refusal('required entry sources')
   for n in files:_relative(n)
   actual=set()
   for p in self.root.rglob('*'):
    if p.is_symlink() or getattr(p.lstat(),'st_file_attributes',0)&0x400:raise Refusal('source inventory reparse')
    if p.is_file():
     rel=p.relative_to(self.root).as_posix()
     if rel=='SOURCE_MANIFEST.json' or '__pycache__'in p.parts and p.suffix=='.pyc':continue
     actual.add(rel)
   if actual!=set(files):raise Refusal('complete source inventory differs')
   parents={self.root/str(PurePosixPath(n).parent) for n in files}
   for p in sorted(parents,key=lambda p:len(p.parts)):
    if p!=self.root:self.pins._open(p,True)
   self.buffers={};digests={};total=0
   for n,pin in sorted(files.items()):
    if type(pin)is not dict or set(pin)!={'bytes','sha256'} or type(pin['bytes'])is not int or not 0<=pin['bytes']<=MAX_FILE:raise Refusal('source pin field')
    data=self.pins.read(n,MAX_FILE);total+=len(data)
    if total>MAX_TOTAL or len(data)!=pin['bytes'] or sha(data)!=pin['sha256']:raise Refusal('source bytes differ:'+n)
    self.buffers[n]=data;digests[n]=sha(data)
   if manifest['source_sha256']!=self.source_sha or sha(canonical(digests))!=self.source_sha:raise Refusal('complete source map differs')
   imports={n[:-3].replace('/','.') for n in files if n.endswith('.py')}|{PurePosixPath(n).stem for n in files if n.startswith('baseline_m3/')and n.endswith('.py')}
   if imports.intersection(sys.modules):raise Refusal('package imported before capsule')
   self.loader=_Buffers(self.root,self.buffers);sys.meta_path.insert(0,self.loader)
   return self
  except BaseException:
   self.pins.__exit__(None,None,None);self.pins=None;raise
 def run(self,entry,argv):
  if entry not in self.buffers or not entry.endswith('.py') or entry=='m4_entry.py':raise Refusal('entry not admitted')
  old=sys.argv;module=types.ModuleType('__main__');module.__file__=str(self.root/entry);module.__cached__=None
  sys.argv=[module.__file__,*argv]
  try:exec(compile(self.buffers[entry],module.__file__,'exec',dont_inherit=True),module.__dict__)
  finally:sys.argv=old
 def __exit__(self,*exc):
  if self.loader in sys.meta_path:sys.meta_path.remove(self.loader)
  if self.pins:self.pins.__exit__(*exc);self.pins=None

def source_manifest(source_root):
 root=Path(source_root);raw=(root/'SOURCE_MANIFEST.json').read_bytes();m=json.loads(raw)
 if m.get('schema')!=1 or sha(canonical({n:v['sha256'] for n,v in m['files'].items()}))!=m.get('source_sha256'):raise Refusal('source manifest digest')
 return raw,m

def fixed_python_args(source_root,entry='m4_engine.py',argv=None):
 root=Path(source_root).absolute();raw,m=source_manifest(root);p=root/'m4_entry.py';pin=m['files']['m4_entry.py']['sha256']
 if sha(p.read_bytes())!=pin:raise Refusal('entry bootstrap differs')
 code='\n'.join(['import pathlib,hashlib,sys','p=pathlib.Path('+repr(str(p))+')','b=p.read_bytes()','if hashlib.sha256(b).hexdigest()!='+repr(pin)+': raise RuntimeError("M4 entry source pin differs")','sys.argv=[str(p)]+sys.argv[1:]','exec(compile(b,str(p),"exec"),{"__name__":"__main__","__file__":str(p)})'])
 return [sys.executable,'-I','-S','-B','-c',code,'--manifest-sha',sha(raw),'--source-sha',m['source_sha256'],'--entry',entry,'--',*(argv or ['--role','engine'])]

def main():
 p=argparse.ArgumentParser();p.add_argument('--manifest-sha',required=True);p.add_argument('--source-sha',required=True);p.add_argument('--entry',required=True);p.add_argument('argv',nargs=argparse.REMAINDER);a=p.parse_args()
 with Capsule(Path(__file__).parent,a.manifest_sha,a.source_sha) as cap:cap.run(a.entry,a.argv[1:]if a.argv[:1]==['--']else a.argv)
if __name__=='__main__':main()
