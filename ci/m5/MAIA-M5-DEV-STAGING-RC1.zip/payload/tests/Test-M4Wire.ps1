param([Parameter(Mandatory=$true)][string]$SourceRoot)
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $SourceRoot 'lib\Supervisor.Core.psm1') -Force -DisableNameChecking
Import-Module (Join-Path $SourceRoot 'lib\M4.Staging.psm1') -Force -DisableNameChecking
$passed = New-Object Collections.Generic.List[string]
function Assert-Test([bool]$Condition,[string]$Name) { if (-not $Condition) { throw ('TEST_FAILED:'+ $Name) }; $passed.Add($Name) }
function Assert-Refuses([scriptblock]$Call,[string]$Name) {
    $refused = $false
    try { [void](& $Call) } catch { $refused = $true }
    Assert-Test $refused $Name
}
$key = [byte[]](0..31)
$boot = [pscustomobject]@{v=1;session=('a'*32);key_b64=[Convert]::ToBase64String($key)}
$deadline = [DateTime]::UtcNow.AddSeconds(10)
$memory = New-Object IO.MemoryStream
$writer = New-M4Channel $memory $memory $boot 'outer_to_controller' 'controller_to_outer' $deadline
$body = 'eyJraW5kIjoiUElORyIsInBheWxvYWQiOnt9fQ=='
Assert-Test ((Get-M4Mac $writer 'outer_to_controller' 0 $body) -ceq 'e3c22715820984ba5fca05af099354468cbd27c7ca206473b6e21a7ab16d58cb') 'independent_hmac_vector'
Send-M4 $writer 'PING' @{count=7;is_error=$false}
$memory.Position=0
$reader = New-M4Channel $memory $memory $boot 'controller_to_outer' 'outer_to_controller' $deadline
$r = Receive-M4 $reader
Assert-Test ([string]$r.kind -ceq 'PING' -and $r.payload.count -eq 7 -and $r.payload.is_error -is [bool] -and -not $r.payload.is_error) 'binary_roundtrip_typed_boolean'
Assert-Test ($writer.tx -eq 1 -and $reader.rx -eq 1) 'sequence_advances_once'
$memory.Dispose()
Assert-Refuses { ConvertFrom-M4Json '{"a":1,"a":2}' } 'duplicate_key_refused'
Assert-Refuses { ConvertFrom-M4Json '{"a":1,"\u0061":2}' } 'escaped_duplicate_refused'
Assert-Refuses { ConvertFrom-M4Json '{"v":NaN}' } 'nan_refused'
Assert-Refuses { ConvertFrom-M4Json '{"v":1e999}' } 'infinity_refused'
Assert-Refuses { ConvertFrom-M4Json '{"v":1}true' } 'trailing_json_refused'
$diagnostic = ConvertFrom-M4Json "{`r`n`"v`":1,`r`n`"nested`":{`"ok`":true}}`r`n"
Assert-Test ($diagnostic.v -eq 1 -and $diagnostic.nested.ok -is [bool]) 'crlf_json_valid'
$memory = New-Object IO.MemoryStream
Write-M4Raw $memory @{v=1;session=$boot.session;direction='outer_to_controller';seq=0;body_b64=$body;mac=('0'*64)} $deadline
$memory.Position=0
$reader = New-M4Channel $memory $memory $boot 'controller_to_outer' 'outer_to_controller' $deadline
Assert-Refuses { Receive-M4 $reader } 'bad_mac_refused'
Assert-Test $reader.failed 'bad_mac_poisons_channel'
Assert-Refuses { Send-M4 $reader 'NO_RETRY' @{} } 'poisoned_send_refused'
$memory.Dispose()
$memory = New-Object IO.MemoryStream
Write-M4Raw $memory @{v=1;session=$boot.session;direction='outer_to_controller';seq=1;body_b64=$body;mac=(Get-M4Mac $writer 'outer_to_controller' 1 $body)} $deadline
$memory.Position=0
$reader = New-M4Channel $memory $memory $boot 'controller_to_outer' 'outer_to_controller' $deadline
Assert-Refuses { Receive-M4 $reader } 'wrong_sequence_refused'
$memory.Dispose()
$memory = New-Object IO.MemoryStream
$memory.Write([byte[]]@(0,1,0,1),0,4); $memory.Position=0
Assert-Refuses { Read-M4Raw $memory $deadline } 'oversize_before_body_read'
$memory.Dispose()
Assert-Test ((Get-M4RefusalReason ([Exception]::new('raw key must never leak'))) -ceq 'M4_LOCAL_ERROR:Exception') 'untyped_error_redacted'
$diagnosticTask = New-Object 'Threading.Tasks.TaskCompletionSource[string]'
$diagnosticTask.SetResult("Traceback (most recent call last):`nRefusal: private_bootstrap_key_must_not_be_saved`nsecret_payload_line")
$diagnostic = Get-M4EngineDiagnostic $diagnosticTask.Task @{pid=1;birth=2} 2 $deadline
$diagnosticJson = $diagnostic | ConvertTo-Json -Depth 8 -Compress
Assert-Test ($diagnostic.read_completed -and $diagnostic.observed_exit -eq 2 -and $diagnosticJson -cnotmatch 'private_bootstrap_key|secret_payload') 'engine_stderr_private_payload_redacted'
Assert-Test ($diagnostic.lines[0] -ceq 'TRACEBACK' -and $diagnostic.lines[1] -ceq 'Refusal: [REDACTED]' -and $diagnosticJson.Length -lt 4096) 'engine_stderr_bounded_categories'
$qualifiedFacts = [pscustomobject]@{input_code_page=852;output_code_page=852;input_preamble_hex='';output_preamble_hex=''}
Assert-Test ($null -eq (Assert-M4ConsoleFacts $qualifiedFacts)) 'console_qualified_typed_facts'
$denied = 0
foreach ($bad in @(
    [pscustomobject]@{input_code_page=65001;output_code_page=852;input_preamble_hex='';output_preamble_hex=''},
    [pscustomobject]@{input_code_page=852;output_code_page=852;input_preamble_hex='EFBBBF';output_preamble_hex=''},
    [pscustomobject]@{input_code_page='852';output_code_page=852;input_preamble_hex='';output_preamble_hex=''},
    [pscustomobject]@{input_code_page=852;output_code_page=852;input_preamble_hex='';output_preamble_hex=$null}
)) {
    try { Assert-M4ConsoleFacts $bad } catch { if ($_.Exception.Message -ceq 'M4_CONSOLE_ENCODING_UNQUALIFIED') { $denied++ } }
}
Assert-Test ($denied -eq 4) 'console_wrong_page_preamble_and_untyped_refused'
[pscustomobject]@{qualified=$true;count=$passed.Count;passed=@($passed);scope='memory_only_wire_no_worker_no_target_effect'} | ConvertTo-Json -Depth 8 -Compress
