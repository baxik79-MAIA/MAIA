"""Read-only projection for the copied actual MAIA monitor.

The journal establishes history; only a retained native handle establishes a
current worker observation. Neither projection nor HTTP grants a capability.
"""
from __future__ import annotations
from datetime import datetime, timezone
from pathlib import Path
import re
import threading
import time

PROFILE = 'M4_PROTECTED_PROPOSAL_STAGING'
OBSERVATION_MAX_AGE_MS = 5000
_RLOCK_TYPE = type(threading.RLock())
_HEX64 = re.compile('[0-9a-f]{64}')
_RESULT_KEYS = {'schema', 'binding', 'profile', 'status', 'is_error', 'verdict',
                'artifact', 'artifact_sha256', 'input_sha256', 'identity'}


def _utc():
    return datetime.now(timezone.utc).isoformat()


class RetainedObserver:
    """Harness-owned, serialized observation of its real retained worker copy."""
    def __init__(self, binding, native, lock):
        from m4_native import NativeProcess
        from baseline_m3.m3_store import validate_binding
        self.binding = validate_binding(binding)
        if type(native) is not NativeProcess or type(lock) is not _RLOCK_TYPE:
            raise ValueError('actual NativeProcess and shared RLock required')
        self.native, self.lock = native, lock

    def sample(self, binding, identity):
        if binding != self.binding or type(identity) is not dict:
            return {'custody': 'BINDING_OR_IDENTITY_MISMATCH', 'live': False}
        with self.lock:
            try:
                actual = self.native.identity()
                if actual != identity:
                    return {'custody': 'IDENTITY_MISMATCH', 'live': False}
                exit_code = self.native.wait(0)
                return {'custody': 'RETAINED_HANDLE_CURRENT', 'live': exit_code is None,
                        'identity': actual, 'exit_code': exit_code,
                        'observed_monotonic_ms': time.monotonic_ns() // 1_000_000,
                        'observed_utc': _utc()}
            except Exception:
                # A failed/closed native boundary confers no new ownership.
                return {'custody': 'NATIVE_OBSERVATION_UNAVAILABLE', 'live': False}


def _semantic_success(value, binding, identity):
    return (type(value) is dict and set(value) == _RESULT_KEYS
            and type(value['schema']) is int and value['schema'] == 1
            and value['binding'] == binding and value['profile'] == PROFILE
            and value['status'] == 'SUCCESS' and value['is_error'] is False
            and value['verdict'] == 'STAGING_COMPLETE'
            and value['artifact'] == 'worktree/ANALYSIS.md'
            and type(value['artifact_sha256']) is str
            and _HEX64.fullmatch(value['artifact_sha256']) is not None
            and type(value['input_sha256']) is str
            and _HEX64.fullmatch(value['input_sha256']) is not None
            and value['identity'] == identity)


def _identity_display(identity):
    """Presentation only: JSON Numbers cannot preserve Windows FILETIME bits."""
    if (type(identity) is dict and set(identity) == {'pid', 'birth'}
            and type(identity['pid']) is int and 0 < identity['pid'] <= 0xffffffff
            and type(identity['birth']) is int and 0 < identity['birth'] <= 0xffffffffffffffff):
        return {name: str(identity[name]) for name in ('pid', 'birth')}
    return None


def _project(value, observation=None, log_tail=''):
    """Pure mapping of already authenticated facts; never reads JSON state."""
    phase = value.get('phase', 'QUARANTINED')
    binding, identity = value.get('binding'), value.get('identity')
    quarantined = value.get('quarantined', False) is True or phase == 'QUARANTINED'
    records = value.get('records') or []
    verified = value.get('receipts_authenticated') or []
    observation = observation or {'custody': 'NO_CUSTODY', 'live': False}
    stamp = observation.get('observed_monotonic_ms')
    fresh = (type(stamp) is int and 0 <= time.monotonic_ns() // 1_000_000 - stamp <= OBSERVATION_MAX_AGE_MS)
    current = (not quarantined and phase == 'STARTED' and 'STARTED' in verified
               and observation.get('custody') == 'RETAINED_HANDLE_CURRENT'
               and observation.get('live') is True and observation.get('identity') == identity and fresh)
    semantic = value.get('semantic')
    terminal = records[-1].get('payload', {}).get('receipt', {}) if records else {}
    completed = (not quarantined and phase == 'COMPLETED'
                 and 'STARTED' in verified and 'COMPLETED' in verified
                 and _semantic_success(semantic, binding, identity)
                 and terminal.get('kind') == 'COMPLETED'
                 and terminal.get('binding') == binding and terminal.get('identity') == identity
                 and type(terminal.get('worker_exit')) is int and terminal['worker_exit'] == 0
                 and type(terminal.get('exit_code')) is int and terminal['exit_code'] == 0
                 and terminal.get('profile') == PROFILE
                 and terminal.get('executor') == 'POWERSHELL_STAGING_WORKER'
                 and terminal.get('artifact_sha256') == semantic['artifact_sha256']
                 and terminal.get('semantic') == semantic)
    if quarantined:
        view = 'QUARANTINED'
    elif completed:
        view = 'STAGING_COMPLETE'
    elif phase == 'COMPLETED':
        view = 'RESULT_UNCONFIRMED'
    elif current:
        view = 'ACTIVE'
    elif phase == 'STARTED':
        view = 'RECONCILIATION_REQUIRED'
    elif phase == 'START_INTENT':
        view = 'START_UNCERTAIN'
    else:
        view = phase
    return {'schema': 1, 'profile': PROFILE, 'binding': binding, 'phase': phase,
            'view': view, 'active': current, 'quarantined': quarantined,
            'executor': 'PINNED_ACTUAL_PS_WORKER_STAGING_BRANCH', 'identity': identity,
            'identity_display': _identity_display(identity),
            'custody': observation.get('custody', 'NO_CUSTODY'),
            'observed_utc': observation.get('observed_utc'),
            'observation_max_age_ms': OBSERVATION_MAX_AGE_MS,
            'semantic': semantic, 'semantic_success': completed,
            'head_sha': records[-1]['record_sha'] if records else None,
            'receipt_authentication': value.get('receipt_authentication'),
            'authority_unchanged': value.get('authority_unchanged'),
            'authority_hashes': value.get('authority_hashes'), 'log_tail': log_tail,
            'reason': value.get('reason'), 'ready': False, 'replay_permitted': False,
            'start_capability': False, 'launch_capability': False,
            'scope': 'ISOLATED_DEVTOOL_STAGING_NON_CANONICAL_READ_ONLY'}


class StageReadModel:
    def __init__(self, root, source_pin, observer=None):
        if type(source_pin) is not str or not _HEX64.fullmatch(source_pin):
            raise ValueError('exact source SHA256 required')
        if observer is not None and type(observer) is not RetainedObserver:
            raise ValueError('only retained native observer accepted')
        self.root, self.source_pin, self.observer = Path(root), source_pin, observer

    def snapshot(self):
        from m4_engine import read_projection
        value = read_projection(self.root, self.source_pin, live=self.observer is not None)
        observation = None
        if self.observer is not None and value.get('identity') is not None:
            observation = self.observer.sample(value.get('binding'), value['identity'])
        log_tail = ''
        if not value.get('quarantined') and value.get('identity') is not None:
            # Optional evidence, fixed under the admitted root; never liveness.
            from m4_native import FilePins, Refusal
            cycle = (value.get('binding') or {}).get('cycle', '')
            if type(cycle) is str and re.fullmatch('[0-9a-f]{32}', cycle):
                name = 'runs/' + cycle + '/SESSION.log'
                try:
                    with FilePins(self.root, [name], max_bytes=65536) as pins:
                        log_tail = pins.buffers[name][-4096:].decode('utf-8-sig', errors='replace')
                except (OSError, Refusal):
                    log_tail = '[log unavailable or currently locked]'
        stage = _project(value, observation, log_tail)
        return {'server_time_utc': _utc(), 'source_available': not stage['quarantined'],
                'stage': stage, 'state': {'status': stage['view']}}
