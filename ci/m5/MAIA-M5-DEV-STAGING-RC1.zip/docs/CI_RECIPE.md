# Fresh artifact validation recipe

Use the exact built RC ZIP and a separately pinned trusted copy of `m5_rc.py`. Run the same preflight/stage/validate/return sequence on a fresh Linux directory and the fixed Windows M5 staging namespace. Record archive/helper/runtime SHA-256, command, actual process exit and raw stdout/stderr. Never infer hosted CI from local success.

The validation command runs these existing source-listed controls from the unpacked candidate:

- M5 packaging negative controls in `tools/test_m5_rc.py`.
- M3 portable controls under `payload/baseline_m3`.
- M4 portable controls under `payload`.
- Actual source5 `payload/test_m4_ui.js` with the fixed Node executable, when supplied.

No `m3_suite.py`, `run_native_matrix.py` or `m4_qualification.py` effect batch is invoked. M4's one consumed native qualification remains evidence of the same unchanged source; its transaction identities are never reused for a new run.

On Windows add a separately pinned finite source-byte/runtime check and the existing `tests/Test-M4Wire.ps1` in its documented memory-only mode. Capture actual code page/runtime identity and zero effect-worker/store-claim counts. Use PowerShell's existing policy and fixed runtime; do not disable protections or silently change native argument transport.

The repository's existing `ci.yml` may cover Rust/Core/spec tests rather than this new RC archive. Read its actual current contents and identify an actual job/artifact before asserting coverage. Adding a workflow, running a hosted job or publishing an artifact is separate from writing this recipe. If no actual CI job ran for this exact RC, record `remote_ci_job_observed:false` and keep that gate open.
