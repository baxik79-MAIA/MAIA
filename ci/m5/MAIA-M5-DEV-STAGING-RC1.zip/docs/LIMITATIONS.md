# Exact RC scope and limitations

Profile: UNSIGNED_DEV_STAGING_RC. Internal candidate validation/copy only; no production update or distribution approval.

| Area | Established by this package | Outside this package |
| --- | --- | --- |
| Source identity | Exact accepted M4 source5, original 43-file manifest and publication receipt binding | New product semantics or a changed M4 source |
| Installation | Fresh owned staging copy, verified archive snapshot, absent preimage, exact file readback | Installed Supervisor replacement, ACL/profile/security changes |
| Migration | Explicit refusal of existing-store/schema/product migration | Schema upgrades, SQLite migration, credential-reference remap |
| Return | Retire unchanged owned candidate, preserve bytes/backup and restore candidate-path absence | Production rollback/recovery authority |
| Validation | Actual recorded fresh-artifact controls on the platforms that ran them | Inferred Windows or hosted CI PASS; re-running historical native effects |
| Native M4 evidence | Previously qualified native results linked by exact unchanged source identity | A new M4 native run, executed-image/section proof or power-loss proof |
| Signing | Explicitly unsigned, hashes bind exact bytes | Trusted release signature, signer/trust changes, DEPLOYMENT_LOCKED artifact |
| Execution | No capability/start/Apply created by packaging or copy | General Git/Codex execution, production Begin/Apply |

All global native_image_chain_proven, native_run_ready, apply_permitted and durability_proven flags remain false. A local CI-compatible command is not evidence that a hosted CI job executed. A controlled DOM test is not a browser screenshot. New artifact validation does not turn source hashes into executed-image proof.

Helpers assume a cooperative same-user development workspace. Static symlink/reparse/hardlink, path, file-set and content checks do not claim protection against a hostile administrator racing filesystem operations. New helpers are reviewable development tooling, not a security principal, release signer, authoritative journal or production updater.

Do not close full MAIA 1.0 or broaden M5 acceptance from this package. Record the exact internal RC outcome, actual test environments, open CI/signing/deployment gates and independent review scope. M6 GO/NO GO remains a separate decision.
