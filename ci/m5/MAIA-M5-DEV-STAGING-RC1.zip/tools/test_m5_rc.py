"""Additional packaging controls using temporary copies and synthetic M4 receipts."""
import hashlib,io,json,os,stat,sys,tempfile,unittest,zipfile
from pathlib import Path
from unittest import mock
import m5_rc as rc

class RCControls(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.tmp=tempfile.TemporaryDirectory(prefix='m5-helper-controls-');cls.base=Path(cls.tmp.name)
  # Fixture receipt exercises parsing only. It is never an actual M4/M5 acceptance.
  pub={'status':'M4_SCOPED_QUALIFICATION_PUBLISHED','source_sha256':rc.SOURCE_SHA,'source_verified':True,'originals_read_back':True,'production_unchanged':True,'milestone_m4_accepted':True,'acceptance_scope':'ISOLATED_COPIED_PS_CONTROLLER_WORKER_AND_MONITOR_UI_STAGING_ONLY','batch_result_sha256':rc.M4_BATCH_SHA,'raw_export_sha256':rc.M4_EXPORT_SHA,'synthetic_unit_fixture':True,**{k:False for k in rc.FLAGS}}
  cls.pub=cls.base/'M4_SYNTHETIC_UNIT_RECEIPT.json';cls.pub.write_bytes(rc.canon(pub))
  # The immutable source is only read; no source module is imported or executed.
  configured=os.environ.get('M5_TEST_SOURCE')
  nearby=Path(__file__).absolute().parent.parent
  cls.source=Path(configured)if configured else nearby/'payload' if (nearby/'payload/SOURCE_MANIFEST.json').is_file()else nearby/'m4_run/frozen_review5'
  cls.archive=cls.base/'UNIT_FIXTURE_ONLY.zip';rc.build(cls.source,cls.pub,cls.archive,Path(__file__).parent)
  cls.raw=cls.archive.read_bytes()
 @classmethod
 def tearDownClass(cls):cls.tmp.cleanup()
 def setUp(self):
  # Temporary unit fixtures test copy semantics, not the fixed native CLI root.
  if os.name=='nt':
   def portable_fixture_scope(work,report):
    work=Path(work).absolute();report=Path(report).absolute();rc.parents(work);rc.parents(report.parent)
    rc.need(work!=report and not work.is_relative_to(report)and not report.is_relative_to(work),'work/report overlap')
    return work,report
   patch=mock.patch.object(rc,'fixed_scope',side_effect=portable_fixture_scope);patch.start();self.addCleanup(patch.stop)
 def scope(self,suffix=''):
  p=self.base/('case-'+self._testMethodName+suffix);p.mkdir();work=p/'work';work.mkdir();reports=p/'reports';reports.mkdir();return work,reports/'RUN'
 def repack(self,files):
  b=io.BytesIO()
  with zipfile.ZipFile(b,'w',zipfile.ZIP_DEFLATED)as z:
   for n,v in files.items():z.writestr(n,v)
  return b.getvalue()
 def test_build_is_reproducible_and_preserves_original_source_manifest(self):
  p=self.base/'SECOND_UNIT_FIXTURE.zip';rc.build(self.source,self.pub,p,Path(__file__).parent)
  self.assertEqual(p.read_bytes(),self.raw);files=rc.verify_bytes(self.raw)
  self.assertEqual(hashlib.sha256(files['payload/SOURCE_MANIFEST.json']).hexdigest(),rc.SOURCE_MANIFEST_SHA)
  self.assertEqual(len([n for n in files if n.startswith('payload/')]),44)
 def test_build_requires_qualified_m4_and_never_creates_output_after_refusal(self):
  p=self.base/'UNRUN_RECEIPT.json';p.write_bytes(rc.canon({'status':'UNRUN'}));output=self.base/'MUST_NOT_EXIST.zip'
  with self.assertRaises(rc.Refusal):rc.build(self.source,p,output,Path(__file__).parent)
  self.assertFalse(output.exists())
 def test_path_traversal_and_windows_aliases_refuse(self):
  for n in ('../escape','/escape','C:/escape','x\\y','x/../y','x.','x /y','a:stream','owner.key','state.sqlite-wal','CON','NUL.txt','x/LPT9.md','COM1.log','nonascii-ą.txt'):
   with self.subTest(n=n),self.assertRaises(rc.Refusal):rc.safe(n)
 def test_duplicate_and_case_alias_members_refuse(self):
  for names in (['x','x'],['X','x'],['x','x/y']):
   b=io.BytesIO()
   with zipfile.ZipFile(b,'w')as z:
    for n in names:z.writestr(n,b'x')
   with self.assertRaises(rc.Refusal):rc.verify_bytes(b.getvalue())
 def test_symlink_and_expansion_bound_refuse_before_payload_use(self):
  b=io.BytesIO()
  with zipfile.ZipFile(b,'w')as z:
   x=zipfile.ZipInfo('x');x.create_system=3;x.external_attr=(stat.S_IFLNK|0o777)<<16;z.writestr(x,b'/outside')
  with self.assertRaises(rc.Refusal):rc.verify_bytes(b.getvalue())
  with self.assertRaises(rc.Refusal):rc.verify_bytes(self.repack({'large.txt':b'a'*(rc.MAX_FILE+1)}))
 def test_hash_corruption_and_authority_escalation_refuse(self):
  files=rc.verify_bytes(self.raw);files['docs/LIMITATIONS.md']+=b'changed'
  with self.assertRaises(rc.Refusal):rc.verify_bytes(self.repack(files))
  files=rc.verify_bytes(self.raw);meta=rc.parse(files['RC_METADATA.json']);meta['apply_permitted']=True;files['RC_METADATA.json']=rc.canon(meta)
  manifest=rc.parse(files['RC_MANIFEST.json']);manifest['files']['RC_METADATA.json']={'bytes':len(files['RC_METADATA.json']),'sha256':rc.sha(files['RC_METADATA.json'])};files['RC_MANIFEST.json']=rc.canon(manifest)
  with self.assertRaises(rc.Refusal):rc.verify_bytes(self.repack(files))
 def test_credentials_and_mutable_store_payloads_refuse(self):
  with self.assertRaises(rc.Refusal):rc.scan('docs/leak.txt',b'sk-proj-'+b'A'*40)
  for n in ('owner.key','.env','journal.db','journal.sqlite','journal.sqlite-shm'):
   with self.subTest(n=n),self.assertRaises(rc.Refusal):rc.scan(n,b'x')
 def test_production_or_schema_migration_refuses_without_writing(self):
  work,report=self.scope()
  for mode,store in [('production-update','none'),('fresh-staging-copy','sqlite')]:
   with self.assertRaises(rc.Refusal):rc.preflight(self.archive,work,report,mode,store)
  self.assertFalse(report.exists());self.assertFalse((work/'candidate').exists())
 def test_existing_or_symlink_target_preserves_foreign_bytes(self):
  work,report=self.scope();target=work/'candidate';target.mkdir();f=target/'FOREIGN.txt';f.write_bytes(b'foreign')
  with self.assertRaises(rc.Refusal):rc.stage(self.archive,work,report)
  self.assertEqual(f.read_bytes(),b'foreign');self.assertFalse(report.exists())
  if os.name!='nt':
   other=work/'alias';other.symlink_to(target,target_is_directory=True)
   with self.assertRaises(rc.Refusal):rc.parents(other)
 def test_fresh_copy_backup_and_return_preserve_every_byte(self):
  work,report=self.scope();copy=rc.stage(self.archive,work,report)
  self.assertEqual(copy['status'],'FRESH_STAGING_COPY_VERIFIED');self.assertEqual((report/'RC_BACKUP.zip').read_bytes(),self.raw)
  self.assertFalse(rc.parse((report/'PREIMAGE.json').read_bytes())['target_existed'])
  returned=rc.return_candidate(work,report);self.assertEqual(returned['status'],'OWNED_CANDIDATE_RETIRED_BYTE_PRESERVED')
  self.assertFalse((work/'candidate').exists());self.assertEqual(rc.tree_bytes(work/'retired_candidate'),rc.verify_bytes(self.raw))
  self.assertTrue((report/'RETURN_ATTEMPT.json').is_file())
 def test_return_refuses_changed_candidate_and_preserves_it(self):
  work,report=self.scope();rc.stage(self.archive,work,report);changed=work/'candidate/docs/LIMITATIONS.md';changed.write_bytes(b'foreign revision')
  with self.assertRaises(rc.Refusal):rc.return_candidate(work,report)
  self.assertEqual(changed.read_bytes(),b'foreign revision');self.assertFalse((work/'retired_candidate').exists());self.assertFalse((report/'RETURN_ATTEMPT.json').exists())
 def test_partial_copy_preserves_attempt_backup_and_failure_record(self):
  work,report=self.scope();original=rc.write
  def fail_target(path,raw):
   if path.is_relative_to(work/'candidate'):raise OSError('injected copy interruption')
   return original(path,raw)
  with mock.patch.object(rc,'write',side_effect=fail_target),self.assertRaises(rc.Refusal):rc.stage(self.archive,work,report)
  self.assertTrue((report/'ATTEMPT.json').exists());self.assertEqual((report/'RC_BACKUP.zip').read_bytes(),self.raw)
  self.assertEqual(rc.parse((report/'COPY_RESULT.json').read_bytes())['status'],'COPY_INCOMPLETE_NO_REPLAY')
  with self.assertRaises(rc.Refusal):rc.stage(self.archive,work,report)
 def test_exit_zero_without_exact_zero_skip_suite_summary_is_not_pass(self):
  for text in (b'\nRan 98 tests in 0.1s\n\nOK (skipped=1)\n',b'\nRan 97 tests in 0.1s\n\nOK\n',b'error but exit zero'):
   self.assertFalse(rc.suite_semantics('M4_PURE',0,b'',text)['passed'])
  self.assertTrue(rc.suite_semantics('M4_PURE',0,b'',b'\nRan 98 tests in 0.1s\n\nOK\n')['passed'])
  self.assertFalse(rc.suite_semantics('UI_CONTROLLED_DOM',0,b'# tests 1\n# fail 0\n# cancelled 0\n# skipped 1\n',b'')['passed'])
 def test_runtime_identity_uses_actual_ordinary_bytes_and_absolute_path(self):
  with self.assertRaises(rc.Refusal):rc.runtime_record('relative-runtime','python')
  p=self.base/'runtime-fixture.bin';p.write_bytes(b'fixture runtime, not executed')
  if os.name!='nt':self.assertEqual(rc.runtime_record(str(p),'python')['sha256'],hashlib.sha256(p.read_bytes()).hexdigest())
  else:
   with self.assertRaises(rc.Refusal):rc.runtime_record(str(p),'python')
 def test_changed_valid_backup_and_candidate_cannot_inherit_copy_receipt(self):
  work,report=self.scope();copied=rc.stage(self.archive,work,report);files=rc.verify_bytes(self.raw)
  meta=rc.parse(files['RC_METADATA.json']);meta['cooperative_copy_note']='other coherent artifact';files['RC_METADATA.json']=rc.canon(meta)
  manifest=rc.parse(files['RC_MANIFEST.json']);manifest['files']['RC_METADATA.json']={'bytes':len(files['RC_METADATA.json']),'sha256':rc.sha(files['RC_METADATA.json'])};files['RC_MANIFEST.json']=rc.canon(manifest)
  raw=self.repack(files);rc.verify_bytes(raw);self.assertNotEqual(rc.sha(raw),copied['archive_sha256'])
  (report/'RC_BACKUP.zip').write_bytes(raw)
  for n in ('RC_METADATA.json','RC_MANIFEST.json'):(work/'candidate'/n).write_bytes(files[n])
  with mock.patch.object(rc.subprocess,'run')as run,self.assertRaises(rc.Refusal):rc.validate(work,report,str(Path(sys.executable).resolve()))
  run.assert_not_called();self.assertFalse((report/'VALIDATION_ATTEMPT.json').exists())
 def test_foreign_empty_directory_refuses_return_without_moving_it(self):
  work,report=self.scope();rc.stage(self.archive,work,report);foreign=work/'candidate/FOREIGN_EMPTY';foreign.mkdir()
  with self.assertRaises(rc.Refusal):rc.return_candidate(work,report)
  self.assertTrue(foreign.is_dir());self.assertFalse((work/'retired_candidate').exists());self.assertFalse((report/'RETURN_ATTEMPT.json').exists())
 def test_dangling_entry_is_existing_and_freshness_refuses_before_writes(self):
  work,report=self.scope();fake=mock.Mock();fake.lstat.return_value=object();fake.exists.return_value=False;self.assertTrue(rc.entry(fake))
  if os.name!='nt':
   (work/'candidate').symlink_to(work/'missing',target_is_directory=True)
   with self.assertRaises(rc.Refusal):rc.preflight(self.archive,work,report)
   self.assertFalse(report.exists())
   output=self.base/'DANGLING_OUTPUT.zip';output.symlink_to(self.base/'missing.zip')
   with self.assertRaises(rc.Refusal):rc.build(self.source,self.pub,output,Path(__file__).parent)
  else:
   with mock.patch.object(rc,'entry',return_value=True),self.assertRaises(rc.Refusal):rc.preflight(self.archive,work,report)
   self.assertFalse(report.exists())
 def test_backup_failure_retains_attempt_and_terminal_failure_before_target(self):
  work,report=self.scope();original=rc.write
  def fail_backup(path,raw):
   if path.name=='RC_BACKUP.zip':raise OSError('injected backup failure')
   return original(path,raw)
  with mock.patch.object(rc,'write',side_effect=fail_backup),self.assertRaises(rc.Refusal):rc.stage(self.archive,work,report)
  self.assertTrue((report/'ATTEMPT.json').is_file());self.assertFalse((work/'candidate').exists())
  self.assertEqual(rc.parse((report/'COPY_RESULT.json').read_bytes())['status'],'COPY_INCOMPLETE_NO_REPLAY')
 def test_windows_scope_rejects_dotdot_ads_and_nonportable_leaf_before_io(self):
  work='C:/MAIA/worktrees/M5_RC_20261109';base='C:/MAIA/reports/M5_RC_20261109/'
  rc.windows_scope(work,base+'STAGE_01')
  for leaf in ('..','RUN/child','RUN.','RUN ','NUL','run:stream'):
   with self.subTest(leaf=leaf),self.assertRaises(rc.Refusal):rc.windows_scope(work,base+leaf)
  with self.assertRaises(rc.Refusal):rc.windows_scope('C:/MAIA/worktrees/OTHER',base+'STAGE_01')
 def test_crlf_summaries_preserve_exact_counts_and_zero_skip_semantics(self):
  for label,count in [('M5_HELPERS',rc.M5_HELPER_TEST_COUNT),('M3_PURE',64),('M4_PURE',98)]:
   summary=('\r\nRan %d tests in 0.1s\r\n\r\nOK\r\n'%count).encode()
   self.assertTrue(rc.suite_semantics(label,0,b'',summary)['passed'])
   for bad in (summary.replace(b'OK',b'OK (skipped=1)'),summary.replace(b'OK',b'FAILED (errors=1)'),summary.replace(str(count).encode(),str(count+1).encode())):
    self.assertFalse(rc.suite_semantics(label,0,b'',bad)['passed'])
   self.assertFalse(rc.suite_semantics(label,1,b'',summary)['passed'])
  tap=b'# tests 1\r\n# pass 1\r\n# fail 0\r\n# cancelled 0\r\n# skipped 0\r\n# todo 0\r\n'
  self.assertTrue(rc.suite_semantics('UI_CONTROLLED_DOM',0,tap,b'')['passed'])
  self.assertFalse(rc.suite_semantics('UI_CONTROLLED_DOM',0,tap.replace(b'# skipped 0',b'# skipped 1'),b'')['passed'])
 def test_publication_requires_exact_qualified_native_batch_and_raw_export(self):
  pub=rc.parse(self.pub.read_bytes());rc.accepted_m4(rc.canon(pub))
  for field in ('batch_result_sha256','raw_export_sha256'):
   for mode in ('missing','wrong'):
    altered=dict(pub)
    if mode=='missing':del altered[field]
    else:altered[field]='0'*64
    with self.subTest(field=field,mode=mode),self.assertRaises(rc.Refusal):rc.accepted_m4(rc.canon(altered))
 def test_expected_publication_bytes_bind_the_prechecked_receipt(self):
  original=self.pub.read_bytes();pub=rc.parse(original);pub['synthetic_unit_fixture_note']='a different valid receipt body';p=self.base/'OTHER_SYNTHETIC_RECEIPT.json';p.write_bytes(rc.canon(pub));archive=self.base/'OTHER_RECEIPT_UNIT_FIXTURE.zip';rc.build(self.source,p,archive,Path(__file__).parent);raw=archive.read_bytes()
  rc.verify_bytes(raw);rc.verify_bytes(raw,expected_m4_publication=p.read_bytes())
  with self.assertRaises(rc.Refusal):rc.verify_bytes(raw,expected_m4_publication=original)
 def test_extra_tools_or_docs_members_refuse_before_discovery(self):
  for extra in ('tools/test_m5_x.py','tools/extra.py','docs/EXTRA.md'):
   files=rc.verify_bytes(self.raw);files[extra]=b'raise RuntimeError("must never execute")\n';manifest=rc.parse(files['RC_MANIFEST.json']);manifest['files'][extra]={'bytes':len(files[extra]),'sha256':rc.sha(files[extra])};files['RC_MANIFEST.json']=rc.canon(manifest)
   with self.subTest(extra=extra),self.assertRaises(rc.Refusal):rc.verify_bytes(self.repack(files))
  files=rc.verify_bytes(self.raw);del files['docs/CI_RECIPE.md'];manifest=rc.parse(files['RC_MANIFEST.json']);del manifest['files']['docs/CI_RECIPE.md'];files['RC_MANIFEST.json']=rc.canon(manifest)
  with self.assertRaises(rc.Refusal):rc.verify_bytes(self.repack(files))

if __name__=='__main__':unittest.main()
